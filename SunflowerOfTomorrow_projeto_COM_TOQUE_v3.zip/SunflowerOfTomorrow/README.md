# Sunflower of Tomorrow — Prólogo + Capítulo I: Um Lugar Para Escapar (protótipo jogável)

Godot **4.3+** · GDScript · 640×360 pixel art (placeholders desenhados por código) · português brasileiro.

**Rodar:** abra `project.godot` na Godot → **F5**. Controles: WASD/setas · **Shift** (correr) · E/Espaço/Enter (interagir e avançar) · Esc (pausa) · gamepad suportado (X corre, A interage).

**O que já existe:** menu principal **reformulado a partir da sua referência** (cidade nevada ao entardecer, logotipo, 5 opções com moldura animada; o antigo fundo com placa de madeira ficou sem uso nos assets) e a sua música **em loop** (`Sunflower_Of_Tomorow.mp3` virou `assets/audio/music/menu_theme.ogg`, emenda sem corte); **o contexto histórico em fragmentos (rádio, jornal de 2008, racionamento), o quarto “Older Brother Core”, a sala com os pais doentes e as conversas com eles**; **Alen Hader com os sprites da sua ficha** e os 6 rostos como retratos nos diálogos; **a casa inteira do Alen, meio destruída e cheia de remendos** (quarto, sala/cozinha com fogão e goteiras, entrada desabada com neve entrando); cenários em pixel art de cidade arruinada sob neve (cidade, jardim) com parallax; **animação do Alen** (idle, andar e correr com aceleração, passos e poeira sincronizados); Marcus e Eleanor como NPCs (variações do estilo do Alen — placeholders); 3 espaços de salvamento; as 6 cenas do prólogo; 86 diálogos com escolhas; som por cena (ambientes e efeitos **placeholder**); pausa (agora com Configurações e confirmação); e fim do prólogo que segue direto para o Capítulo I.

**Capítulo I — Um Lugar Para Escapar (novo):** continua direto do prólogo (manhã seguinte). Declan City explorável em 5 áreas externas e 5 interiores (casa, locadora, padaria, casa abandonada, biblioteca), 3 barricadas militares que bloqueiam de verdade, 206 diálogos (~11 mil palavras), Olivier, o minijogo **Space Travelers** e a volta para casa. **Atalho de teste: F10 no menu principal.** Detalhes, mapa, flags, testes e limitações: `docs/06_capitulo_1_implementacao.md`; roteiro completo: `docs/05_roteiro_capitulo_1.md`.

**Menu principal, Configurações e Pausa (novos):** menu com fundo animado (parallax, nuvens, luzes que piscam, neve), lista com moldura deslizante, tela de configurações completa (modo de janela, resolução, V-Sync, FPS, escala de pixels, efeitos, áudio; salva em arquivo) e pausa com Continuar / Configurações / Voltar ao menu (com confirmação) / Sair. Detalhes, decisões e checklist em `docs/07_menu_configuracoes_pausa.md`. **Escrito sem poder abrir a Godot: teste antes de confiar.**

**Leia:** `docs/01_visao_e_roteiro.md` (visão + todo o texto) · `docs/02_direcao_de_audio.md` · `docs/03_menu_e_guia_visual.md` · `docs/04_implementacao_e_producao.md` (estrutura, sistemas, fases, testes, erros prováveis).

**Atenção:** a arte foi conferida em simulações, e o código foi verificado estaticamente (`python3 tools/verificar_projeto.py`, `verificar_cap1.py` e `verificar_menu.py`) mas **nunca foi aberto na Godot**. Se aparecer erro, copie a mensagem exata (arquivo e linha) e me envie: corrijo em seguida.

**Editar texto:** prólogo → `data/dialogue/prologue_*.json` e `python3 tools/gerar_roteiro.py`; **Capítulo I** → `tools/roteiro_cap1/*.py` e `python3 tools/gerar_dialogos_cap1.py` (gera os JSON e o roteiro).
