extends Node
## Autoload "GameState": flags da história, slots de salvamento (3) e contagem de tempo.

const DemoInfo := preload("res://scripts/core/demo_info.gd")
const SAVE_DIR := "user://saves/"
const SLOT_COUNT := 3
const SAVE_VERSION := 1
const SCENES := {
    "house": "res://scenes/house/house.tscn",
    "town": "res://scenes/town/town.tscn",
    "garden": "res://scenes/garden/garden.tscn",
    # Capítulo I — Declan City
    "centro": "res://scenes/ch1/centro.tscn",
    "praca": "res://scenes/ch1/praca.tscn",
    "humanitaria": "res://scenes/ch1/humanitaria.tscn",
    "biblioteca": "res://scenes/ch1/biblioteca.tscn",
    "locadora": "res://scenes/ch1/locadora.tscn",
    "padaria": "res://scenes/ch1/padaria.tscn",
    "casa_vazia": "res://scenes/ch1/casa_vazia.tscn",
}
const SCENE_LABELS := {
    "house": "Casa", "town": "Cidade", "garden": "Jardim",
    "centro": "Rua das Lojas", "praca": "Praça do Relógio", "humanitaria": "Área humanitária", "biblioteca": "Biblioteca",
    "locadora": "Locadora", "padaria": "Padaria", "casa_vazia": "Casa abandonada",
}
const MENU_SCENE := "res://scenes/main_menu/main_menu.tscn"

var flags: Dictionary = {}
var scene_id: String = "house"
var slot: int = 1
var playtime: float = 0.0
var spawn: String = ""        # de onde o jogador chegou (lido e usado pela fase)
var playing: bool = false
var dirty: bool = false          # há progresso (flags) alterado desde o último salvamento: o menu de pausa pede confirmação


func _process(delta: float) -> void:
    if playing:
        playtime += delta


# ------------------------------------------------------------------ flags
func set_flag(key: String, value: Variant = true) -> void:
    if not flags.has(key) or flags[key] != value:
        flags[key] = value
        dirty = true


func get_flag(key: String, default: Variant = false) -> Variant:
    return flags.get(key, default)


## Incrementa e devolve um contador (ex.: quantas vezes o objeto já foi examinado).
func bump(key: String) -> int:
    var n: int = int(flags.get(key, 0)) + 1
    flags[key] = n
    dirty = true
    return n


# ------------------------------------------------------------------ jogo
func new_game(n: int) -> void:
    flags = {}
    scene_id = "house"
    slot = n
    playtime = 0.0
    spawn = ""
    playing = true
    dirty = false


## Capítulo I começa na manhã seguinte ao prólogo, na casa de Alen. Mantém as flags do prólogo (ex.: planted).
func start_chapter1() -> void:
    for k in flags.keys():
        if str(k).begins_with("c1_") or str(k).begins_with("st_"):
            flags.erase(k)
    flags["ch1_started"] = true
    flags["ch1_done"] = false
    scene_id = "house"
    spawn = "ch1_start"
    playing = true


func is_ch1() -> bool:
    return bool(flags.get("ch1_started", false))


func autosave(id: String) -> void:
    scene_id = id
    save_game()


func save_game() -> bool:
    DirAccess.make_dir_recursive_absolute(SAVE_DIR)
    var data := {
        "version": SAVE_VERSION,
        "game_version": DemoInfo.VERSION,
        "scene": scene_id,
        "flags": flags,
        "playtime": playtime,
        "saved_at": Time.get_unix_time_from_system(),
    }
    var f := FileAccess.open(_path(slot), FileAccess.WRITE)
    if f == null:
        push_warning("GameState: não foi possível salvar (erro %d)" % FileAccess.get_open_error())
        return false
    f.store_string(JSON.stringify(data, "  "))
    dirty = false
    return true


func load_slot(n: int) -> bool:
    var info := slot_info(n)
    if info.is_empty():
        return false
    var fl = info.get("flags", {})
    flags = fl if typeof(fl) == TYPE_DICTIONARY else {}
    scene_id = str(info.get("scene", "house"))
    if scene_id == "bedroom":              # salvamentos antigos (antes da casa inteira)
        scene_id = "house"
    if not SCENES.has(scene_id):
        scene_id = "house"
    playtime = float(info.get("playtime", 0.0))
    slot = n
    spawn = ""
    playing = true
    dirty = false
    if bool(flags.get("prologue_done", false)) and not bool(flags.get("ch1_started", false)):
        start_chapter1()                  # salvamento que terminou o prólogo: continua no Capítulo I
    return true


func delete_slot(n: int) -> void:
    if FileAccess.file_exists(_path(n)):
        DirAccess.remove_absolute(_path(n))


# --------------------------------------------------------------- consultas
func slot_info(n: int) -> Dictionary:
    var p := _path(n)
    if not FileAccess.file_exists(p):
        return {}
    var parsed = JSON.parse_string(FileAccess.get_file_as_string(p))
    if typeof(parsed) != TYPE_DICTIONARY:
        return {}
    return parsed


func has_any_save() -> bool:
    return latest_slot() > 0


## Slot mais recente (0 se não houver nenhum).
func latest_slot() -> int:
    var best := 0
    var best_t := -1.0
    for i in range(1, SLOT_COUNT + 1):
        var info := slot_info(i)
        if not info.is_empty() and float(info.get("saved_at", 0.0)) > best_t:
            best_t = float(info.get("saved_at", 0.0))
            best = i
    return best


func first_free_slot() -> int:
    for i in range(1, SLOT_COUNT + 1):
        if slot_info(i).is_empty():
            return i
    return 0


func oldest_slot() -> int:
    var best := 1
    var best_t := INF
    for i in range(1, SLOT_COUNT + 1):
        var info := slot_info(i)
        if not info.is_empty() and float(info.get("saved_at", 0.0)) < best_t:
            best_t = float(info.get("saved_at", 0.0))
            best = i
    return best


func scene_label(id: String) -> String:
    return str(SCENE_LABELS.get(id, "—"))


func format_playtime(sec: float) -> String:
    var m := int(sec) / 60
    return "%d min" % m if m < 60 else "%dh%02d" % [m / 60, m % 60]


func format_date(ts: float) -> String:
    var bias := int(Time.get_time_zone_from_system().get("bias", 0))
    var d := Time.get_datetime_dict_from_unix_time(int(ts) + bias * 60)
    return "%02d/%02d %02d:%02d" % [d.day, d.month, d.hour, d.minute]


func _path(n: int) -> String:
    return SAVE_DIR + "slot_%d.json" % n
