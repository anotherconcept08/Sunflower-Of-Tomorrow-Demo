extends "res://scripts/world/ch1_level.gd"
## Capítulo I — Locadora "Vídeo Ponto" (interior de loja abandonada). Dono saiu às pressas; pistas sobre a Another Concept.
## Cenário: assets/environments/locadora.png + loc_balcao.png (tools/gerar_cap1.py). Saída pela porta de vidro, à esquerda.

const ENV := "res://assets/environments/"


func _build() -> void:
    surface = "wood"
    follow_player = true
    camera_offset = Vector2(0, 0)
    world_rect = Rect2(0, 0, 800, 360)
    add_bg(ENV + "locadora.png")
    add_block(Rect2(80, 100, 640, 68))
    add_block(Rect2(60, 100, 52, 220))
    add_block(Rect2(688, 100, 80, 240))
    add_block(Rect2(60, 300, 700, 40))
    prop(ENV + "loc_balcao.png", 560.0, 262.0)
    add_block(Rect2(560, 210, 120, 54))
    add_block(Rect2(450, 224, 90, 26))      # expositor de capas
    add_block(Rect2(186, 258, 40, 26))      # caixa de devolução
    add_interactable(Vector2(134, 214), "c1_loc_saida", [], 32.0, _on_exit)
    look(Vector2(190, 190), "c1_loc_neon", ["c1_loc_neon"], 16.0)
    look(Vector2(252, 190), "c1_loc_cartaz_s", ["c1_loc_cartaz_space"], 18.0)
    look(Vector2(302, 190), "c1_loc_cartaz_g", ["c1_loc_cartaz_guitar"], 18.0)
    look(Vector2(348, 190), "c1_loc_tv", ["c1_loc_tv"], 20.0)
    look(Vector2(480, 190), "c1_loc_fitas", ["c1_loc_fitas"], 44.0)
    look(Vector2(206, 294), "c1_loc_devolucao", ["c1_loc_devolucao"], 24.0)
    look(Vector2(570, 276), "c1_loc_ficha", ["c1_loc_ficha"], 18.0)
    look(Vector2(610, 276), "c1_loc_nota", ["c1_loc_nota"], 20.0)
    look(Vector2(650, 276), "c1_loc_balcao", ["c1_loc_balcao"], 18.0)


func _spawn_position() -> Vector2:
    GameState.spawn = ""
    return Vector2(140, 246)


func _start() -> void:
    AudioManager.set_muffled(true, 1.0)
    AudioManager.play_ambience("bedroom", 2.5)
    start_occasional(["wood_creak", "far_door", "boom_far2"], 16.0, 30.0, -24.0)
    GameState.autosave("locadora")
    await SceneRouter.wait_reveal()
    set_objective("Olhe em volta, sem pressa.")


func _on_exit(_c: int) -> void:
    await Dialogue.play("c1_loc_saida")
    AudioManager.set_muffled(false, 1.5)
    await enter("centro", "from_locadora")
