extends "res://scripts/world/level_base.gd"
## Cenas 1 a 3: a CASA de Alen Hader — quarto, sala (os pais), cozinha e entrada meio desabada, tudo remendado.
## Cenário estático: assets/environments/house.png (1780×360, tools/gerar_cenarios.py).
## Aqui: colisões, interações, os pais (NPCs sentados), o rádio (som posicional + legenda que fica nítida de perto),
## a conversa interrompida, a música baixinha da sala, goteiras, brasa do fogão e a neve que entra.
## A cozinha e o desabamento ficam KX px à direita do desenho original (a sala ocupa x 544-924).

const Npc := preload("res://scripts/world/npc.gd")
const ChapterCard := preload("res://scripts/ui/chapter_card.gd")
const ControlsHint := preload("res://scripts/ui/controls_hint.gd")
const DemoEnd := preload("res://scripts/ui/demo_end.gd")
const KX := 380.0
const DRIP_FALL := 0.55
const RADIO_POS := Vector2(630, 146)
# Fragmentos de notícia (realidade alternativa; nomes reais nunca aparecem). Curtos, incompletos, inquietantes.
const RADIO_LINES := [
    "...a bolsa fechou o quinto pregão seguido em queda, e o governo pede calma...",
    "...combates na fronteira leste. Novas famílias cruzam a pé, sem documentos...",
    "...postos de saúde sem antibióticos pela terceira semana. A entrega foi adiada de novo...",
    "...o banco que anunciou a falência cedo teve as agências cercadas por poupadores...",
    "...fronteiras fechadas. A ajuda humanitária segue parada nos depósitos...",
    "...se você nos ouve, economize a bateria. Repetimos: econo-mize...",
    "...e a previsão para a serra é de neve. De novo.",
]

# Capítulo I: o rádio agora diz o nome da cidade e ouve-se a guerra "ao longe".
const RADIO_LINES_C1 := [
    "...a prefeitura de Declan City informa que o toque de recolher passa a valer às vinte horas em todos os setores...",
    "...a Estrada do Moinho permanece interditada por ordem do comando regional...",
    "...o comboio de sexta-feira segue previsto pela Avenida Central. Repetimos: sexta...",
    "...a biblioteca municipal funciona como centro de distribuição e abrigo. Tragam o cartão...",
    "...postos de saúde sem antibióticos pela sétima semana...",
    "...se você nos ouve, economize a bateria. Repetimos: econo-mize...",
    "...e a previsão para a serra é de neve. De novo.",
]

var _motes: Array = []
var _title_layer: CanvasLayer
var _outside := false
var _music_on := false
var _overheard_done := false
var _drips := [
    {"x": 736.0, "y_end": 174.0, "period": 2.7, "t": 0.0, "landed": false},
    {"x": 856.0, "y_end": 176.0, "period": 3.9, "t": 1.4, "landed": false},
]
var _flakes: Array = []       # neve que entra pelo desabamento (coordenadas da cozinha, sem KX)
var _wflakes: Array = []      # neve na janela da sala
var _snow_t := 0.0
var _pai
var _mae
var _radio_player = null
var _radio_low_applied := false
var _radio_label: Label
var _radio_i := 0
var _radio_t := 0.0
var _static_timer: Timer


func _build() -> void:
    surface = "wood"
    follow_player = true
    camera_offset = Vector2(0, 0)
    world_rect = Rect2(0, 0, 1780, 360)
    add_bg("res://assets/environments/house.png")
    # limites da casa
    add_block(Rect2(80, 100, 1610, 68))    # parede de fundo, de ponta a ponta
    add_block(Rect2(60, 100, 52, 220))     # parede esquerda
    add_block(Rect2(60, 300, 1640, 40))    # limite inferior
    add_block(Rect2(1684, 100, 80, 240))   # parede direita (porta da frente)
    add_block(Rect2(528, 100, 16, 100))    # parede quarto/sala, acima do vão da porta
    add_block(Rect2(528, 268, 16, 52))     # ... e abaixo do vão
    # quarto
    add_block(Rect2(112, 168, 118, 96))    # cama
    add_block(Rect2(234, 168, 30, 30))     # criado-mudo
    add_block(Rect2(306, 168, 68, 16))     # aparador sob a janela
    add_block(Rect2(398, 168, 122, 34))    # escrivaninha
    add_block(Rect2(258, 262, 30, 24))     # cadeira da jaqueta
    # sala (móveis encostados na parede; os pais NÃO têm colisão própria, e sobram 24 px de corredor na frente)
    add_block(Rect2(656, 168, 68, 24))     # poltrona do pai
    add_block(Rect2(726, 168, 36, 22))     # mesinha dos remédios
    add_block(Rect2(762, 184, 20, 8))      # base do abajur
    add_block(Rect2(786, 168, 116, 24))    # sofá da mãe
    add_block(Rect2(694, 226, 80, 22))     # mesinha de centro
    # cozinha e entrada desabada (deslocadas em KX)
    add_block(Rect2(704.0 + KX, 214, 84, 34))   # mesa
    add_block(Rect2(684.0 + KX, 220, 18, 26))   # cadeiras
    add_block(Rect2(788.0 + KX, 220, 18, 26))
    add_block(Rect2(729.0 + KX, 172, 14, 12))   # baldes
    add_block(Rect2(849.0 + KX, 174, 14, 12))
    add_block(Rect2(1004.0 + KX, 100, 26, 80))  # pilar quebrado
    add_block(Rect2(1088.0 + KX, 176, 64, 34))  # entulho
    add_block(Rect2(1196.0 + KX, 184, 36, 22))
    add_block(Rect2(1108.0 + KX, 264, 90, 40))  # buraco no chão
    add_block(Rect2(1236.0 + KX, 176, 56, 64))  # materiais de remendo
    # pais, sentados (sprites de assets/characters; ver tools/arte/criar_pais.py)
    _pai = Npc.new()
    _pai.texture = load("res://assets/characters/pai_sentado.png")
    _pai.position = Vector2(690, 190)
    add_child(_pai)
    _mae = Npc.new()
    _mae.texture = load("res://assets/characters/mae_sentada.png")
    _mae.position = Vector2(842, 190)
    add_child(_mae)
    # interações: quarto (data/dialogue/prologue_bedroom.json)
    add_interactable(Vector2(172, 282), "bed", [], 36.0, _on_bed)
    add_interactable(Vector2(248, 214), "photo", ["photo_1", "photo_2", "photo_3"], 28.0)
    add_interactable(Vector2(306, 198), "window", ["window_1", "window_2", "window_3"], 16.0)
    add_interactable(Vector2(358, 206), "plant", [], 26.0, _on_plant)
    add_interactable(Vector2(276, 224), "guitar", ["guitar_1", "guitar_2"], 16.0)
    add_interactable(Vector2(424, 214), "computer", ["computer_1", "computer_2"], 18.0)
    add_interactable(Vector2(468, 214), "stereo", ["stereo_1", "stereo_2"], 16.0)
    add_interactable(Vector2(504, 214), "notebook", ["notebook_1", "notebook_2"], 14.0)
    add_interactable(Vector2(304, 296), "school", ["school_1", "school_2"], 16.0)
    add_interactable(Vector2(272, 294), "coat", [], 20.0, _on_coat)
    # interações: sala (data/dialogue/prologue_house.json)
    add_interactable(Vector2(576, 196), "tv", ["tv_1", "tv_2"], 26.0)
    add_interactable(Vector2(628, 196), "radio", [], 20.0, _on_radio)
    add_interactable(Vector2(688, 206), "pai", [], 30.0, _on_pai)
    add_interactable(Vector2(743, 196), "meds", ["meds_1", "meds_2"], 18.0)
    add_interactable(Vector2(842, 206), "mae", [], 34.0, _on_mae)
    add_interactable(Vector2(908, 200), "window_sala", ["window_sala_1", "window_sala_2"], 20.0)
    add_interactable(Vector2(735, 266), "newspaper", ["newspaper_1", "newspaper_2"], 26.0)
    # interações: cozinha e entrada desabada
    add_interactable(Vector2(618.0 + KX, 196), "stove", ["stove_1", "stove_2"], 30.0)
    add_interactable(Vector2(708.0 + KX, 196), "sink", ["sink_1"], 28.0)
    add_interactable(Vector2(772.0 + KX, 196), "patches", ["patches_1", "patches_2"], 26.0)
    add_interactable(Vector2(842.0 + KX, 196), "quilt", ["quilt_window"], 26.0)
    add_interactable(Vector2(912.0 + KX, 196), "fridge", ["fridge_note", "fridge_note_again"], 28.0)
    add_interactable(Vector2(966.0 + KX, 196), "closed_door", ["closed_door_1", "closed_door_2"], 26.0)
    add_interactable(Vector2(746.0 + KX, 262), "table", [], 30.0, _on_table)
    add_interactable(Vector2(1070.0 + KX, 196), "stairs", ["stairs_1", "stairs_2"], 30.0)
    add_interactable(Vector2(1150.0 + KX, 236), "collapse", ["collapse_1", "collapse_2"], 34.0)
    add_interactable(Vector2(1258.0 + KX, 266), "toolbox", ["toolbox_1"], 28.0)
    add_interactable(Vector2(1294.0 + KX, 246), "door", [], 30.0, _on_door)
    for i in 9:
        _motes.append([randf_range(310.0, 400.0), randf_range(90.0, 290.0), randf() * TAU])


func _spawn_position() -> Vector2:
    var sp := GameState.spawn
    GameState.spawn = ""
    if sp == "from_town":                      # Capítulo I: Alen volta da biblioteca pela porta da frente
        return Vector2(1640, 254)
    return Vector2(262, 236)


func _start() -> void:
    AudioManager.set_muffled(true, 0.0)             # som de dentro: abafado
    AudioManager.play_ambience("bedroom", 3.5)
    AudioManager.make_positional("crackle", self, Vector2(617.0 + KX, 150), 170.0, -10.0)     # o fogão
    AudioManager.make_positional("town", self, Vector2(1160.0 + KX, 110), 300.0, -13.0)       # vento pelo desabamento
    _radio_player = AudioManager.make_positional("radio", self, RADIO_POS, 380.0, -9.0)       # o rádio da sala
    _build_radio_label()
    _schedule_static()
    start_occasional(["wood_creak", "far_door"], 24.0, 46.0, -24.0)    # rangidos da casa
    if GameState.is_ch1():
        await _start_ch1()
        return
    if GameState.get_flag("intro_done", false):
        _refresh_objective()
        return
    player.controls_enabled = false
    await SceneRouter.wait_reveal()
    # Cena 1: nada de texto. Câmera à deriva, ambiente, um estalo de madeira, e só então o título.
    camera.offset = Vector2(-14, 5)
    var drift := create_tween()
    drift.tween_property(camera, "offset", Vector2.ZERO, 18.0).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
    await get_tree().create_timer(3.0).timeout
    AudioManager.play_sfx("wood_creak", -14.0)
    await get_tree().create_timer(6.0).timeout
    await _show_title()
    await get_tree().create_timer(1.0).timeout
    # Cena 2: o jogador assume o controle
    AudioManager.play_sfx("cloth", -10.0)
    GameState.set_flag("intro_done", true)
    GameState.autosave("house")
    player.controls_enabled = true
    _refresh_objective()
    ControlsHint.show_once(self)


func _refresh_objective() -> void:
    if GameState.is_ch1():
        _refresh_objective_c1()
        return
    var coat: bool = GameState.get_flag("has_coat", false)
    var met: bool = GameState.get_flag("parents_met", false)
    if not coat:
        set_objective("Prepare-se para sair.")
    elif not met:
        set_objective("Passe pela sala.")
    else:
        set_objective("Saia.")


func _show_title(small_text: String = "SUNFLOWER OF TOMORROW", big_text: String = "PRÓLOGO") -> void:
    _title_layer = CanvasLayer.new()
    _title_layer.layer = 20
    add_child(_title_layer)
    var small := UITheme.label(small_text, 10, Color(0.62, 0.69, 0.78))
    small.position = Vector2(40, 262)
    var big := UITheme.label(big_text, 22, UITheme.INK)
    big.position = Vector2(38, 274)
    small.modulate.a = 0.0
    big.modulate.a = 0.0
    _title_layer.add_child(small)
    _title_layer.add_child(big)
    var t := create_tween().set_parallel(true)
    t.tween_property(small, "modulate:a", 1.0, 2.2)
    t.tween_property(big, "modulate:a", 1.0, 2.8).set_delay(0.6)
    await get_tree().create_timer(6.2).timeout
    var t2 := create_tween().set_parallel(true)
    t2.tween_property(small, "modulate:a", 0.0, 2.2)
    t2.tween_property(big, "modulate:a", 0.0, 2.2)
    await t2.finished
    _title_layer.queue_free()


# ------------------------------------------------------------ rádio
func _build_radio_label() -> void:
    _radio_label = UITheme.label("", 10, Color(0.74, 0.80, 0.90, 1.0))
    _radio_label.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
    _radio_label.offset_top = 14.0
    _radio_label.offset_left = 70.0
    _radio_label.offset_right = -70.0
    _radio_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _radio_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    _radio_label.modulate.a = 0.0
    add_hud_node(_radio_label)


## Legenda do rádio: de longe só algumas palavras ("···"), de perto a frase inteira. Some durante diálogos.
func _update_radio(delta: float) -> void:
    if player == null or _radio_label == null:
        return
    _radio_t += delta
    if _radio_t > 8.0:
        _radio_t = 0.0
        _radio_i = (_radio_i + 1) % _radio_lines().size()
    var dist: float = player.global_position.distance_to(RADIO_POS)
    var low: bool = GameState.get_flag("radio_low", false)
    var reach: float = 220.0 if low else 380.0
    var clarity: float = clampf(1.0 - dist / reach, 0.0, 1.0)
    var target_a: float = 0.0
    if clarity > 0.12 and not Dialogue.active:
        target_a = 0.9
        var words: PackedStringArray = (_radio_lines()[_radio_i] as String).split(" ")
        var shown: PackedStringArray = PackedStringArray()
        for i in words.size():
            var keep: bool = float((i * 37 + _radio_i * 91) % 100) / 100.0 < clarity * 1.15
            shown.append(words[i] if keep else "···")
        _radio_label.text = " ".join(shown)
    _radio_label.modulate.a = lerpf(_radio_label.modulate.a, target_a, clampf(delta * 3.0, 0.0, 1.0))
    # se Alen abaixou o volume, o som do rádio cai também
    if low != _radio_low_applied and _radio_player != null:
        _radio_low_applied = low
        var t := create_tween()
        t.tween_property(_radio_player, "volume_db", -21.0 if low else -9.0, 1.2)


func _radio_lines() -> Array:
    return RADIO_LINES_C1 if GameState.is_ch1() else RADIO_LINES


func _schedule_static() -> void:
    _static_timer = Timer.new()
    _static_timer.one_shot = true
    add_child(_static_timer)
    _static_timer.timeout.connect(_on_static)
    _static_timer.start(randf_range(14.0, 28.0))


## Chiado de interferência ocasional, mais baixo com a distância.
func _on_static() -> void:
    if player != null:
        var dist: float = player.global_position.distance_to(RADIO_POS)
        if dist < 460.0:
            var low_db: float = 6.0 if GameState.get_flag("radio_low", false) else 0.0
            AudioManager.play_sfx("radio_static", -16.0 - dist * 0.02 - low_db, 1.0, 0.1)
    _static_timer.start(randf_range(14.0, 28.0))


# ------------------------------------------------------------ interações
func _on_plant(_count: int) -> void:
    if GameState.get_flag("plant_watered", false):
        await Dialogue.play("plant_after")
    else:
        await Dialogue.play("plant_1")


func _on_coat(_count: int) -> void:
    if GameState.get_flag("has_coat", false):
        await Dialogue.play("coat_after")
        return
    AudioManager.play_sfx("cloth", -8.0)
    await Dialogue.play("coat_1")
    GameState.set_flag("has_coat", true)
    player.queue_redraw()
    _refresh_objective()


func _on_radio(_count: int) -> void:
    if GameState.is_ch1() and not GameState.get_flag("c1_radio_seen", false):
        GameState.set_flag("c1_radio_seen", true)
        await Dialogue.play("c1_radio_c1")
        return
    if GameState.get_flag("radio_seen", false):
        await Dialogue.play("radio_again")
    else:
        await Dialogue.play("radio_1")      # o próprio diálogo grava radio_seen (e radio_low, se Alen abaixar)


func _on_pai(_count: int) -> void:
    if GameState.is_ch1():
        await _talk_parent_c1("pai")
        return
    await Dialogue.play("pai_again" if GameState.get_flag("pai_talked", false) else "pai_1")
    _refresh_objective()


func _on_mae(_count: int) -> void:
    if GameState.is_ch1():
        await _talk_parent_c1("mae")
        return
    await Dialogue.play("mae_again" if GameState.get_flag("mae_talked", false) else "mae_1")
    _refresh_objective()


func _on_door(_count: int) -> void:
    if GameState.is_ch1():
        await _door_c1()
        return
    if not GameState.get_flag("has_coat", false):
        await Dialogue.play("door_nocoat")
        return
    if not GameState.get_flag("parents_met", false):
        await Dialogue.play("door_parents")
        return
    await Dialogue.play("door_ready")
    var choice := str(GameState.get_flag("door_choice", ""))
    GameState.set_flag("door_choice", "")
    if choice == "leave":
        await _leave_room()


## Conversa interrompida: ao se aproximar da sala, Alen ouve os pais; eles se calam quando o veem.
func _check_overheard() -> void:
    if GameState.is_ch1():
        _overheard_done = true
        return
    if _overheard_done or player == null or not GameState.get_flag("intro_done", false):
        return
    if GameState.get_flag("overheard", false):
        _overheard_done = true
        return
    if player.global_position.x > 586.0 and player.controls_enabled and not Dialogue.active:
        _overheard_done = true
        GameState.set_flag("overheard", true)
        _play_overheard()


func _play_overheard() -> void:
    player.controls_enabled = false
    await Dialogue.play("parents_overheard")
    player.controls_enabled = true


## Cena 3: transição sonora e visual interior -> exterior (a porta da frente, no fim da casa).
func _leave_room() -> void:
    player.controls_enabled = false
    set_objective("")
    AudioManager.play_sfx("door_open", -2.0)
    AudioManager.stop_music(3.0)
    AudioManager.play_ambience("town", 5.0, 4.0)     # o som de fora chega antes da imagem
    AudioManager.set_muffled(false, 4.0)              # e o abafado da casa se abre
    await get_tree().create_timer(1.1).timeout
    GameState.spawn = "home"
    GameState.autosave("town")
    SceneRouter.go(GameState.SCENES["town"], 2.4, 0.6, 2.8, Color("#b9c6d8"))   # luz fria e pálida


# ------------------------------------------------------------ Capítulo I (manhã seguinte e volta para casa)
func _start_ch1() -> void:
    GameState.set_flag("has_coat", true)
    GameState.set_flag("intro_done", true)
    if not GameState.get_flag("c1_intro_done", false):
        player.controls_enabled = false
        await SceneRouter.wait_reveal()
        await get_tree().create_timer(2.0).timeout
        AudioManager.play_sfx("wood_creak", -14.0)
        await _show_title("CAPÍTULO I", "UM LUGAR PARA ESCAPAR")
        await get_tree().create_timer(0.6).timeout
        await Dialogue.play("c1_wake")
        GameState.set_flag("c1_intro_done", true)
        GameState.autosave("house")
        player.controls_enabled = true
    elif GameState.get_flag("c1_food", false) and not GameState.get_flag("c1_home_arrived", false):
        await SceneRouter.wait_reveal()
        GameState.set_flag("c1_home_arrived", true)
        player.controls_enabled = false
        await Dialogue.play("c1_home_arrive")
        player.controls_enabled = true
        GameState.autosave("house")
    _refresh_objective_c1()


func _refresh_objective_c1() -> void:
    if not GameState.get_flag("c1_food", false):
        if not GameState.get_flag("c1_card", false) or not GameState.get_flag("c1_pai_talked", false):
            set_objective("Fale com os seus pais.")
        else:
            set_objective("Saia pela porta da frente e vá à biblioteca.")
    elif not GameState.get_flag("c1_unpacked", false):
        set_objective("Leve a caixa para a cozinha.")
    elif not (GameState.get_flag("c1_mae_ret_done", false) and GameState.get_flag("c1_pai_ret_done", false)):
        set_objective("Conte aos seus pais como foi.")
    else:
        set_objective("Descanse no seu quarto.")


func _talk_parent_c1(who: String) -> void:
    var parent_name: String = "pai" if who == "pai" else "mae"
    if not GameState.get_flag("c1_food", false):
        var talked: bool = GameState.get_flag("c1_%s_talked" % who, false)
        await Dialogue.play("c1_%s_again" % parent_name if talked else "c1_%s_1" % parent_name)
    elif not GameState.get_flag("c1_%s_ret_done" % who, false):
        if not GameState.get_flag("c1_unpacked", false):
            await Dialogue.play("c1_cozinha_nao")
        else:
            await Dialogue.play("c1_%s_ret" % parent_name)
    else:
        await Dialogue.play("c1_%s_final" % parent_name)
    _refresh_objective_c1()


func _door_c1() -> void:
    if not GameState.get_flag("c1_card", false):
        await Dialogue.play("c1_door_nocard")
        return
    if not GameState.get_flag("c1_pai_talked", false):
        await Dialogue.play("c1_door_parents")
        return
    if GameState.get_flag("c1_food", false):
        await Dialogue.play("c1_door_back")
        return
    await Dialogue.play("c1_door_ready")
    var choice := str(GameState.get_flag("door_choice", ""))
    GameState.set_flag("door_choice", "")
    if choice == "leave":
        await _leave_room()


func _on_table(count: int) -> void:
    if GameState.is_ch1() and GameState.get_flag("c1_food", false) and not GameState.get_flag("c1_unpacked", false):
        AudioManager.play_sfx("paper", -6.0)
        await Dialogue.play("c1_unpack")
        _refresh_objective_c1()
        return
    await Dialogue.play("table_1" if count <= 1 else "table_2")


func _on_bed(count: int) -> void:
    if GameState.is_ch1() and GameState.get_flag("c1_food", false):
        var ready: bool = GameState.get_flag("c1_unpacked", false) and GameState.get_flag("c1_mae_ret_done", false) and GameState.get_flag("c1_pai_ret_done", false)
        if ready:
            await _night()
        else:
            await Dialogue.play("c1_bed_cedo")
        return
    var ids := ["bed_1", "bed_2", "bed_3"]
    await Dialogue.play(ids[mini(count - 1, ids.size() - 1)])


## Cena final: noite no quarto, o item emprestado (jogo, livro ou nada), a janela embaçada e o cartão de fim de capítulo.
func _night() -> void:
    player.controls_enabled = false
    set_objective("")
    await Dialogue.play("c1_bed_pronto")
    var black: ColorRect = await ChapterCard.fade_layer(self, 1.0, 1.6)
    await get_tree().create_timer(0.6).timeout
    var night := CanvasModulate.new()
    night.color = Color(0.55, 0.62, 0.82)
    add_child(night)
    player.global_position = Vector2(262, 236)
    camera.reset_smoothing()
    AudioManager.stop_music(2.0)
    var t := create_tween()
    t.tween_property(black, "modulate:a", 0.0, 1.8)
    await t.finished
    var item := str(GameState.get_flag("c1_item", "none"))
    var seq := "c1_night_none"
    if item == "guitar":
        seq = "c1_night_guitar"
    elif item == "book":
        seq = "c1_night_book"
    await Dialogue.play(seq)
    await Dialogue.play("c1_night_window")
    GameState.set_flag("ch1_done", true)
    GameState.autosave("house")
    await ChapterCard.show_end(self, "FIM DO CAPÍTULO I", "Sunflower of Tomorrow  ·  Um Lugar Para Escapar", 5.0)
    await DemoEnd.show_panel(self)
    AudioManager.stop_ambience(2.5)
    GameState.playing = false
    SceneRouter.go(GameState.MENU_SCENE, 1.5, 0.3, 2.0)


# --------------------------------------------------------------- animação
func _process(delta: float) -> void:
    super(delta)
    _update_muffle()
    _update_music()
    _update_radio(delta)
    _check_overheard()
    _update_drips(delta)
    _update_snow(delta)


## Dentro da casa o ambiente é abafado; ao chegar perto do desabamento ele "abre" aos poucos.
func _update_muffle() -> void:
    if player == null:
        return
    var out: bool = player.global_position.x > 1010.0 + KX
    if out != _outside:
        _outside = out
        AudioManager.set_muffled(not out, 2.5)


## Música melancólica, bem baixa, só na sala e na cozinha (o quarto e o desabamento ficam só com ambiente).
func _update_music() -> void:
    if player == null:
        return
    var px: float = player.global_position.x
    var want: bool = px > 560.0 and px < 1380.0
    if want != _music_on:
        _music_on = want
        if want:
            AudioManager.set_music_intensity(0.4, 0.5)
            AudioManager.play_music("menu", 7.0, 4.0, -22.0)
        else:
            AudioManager.stop_music(4.0)
            AudioManager.set_music_intensity(1.0, 4.0)


func _update_drips(delta: float) -> void:
    for dd in _drips:
        dd["t"] += delta
        if dd["t"] >= dd["period"]:
            dd["t"] -= dd["period"]
            dd["landed"] = false
        if not dd["landed"] and dd["t"] >= DRIP_FALL:
            dd["landed"] = true
            if player != null:
                var dist: float = absf(player.global_position.x - (float(dd["x"]) + KX))
                if dist < 600.0:
                    AudioManager.play_sfx("drip", -14.0 - dist * 0.025, 1.0, 0.12)


func _update_snow(delta: float) -> void:
    _snow_t += delta
    if _snow_t > 0.14:
        _snow_t = 0.0
        _flakes.append([randf_range(1040.0, 1245.0), randf_range(54.0, 66.0), randf() * TAU, randf_range(170.0, 296.0)])
        if randf() < 0.55:
            _wflakes.append([randf_range(823.0, 898.0), 66.0, randf() * TAU])
    for f in _flakes:
        f[1] += 20.0 * delta
        f[0] += sin(time * 1.3 + f[2]) * 6.0 * delta
    _flakes = _flakes.filter(func(f): return f[1] < f[3])
    for f in _wflakes:
        f[1] += 9.0 * delta
        f[0] += sin(time * 1.1 + f[2]) * 4.0 * delta
    _wflakes = _wflakes.filter(func(f): return f[1] < 112.0)


# ---------------------------------------------------------------- desenho
## A casa estática está em assets/environments/house.png (tools/gerar_cenarios.py).
## Aqui ficam só os elementos que se mexem ou mudam com as escolhas.
func _draw() -> void:
    var sway: float = sin(time * 0.7) * 3.0 + sin(time * 1.9) * 1.0
    var shaft: float = 0.07 + 0.02 * sin(time * 0.5)
    if fx_lights():
        draw_colored_polygon(PackedVector2Array([Vector2(304, 150), Vector2(376, 150), Vector2(446, 306), Vector2(236, 306)]), Color(0.78, 0.86, 1.0, shaft))
    # cortinas do quarto balançando
    draw_rect(Rect2(290, 62, 15 + sway, 88), Color("#5a4a46"))
    draw_rect(Rect2(290, 62, 15 + sway, 3), Color("#3c302e"))
    for i in 3:
        draw_line(Vector2(294 + i * 4, 66), Vector2(294 + i * 4 + sway * 0.4, 148), Color("#4a3c39"), 1.0)
    draw_rect(Rect2(375 - sway * 0.6, 62, 16, 88), Color("#5a4a46"))
    draw_rect(Rect2(375 - sway * 0.6, 62, 16, 3), Color("#3c302e"))
    for i in 3:
        draw_line(Vector2(379 + i * 4 - sway * 0.6, 66), Vector2(379 + i * 4 - sway * 0.4, 148), Color("#4a3c39"), 1.0)
    # planta na muda (a terra escurece se Alen regou)
    var watered: bool = GameState.get_flag("plant_watered", false)
    draw_rect(Rect2(350, 156, 16, 14), Color("#7a4f3d"))
    draw_rect(Rect2(352, 156, 12, 2), Color("#2f241d") if watered else Color("#5a4636"))
    draw_line(Vector2(358, 156), Vector2(358, 140), Color("#6f8a4b"), 2.0)
    draw_colored_polygon(PackedVector2Array([Vector2(358, 142), Vector2(372, 140), Vector2(373, 148)]), Color("#6f8a4b"))
    draw_colored_polygon(PackedVector2Array([Vector2(358, 148), Vector2(344, 146), Vector2(343, 156)]), Color("#a69a4a"))
    # a jaqueta xadrez sobre a cadeira (some quando Alen a veste)
    if not GameState.get_flag("has_coat", false):
        draw_colored_polygon(PackedVector2Array([Vector2(260, 254), Vector2(286, 254), Vector2(290, 280), Vector2(256, 280)]), Color("#3f4249"))
        for k in 4:
            draw_line(Vector2(260 + k * 7, 254), Vector2(258 + k * 8, 280), Color("#555963"), 1.0)
        for k in 3:
            draw_line(Vector2(258, 260 + k * 8), Vector2(289, 260 + k * 8), Color("#555963"), 1.0)
    # poeira dentro do feixe de luz
    for m in _motes:
        m[1] += 2.0 * get_process_delta_time()
        m[0] += sin(time * 0.6 + m[2]) * 4.0 * get_process_delta_time()
        if m[1] > 300.0:
            m[1] = 100.0
        if fx_lights():
            draw_rect(Rect2(floorf(m[0]), floorf(m[1]), 1, 1), Color(1, 1, 1, 0.45))
    # luz amarelada do abajur do criado-mudo (pequena fonte de calor no quarto)
    var lf: float = 0.92 + 0.08 * sin(time * 3.7)
    if fx_lights():
        draw_circle(Vector2(241, 160), 46.0, Color(1.0, 0.78, 0.4, 0.045 * lf))
        draw_circle(Vector2(241, 160), 22.0, Color(1.0, 0.78, 0.4, 0.06 * lf))
    # sala: abajur de pé, mostrador âmbar do rádio e neve caindo na janela
    if fx_lights():
        draw_circle(Vector2(771, 80), 74.0, Color(1.0, 0.76, 0.4, 0.04 * lf))
        draw_circle(Vector2(771, 82), 34.0, Color(1.0, 0.76, 0.4, 0.06 * lf))
        draw_colored_polygon(PackedVector2Array([Vector2(752, 190), Vector2(792, 190), Vector2(850, 300), Vector2(694, 300)]), Color(1.0, 0.72, 0.36, 0.04 * lf))
    draw_rect(Rect2(633, 130, 5, 6), Color(1.0, 0.72, 0.28, 0.45 + 0.2 * sin(time * 2.1)))
    if fx_lights():
        draw_circle(Vector2(636, 133), 14.0, Color(1.0, 0.72, 0.28, 0.07))
    if GameSettings.fx_snow:
        for f in _wflakes:
            draw_rect(Rect2(floorf(f[0]), floorf(f[1]), 1, 1), Color(1, 1, 1, 0.9))
    # --- cozinha e desabamento (desenhados a KX px, em coordenadas do desenho original)
    draw_set_transform(Vector2(KX, 0.0), 0.0, Vector2.ONE)
    var fl: float = 0.5 + 0.5 * sin(time * 7.3) * sin(time * 3.1 + 1.0)
    draw_rect(Rect2(601, 143, 26, 16), Color(0.95, 0.45, 0.14, 0.55 + 0.35 * fl))
    draw_rect(Rect2(607, 149, 14, 8), Color(1.0, 0.75, 0.3, 0.45 + 0.4 * fl))
    if fx_lights():
        draw_circle(Vector2(617, 150), 78.0, Color(1.0, 0.62, 0.25, 0.035 + 0.02 * fl))
        draw_circle(Vector2(617, 150), 44.0, Color(1.0, 0.62, 0.25, 0.05 + 0.03 * fl))
        draw_colored_polygon(PackedVector2Array([Vector2(596, 172), Vector2(640, 172), Vector2(720, 300), Vector2(520, 300)]), Color(1.0, 0.62, 0.25, 0.05 + 0.025 * fl))
    for dd in _drips:
        var p: float = dd["t"]
        var gx: float = dd["x"]
        var ye: float = dd["y_end"]
        if p < DRIP_FALL:
            var kk: float = p / DRIP_FALL
            draw_rect(Rect2(gx, 58.0 + (ye - 58.0) * kk * kk, 1, 3), Color(0.62, 0.74, 0.88, 0.9))
        elif p < DRIP_FALL + 0.4:
            var rr: float = 1.0 + (p - DRIP_FALL) / 0.4 * 7.0
            var aa: float = 1.0 - (p - DRIP_FALL) / 0.4
            draw_set_transform(Vector2(KX + gx, ye), 0.0, Vector2(1.0, 0.4))
            draw_arc(Vector2.ZERO, rr, 0.0, TAU, 14, Color(0.7, 0.8, 0.92, aa * 0.8), 1.0)
            draw_set_transform(Vector2(KX, 0.0), 0.0, Vector2.ONE)
    var w: float = sin(time * 1.6) * 5.0 + sin(time * 4.1) * 1.5
    draw_colored_polygon(PackedVector2Array([Vector2(1098, 86), Vector2(1134, 99), Vector2(1134 + w * 0.6, 142 + w * 0.3), Vector2(1098 + w * 0.4, 128 + w * 0.3)]), Color("#34567f"))
    draw_line(Vector2(1098, 86), Vector2(1134, 99), Color("#9aa4b0"), 2.0)
    draw_line(Vector2(1106, 92), Vector2(1108 + w * 0.3, 128), Color("#46699a"), 1.0)
    draw_line(Vector2(1120, 96), Vector2(1122 + w * 0.5, 136), Color("#46699a"), 1.0)
    var sh: float = 0.07 + 0.02 * sin(time * 0.4)
    draw_colored_polygon(PackedVector2Array([Vector2(1110, 160), Vector2(1240, 160), Vector2(1270, 300), Vector2(1070, 300)]), Color(0.8, 0.88, 1.0, sh))
    for f in _flakes:
        draw_rect(Rect2(floorf(f[0]), floorf(f[1]), 1, 1), Color(0.95, 0.97, 1.0, 0.8))
    draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
