extends Node2D
## NPC de sprite único: sombra, respiração discreta e (opcional) vassoura que varre.
## Defina texture/flip/broom ANTES de add_child(). Origem nos pés.

var texture: Texture2D
var flip: bool = false
var broom: bool = false
var talking: bool = false

var _spr: Sprite2D
var _t := 0.0


func _ready() -> void:
    _spr = Sprite2D.new()
    _spr.centered = false
    _spr.texture = texture
    _spr.flip_h = flip
    _spr.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
    var s := texture.get_size()
    _spr.offset = Vector2(-s.x * 0.5, -s.y + 1.0)
    add_child(_spr)


func _process(delta: float) -> void:
    _t += delta
    var dx := roundf(sin(_t * 2.2)) if (broom and not talking) else 0.0
    _spr.position = Vector2(dx, -roundf(0.5 + 0.5 * sin(_t * 1.6)))
    queue_redraw()


func _draw() -> void:
    draw_set_transform(Vector2(0, -2), 0.0, Vector2(1.0, 0.35))
    draw_circle(Vector2.ZERO, 12.0, Color(0, 0, 0, 0.20))
    draw_circle(Vector2.ZERO, 8.0, Color(0, 0, 0, 0.18))
    draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
    if broom:
        var sw := 0.0 if talking else sin(_t * 2.2) * 6.0
        draw_line(Vector2(-8, -22), Vector2(-22 + sw, -2), Color("#8a6c44"), 2.0)
        draw_rect(Rect2(-29 + sw, -5, 13, 4), Color("#b89a5c"))
        draw_rect(Rect2(-29 + sw, -2, 13, 2), Color("#8c7440"))
