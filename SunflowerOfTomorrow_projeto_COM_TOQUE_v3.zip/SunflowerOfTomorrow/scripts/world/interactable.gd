extends Node2D
## Ponto de interação. O jogador (player.gd) procura o mais próximo dentro de "radius".
## Se houver "hook" (Callable), ele conduz a interação; senão, toca dialogue_ids[contagem-1]
## (o último id se repete nas visitas seguintes).

var key: String = ""
var dialogue_ids: Array = []
var radius: float = 34.0
var hook: Callable = Callable()
var enabled: bool = true

var _highlight := false
var _t := 0.0


func _ready() -> void:
    add_to_group("interactable")
    z_index = 30


func set_highlight(on: bool) -> void:
    _highlight = on and enabled
    queue_redraw()


func _process(delta: float) -> void:
    if _highlight:
        _t += delta
        queue_redraw()


func _draw() -> void:
    if not _highlight:
        return
    var y := -30.0 + sin(_t * 3.0) * 2.0
    var gold := Color(0.914, 0.769, 0.416)
    draw_circle(Vector2(0, y), 7.0, Color(0.06, 0.09, 0.15, 0.85))
    draw_arc(Vector2(0, y), 7.0, 0.0, TAU, 20, gold, 1.0)
    draw_string(ThemeDB.fallback_font, Vector2(-3.5, y + 4.0), "E", HORIZONTAL_ALIGNMENT_LEFT, -1, 10, gold)


func activate(_player: Node) -> void:
    if not enabled:
        return
    var count: int = GameState.bump("seen_" + key)
    if hook.is_valid():
        await hook.call(count)
    elif dialogue_ids.size() > 0:
        var idx: int = mini(count - 1, dialogue_ids.size() - 1)
        await Dialogue.play(str(dialogue_ids[idx]))
