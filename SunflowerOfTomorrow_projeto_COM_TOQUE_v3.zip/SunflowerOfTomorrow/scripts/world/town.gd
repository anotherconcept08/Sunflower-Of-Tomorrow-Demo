extends "res://scripts/world/ch1_level.gd"
## Cena 4: a cidade (Pinhal Alto, o bairro alto de Declan City) em ruínas e neve. Uma rua longa, de esquerda a direita.
## No Capítulo I (GameState.is_ch1()) a mesma rua ganha barricada na Estrada do Moinho, moradores e a saída pela esquerda para o Centro.
## Cenário estático: assets/environments/town_sky|far|main.png (gerados por tools/gerar_cenarios.py).
## Aqui ficam colisões, interações, NPC e os elementos animados (janelas acesas, fumaça).

const W := 2240.0
const Npc := preload("res://scripts/world/npc.gd")
const CHIMNEYS := [Vector2(440, 108), Vector2(1444, 102), Vector2(1686, 86)]
const LIT_WINDOWS := [Vector2(390, 168), Vector2(716, 178), Vector2(760, 178), Vector2(1590, 160)]

var _smoke: Array = []
var _smoke_t := 0.0
var _marcus


func _build() -> void:
    surface = "snow"
    follow_player = true
    camera_offset = Vector2(0, 0)
    world_rect = Rect2(0, 0, W, 360)
    add_bg("res://assets/environments/town_sky.png", Vector2.ZERO, -30)
    add_parallax("res://assets/environments/town_far.png", Vector2(-200, 20), 0.4, -20)
    add_bg("res://assets/environments/town_main.png", Vector2.ZERO, -10)
    add_block(Rect2(0, 150, W, 88))        # limite superior (fachadas)
    add_block(Rect2(0, 340, W, 40))        # limite inferior
    add_block(Rect2(-40, 0, 40, 360))
    add_block(Rect2(W, 0, 40, 360))
    add_block(Rect2(808, 262, 26, 12))     # Marcus
    add_block(Rect2(1044, 250, 72, 10))    # banco
    _marcus = Npc.new()
    _marcus.texture = load("res://assets/characters/marcus_side.png")
    _marcus.flip = true
    _marcus.broom = true
    _marcus.position = Vector2(820, 270)
    add_child(_marcus)
    add_interactable(Vector2(190, 258), "house_door", [], 34.0, _on_house_door)
    add_interactable(Vector2(400, 260), "radio_window", ["window_radio"], 40.0)
    add_interactable(Vector2(582, 260), "notice", [], 36.0, _on_notice)
    add_interactable(Vector2(824, 276), "marcus", [], 40.0, _on_marcus)
    add_interactable(Vector2(1080, 278), "bench", ["bench_book"], 36.0)
    add_interactable(Vector2(1292, 298), "pinhao", [], 34.0, _on_pinhao)
    add_interactable(Vector2(1622, 262), "smoke_house", ["smoke_house"], 40.0)
    add_interactable(Vector2(1444, 262), "pharmacy", ["pharmacy_1", "pharmacy_again"], 34.0)
    add_interactable(Vector2(1856, 262), "road_sign", ["sign_road"], 36.0)
    if GameState.is_ch1():
        _build_ch1()
    else:
        add_interactable(Vector2(2194, 296), "road_exit", [], 46.0, _on_exit)


func _spawn_position() -> Vector2:
    var s := GameState.spawn
    GameState.spawn = ""
    if s == "from_garden":
        return Vector2(2150, 296)
    if s == "from_centro":
        return Vector2(70, 292)
    return Vector2(190, 262)


func _start() -> void:
    AudioManager.set_muffled(false, 3.0)
    AudioManager.play_ambience("town", 4.0)
    AudioManager.make_positional("radio", self, Vector2(400, 190), 200.0, -10.0)
    AudioManager.make_positional("crackle", self, Vector2(1692, 130), 180.0, -12.0)
    if GameState.is_ch1():
        start_occasional(["boom_far", "far_door", "car_pass", "boom_far2"], 20.0, 38.0, -18.0)
        apply_dusk()
    else:
        start_occasional(["car_pass", "far_door"], 14.0, 26.0, -16.0)
    add_snow(60, 12.0, 5.0)
    GameState.autosave("town")
    await SceneRouter.wait_reveal()
    if GameState.is_ch1():
        trip_objective("Vá à biblioteca: a rua segue para a esquerda, até o Centro.", "Entre em casa.")
        return
    set_objective("Siga a estrada do Moinho." if GameState.get_flag("marcus_met", false) else "Dê uma volta.")


# ------------------------------------------------------------ interações
func _on_notice(count: int) -> void:
    # o próprio diálogo notice_board grava a flag read_notice
    await Dialogue.play("notice_board" if count <= 1 else "notice_again")


func _on_marcus(_c: int) -> void:
    _marcus.talking = true
    if GameState.is_ch1():
        if returning():
            await Dialogue.play("c1_marcus_back")
        elif not GameState.get_flag("c1_marcus_met", false):
            await Dialogue.play("c1_marcus_1")
        else:
            await Dialogue.play("c1_marcus_2")
        _marcus.talking = false
        return
    if not GameState.get_flag("marcus_met", false):
        await Dialogue.play("marcus_intro")
        set_objective("Siga a estrada do Moinho.")
    else:
        await Dialogue.play("marcus_again")
    _marcus.talking = false


func _on_pinhao(_c: int) -> void:
    if GameState.get_flag("has_pinhao", false):
        await Dialogue.play("pinhao_after")
    else:
        AudioManager.play_sfx("twig", -10.0, 1.4)
        await Dialogue.play("pinhao")


## Capítulo I: a porta de casa só abre depois de voltar com a ração.
func _on_house_door(_c: int) -> void:
    if GameState.is_ch1() and returning():
        await enter("house", "from_town")
    else:
        await Dialogue.play("house_door")


## Capítulo I: o que mudou na rua desde o prólogo.
func _build_ch1() -> void:
    add_bg("res://assets/environments/bairro_overlay.png", Vector2.ZERO, -9)
    add_block(Rect2(2046, 238, 200, 102))                  # a barricada fecha a Estrada do Moinho de verdade
    npc("ferraz", Vector2(2020, 276))
    add_interactable(Vector2(2016, 296), "c1_barricada", [], 46.0, _on_barricada)
    npc("candida", Vector2(354, 262), false, false)
    look2(Vector2(354, 284), "c1_candida", ["c1_candida_1"], ["c1_candida_back"], 34.0)
    look(Vector2(322, 262), "c1_laundry", ["c1_laundry_sign"], 20.0)
    npc("tobias_sentado", Vector2(972, 264), false, false)
    look2(Vector2(972, 284), "c1_tobias", ["c1_tobias_1", "c1_tobias_2"], ["c1_tobias_2"], 34.0)
    npc("crianca_a", Vector2(1540, 300), false, false)
    npc("crianca_b", Vector2(1576, 304), false, false)
    look2(Vector2(1558, 322), "c1_giz", ["c1_criancas_giz", "c1_criancas_giz_2"], ["c1_criancas_giz_back"], 40.0)
    look(Vector2(76, 262), "c1_sign_centro", ["c1_sign_centro"], 44.0)
    add_edge_exit("left", "centro", "from_bairro")


func _on_barricada(_c: int) -> void:
    if returning():
        await Dialogue.play("c1_barricada_back")
    elif GameState.get_flag("c1_barricada_seen", false):
        await Dialogue.play("c1_barricada_2")
    else:
        await Dialogue.play("c1_barricada_1")


func _on_exit(_c: int) -> void:
    if not GameState.get_flag("marcus_met", false):
        await Dialogue.play("exit_locked")
        return
    go_to_level("garden", "from_town")


# ------------------------------------------------------------- animação
func _process(delta: float) -> void:
    super(delta)
    _smoke_t += delta
    if _smoke_t > 0.8:
        _smoke_t = 0.0
        for c in CHIMNEYS:
            _smoke.append([c.x + 6.0, c.y, 0.0])
    for s in _smoke:
        s[1] -= 7.0 * delta
        s[0] += (3.0 + sin(s[2] * 1.3) * 2.0) * delta
        s[2] += delta
    _smoke = _smoke.filter(func(s): return s[2] < 7.0)


func _draw() -> void:
    for p in LIT_WINDOWS:
        var px: float = p.x
        var py: float = p.y
        var glow: float = 0.10 + 0.02 * sin(time * 2.3 + px)
        if fx_lights():
            draw_rect(Rect2(px - 7, py - 6, 32, 36), Color(1, 0.78, 0.4, glow))
        draw_rect(Rect2(px + 1, py + 1, 16, 22), Color("#f2c26b"))
        draw_rect(Rect2(px + 8, py + 1, 2, 22), Color("#a8782f"))
        draw_rect(Rect2(px + 1, py + 11, 16, 2), Color("#a8782f"))
    if fx_lights():
        draw_colored_polygon(PackedVector2Array([Vector2(392, 228), Vector2(412, 228), Vector2(440, 262), Vector2(370, 262)]), Color(1, 0.78, 0.4, 0.07))
    if GameState.is_ch1():       # amarelinha riscada a carvão na neve
        for i in 5:
            draw_rect(Rect2(1522.0, 336.0 - float(i) * 11.0, 14, 11), Color(0.16, 0.16, 0.2, 0.8), false, 1.0)
    for s in _smoke:
        var a: float = clampf(0.4 * (1.0 - float(s[2]) / 7.0), 0.0, 0.4)
        draw_rect(Rect2(floorf(s[0]), floorf(s[1]), 4, 4), Color(0.75, 0.8, 0.88, a))
