extends "res://scripts/world/ch1_level.gd"
## Capítulo I — Rua das Lojas (Declan City). Duas saídas pelas bordas: leste = bairro (Pinhal Alto), oeste = Praça do Relógio.
## Interiores: locadora abandonada, padaria (funcionando no mínimo) e, pelo beco, uma casa abandonada.
## Cenário: assets/environments/centro_main.png (tools/gerar_cap1.py). Posições de portas/placas vêm desse desenho.

const W := 2240.0
const CHIMNEYS := [Vector2(812, 90)]

var _smoke: Array = []
var _smoke_t := 0.0
var _menezes


func _build() -> void:
    surface = "snow"
    follow_player = true
    camera_offset = Vector2(0, 0)
    world_rect = Rect2(0, 0, W, 360)
    add_bg("res://assets/environments/town_sky.png", Vector2.ZERO, -30)
    add_parallax("res://assets/environments/town_far.png", Vector2(-200, 20), 0.4, -20)
    add_bg("res://assets/environments/centro_main.png", Vector2.ZERO, -10)
    add_block(Rect2(0, 150, W, 88))
    add_block(Rect2(0, 340, W, 40))
    add_block(Rect2(-40, 0, 40, 360))
    add_block(Rect2(W, 0, 40, 360))
    add_block(Rect2(348, 226, 98, 48))      # barricada da Rua das Ferrarias
    add_block(Rect2(868, 240, 56, 14))      # banco
    add_block(Rect2(1762, 236, 66, 16))     # banca de trocas
    # Cb. Menezes, sentado num caixote ao lado do jipe
    _menezes = npc("menezes_sentado", Vector2(466, 262))
    # Seu Aurélio, atrás da mesa da banca
    npc("aurelio", Vector2(1796, 240), false, false)
    # --- fachadas e objetos examináveis
    look(Vector2(76, 262), "c1_oficina", ["c1_oficina_1", "c1_oficina_2"], 40.0)
    look(Vector2(206, 262), "c1_loc_fachada", ["c1_locadora_fachada"], 28.0)
    add_interactable(Vector2(262, 262), "c1_loc_porta", [], 30.0, _on_locadora)
    add_interactable(Vector2(470, 280), "c1_ferrarias", [], 40.0, _on_ferrarias)
    look(Vector2(508, 262), "c1_televale", ["c1_televale_1", "c1_televale_2"], 44.0)
    look(Vector2(704, 262), "c1_pad_fachada", ["c1_padaria_fachada", "c1_padaria_lousa"], 28.0)
    add_interactable(Vector2(754, 262), "c1_pad_porta", [], 30.0, _on_padaria)
    look(Vector2(1022, 262), "c1_mercearia", ["c1_mercearia_1", "c1_mercearia_2"], 46.0)
    add_interactable(Vector2(1192, 262), "c1_beco", [], 34.0, _on_beco)
    look(Vector2(1290, 262), "c1_moda", ["c1_moda_1", "c1_moda_2"], 44.0)
    look(Vector2(1462, 262), "c1_cafe", ["c1_cafe_1", "c1_cafe_2"], 44.0)
    look(Vector2(1694, 262), "c1_sebo", ["c1_sebo_1", "c1_sebo_2"], 44.0)
    look(Vector2(1900, 262), "c1_ruina", ["c1_ruina_1", "c1_ruina_2"], 46.0)
    add_interactable(Vector2(1796, 266), "c1_banca", [], 40.0, _on_banca)
    look(Vector2(2080, 262), "c1_onibus", ["c1_onibus_1", "c1_onibus_2"], 50.0)
    look(Vector2(2204, 262), "c1_centro_sign", ["c1_centro_sign_back"], 30.0)
    add_edge_exit("right", "town", "from_centro")
    add_edge_exit("left", "praca", "from_centro")


func _spawn_position() -> Vector2:
    var s := GameState.spawn
    GameState.spawn = ""
    match s:
        "from_bairro":
            return Vector2(W - 70.0, 296)
        "from_locadora":
            return Vector2(268, 280)
        "from_padaria":
            return Vector2(760, 280)
        "from_beco":
            return Vector2(1192, 276)
    return Vector2(70, 296)


func _start() -> void:
    AudioManager.set_muffled(false, 2.0)
    AudioManager.play_ambience("town", 3.0)
    start_occasional(["boom_far", "far_door", "car_pass", "boom_far2"], 22.0, 40.0, -19.0)
    add_snow(55, 12.0, 5.0)
    apply_dusk()
    GameState.autosave("centro")
    await SceneRouter.wait_reveal()
    trip_objective("Siga até a praça. A biblioteca fica depois.", "Volte para casa.")


# ------------------------------------------------------------ interações
func _on_locadora(_c: int) -> void:
    await Dialogue.play("c1_locadora_porta")
    await enter("locadora", "from_street")


func _on_padaria(_c: int) -> void:
    await Dialogue.play("c1_padaria_porta")
    await enter("padaria", "from_street")


func _on_beco(_c: int) -> void:
    await Dialogue.play("c1_beco_1")
    await enter("casa_vazia", "from_beco", "wood_creak")


func _on_ferrarias(_c: int) -> void:
    if returning():
        await Dialogue.play("c1_ferrarias_back")
    else:
        await Dialogue.play("c1_ferrarias_1" if not GameState.get_flag("c1_menezes_met", false) else "c1_ferrarias_2")


func _on_banca(_c: int) -> void:
    if returning():
        await Dialogue.play("c1_banca_back")
    elif not GameState.get_flag("c1_banca_done", false):
        GameState.set_flag("c1_banca_done", true)
        await Dialogue.play("c1_banca_1")
    else:
        await Dialogue.play("c1_banca_2")


# ------------------------------------------------------------- animação
func _process(delta: float) -> void:
    super(delta)
    _smoke_t += delta
    if _smoke_t > 0.8:
        _smoke_t = 0.0
        for c in CHIMNEYS:
            _smoke.append([c.x + 6.0, c.y, 0.0])
    for s in _smoke:
        s[1] -= 7.0 * delta
        s[0] += (3.0 + sin(s[2] * 1.3) * 2.0) * delta
        s[2] += delta
    _smoke = _smoke.filter(func(s): return s[2] < 7.0)


func _draw() -> void:
    # brilho do forno da padaria atrás da vitrine
    var g: float = 0.10 + 0.03 * sin(time * 3.1)
    if fx_lights():
        draw_rect(Rect2(770, 174, 70, 40), Color(1, 0.7, 0.3, g))
    for s in _smoke:
        var a: float = clampf(0.4 * (1.0 - float(s[2]) / 7.0), 0.0, 0.4)
        draw_rect(Rect2(floorf(s[0]), floorf(s[1]), 4, 4), Color(0.75, 0.8, 0.88, a))
