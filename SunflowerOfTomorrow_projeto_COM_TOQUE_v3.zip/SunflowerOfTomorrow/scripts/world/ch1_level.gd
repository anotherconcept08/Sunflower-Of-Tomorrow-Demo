extends "res://scripts/world/level_base.gd"
## Base das fases do Capítulo I (Declan City): NPCs, adereços ordenados por profundidade (y-sort), saídas pela borda do mapa,
## interações com variantes "antes/depois de pegar a ração" e o entardecer da volta para casa.
## As subclasses só descrevem o que existe em cada lugar (colisões, objetos, falas); a lógica comum fica aqui.

const C1_NPC := preload("res://scripts/world/npc.gd")
const C1_CHARS := "res://assets/characters/"
const C1_EDGE := 22.0           # a que distância da borda a saída é acionada

var _edge_exits: Array = []
var _leaving := false
var _dusk_mod: CanvasModulate


## Verdadeiro depois que Alen recebeu a ração: a viagem de volta tem falas e luz diferentes.
func returning() -> bool:
    return bool(GameState.get_flag("c1_food", false))


## Luz do fim de tarde (só em exteriores, na volta para casa).
func apply_dusk() -> void:
    if not returning() or _dusk_mod != null:
        return
    _dusk_mod = CanvasModulate.new()
    _dusk_mod.color = Color(0.80, 0.76, 0.90)
    add_child(_dusk_mod)


## NPC parado. tex = nome do PNG em assets/characters (sem extensão). Origem nos pés.
func npc(tex: String, pos: Vector2, flip: bool = false, block: bool = true):
    var n = C1_NPC.new()
    n.texture = load(C1_CHARS + tex + ".png")
    n.flip = flip
    n.position = pos
    add_child(n)
    if block:
        add_block(Rect2(pos.x - 8.0, pos.y - 7.0, 16.0, 10.0))
    return n


## Objeto que se ordena por profundidade junto com o jogador (balcões, mesas, TV). y_bottom = base do objeto.
func prop(path: String, x: float, y_bottom: float) -> Sprite2D:
    var s := Sprite2D.new()
    s.centered = false
    s.texture = load(path)
    s.offset = Vector2(0.0, -float(s.texture.get_height()))
    s.position = Vector2(x, y_bottom)
    s.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
    add_child(s)
    return s


func look(pos: Vector2, key: String, ids: Array, radius: float = 34.0):
    return add_interactable(pos, key, ids, radius)


## Interação com duas sequências de falas: antes e depois de pegar a ração.
func look2(pos: Vector2, key: String, before: Array, after: Array, radius: float = 34.0):
    return add_interactable(pos, key, [], radius, _play_variant.bind(key, before, after))


func _play_variant(_count: int, key: String, before: Array, after: Array) -> void:
    var use_after: bool = returning() and after.size() > 0
    var ids: Array = after if use_after else before
    var n: int = GameState.bump("c1v_" + ("a_" if use_after else "b_") + key)
    await Dialogue.play(str(ids[mini(n - 1, ids.size() - 1)]))


## Saída pela borda esquerda ou direita do mapa: ao encostar, a fase muda (com fade).
func add_edge_exit(side: String, target: String, spawn: String) -> void:
    _edge_exits.append({"side": side, "target": target, "spawn": spawn})


func _process(delta: float) -> void:
    super(delta)
    _check_edges()


func _check_edges() -> void:
    if _leaving or player == null or not player.controls_enabled or Dialogue.active:
        return
    var px: float = player.global_position.x
    for e in _edge_exits:
        var hit := false
        if str(e["side"]) == "left":
            hit = px < world_rect.position.x + C1_EDGE
        else:
            hit = px > world_rect.end.x - C1_EDGE
        if hit:
            _leaving = true
            go_to_level(str(e["target"]), str(e["spawn"]))
            return


## Entrar num interior (porta de loja/casa).
func enter(target: String, spawn: String, sfx: String = "door_open") -> void:
    if _leaving:
        return
    _leaving = true
    AudioManager.play_sfx(sfx, -4.0)
    await get_tree().create_timer(0.25).timeout
    go_to_level(target, spawn)


## Texto do objetivo: um para a ida, outro para a volta.
func trip_objective(going: String, back: String) -> void:
    set_objective(back if returning() else going)
