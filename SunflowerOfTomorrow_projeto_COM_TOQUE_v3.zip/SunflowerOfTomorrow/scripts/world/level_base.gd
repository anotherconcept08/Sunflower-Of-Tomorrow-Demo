extends Node2D
## Base de todas as fases (quarto, cidade, jardim).
## Subclasses sobrescrevem: _build() (cenário, colisões, interações), _spawn_position() e _start() (som/eventos).
## O cenário é desenhado por código (_draw) como PLACEHOLDER; veja docs/04 para trocar por arte real.

const Interactable := preload("res://scripts/world/interactable.gd")
const SnowLayer := preload("res://scripts/world/snow_layer.gd")
const PauseMenu := preload("res://scripts/ui/pause_menu.gd")
const UITheme := preload("res://scripts/ui/ui_theme.gd")
const PLAYER_SCENE := preload("res://scenes/characters/player.tscn")

var world_rect: Rect2 = Rect2(0, 0, 640, 360)
var surface: String = "wood"
var follow_player: bool = true
var camera_offset: Vector2 = Vector2(0, -24)
var animated: bool = true      # redesenha o cenário todo quadro (cortinas, fumaça...)

var player
var camera: Camera2D
var time: float = 0.0

var _parallax: Array = []
var _hud: CanvasLayer
var _objective: Label
var _hint: Label
var _pause
var _occ_timer: Timer
var _occ_ids: Array = []
var _occ_min := 10.0
var _occ_max := 20.0
var _occ_db := -14.0


func _ready() -> void:
    y_sort_enabled = true          # jogador e NPCs se ordenam pela posição dos pés
    _build_hud()
    _build()
    player = PLAYER_SCENE.instantiate()
    add_child(player)
    player.global_position = _spawn_position()
    player.surface = surface
    camera = Camera2D.new()
    add_child(camera)
    camera.position_smoothing_enabled = true
    camera.position_smoothing_speed = 5.0
    camera.global_position = _camera_target()
    camera.make_current()
    camera.reset_smoothing()
    _pause = PauseMenu.new()
    add_child(_pause)
    GameState.playing = true
    _start()


# ---- métodos para sobrescrever ----------------------------------------
func _build() -> void:
    pass


func _spawn_position() -> Vector2:
    return world_rect.get_center()


func _start() -> void:
    pass


# ---- câmera -------------------------------------------------------------
func _process(delta: float) -> void:
    time += delta
    if player != null and follow_player:
        camera.global_position = _camera_target()
    if camera != null:
        for p in _parallax:
            p[0].position.x = p[1].x + camera.global_position.x * (1.0 - float(p[2]))
    if animated:
        queue_redraw()


func _camera_target() -> Vector2:
    if not follow_player or player == null:
        return world_rect.get_center()
    var half := get_viewport_rect().size * 0.5
    var p: Vector2 = player.global_position + camera_offset
    return Vector2(
        _clamp_axis(p.x, world_rect.position.x + half.x, world_rect.end.x - half.x),
        _clamp_axis(p.y, world_rect.position.y + half.y, world_rect.end.y - half.y))


func _clamp_axis(v: float, lo: float, hi: float) -> float:
    if hi <= lo:
        return (lo + hi) * 0.5
    return clampf(v, lo, hi)


# ---- HUD (objetivo discreto e dica de ação) ------------------------------
func _build_hud() -> void:
    _hud = CanvasLayer.new()
    _hud.layer = 10
    add_child(_hud)
    _objective = UITheme.label("", 10, Color(0.78, 0.84, 0.95, 0.85))
    var ins := GameSettings.safe_insets()
    _objective.position = Vector2(18.0 + ins.left, 12.0 + ins.top)
    _objective.modulate.a = 0.0
    _hud.add_child(_objective)
    _hint = UITheme.label("", 12, UITheme.INK)
    _hint.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
    _hint.offset_top = -64.0
    _hint.offset_bottom = -40.0
    _hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _hud.add_child(_hint)


func set_objective(text: String) -> void:
    var t := create_tween()
    if _objective.text != "":
        t.tween_property(_objective, "modulate:a", 0.0, 0.5)
    t.tween_callback(_set_objective_text.bind(text))
    if text != "":
        t.tween_property(_objective, "modulate:a", 0.85, 1.2)


func _set_objective_text(text: String) -> void:
    _objective.text = text


func show_hint(text: String) -> void:
    _hint.text = text


func hide_hint() -> void:
    _hint.text = ""


func add_hud_node(n: Node) -> void:
    _hud.add_child(n)


# ---- construção ---------------------------------------------------------
## Fundo estático (PNG 1 px = 1 px). z negativo: fica atrás do jogador e dos NPCs.
func add_bg(path: String, pos: Vector2 = Vector2.ZERO, z: int = -10) -> Sprite2D:
    var s := Sprite2D.new()
    s.centered = false
    s.texture = load(path)
    s.position = pos
    s.z_index = z
    s.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
    add_child(s)
    return s


## Camada com parallax: speed = fração do movimento da câmera (0.4 = move devagar, parece distante).
func add_parallax(path: String, base: Vector2, speed: float, z: int) -> void:
    var s := add_bg(path, base, z)
    _parallax.append([s, base, speed])



func add_block(rect: Rect2) -> StaticBody2D:
    var body := StaticBody2D.new()
    body.collision_layer = 1
    body.collision_mask = 0
    body.position = rect.position + rect.size * 0.5
    var shape := CollisionShape2D.new()
    var rs := RectangleShape2D.new()
    rs.size = rect.size
    shape.shape = rs
    body.add_child(shape)
    add_child(body)
    return body


func add_interactable(pos: Vector2, key: String, ids: Array, radius: float = 34.0, hook: Callable = Callable()):
    var it := Interactable.new()
    it.position = pos
    it.key = key
    it.dialogue_ids = ids
    it.radius = radius
    it.hook = hook
    add_child(it)
    return it


func add_snow(count: int, fall: float, wind: float, col: Color = Color(0.9, 0.93, 1.0, 0.75), smin: int = 1, smax: int = 2) -> void:
    var cl := CanvasLayer.new()
    cl.layer = 4
    add_child(cl)
    var s := SnowLayer.new()
    s.setup(count, fall, wind, col, smin, smax)
    cl.add_child(s)


## Sons ocasionais ao longe (carro, porta...). Usa um Timer filho: morre junto com a cena.
func start_occasional(ids: Array, min_s: float, max_s: float, volume_db: float = -14.0) -> void:
    _occ_ids = ids
    _occ_min = min_s
    _occ_max = max_s
    _occ_db = volume_db
    _occ_timer = Timer.new()
    _occ_timer.one_shot = true
    add_child(_occ_timer)
    _occ_timer.timeout.connect(_on_occasional)
    _occ_timer.start(randf_range(min_s, max_s))


func _on_occasional() -> void:
    AudioManager.play_sfx(str(_occ_ids.pick_random()), _occ_db, 1.0, 0.04)
    _occ_timer.start(randf_range(_occ_min, _occ_max))


# ---- fluxo --------------------------------------------------------------
## Espera o jogador apertar "interagir" (usado nas sequências interativas, como plantar).
func wait_press() -> void:
    add_to_group("touch_wait_press")               # avisa os controles de toque: "estou esperando o E" (mostra o botão E)
    await get_tree().create_timer(0.2).timeout     # ignora a tecla que acabou de fechar um diálogo
    while true:
        await get_tree().process_frame
        if Input.is_action_just_pressed("interact"):
            remove_from_group("touch_wait_press")
            return


func go_to_level(id: String, spawn_name: String = "") -> void:
    player.controls_enabled = false
    GameState.spawn = spawn_name
    GameState.autosave(id)
    SceneRouter.go(GameState.SCENES[id], 1.1, 0.4, 1.4)


## Efeitos de iluminação ligados? (Configurações > Efeitos). Brilhos e feixes desenhados em código obedecem a isto.
func fx_lights() -> bool:
    return GameSettings.fx_lights


func _unhandled_input(event: InputEvent) -> void:
    if event.is_action_pressed("ui_cancel") and player != null and player.controls_enabled and not Dialogue.active:
        get_viewport().set_input_as_handled()
        _pause.open()
