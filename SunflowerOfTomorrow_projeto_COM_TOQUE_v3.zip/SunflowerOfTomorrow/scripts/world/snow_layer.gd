extends Node2D
## Partículas simples em espaço de tela (neve, folhas secas). Coloque dentro de um CanvasLayer.
## Uso: var s = SnowLayer.new(); s.setup(70, 14.0, 6.0); canvas_layer.add_child(s)

var count: int = 70
var fall_speed: float = 14.0
var wind: float = 6.0
var color: Color = Color(0.9, 0.93, 1.0, 0.75)
var size_min: int = 1
var size_max: int = 2
var area: Vector2 = Vector2(640, 360)
var follow_viewport := false     # menu principal: acompanha o tamanho real da janela (aspecto expandido)
var _flakes: Array = []    # cada item: [x, y, tamanho, fase, multiplicador de velocidade]
var _t := 0.0


func setup(c: int, fall: float, w: float, col: Color = Color(0.9, 0.93, 1.0, 0.75), smin: int = 1, smax: int = 2) -> void:
    count = c
    fall_speed = fall
    wind = w
    color = col
    size_min = smin
    size_max = smax


func _ready() -> void:
    if follow_viewport:
        area = get_viewport_rect().size
    GameSettings.changed.connect(_apply_fx)
    _apply_fx()
    for i in count:
        _flakes.append([randf() * area.x, randf() * area.y, randi_range(size_min, size_max), randf() * TAU, 0.6 + randf() * 0.8])


## Partículas ambientais (neve, folhas) podem ser desligadas em Configurações.
func _apply_fx() -> void:
    visible = GameSettings.fx_snow
    set_process(GameSettings.fx_snow)


func _process(delta: float) -> void:
    _t += delta
    if follow_viewport:
        area = get_viewport_rect().size
    for f in _flakes:
        f[1] += fall_speed * f[4] * delta
        f[0] += (wind + sin(_t * 0.8 + f[3]) * 5.0) * delta
        if f[1] > area.y + 4.0:
            f[1] = -4.0
            f[0] = randf() * area.x
        if f[0] > area.x + 4.0:
            f[0] = -4.0
        elif f[0] < -4.0:
            f[0] = area.x + 4.0
    queue_redraw()


func _draw() -> void:
    for f in _flakes:
        var s := float(f[2])
        draw_rect(Rect2(floorf(f[0]), floorf(f[1]), s, s), color)
