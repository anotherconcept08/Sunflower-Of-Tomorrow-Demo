extends "res://scripts/world/ch1_level.gd"
## Capítulo I — Biblioteca Municipal: centro de distribuição de alimentos, abrigo e, no fundo, o canto de entretenimento onde
## Alen conhece Olivier. Um corredor de 2440 px, da esquerda para a direita:
##   entrada/recepção · distribuição (Helena) · depósito restrito · abrigo · estantes · canto dos jogos (Olivier + TV).
## Cenário: assets/environments/biblioteca.png + adereços bib_*.png (ordenados por profundidade). Gerados por tools/gerar_cap1.py.

const W := 2440.0
const SpaceTravelers := preload("res://scripts/minigame/space_travelers.gd")
const ENV := "res://assets/environments/"
const BULBS := [330.0, 700.0, 1100.0, 1500.0, 1700.0, 1900.0, 2250.0]
const TV_SCREEN := Rect2(2298, 172, 38, 26)

var _olivier
var _tv_hint_done := false


func _build() -> void:
    surface = "wood"
    follow_player = true
    camera_offset = Vector2(0, 0)
    world_rect = Rect2(0, 0, W, 360)
    add_bg(ENV + "biblioteca.png")
    add_block(Rect2(80, 100, 2300, 68))      # parede do fundo
    add_block(Rect2(60, 100, 52, 220))       # parede esquerda
    add_block(Rect2(60, 300, 2330, 40))      # limite inferior
    add_block(Rect2(2380, 100, 80, 240))     # parede direita
    # --- balcões e móveis (ordenados por profundidade: NPCs aparecem "atrás" deles)
    prop(ENV + "bib_recepcao.png", 300.0, 236.0)
    add_block(Rect2(300, 168, 130, 70))
    prop(ENV + "bib_balcao.png", 520.0, 240.0)
    add_block(Rect2(520, 168, 380, 72))
    prop(ENV + "bib_mesa.png", 1850.0, 250.0)
    add_block(Rect2(1850, 224, 124, 26))
    prop(ENV + "bib_tv.png", 2290.0, 232.0)
    add_block(Rect2(2284, 168, 70, 66))
    add_block(Rect2(404, 252, 60, 14))       # banco da entrada
    add_block(Rect2(1204, 176, 390, 40))     # colchões da fileira de trás
    add_block(Rect2(1300, 258, 118, 36))     # colchões da frente
    add_block(Rect2(1500, 258, 118, 36))
    add_block(Rect2(1672, 168, 44, 34))      # aquecedor
    add_block(Rect2(2174, 246, 38, 26))      # pufe
    # --- gente (a biblioteca precisa parecer habitada)
    npc("nina", Vector2(364, 200), false, false)
    npc("tobias_sentado", Vector2(430, 262), false, false)
    npc("helena", Vector2(640, 204), false, false)
    npc("tiago", Vector2(790, 204), false, false)
    npc("civil_b", Vector2(556, 274))
    npc("velho", Vector2(584, 274))
    npc("ferraz_side", Vector2(1146, 202), true)         # Sd. Teixeira, de guarda
    npc("lucia_sentada", Vector2(1262, 206), false, false)
    npc("anselmo_dormindo", Vector2(1400, 208), false, false)
    npc("crianca_a", Vector2(1546, 288), false, false)
    npc("crianca_b", Vector2(1580, 288), false, false)
    npc("candida", Vector2(1700, 202), false, false)     # Dona Rute, dona do fogão
    npc("crianca_b", Vector2(1912, 226), false, false)   # a leitora
    _olivier = npc("olivier_sentado", Vector2(2268, 268))
    # --- interações: recepção
    look(Vector2(136, 276), "c1_capacho", ["c1_capacho"], 30.0)
    look(Vector2(206, 190), "c1_cabides", ["c1_cabides"], 24.0)
    look(Vector2(256, 190), "c1_regras", ["c1_regras"], 26.0)
    add_interactable(Vector2(364, 252), "c1_nina", [], 40.0, _on_nina)
    look(Vector2(444, 244), "c1_banco_ent", ["c1_banco_entrada"], 30.0)
    add_interactable(Vector2(134, 214), "c1_porta", [], 32.0, _on_exit)
    # --- interações: distribuição
    add_interactable(Vector2(650, 252), "c1_helena", [], 42.0, _on_helena)
    look(Vector2(730, 252), "c1_livro_caixa", ["c1_balcao_livro"], 20.0)
    look(Vector2(790, 252), "c1_tiago_cx", ["c1_tiago_caixas"], 24.0)
    look(Vector2(836, 252), "c1_balanca", ["c1_balanca"], 20.0)
    look(Vector2(570, 288), "c1_fila_dist", ["c1_fila_dist"], 30.0)
    # --- depósito
    look(Vector2(1040, 190), "c1_dep_cartaz", ["c1_deposito_cartaz"], 24.0)
    look(Vector2(1100, 190), "c1_dep_porta", ["c1_deposito_porta"], 26.0)
    look(Vector2(1146, 226), "c1_teixeira", ["c1_teixeira_1", "c1_teixeira_2"], 34.0)
    # --- abrigo
    look(Vector2(1226, 228), "c1_malas", ["c1_malas"], 18.0)
    look(Vector2(1262, 232), "c1_lucia", ["c1_lucia_1", "c1_lucia_2"], 30.0)
    look(Vector2(1306, 226), "c1_desenhos", ["c1_desenhos"], 18.0)
    look(Vector2(1396, 234), "c1_anselmo", ["c1_anselmo"], 28.0)
    look(Vector2(1360, 252), "c1_colchao", ["c1_colchao"], 22.0)
    look(Vector2(1456, 226), "c1_lencol", ["c1_lencol"], 20.0)
    look(Vector2(1562, 250), "c1_cartas", ["c1_criancas_cartas"], 38.0)
    look(Vector2(1618, 190), "c1_cal_bib", ["c1_calendario_bib"], 28.0)
    look(Vector2(1668, 226), "c1_aquecedor", ["c1_aquecedor"], 22.0)
    add_interactable(Vector2(1714, 228), "c1_rute", [], 30.0, _on_rute)
    # --- estantes
    look(Vector2(1812, 188), "c1_contos", ["c1_book_contos"], 24.0)
    look(Vector2(1852, 188), "c1_dic", ["c1_book_dicionario"], 22.0)
    look(Vector2(1894, 188), "c1_atlas", ["c1_book_atlas"], 22.0)
    look(Vector2(1946, 188), "c1_infantil", ["c1_book_infantil"], 24.0)
    look(Vector2(2000, 188), "c1_ficha_cx", ["c1_fichario"], 24.0)
    look(Vector2(2070, 188), "c1_revista", ["c1_revista"], 24.0)
    look(Vector2(2104, 188), "c1_guitar_box", ["c1_guitar_box"], 20.0)
    look(Vector2(1880, 258), "c1_emprestimo", ["c1_emprestimo"], 26.0)
    look(Vector2(1946, 258), "c1_leitora", ["c1_mesa_leitura"], 22.0)
    # --- canto de entretenimento
    look(Vector2(2190, 190), "c1_cartuchos", ["c1_cartuchos", "c1_cartucho_space"], 30.0)
    look(Vector2(2250, 190), "c1_poster", ["c1_poster_another"], 18.0)
    look(Vector2(2318, 244), "c1_tv", ["c1_tv"], 22.0)
    look(Vector2(2300, 282), "c1_console", ["c1_console"], 16.0)
    look(Vector2(2192, 282), "c1_pufe", ["c1_pufe"], 20.0)
    add_interactable(Vector2(2242, 270), "c1_olivier", [], 30.0, _on_olivier)


func _spawn_position() -> Vector2:
    GameState.spawn = ""
    return Vector2(150, 252)


func _start() -> void:
    AudioManager.set_muffled(false, 1.5)
    AudioManager.play_ambience("library", 3.0)
    AudioManager.make_positional("crackle", self, Vector2(1690, 150), 220.0, -13.0)
    start_occasional(["tin_clink", "paper", "cloth", "wood_creak", "boom_far2"], 10.0, 20.0, -25.0)
    GameState.set_flag("c1_in_library", true)
    GameState.autosave("biblioteca")
    await SceneRouter.wait_reveal()
    if not GameState.get_flag("c1_bib_intro", false):
        GameState.set_flag("c1_bib_intro", true)
        player.controls_enabled = false
        await Dialogue.play("c1_bib_entrada")
        player.controls_enabled = true
    _refresh_objective()


func _refresh_objective() -> void:
    if not GameState.get_flag("c1_food", false):
        set_objective("Pegue a ração da família, no balcão.")
    elif not GameState.get_flag("c1_oliv_met", false):
        set_objective("Veja o que há no fundo da biblioteca.")
    elif GameState.get_flag("c1_oliv_bye", false):
        set_objective("Volte para casa.")
    else:
        set_objective("Explore, se quiser. Depois, volte para casa.")


# ------------------------------------------------------------ interações
func _on_exit(_c: int) -> void:
    if not GameState.get_flag("c1_food", false):
        await Dialogue.play("c1_bib_exit_nofood")
        return
    if not GameState.get_flag("c1_oliv_met", false):
        await Dialogue.play("c1_porta_saida_wait")
        return
    await Dialogue.play("c1_porta_saida_ok")
    await enter("humanitaria", "from_library")


func _on_nina(_c: int) -> void:
    if returning():
        await Dialogue.play("c1_nina_back")
    elif not GameState.get_flag("c1_nina_met", false):
        await Dialogue.play("c1_nina_1")
    else:
        await Dialogue.play("c1_nina_2")


func _on_helena(_c: int) -> void:
    if not GameState.get_flag("c1_food", false):
        await Dialogue.play("c1_helena_1")
        AudioManager.play_sfx("paper", -4.0)
    elif GameState.get_flag("c1_oliv_bye", false):
        await Dialogue.play("c1_helena_ret")
    else:
        await Dialogue.play("c1_helena_2")
    _refresh_objective()


func _on_rute(_c: int) -> void:
    var n: int = GameState.bump("c1_rute_n")
    await Dialogue.play("c1_rute_1" if n <= 1 else "c1_rute_2")


func _on_olivier(_c: int) -> void:
    if not GameState.get_flag("c1_oliv_met", false):
        await Dialogue.play("c1_oliv_intro")
    await Dialogue.play("c1_oliv_hub")
    if GameState.get_flag("c1_play_now", false):
        GameState.set_flag("c1_play_now", false)
        await _play_game()
    _refresh_objective()


## Minijogo Space Travelers (assets/minigame/*.png, scripts/minigame/space_travelers.gd). Esc encerra a partida.
func _play_game() -> void:
    player.controls_enabled = false
    if not GameState.get_flag("c1_played", false):
        await Dialogue.play("c1_oliv_before_game")
    AudioManager.play_sfx("console_on", -2.0)
    var layer := CanvasLayer.new()
    layer.layer = 40
    add_child(layer)
    var game = SpaceTravelers.new()
    layer.add_child(game)
    AudioManager.set_ambience_level(-30.0, 0.6)
    var res: Dictionary = await game.run()
    layer.queue_free()
    AudioManager.set_ambience_level(0.0, 1.8)
    if not bool(res.get("started", false)):         # saiu na tela de título: não houve partida
        player.controls_enabled = true
        return
    var result := str(res.get("result", "quit"))
    var deaths := int(res.get("deaths", 0))
    GameState.set_flag("c1_played", true)
    GameState.set_flag("st_result", result)
    GameState.set_flag("st_deaths", deaths)
    GameState.set_flag("st_score", int(res.get("score", 0)))
    GameState.autosave("biblioteca")
    await get_tree().create_timer(0.6).timeout
    var after := "c1_oliv_after_quit"
    if result == "win":
        after = "c1_oliv_after_win_clean" if deaths == 0 else "c1_oliv_after_win"
    elif result == "lose":
        after = "c1_oliv_after_lose"
    await Dialogue.play(after)
    if result != "quit" and not GameState.get_flag("c1_boom_done", false):
        await get_tree().create_timer(0.8).timeout
        await Dialogue.play("c1_oliv_boom")
    player.controls_enabled = true


# ---------------------------------------------------------------- animação
func _process(delta: float) -> void:
    super(delta)
    _check_tv_hint()


## Primeira vez que Alen se aproxima do fundo: a luz azul da TV chama a atenção.
func _check_tv_hint() -> void:
    if _tv_hint_done or player == null or not player.controls_enabled or Dialogue.active:
        return
    if player.global_position.x > 2020.0 and not GameState.get_flag("c1_oliv_met", false):
        _tv_hint_done = true
        player.controls_enabled = false
        await Dialogue.play("c1_tv_luz")
        player.controls_enabled = true


func _draw() -> void:
    # lâmpadas nuas com cintilação
    if fx_lights():
        for bx in BULBS:
            var fl: float = 0.035 + 0.012 * sin(time * 2.1 + float(bx) * 0.07) + 0.006 * sin(time * 9.0 + float(bx))
            draw_circle(Vector2(float(bx), 84.0), 52.0, Color(1.0, 0.86, 0.56, fl))
            draw_circle(Vector2(float(bx), 84.0), 26.0, Color(1.0, 0.9, 0.65, fl))
        # brasa do aquecedor
        var st: float = 0.06 + 0.025 * sin(time * 7.0) + 0.015 * sin(time * 12.5)
        draw_circle(Vector2(1690, 156), 34.0, Color(1.0, 0.55, 0.2, st))
    # tela da TV: modo "demonstração" do Space Travelers
    var sx: float = TV_SCREEN.position.x
    var sy: float = TV_SCREEN.position.y
    draw_rect(TV_SCREEN, Color(0.04, 0.07, 0.2))
    for i in 14:
        var px: float = sx + fmod(float(i) * 13.7 + time * 3.0 * float(1 + i % 3), 38.0)
        var py: float = sy + fmod(float(i) * 7.3 + time * 14.0 * float(1 + i % 2), 26.0)
        draw_rect(Rect2(floorf(px), floorf(py), 1, 1), Color(0.85, 0.9, 1.0, 0.8))
    for i in 3:
        var rx: float = sx + 5.0 + float(i) * 12.0 + sin(time * 1.5 + float(i)) * 3.0
        draw_rect(Rect2(floorf(rx), sy + 4.0 + float(i % 2) * 5.0, 5, 3), Color(0.72, 0.30, 0.30))
    var nx: float = sx + 19.0 + sin(time * 2.2) * 12.0
    draw_rect(Rect2(floorf(nx) - 2.0, sy + 21.0, 5, 3), Color(0.45, 0.65, 0.98))
    draw_rect(Rect2(floorf(nx), sy + 12.0 + fmod(time * 30.0, 8.0), 1, 3), Color(1.0, 0.9, 0.45))
    if fx_lights():
        var gl: float = 0.07 + 0.02 * sin(time * 11.0)
        draw_circle(Vector2(sx + 19.0, sy + 13.0), 62.0, Color(0.35, 0.5, 1.0, gl))
    for k in 6:
        draw_rect(Rect2(sx, sy + 2.0 + float(k) * 4.0, 38, 1), Color(0, 0, 0, 0.18))
