extends "res://scripts/world/ch1_level.gd"
## Capítulo I — Padaria "Pão & Prosa": o único forno aceso da rua. Dona Íris entrega a Alen o saco de pães do abrigo
## (flag c1_bread; mais tarde, Helena retribui com a lata de pêssego) e um pão para a família (c1_roll).
## Cenário: assets/environments/padaria.png + pad_balcao.png.

const ENV := "res://assets/environments/"


func _build() -> void:
    surface = "wood"
    follow_player = true
    camera_offset = Vector2(0, 0)
    world_rect = Rect2(0, 0, 800, 360)
    add_bg(ENV + "padaria.png")
    add_block(Rect2(80, 100, 640, 68))
    add_block(Rect2(60, 100, 52, 220))
    add_block(Rect2(688, 100, 80, 240))
    add_block(Rect2(60, 300, 700, 40))
    prop(ENV + "pad_balcao.png", 200.0, 240.0)
    add_block(Rect2(200, 168, 230, 74))
    add_block(Rect2(440, 226, 100, 26))     # mesa de sovar
    add_block(Rect2(660, 190, 28, 64))      # sacos de farinha
    npc("iris", Vector2(320, 204), false, false)
    add_interactable(Vector2(134, 214), "c1_pad_saida", [], 32.0, _on_exit)
    add_interactable(Vector2(320, 254), "c1_iris", [], 42.0, _on_iris)
    look(Vector2(250, 254), "c1_pad_balcao", ["c1_pad_balcao"], 22.0)
    look(Vector2(440, 190), "c1_pad_lousa", ["c1_pad_lousa"], 34.0)
    look(Vector2(585, 192), "c1_pad_forno", ["c1_pad_forno"], 40.0)
    look(Vector2(640, 240), "c1_pad_farinha", ["c1_pad_farinha"], 22.0)
    look(Vector2(676, 232), "c1_pad_gato", ["c1_pad_gato"], 16.0)


func _spawn_position() -> Vector2:
    GameState.spawn = ""
    return Vector2(140, 246)


func _start() -> void:
    AudioManager.set_muffled(true, 1.0)
    AudioManager.play_ambience("bedroom", 2.5)
    AudioManager.make_positional("crackle", self, Vector2(585, 140), 260.0, -9.0)      # o forno
    GameState.autosave("padaria")
    await SceneRouter.wait_reveal()
    set_objective("Converse com a Dona Íris.")


func _on_iris(_c: int) -> void:
    if returning():
        await Dialogue.play("c1_pad_iris_back")
    elif not GameState.get_flag("c1_iris_met", false):
        await Dialogue.play("c1_pad_iris_1")
        set_objective("Leve os pães ao abrigo, na biblioteca.")
    else:
        await Dialogue.play("c1_pad_iris_2")


func _on_exit(_c: int) -> void:
    await Dialogue.play("c1_pad_saida")
    AudioManager.set_muffled(false, 1.5)
    await enter("centro", "from_padaria")


func _draw() -> void:
    var g: float = 0.07 + 0.03 * sin(time * 6.0) + 0.02 * sin(time * 10.3)
    if fx_lights():
        draw_circle(Vector2(585, 140), 70.0, Color(1.0, 0.55, 0.2, g))
