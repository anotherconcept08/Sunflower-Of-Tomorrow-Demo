extends "res://scripts/world/ch1_level.gd"
## Capítulo I — Praça do Relógio: monumento parado às 4h10, mural de desaparecidos, correios e banco fechados,
## capela com velas e o posto de controle da Avenida Central (barricada de verdade). Leste = Rua das Lojas, oeste = área humanitária.

const W := 2000.0

var _lopes
var _lopes_it


func _build() -> void:
    surface = "snow"
    follow_player = true
    camera_offset = Vector2(0, 0)
    world_rect = Rect2(0, 0, W, 360)
    add_bg("res://assets/environments/town_sky.png", Vector2.ZERO, -30)
    add_parallax("res://assets/environments/town_far.png", Vector2(-200, 20), 0.4, -20)
    add_bg("res://assets/environments/praca_main.png", Vector2.ZERO, -10)
    add_block(Rect2(0, 150, W, 88))
    add_block(Rect2(0, 340, W, 40))
    add_block(Rect2(-40, 0, 40, 360))
    add_block(Rect2(W, 0, 40, 360))
    add_block(Rect2(822, 240, 60, 14))      # banco da sopa
    add_block(Rect2(1400, 240, 60, 14))     # banco do xadrez
    add_block(Rect2(1486, 224, 150, 54))    # posto de controle (sacos de areia + barreira)
    add_block(Rect2(1150, 236, 80, 8))      # fonte congelada
    npc("mulher", Vector2(596, 268))
    _lopes = npc("lopes", Vector2(1652, 262))
    npc("velho", Vector2(1430, 252), false, false)
    look(Vector2(112, 262), "c1_praca_sign", ["c1_praca_sign"], 30.0)
    look(Vector2(290, 262), "c1_banco", ["c1_banco_1", "c1_banco_2"], 60.0)
    look(Vector2(500, 262), "c1_correios", ["c1_correios_1"], 36.0)
    look(Vector2(566, 262), "c1_caixa_correio", ["c1_correio_caixa"], 18.0)
    add_interactable(Vector2(598, 284), "c1_mulher", [], 28.0, _on_mulher)
    look(Vector2(660, 262), "c1_desaparecidos", ["c1_desaparecidos_1", "c1_desaparecidos_2", "c1_desaparecidos_3"], 56.0)
    look(Vector2(850, 266), "c1_sopa", ["c1_sopa"], 34.0)
    look(Vector2(1030, 262), "c1_relogio", ["c1_relogio_1", "c1_relogio_2"], 44.0)
    look(Vector2(1190, 262), "c1_fonte", ["c1_fonte"], 44.0)
    look(Vector2(1318, 262), "c1_jornais", ["c1_jornais"], 34.0)
    add_interactable(Vector2(1432, 270), "c1_xadrez", [], 30.0, _on_xadrez)
    look(Vector2(1518, 296), "c1_posto_barreira", ["c1_posto_barreira"], 24.0)
    look(Vector2(1562, 296), "c1_posto_sinal", ["c1_posto_sinal"], 24.0)
    look(Vector2(1604, 296), "c1_posto_jipe", ["c1_posto_jipe"], 24.0)
    _lopes_it = add_interactable(Vector2(1654, 280), "c1_lopes", [], 34.0, _on_lopes)
    look(Vector2(1768, 262), "c1_hotel", ["c1_hotel_1", "c1_hotel_2"], 50.0)
    look(Vector2(1930, 262), "c1_capela", ["c1_capela_1"], 26.0)
    look(Vector2(1970, 262), "c1_doacoes", ["c1_capela_doacoes"], 22.0)
    add_edge_exit("right", "centro", "from_praca")
    add_edge_exit("left", "humanitaria", "from_praca")


func _spawn_position() -> Vector2:
    var s := GameState.spawn
    GameState.spawn = ""
    if s == "from_humanitaria":
        return Vector2(70, 296)
    return Vector2(W - 70.0, 296)


func _start() -> void:
    AudioManager.set_muffled(false, 2.0)
    AudioManager.play_ambience("town", 3.0)
    start_occasional(["boom_far", "far_door", "boom_far2"], 20.0, 36.0, -18.0)
    add_snow(55, 12.0, 5.0)
    apply_dusk()
    GameState.autosave("praca")
    await SceneRouter.wait_reveal()
    trip_objective("A biblioteca fica a oeste, depois da praça.", "Volte para casa, a leste.")


func _on_mulher(_c: int) -> void:
    var n: int = GameState.bump("c1_mulher_n")
    await Dialogue.play("c1_mulher_cartas" if n <= 1 else "c1_mulher_cartas_2")


func _on_xadrez(_c: int) -> void:
    var n: int = GameState.bump("c1_xadrez_n")
    await Dialogue.play("c1_xadrez" if n <= 1 else "c1_xadrez_2")


func _on_lopes(_c: int) -> void:
    if returning():
        await Dialogue.play("c1_posto_lopes_back")
    elif not GameState.get_flag("c1_lopes_met", false):
        await Dialogue.play("c1_posto_lopes_1")
    else:
        await Dialogue.play("c1_posto_lopes_2")


func _draw() -> void:
    # luz das velas da capela
    var g: float = 0.12 + 0.03 * sin(time * 5.0) + 0.02 * sin(time * 8.3)
    if fx_lights():
        draw_rect(Rect2(1914, 176, 32, 50), Color(1, 0.78, 0.4, g))
