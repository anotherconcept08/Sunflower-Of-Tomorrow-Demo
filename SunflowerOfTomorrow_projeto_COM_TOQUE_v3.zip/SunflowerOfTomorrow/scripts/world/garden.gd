extends "res://scripts/world/level_base.gd"
## Cenas 5 e 6: o jardim abandonado, a conversa com Eleanor, a semente e o encerramento.
## Cenário estático: assets/environments/garden_sky|far|main.png (tools/gerar_cenarios.py).

const W := 1440.0
const MOUND := Vector2(1300, 292)
const Npc := preload("res://scripts/world/npc.gd")

var _eleanor
var _eleanor_it = null
var _dug := 0
var _seed_in := false
var _covered := 0
var _ray := 0.0


func _build() -> void:
    surface = "dirt"
    follow_player = true
    camera_offset = Vector2(0, 0)
    world_rect = Rect2(0, 0, W, 360)
    add_bg("res://assets/environments/garden_sky.png", Vector2.ZERO, -30)
    add_parallax("res://assets/environments/garden_far.png", Vector2(-190, 30), 0.45, -20)
    add_bg("res://assets/environments/garden_main.png", Vector2.ZERO, -10)
    add_block(Rect2(0, 150, W, 88))
    add_block(Rect2(0, 340, W, 40))
    add_block(Rect2(-40, 0, 40, 360))
    add_block(Rect2(W, 0, 40, 360))
    add_block(Rect2(526, 252, 68, 10))     # banco
    add_block(Rect2(690, 264, 24, 12))     # Eleanor
    add_block(Rect2(1262, 268, 76, 44))    # canteiro livre (o jogador fica abaixo dele)
    _eleanor = Npc.new()
    _eleanor.texture = load("res://assets/characters/eleanor_crouch.png")
    _eleanor.position = Vector2(700, 284)
    add_child(_eleanor)
    add_interactable(Vector2(34, 300), "to_town", [], 40.0, _on_back_to_town)
    add_interactable(Vector2(250, 264), "gate", ["gate_broken"], 38.0)
    add_interactable(Vector2(400, 276), "stalks", ["stalks"], 40.0)
    add_interactable(Vector2(560, 278), "bench", ["bench_initials"], 36.0)
    _eleanor_it = add_interactable(Vector2(704, 284), "eleanor", [], 42.0, _on_eleanor)
    add_interactable(Vector2(824, 296), "can", ["watering_can"], 32.0)
    add_interactable(Vector2(1040, 270), "tin", [], 34.0, _on_tin)
    add_interactable(Vector2(1300, 328), "bed", [], 38.0, _on_bed)


func _spawn_position() -> Vector2:
    GameState.spawn = ""
    return Vector2(90, 296)


func _start() -> void:
    AudioManager.set_muffled(false, 2.0)
    AudioManager.play_ambience("garden", 4.5)
    start_occasional(["twig"], 18.0, 34.0, -16.0)
    add_snow(26, 7.0, 26.0, Color(0.50, 0.38, 0.24, 0.85), 2, 3)     # folhas secas ao vento
    GameState.autosave("garden")
    if GameState.get_flag("planted", false):
        _dug = 3
        _seed_in = true
        _covered = 2
    if GameState.get_flag("eleanor_ok", false):
        _eleanor.visible = false
        _eleanor_it.enabled = false
    await SceneRouter.wait_reveal()
    if GameState.get_flag("prologue_done", false):
        set_objective("Fim do prólogo.")
    else:
        set_objective("Olhe em volta.")


# ------------------------------------------------------------ interações
func _on_back_to_town(_c: int) -> void:
    go_to_level("town", "from_garden")


func _on_tin(_c: int) -> void:
    if GameState.get_flag("has_seed", false):
        await Dialogue.play("tin_after")
        return
    AudioManager.play_sfx("paper", -4.0)
    await Dialogue.play("seed_find")


func _on_eleanor(count: int) -> void:
    if not GameState.get_flag("eleanor_met", false):
        await Dialogue.play("eleanor_intro")
    var has_seed: bool = GameState.get_flag("has_seed", false)
    if has_seed and not GameState.get_flag("eleanor_ok", false):
        await Dialogue.play("eleanor_seeds")
        _eleanor_it.enabled = false
        var t := create_tween()
        t.tween_property(_eleanor, "modulate:a", 0.0, 2.5)
        await t.finished
        _eleanor.visible = false
    elif count > 1 and not has_seed:
        await Dialogue.play("eleanor_idle")


func _on_bed(_c: int) -> void:
    if GameState.get_flag("planted", false):
        await Dialogue.play("bed_planted")
    elif not GameState.get_flag("has_seed", false):
        await Dialogue.play("bed_empty")
    elif not GameState.get_flag("eleanor_ok", false):
        await Dialogue.play("bed_ask_first")
    else:
        await _plant_sequence()


## Cena 6: plantar. Pequena sequência interativa, sem música e sem grande revelação.
func _plant_sequence() -> void:
    player.controls_enabled = false
    set_objective("")
    await Dialogue.play("plant_start")
    var steps := ["Cavar", "Cavar mais fundo", "Quase"]
    for i in 3:
        show_hint("[E]  %s  (%d/3)" % [steps[i], i + 1])
        await wait_press()
        AudioManager.play_sfx("dig", -4.0, 1.0, 0.08)
        _dug = i + 1
    show_hint("[E]  Deixar a semente")
    await wait_press()
    AudioManager.play_sfx("seed_drop", -4.0)
    _seed_in = true
    hide_hint()
    await get_tree().create_timer(1.3).timeout
    for i in 2:
        show_hint("[E]  Cobrir  (%d/2)" % (i + 1))
        await wait_press()
        AudioManager.play_sfx("dig", -9.0, 0.9, 0.08)
        _covered = i + 1
    hide_hint()
    GameState.set_flag("planted", true)
    await get_tree().create_timer(1.6).timeout
    await Dialogue.play("plant_end")
    await _final_shot()


## A última imagem: o vento quase some, a câmera sobe, um raio baixo de sol toca a terra, uma nota.
func _final_shot() -> void:
    AudioManager.set_ambience_level(-18.0, 6.0)
    var t := create_tween().set_parallel(true)
    t.tween_property(camera, "offset", Vector2(0, -34), 9.0).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
    t.tween_property(self, "_ray", 1.0, 6.0).set_delay(2.5)
    await get_tree().create_timer(5.5).timeout
    AudioManager.play_sfx("final_note", -4.0)
    await get_tree().create_timer(7.0).timeout
    GameState.set_flag("prologue_done", true)
    GameState.autosave("garden")
    await _end_card()


func _end_card() -> void:
    var cl := CanvasLayer.new()
    cl.layer = 70
    add_child(cl)
    var black := ColorRect.new()
    black.color = Color(0.015, 0.02, 0.035)
    black.set_anchors_preset(Control.PRESET_FULL_RECT)
    black.modulate.a = 0.0
    cl.add_child(black)
    var t := create_tween()
    t.tween_property(black, "modulate:a", 1.0, 3.0)
    await t.finished
    var box := VBoxContainer.new()
    box.set_anchors_preset(Control.PRESET_FULL_RECT)
    box.alignment = BoxContainer.ALIGNMENT_CENTER
    box.modulate.a = 0.0
    var l1 := UITheme.label("FIM DO PRÓLOGO", 16, UITheme.INK)
    var l2 := UITheme.label("Sunflower of Tomorrow  ·  Prólogo", 10, UITheme.GOLD)
    l1.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    l2.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    box.add_child(l1)
    box.add_child(l2)
    cl.add_child(box)
    var t2 := create_tween()
    t2.tween_property(box, "modulate:a", 1.0, 2.0)
    await t2.finished
    await get_tree().create_timer(5.0).timeout
    AudioManager.stop_ambience(2.5)
    GameState.start_chapter1()                      # a história continua na manhã seguinte, na casa de Alen
    GameState.autosave("house")
    SceneRouter.go(GameState.SCENES["house"], 1.5, 0.3, 2.0)


# ---------------------------------------------------------------- desenho
## Só o que muda durante o jogo: o estado do plantio e o raio de sol final.
func _draw() -> void:
    if _dug > 0 and _covered == 0:
        draw_rect(Rect2(MOUND.x - 4 - _dug * 3, MOUND.y - 2, 8 + _dug * 6, 4 + _dug * 2), Color("#2b241d"))
    if _seed_in and _covered == 0:
        draw_rect(Rect2(MOUND.x - 1, MOUND.y, 3, 2), Color("#d9d2c4"))
    if _covered > 0:
        draw_colored_polygon(PackedVector2Array([Vector2(MOUND.x - 16, MOUND.y + 6), Vector2(MOUND.x - 7, MOUND.y - 4), Vector2(MOUND.x + 7, MOUND.y - 4), Vector2(MOUND.x + 16, MOUND.y + 6)]), Color("#2f271f"))
        draw_rect(Rect2(MOUND.x - 10, MOUND.y - 3, 20, 2), Color("#463a2e"))
    if _ray > 0.01:
        draw_colored_polygon(PackedVector2Array([Vector2(1210, 0), Vector2(1290, 0), Vector2(1330, 300), Vector2(1270, 300)]), Color(1.0, 0.82, 0.45, 0.17 * _ray))
        draw_circle(MOUND, 36.0 * _ray, Color(1.0, 0.8, 0.4, 0.10))
        draw_circle(MOUND, 16.0 * _ray, Color(1.0, 0.85, 0.5, 0.16))
