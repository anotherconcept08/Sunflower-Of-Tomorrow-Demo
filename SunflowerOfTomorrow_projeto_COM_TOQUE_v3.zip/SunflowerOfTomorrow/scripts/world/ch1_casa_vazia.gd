extends "res://scripts/world/ch1_level.gd"
## Capítulo I — Casa parcialmente abandonada (Beco do Sapateiro): a família saiu às pressas, alguém ainda usa a chave
## e a janela do quarto tem uma nave desenhada no vidro (flag c1_saw_ship -> uma pergunta opcional para Olivier).
## Cenário: assets/environments/casa_vazia.png + casa_mesa.png.

const ENV := "res://assets/environments/"


func _build() -> void:
    surface = "wood"
    follow_player = true
    camera_offset = Vector2(0, 0)
    world_rect = Rect2(0, 0, 900, 360)
    add_bg(ENV + "casa_vazia.png")
    add_block(Rect2(80, 100, 740, 68))
    add_block(Rect2(60, 100, 52, 220))
    add_block(Rect2(820, 100, 80, 240))
    add_block(Rect2(60, 300, 800, 40))
    add_block(Rect2(512, 100, 16, 102))     # parede entre a sala e o quarto, com vão de porta no meio
    add_block(Rect2(512, 262, 16, 40))
    prop(ENV + "casa_mesa.png", 230.0, 252.0)
    add_block(Rect2(230, 228, 120, 26))
    add_block(Rect2(664, 190, 128, 50))     # cama
    add_interactable(Vector2(134, 214), "c1_casa_saida", [], 32.0, _on_exit)
    look(Vector2(172, 190), "c1_casa_vaso", ["c1_casa_vaso"], 14.0)
    look(Vector2(210, 190), "c1_casa_casaco", ["c1_casa_casaco"], 14.0)
    look(Vector2(270, 190), "c1_casa_fogao", ["c1_casa_fogao"], 22.0)
    look(Vector2(270, 270), "c1_casa_mesa", ["c1_casa_mesa"], 28.0)
    look(Vector2(344, 270), "c1_casa_bilhete", ["c1_casa_bilhete"], 18.0)
    look(Vector2(386, 190), "c1_casa_canecas", ["c1_casa_canecas"], 40.0)
    look(Vector2(475, 190), "c1_casa_foto", ["c1_casa_foto"], 22.0)
    look(Vector2(572, 284), "c1_casa_mochila", ["c1_casa_mochila"], 16.0)
    look(Vector2(616, 264), "c1_casa_trem", ["c1_casa_trem"], 20.0)
    look(Vector2(668, 184), "c1_casa_janela", ["c1_casa_janela"], 22.0)
    look(Vector2(728, 254), "c1_casa_cama", ["c1_casa_cama"], 30.0)
    look(Vector2(703, 282), "c1_casa_neve", ["c1_casa_neve"], 22.0)
    look(Vector2(780, 190), "c1_casa_calendario", ["c1_casa_calendario"], 22.0)


func _spawn_position() -> Vector2:
    GameState.spawn = ""
    return Vector2(140, 246)


func _start() -> void:
    AudioManager.set_muffled(true, 1.0)
    AudioManager.play_ambience("bedroom", 2.5)
    start_occasional(["wood_creak", "drip"], 14.0, 26.0, -22.0)
    GameState.autosave("casa_vazia")
    await SceneRouter.wait_reveal()
    if not GameState.get_flag("c1_casa_intro", false):
        GameState.set_flag("c1_casa_intro", true)
        player.controls_enabled = false
        await Dialogue.play("c1_casa_entrada")
        player.controls_enabled = true
    set_objective("Olhe em volta, sem pressa.")


func _on_exit(_c: int) -> void:
    await Dialogue.play("c1_casa_saida")
    AudioManager.set_muffled(false, 1.5)
    await enter("centro", "from_beco", "wood_creak")
