extends "res://scripts/world/ch1_level.gd"
## Capítulo I — Área de distribuição humanitária, em frente à biblioteca: filas, caminhão de suprimentos, ponto de água,
## quadro de avisos, alto-falante e o "Teatro de Meias". Leste = Praça do Relógio; a porta grande, a oeste, leva à biblioteca.

const W := 1900.0



func _build() -> void:
    surface = "snow"
    follow_player = true
    camera_offset = Vector2(0, 0)
    world_rect = Rect2(0, 0, W, 360)
    add_bg("res://assets/environments/town_sky.png", Vector2.ZERO, -30)
    add_parallax("res://assets/environments/town_far.png", Vector2(-200, 20), 0.4, -20)
    add_bg("res://assets/environments/humanitaria_main.png", Vector2.ZERO, -10)
    add_block(Rect2(0, 150, W, 88))
    add_block(Rect2(0, 340, W, 40))
    add_block(Rect2(-40, 0, 40, 360))
    add_block(Rect2(W, 0, 40, 360))
    add_block(Rect2(18, 232, 124, 18))      # sacos de areia da fachada
    add_block(Rect2(294, 232, 124, 18))
    add_block(Rect2(988, 232, 68, 14))      # caixas de suprimentos
    add_block(Rect2(1058, 232, 48, 14))
    # fila do cadastro
    npc("civil_b", Vector2(572, 276))
    npc("mulher", Vector2(602, 276))
    npc("civil_c", Vector2(632, 276))
    npc("velho", Vector2(662, 276))
    npc("civil_a", Vector2(692, 276))
    npc("nina", Vector2(476, 262), false, false)           # voluntária da tenda
    # corrente de descarregamento do caminhão
    npc("ferraz_side", Vector2(944, 266))
    npc("civil_a_side", Vector2(972, 270), true)
    # fila da água e teatro de meias
    npc("crianca_a", Vector2(1258, 278))
    npc("civil_c", Vector2(1290, 274), true)
    npc("crianca_b", Vector2(1776, 236), false, false)
    # porta da biblioteca: Tiago confere os cartões
    npc("tiago", Vector2(268, 262))
    add_interactable(Vector2(215, 270), "c1_bib_porta", [], 34.0, _on_bib_door)
    look2(Vector2(268, 280), "c1_tiago_porta", ["c1_porta_bib_2"], ["c1_porta_bib_back"], 30.0)
    look(Vector2(480, 280), "c1_cadastro", ["c1_hum_cadastro"], 36.0)
    look(Vector2(602, 296), "c1_fila_1", ["c1_fila_1"], 24.0)
    look(Vector2(572, 296), "c1_fila_2", ["c1_fila_2"], 24.0)
    look(Vector2(662, 296), "c1_fila_velho", ["c1_fila_velho"], 24.0)
    look(Vector2(900, 270), "c1_caminhao", ["c1_caminhao_1"], 44.0)
    look(Vector2(1022, 262), "c1_caixas", ["c1_caixas"], 34.0)
    look(Vector2(1230, 262), "c1_agua", ["c1_agua_1"], 30.0)
    look(Vector2(1296, 296), "c1_agua_fila", ["c1_agua_2"], 20.0)
    look(Vector2(1420, 262), "c1_avisos", ["c1_avisos_1", "c1_avisos_2", "c1_avisos_3"], 60.0)
    look(Vector2(1522, 262), "c1_alto_falante", ["c1_alto_falante"], 30.0)
    look(Vector2(1660, 262), "c1_hum_ruina", ["c1_hum_ruina"], 50.0)
    look2(Vector2(1776, 262), "c1_teatro", ["c1_teatro_1", "c1_teatro_2"], ["c1_teatro_back"], 34.0)
    look(Vector2(1860, 262), "c1_hum_lamp", ["c1_hum_lamp"], 24.0)
    add_edge_exit("right", "praca", "from_humanitaria")


func _spawn_position() -> Vector2:
    var s := GameState.spawn
    GameState.spawn = ""
    if s == "from_library":
        return Vector2(215, 282)
    return Vector2(W - 70.0, 296)


func _start() -> void:
    AudioManager.set_muffled(false, 2.0)
    AudioManager.play_ambience("crowd", 3.0)
    start_occasional(["boom_far", "tin_clink", "far_door", "boom_far2"], 18.0, 34.0, -19.0)
    add_snow(55, 12.0, 5.0)
    apply_dusk()
    GameState.autosave("humanitaria")
    await SceneRouter.wait_reveal()
    trip_objective("Entre na biblioteca (a porta grande, a oeste).", "Volte para casa, a leste.")


func _on_bib_door(_c: int) -> void:
    if not GameState.get_flag("c1_tiago_door", false):
        await Dialogue.play("c1_porta_bib_1")
    await enter("biblioteca", "from_street")
