extends Node
## Autoload "GameSettings": todas as preferências do jogador, aplicadas de verdade e salvas em user://settings.cfg.
##   Vídeo:       modo de janela (janela / tela cheia / janela sem bordas), resolução da janela, escala de pixels
##   Desempenho:  V-Sync e limite de FPS
##   Efeitos:     partículas (neve e afins) e efeitos de iluminação
##   Áudio:       volume geral, música e efeitos
## A interface (settings_panel.gd) só chama os setters abaixo; cada setter aplica, salva e emite "changed".
## Os controles do jogo também são criados aqui, em código (o projeto roda sem configurar o Mapa de Entrada).

signal changed          # qualquer opção mudou (efeitos visuais se ajustam sozinhos)

const SETTINGS_PATH := "user://settings.cfg"
const MODE_WINDOWED := 0
const MODE_FULLSCREEN := 1
const MODE_BORDERLESS := 2
const BASE_RESOLUTIONS: Array[Vector2i] = [
    Vector2i(1280, 720), Vector2i(1366, 768), Vector2i(1600, 900), Vector2i(1920, 1080), Vector2i(2560, 1440), Vector2i(3840, 2160),
]
const LEGACY_RESOLUTIONS: Array[Vector2i] = [Vector2i(1280, 720), Vector2i(1600, 900), Vector2i(1920, 1080)]   # índice salvo por versões antigas
const FPS_OPTIONS: Array[int] = [30, 60, 120, 144, 240, 0]     # 0 = ilimitado
const DEFAULT_RESOLUTION := Vector2i(1280, 720)

var master_volume: float = 0.8
var music_volume: float = 0.8
var sfx_volume: float = 0.8
var window_mode: int = MODE_WINDOWED
var resolution: Vector2i = DEFAULT_RESOLUTION
var vsync: bool = true
var fps_limit: int = 0
var pixel_integer: bool = not is_mobile_device()   # escala inteira (pixels perfeitos) x ajustada (preenche a janela); no celular o padrão é ajustada
var fill_screen: bool = is_mobile_device()          # em telas mais largas que 16:9, o jogo ocupa a tela toda (mostra um pouco mais do cenário nas laterais)
var _menu_aspect: bool = false
var fx_snow: bool = true
var fx_lights: bool = true


## Celular ou navegador de celular.
static func is_mobile_device() -> bool:
    return OS.has_feature("mobile") or OS.has_feature("web_android") or OS.has_feature("web_ios")


func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    _setup_input()
    load_settings()
    var win := get_window()
    if win != null and not win.size_changed.is_connected(_apply_aspect):
        win.size_changed.connect(_apply_aspect)       # girar o celular / redimensionar a janela
    apply_all()      # se os barramentos de áudio ainda não existirem, o AudioManager chama apply_audio() de novo


func _notification(what: int) -> void:
    if what == NOTIFICATION_WM_CLOSE_REQUEST:
        save_settings()


# ------------------------------------------------------------------ controles
func _setup_input() -> void:
    _add_action("move_left", [KEY_A, KEY_LEFT], [JOY_BUTTON_DPAD_LEFT], [[JOY_AXIS_LEFT_X, -1.0]])
    _add_action("move_right", [KEY_D, KEY_RIGHT], [JOY_BUTTON_DPAD_RIGHT], [[JOY_AXIS_LEFT_X, 1.0]])
    _add_action("move_up", [KEY_W, KEY_UP], [JOY_BUTTON_DPAD_UP], [[JOY_AXIS_LEFT_Y, -1.0]])
    _add_action("move_down", [KEY_S, KEY_DOWN], [JOY_BUTTON_DPAD_DOWN], [[JOY_AXIS_LEFT_Y, 1.0]])
    _add_action("interact", [KEY_E, KEY_SPACE, KEY_ENTER], [JOY_BUTTON_A], [])
    _add_action("run", [KEY_SHIFT], [JOY_BUTTON_X], [])


func _add_action(action: String, keys: Array, joy_buttons: Array, joy_axes: Array) -> void:
    if not InputMap.has_action(action):
        InputMap.add_action(action, 0.5)
    for k in keys:
        var ev := InputEventKey.new()
        ev.physical_keycode = k
        InputMap.action_add_event(action, ev)
    for b in joy_buttons:
        var jb := InputEventJoypadButton.new()
        jb.button_index = b
        InputMap.action_add_event(action, jb)
    for a in joy_axes:
        var jm := InputEventJoypadMotion.new()
        jm.axis = a[0]
        jm.axis_value = a[1]
        InputMap.action_add_event(action, jm)


# ------------------------------------------------------- carregar / salvar
func load_settings() -> void:
    var cfg := ConfigFile.new()
    if cfg.load(SETTINGS_PATH) != OK:
        return
    master_volume = clampf(float(cfg.get_value("audio", "master", master_volume)), 0.0, 1.0)
    music_volume = clampf(float(cfg.get_value("audio", "music", music_volume)), 0.0, 1.0)
    sfx_volume = clampf(float(cfg.get_value("audio", "sfx", sfx_volume)), 0.0, 1.0)
    # vídeo: arquivos antigos tinham só "fullscreen" (bool) e "resolution" (índice)
    if cfg.has_section_key("video", "mode"):
        window_mode = clampi(int(cfg.get_value("video", "mode", MODE_WINDOWED)), MODE_WINDOWED, MODE_BORDERLESS)
    else:
        window_mode = MODE_FULLSCREEN if bool(cfg.get_value("video", "fullscreen", false)) else MODE_WINDOWED
    if cfg.has_section_key("video", "width") and cfg.has_section_key("video", "height"):
        var r := Vector2i(int(cfg.get_value("video", "width", DEFAULT_RESOLUTION.x)), int(cfg.get_value("video", "height", DEFAULT_RESOLUTION.y)))
        resolution = r if (r.x >= 640 and r.y >= 360) else DEFAULT_RESOLUTION
    else:
        resolution = LEGACY_RESOLUTIONS[clampi(int(cfg.get_value("video", "resolution", 0)), 0, LEGACY_RESOLUTIONS.size() - 1)]
    vsync = bool(cfg.get_value("video", "vsync", vsync))
    var f := int(cfg.get_value("video", "fps", fps_limit))
    fps_limit = f if FPS_OPTIONS.has(f) else 0
    pixel_integer = bool(cfg.get_value("video", "pixel_integer", pixel_integer))
    fill_screen = bool(cfg.get_value("video", "fill_screen", fill_screen))
    fx_snow = bool(cfg.get_value("effects", "snow", fx_snow))
    fx_lights = bool(cfg.get_value("effects", "lights", fx_lights))


func save_settings() -> void:
    var cfg := ConfigFile.new()
    cfg.set_value("audio", "master", master_volume)
    cfg.set_value("audio", "music", music_volume)
    cfg.set_value("audio", "sfx", sfx_volume)
    cfg.set_value("video", "mode", window_mode)
    cfg.set_value("video", "width", resolution.x)
    cfg.set_value("video", "height", resolution.y)
    cfg.set_value("video", "vsync", vsync)
    cfg.set_value("video", "fps", fps_limit)
    cfg.set_value("video", "pixel_integer", pixel_integer)
    cfg.set_value("video", "fill_screen", fill_screen)
    cfg.set_value("effects", "snow", fx_snow)
    cfg.set_value("effects", "lights", fx_lights)
    if cfg.save(SETTINGS_PATH) != OK:
        push_warning("GameSettings: não consegui salvar " + SETTINGS_PATH)


## Volta tudo ao padrão (vídeo, desempenho, efeitos e áudio), aplica e salva.
func reset_defaults() -> void:
    master_volume = 0.8
    music_volume = 0.8
    sfx_volume = 0.8
    window_mode = MODE_WINDOWED
    resolution = DEFAULT_RESOLUTION
    vsync = true
    fps_limit = 0
    pixel_integer = not is_mobile_device()
    fill_screen = is_mobile_device()
    fx_snow = true
    fx_lights = true
    apply_all()
    save_settings()
    changed.emit()


# ----------------------------------------------------------------- setters
func set_window_mode(mode: int) -> void:
    window_mode = clampi(mode, MODE_WINDOWED, MODE_BORDERLESS)
    apply_display()
    save_settings()
    changed.emit()


func set_resolution(r: Vector2i) -> void:
    resolution = r
    if window_mode == MODE_WINDOWED:
        apply_display()
    save_settings()
    changed.emit()


func set_vsync(on: bool) -> void:
    vsync = on
    apply_performance()
    save_settings()
    changed.emit()


func set_fps_limit(fps: int) -> void:
    fps_limit = fps if FPS_OPTIONS.has(fps) else 0
    apply_performance()
    save_settings()
    changed.emit()


func set_pixel_integer(on: bool) -> void:
    pixel_integer = on
    apply_scaling()
    save_settings()
    changed.emit()


func set_fill_screen(on: bool) -> void:
    fill_screen = on
    _apply_aspect()
    save_settings()
    changed.emit()


func set_fx_snow(on: bool) -> void:
    fx_snow = on
    save_settings()
    changed.emit()


func set_fx_lights(on: bool) -> void:
    fx_lights = on
    save_settings()
    changed.emit()


# ------------------------------------------------------------------ aplicar
func apply_all() -> void:
    apply_audio()
    apply_performance()
    apply_scaling()
    apply_display()


func apply_audio() -> void:
    _set_bus("Master", master_volume)
    _set_bus("Music", music_volume)
    _set_bus("SFX", sfx_volume)


func _set_bus(bus_name: String, linear: float) -> void:
    var idx := AudioServer.get_bus_index(bus_name)
    if idx == -1:
        return
    AudioServer.set_bus_volume_db(idx, linear_to_db(maxf(linear, 0.0001)))
    AudioServer.set_bus_mute(idx, linear <= 0.001)


## V-Sync e limite de FPS (0 = ilimitado). Com V-Sync ligado, a taxa já é limitada pelo monitor.
func apply_performance() -> void:
    if DisplayServer.get_name() != "headless":
        DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_ENABLED if vsync else DisplayServer.VSYNC_DISABLED)
    Engine.max_fps = fps_limit


## Escala de pixels do jogo: inteira (nítida, com faixas pretas se a janela não for múltipla de 640x360) ou ajustada (preenche).
func apply_scaling() -> void:
    var w := get_window()
    if w != null:
        w.set("content_scale_stretch", 1 if pixel_integer else 0)      # Window.CONTENT_SCALE_STRETCH_INTEGER / FRACTIONAL
    _apply_aspect()


## O menu principal ocupa a janela inteira (expande além de 16:9). No jogo: 16:9 com faixas pretas, ou, com "Preencher a tela",
## a altura fica fixa (360) e a largura cresce para ocupar a tela toda (celulares são mais compridos que 16:9).
func set_menu_aspect(expand: bool) -> void:
    _menu_aspect = expand
    _apply_aspect()


func _apply_aspect() -> void:
    var w := get_window()
    if w == null:
        return
    var want := Window.CONTENT_SCALE_ASPECT_KEEP
    if _menu_aspect:
        want = Window.CONTENT_SCALE_ASPECT_EXPAND
    elif fill_screen and float(w.size.x) / maxf(1.0, float(w.size.y)) > 640.0 / 360.0 + 0.01:
        want = Window.CONTENT_SCALE_ASPECT_KEEP_HEIGHT
    if w.content_scale_aspect != want:
        w.content_scale_aspect = want


## Margens seguras do celular (entalhe da câmera, cantos arredondados), em unidades do jogo (640x360). Zero fora do celular.
func safe_insets() -> Dictionary:
    var out := {"left": 0.0, "top": 0.0, "right": 0.0, "bottom": 0.0}
    if not is_mobile_device() or DisplayServer.get_name() == "headless":
        return out
    var w := get_window()
    if w == null or w.size.x <= 0:
        return out
    var sa: Rect2i = DisplayServer.get_display_safe_area()
    var scr: Vector2i = DisplayServer.screen_get_size()
    if sa.size == Vector2i.ZERO or scr.x <= 0 or scr.y <= 0:
        return out
    var f := get_viewport().get_visible_rect().size.x / float(w.size.x)
    out["left"] = clampf(float(sa.position.x) * f, 0.0, 60.0)
    out["top"] = clampf(float(sa.position.y) * f, 0.0, 40.0)
    out["right"] = clampf(float(scr.x - sa.end.x) * f, 0.0, 60.0)
    out["bottom"] = clampf(float(scr.y - sa.end.y) * f, 0.0, 40.0)
    return out


func supports_window_modes() -> bool:
    return not (OS.has_feature("web") or OS.has_feature("mobile"))


## Resoluções de janela que cabem na tela (sempre inclui a atual, mesmo que a tela tenha mudado).
func available_resolutions() -> Array[Vector2i]:
    var out: Array[Vector2i] = []
    var usable := Rect2i()
    if DisplayServer.get_name() != "headless":
        usable = DisplayServer.screen_get_usable_rect(DisplayServer.window_get_current_screen())
    for r in BASE_RESOLUTIONS:
        if usable.size == Vector2i.ZERO or (r.x <= usable.size.x and r.y + 40 <= usable.size.y):
            out.append(r)
    if out.is_empty():
        out.append(DEFAULT_RESOLUTION)
    if not out.has(resolution):
        out.append(resolution)
        out.sort_custom(func(a: Vector2i, b: Vector2i): return a.x * a.y < b.x * b.y)
    return out


## Taxa de atualização do monitor em Hz (0 se desconhecida).
func refresh_rate() -> int:
    if DisplayServer.get_name() == "headless":
        return 0
    var hz := DisplayServer.screen_get_refresh_rate(DisplayServer.window_get_current_screen())
    return int(roundf(hz)) if hz > 0.0 else 0


func apply_display() -> void:
    _apply_display_async()


func _apply_display_async() -> void:
    if DisplayServer.get_name() == "headless":
        return
    if not supports_window_modes():
        # navegador/celular: só alterna tela cheia
        DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN if window_mode != MODE_WINDOWED else DisplayServer.WINDOW_MODE_WINDOWED)
        return
    match window_mode:
        MODE_FULLSCREEN:
            DisplayServer.window_set_flag(DisplayServer.WINDOW_FLAG_BORDERLESS, false)
            # no Windows existe tela cheia exclusiva; nos demais sistemas o modo "fullscreen" já é o padrão do sistema
            var exclusive := OS.get_name() == "Windows"
            DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_EXCLUSIVE_FULLSCREEN if exclusive else DisplayServer.WINDOW_MODE_FULLSCREEN)
        MODE_BORDERLESS:
            DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)
            await get_tree().process_frame
            DisplayServer.window_set_flag(DisplayServer.WINDOW_FLAG_BORDERLESS, true)
            var scr := DisplayServer.window_get_current_screen()
            DisplayServer.window_set_position(DisplayServer.screen_get_position(scr))
            DisplayServer.window_set_size(DisplayServer.screen_get_size(scr))
        _:
            DisplayServer.window_set_flag(DisplayServer.WINDOW_FLAG_BORDERLESS, false)
            DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)
            await get_tree().process_frame
            DisplayServer.window_set_size(resolution)
            var usable := DisplayServer.screen_get_usable_rect(DisplayServer.window_get_current_screen())
            var pos := usable.position + (usable.size - resolution) / 2
            DisplayServer.window_set_position(Vector2i(maxi(pos.x, usable.position.x), maxi(pos.y, usable.position.y)))
