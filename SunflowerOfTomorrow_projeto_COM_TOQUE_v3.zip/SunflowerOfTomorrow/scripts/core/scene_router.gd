extends CanvasLayer
## Autoload "SceneRouter": troca de cenas com fade (cor configurável) e sinal de "revelação".
## Uso: SceneRouter.go("res://...tscn", fade_out, espera_no_escuro, fade_in, cor)
## Nas fases, "await SceneRouter.wait_reveal()" faz a cena esperar a tela clarear antes de começar.

signal revealed

const DARK := Color(0.015, 0.02, 0.035, 1.0)

var _rect: ColorRect
var _busy := false


func _ready() -> void:
    layer = 100
    process_mode = Node.PROCESS_MODE_ALWAYS
    _rect = ColorRect.new()
    _rect.color = DARK
    _rect.set_anchors_preset(Control.PRESET_FULL_RECT)
    _rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _rect.modulate.a = 0.0
    add_child(_rect)


func is_busy() -> bool:
    return _busy


func wait_reveal() -> void:
    if _busy:
        await revealed


func go(path: String, fade_out: float = 1.0, hold: float = 0.4, fade_in: float = 1.4, color: Color = DARK) -> void:
    if _busy:
        return
    _busy = true
    _rect.color = color
    _rect.mouse_filter = Control.MOUSE_FILTER_STOP
    var t := create_tween()
    t.tween_property(_rect, "modulate:a", 1.0, maxf(fade_out, 0.01))
    await t.finished
    get_tree().paused = false
    var err := get_tree().change_scene_to_file(path)
    if err != OK:
        push_error("SceneRouter: não consegui abrir " + path)
    await get_tree().process_frame
    await get_tree().process_frame
    await get_tree().create_timer(hold).timeout
    revealed.emit()
    var t2 := create_tween()
    t2.tween_property(_rect, "modulate:a", 0.0, maxf(fade_in, 0.01))
    await t2.finished
    _rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _busy = false
