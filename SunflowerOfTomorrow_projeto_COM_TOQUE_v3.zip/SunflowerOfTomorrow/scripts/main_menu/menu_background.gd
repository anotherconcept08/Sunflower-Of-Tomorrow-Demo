extends Control
## Fundo animado do menu principal (cenário em assets/ui/menu/sot_bg.png, 1672x941; veja tools/gerar_menu_sot.py).
##   • parallax por mapa de profundidade (balanço lento + acompanha o mouse) — shader assets/ui/menu/menu_parallax.gdshader
##   • nuvens pintadas que derivam devagar, névoa baixa sobre a cidade
##   • luzes que cintilam e piscam (lampiões, janelas) e o brilho do sol que "respira"
##   • neve em três camadas (longe / meio / perto)
##   • sombra à esquerda e vinheta para dar leitura ao texto
## Cobre a janela inteira em qualquer proporção (recorta, mantendo Alen visível). Efeitos de luz e neve obedecem às Configurações.

const SnowLayer := preload("res://scripts/world/snow_layer.gd")
const ART := preload("res://assets/ui/menu/sot_bg.png")
const DEPTH := preload("res://assets/ui/menu/sot_depth.png")
const SKY := preload("res://assets/ui/menu/sot_sky.png")
const SHADER := preload("res://assets/ui/menu/menu_parallax.gdshader")
const ART_SIZE := Vector2(1672.0, 941.0)
const MARGIN := 1.045          # a arte é ampliada um pouco para o parallax nunca mostrar a borda
const ALIGN_X := 0.88          # ao cortar nas laterais, mantém o lado direito (Alen) visível
const ALIGN_Y := 0.55
const SUN := Vector2(1195.0, 258.0)
# luzes: p = posição na arte (px), r = raio (px), c = cor, a = intensidade, d = profundidade (0 longe .. 1 perto),
#        f = velocidade da cintilação, b = chance por segundo de "piscar"
const LIGHTS := [
    {"p": Vector2(674, 616), "r": 62.0, "c": Color(1.0, 0.78, 0.42), "a": 0.55, "d": 0.50, "f": 5.2, "b": 0.05},
    {"p": Vector2(928, 538), "r": 46.0, "c": Color(1.0, 0.78, 0.45), "a": 0.45, "d": 0.42, "f": 4.1, "b": 0.07},
    {"p": Vector2(1077, 521), "r": 30.0, "c": Color(1.0, 0.80, 0.5), "a": 0.34, "d": 0.38, "f": 6.0, "b": 0.08},
    {"p": Vector2(792, 616), "r": 24.0, "c": Color(1.0, 0.72, 0.38), "a": 0.40, "d": 0.50, "f": 2.3, "b": 0.03},
    {"p": Vector2(812, 612), "r": 22.0, "c": Color(1.0, 0.72, 0.38), "a": 0.34, "d": 0.50, "f": 2.9, "b": 0.04},
    {"p": Vector2(1128, 516), "r": 20.0, "c": Color(1.0, 0.76, 0.42), "a": 0.30, "d": 0.40, "f": 3.3, "b": 0.05},
    {"p": Vector2(1166, 520), "r": 18.0, "c": Color(1.0, 0.76, 0.42), "a": 0.28, "d": 0.40, "f": 2.6, "b": 0.06},
    {"p": Vector2(1231, 517), "r": 18.0, "c": Color(1.0, 0.76, 0.42), "a": 0.26, "d": 0.40, "f": 3.8, "b": 0.05},
]

var _t := 0.0
var _mouse := Vector2.ZERO
var _offset := Vector2.ZERO
var _art_rect := Rect2()
var _art: TextureRect
var _glows: Control
var _mat: ShaderMaterial
var _glow_tex: GradientTexture2D
var _blink: Array = []
var _snow_layers: Array = []


func _ready() -> void:
    # IMPORTANTE: aqui o nó já está na árvore; set_anchors_preset() sozinho preserva o tamanho atual (0x0).
    # set_anchors_and_offsets_preset() zera também os offsets e de fato preenche o pai.
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    clip_contents = true
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    _mat = ShaderMaterial.new()
    _mat.shader = SHADER
    _mat.set_shader_parameter("depth_tex", DEPTH)
    _mat.set_shader_parameter("sky_tex", SKY)
    _art = TextureRect.new()
    _art.texture = ART
    _art.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    _art.stretch_mode = TextureRect.STRETCH_SCALE
    _art.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
    _art.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _art.material = _mat
    add_child(_art)
    # brilho aditivo: sol e luzes
    _glow_tex = GradientTexture2D.new()
    var g := Gradient.new()
    g.offsets = PackedFloat32Array([0.0, 0.35, 1.0])
    g.colors = PackedColorArray([Color(1, 1, 1, 1), Color(1, 1, 1, 0.28), Color(1, 1, 1, 0)])
    _glow_tex.gradient = g
    _glow_tex.width = 128
    _glow_tex.height = 128
    _glow_tex.fill = GradientTexture2D.FILL_RADIAL
    _glow_tex.fill_from = Vector2(0.5, 0.5)
    _glow_tex.fill_to = Vector2(1.0, 0.5)
    _glows = Control.new()
    _glows.set_anchors_preset(Control.PRESET_FULL_RECT)
    _glows.mouse_filter = Control.MOUSE_FILTER_IGNORE
    var add := CanvasItemMaterial.new()
    add.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
    _glows.material = add
    _glows.draw.connect(_draw_glows)
    add_child(_glows)
    for i in LIGHTS.size():
        _blink.append(0.0)
    # neve: três camadas com velocidade, tamanho e opacidade diferentes (profundidade)
    for cfg in [[75, 7.0, 2.5, Color(0.84, 0.90, 1.0, 0.30), 1, 1], [48, 14.0, 5.5, Color(0.92, 0.95, 1.0, 0.55), 1, 2], [16, 27.0, 10.0, Color(1.0, 1.0, 1.0, 0.85), 2, 3]]:
        var s := SnowLayer.new()
        s.setup(cfg[0], cfg[1], cfg[2], cfg[3], cfg[4], cfg[5])
        s.follow_viewport = true
        add_child(s)
        _snow_layers.append(s)
    # leitura do texto: sombra à esquerda e vinheta
    add_child(_gradient_rect(PackedFloat32Array([0.0, 0.6, 1.0]), PackedColorArray([Color(0, 0, 0, 0.60), Color(0, 0, 0, 0.22), Color(0, 0, 0, 0)]), Vector2(0, 0), Vector2(1, 0), GradientTexture2D.FILL_LINEAR, 0.62))
    var vig := _gradient_rect(PackedFloat32Array([0.55, 1.0]), PackedColorArray([Color(0, 0, 0, 0), Color(0, 0, 0, 0.62)]), Vector2(0.5, 0.5), Vector2(1.0, 0.5), GradientTexture2D.FILL_RADIAL, 1.0)
    add_child(vig)
    resized.connect(_layout)
    GameSettings.changed.connect(_apply_fx)
    _apply_fx()
    _layout()


func _gradient_rect(offsets: PackedFloat32Array, colors: PackedColorArray, from: Vector2, to: Vector2, fill: int, width_frac: float) -> Control:
    var gt := GradientTexture2D.new()
    var g := Gradient.new()
    g.offsets = offsets
    g.colors = colors
    gt.gradient = g
    gt.width = 256
    gt.height = 256
    gt.fill = fill
    gt.fill_from = from
    gt.fill_to = to
    var r := TextureRect.new()
    r.texture = gt
    r.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    r.stretch_mode = TextureRect.STRETCH_SCALE
    r.mouse_filter = Control.MOUSE_FILTER_IGNORE
    r.anchor_right = width_frac
    r.anchor_bottom = 1.0
    return r


func _apply_fx() -> void:
    _glows.visible = GameSettings.fx_lights


## Cobre a janela (escala "cover") alinhando para manter Alen à direita.
func _layout() -> void:
    var s := maxf(size.x / ART_SIZE.x, size.y / ART_SIZE.y) * MARGIN
    var sz := ART_SIZE * s
    var pos := Vector2((size.x - sz.x) * ALIGN_X, (size.y - sz.y) * ALIGN_Y)
    _art.position = pos
    _art.size = sz
    _art_rect = Rect2(pos, sz)


func _process(delta: float) -> void:
    _t += delta
    var target := Vector2.ZERO
    if size.x > 1.0 and size.y > 1.0:
        target = (get_local_mouse_position() / size - Vector2(0.5, 0.5)).clamp(Vector2(-0.5, -0.5), Vector2(0.5, 0.5))
    _mouse = _mouse.lerp(target, 1.0 - exp(-delta * 2.5))
    # balanço lento (câmera "respirando") + leve acompanhamento do mouse
    var sway := Vector2(sin(_t * 0.23) * 0.0055, sin(_t * 0.31 + 1.1) * 0.0022)
    _offset = sway + Vector2(-_mouse.x * 0.0045, -_mouse.y * 0.0018)
    _mat.set_shader_parameter("offset", _offset)
    _mat.set_shader_parameter("cloud_shift", sin(_t * 0.10) * 0.014)
    _mat.set_shader_parameter("time_s", _t)
    for i in _blink.size():
        if _blink[i] > 0.0:
            _blink[i] = maxf(0.0, float(_blink[i]) - delta)
        elif randf() < float(LIGHTS[i]["b"]) * delta:
            _blink[i] = randf_range(0.07, 0.30)
    if _glows.visible:
        _glows.queue_redraw()


func _art_to_screen(p: Vector2, depth: float) -> Vector2:
    return _art_rect.position + (p / ART_SIZE) * _art_rect.size - _offset * depth * _art_rect.size


func _draw_glows() -> void:
    var k: float = _art_rect.size.x / ART_SIZE.x
    # sol: halo largo que respira e um núcleo mais quente
    var breathe: float = 0.5 + 0.5 * sin(_t * 0.7)
    var sp := _art_to_screen(SUN, 0.0)
    _draw_glow(sp, 230.0 * k, Color(1.0, 0.55, 0.28), 0.16 + 0.05 * breathe)
    _draw_glow(sp, 90.0 * k, Color(1.0, 0.72, 0.40), 0.20 + 0.06 * breathe)
    for i in LIGHTS.size():
        var l: Dictionary = LIGHTS[i]
        var f: float = float(l["f"])
        var v: float = 0.80 + 0.13 * sin(_t * f + float(i) * 1.7) + 0.07 * sin(_t * f * 2.7 + float(i) * 0.9)
        if _blink[i] > 0.0:
            v *= 0.12
        var pos := _art_to_screen(l["p"], float(l["d"]))
        _draw_glow(pos, float(l["r"]) * k, l["c"], float(l["a"]) * v)
        _draw_glow(pos, float(l["r"]) * 0.35 * k, Color(1.0, 0.92, 0.7), float(l["a"]) * 0.8 * v)


func _draw_glow(center: Vector2, radius: float, col: Color, alpha: float) -> void:
    _glows.draw_texture_rect(_glow_tex, Rect2(center - Vector2(radius, radius), Vector2(radius, radius) * 2.0), false, Color(col.r, col.g, col.b, alpha))
