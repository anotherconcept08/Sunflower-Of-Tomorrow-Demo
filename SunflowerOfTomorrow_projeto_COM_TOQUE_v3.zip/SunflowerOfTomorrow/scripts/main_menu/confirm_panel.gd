extends Control
## Confirmação discreta. Dois jeitos de usar:
##   sim/não:      var p = ConfirmPanel.new(); p.setup("texto", "SUBSTITUIR", "VOLTAR"); add_child(p); var yes: bool = await p.answered
##   várias opções: p.setup_options("texto", ["SALVAR E SAIR", "SAIR SEM SALVAR", "CANCELAR"], 0, 2); var i: int = await p.picked
## Esc/B escolhe a opção de cancelar. Funciona com o jogo pausado (process_mode = ALWAYS).

signal answered(yes: bool)
signal picked(index: int)

const UITheme := preload("res://scripts/ui/ui_theme.gd")

var message := ""
var _labels: Array = []
var _default := 0
var _cancel := 0
var _legacy := false


func setup(msg: String, yes_label: String, no_label: String) -> void:
    message = msg
    _labels = [no_label, yes_label]       # o lado seguro (não) vem primeiro e recebe o foco
    _default = 0
    _cancel = 0
    _legacy = true


func setup_options(msg: String, labels: Array, default_index: int = 0, cancel_index: int = -1) -> void:
    message = msg
    _labels = labels
    _default = clampi(default_index, 0, maxi(labels.size() - 1, 0))
    _cancel = cancel_index if cancel_index >= 0 else _default
    _legacy = false


func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)   # já está na árvore: precisa zerar os offsets também
    var dim := ColorRect.new()
    dim.color = Color(0.02, 0.03, 0.06, 0.78)
    dim.set_anchors_preset(Control.PRESET_FULL_RECT)
    dim.mouse_filter = Control.MOUSE_FILTER_STOP
    add_child(dim)
    var center := CenterContainer.new()
    center.set_anchors_preset(Control.PRESET_FULL_RECT)
    add_child(center)
    var panel := PanelContainer.new()
    panel.add_theme_stylebox_override("panel", UITheme.box(UITheme.PANEL_BG, UITheme.PANEL_BORDER, 1, 18, 14))
    center.add_child(panel)
    var vb := VBoxContainer.new()
    vb.add_theme_constant_override("separation", 12)
    panel.add_child(vb)
    var lbl := UITheme.label(message, 12, UITheme.INK)
    lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    lbl.custom_minimum_size = Vector2(340, 0)
    vb.add_child(lbl)
    var row := HBoxContainer.new()
    row.alignment = BoxContainer.ALIGNMENT_END
    row.add_theme_constant_override("separation", 8)
    vb.add_child(row)
    var focus_btn: Button = null
    for i in _labels.size():
        var b := Button.new()
        b.text = str(_labels[i])
        UITheme.style_button(b, 12)
        b.pressed.connect(_pick.bind(i))
        row.add_child(b)
        if i == _default:
            focus_btn = b
    if focus_btn != null:
        focus_btn.grab_focus()
    modulate.a = 0.0
    create_tween().tween_property(self, "modulate:a", 1.0, 0.14)


func _pick(i: int) -> void:
    var cancel := i == _cancel
    AudioManager.play_sfx("ui_back" if cancel else "ui_select", -6.0)
    if _legacy:
        answered.emit(i == 1)
    picked.emit(i)


func _unhandled_input(event: InputEvent) -> void:
    if event.is_action_pressed("ui_cancel"):
        get_viewport().set_input_as_handled()
        _pick(_cancel)
