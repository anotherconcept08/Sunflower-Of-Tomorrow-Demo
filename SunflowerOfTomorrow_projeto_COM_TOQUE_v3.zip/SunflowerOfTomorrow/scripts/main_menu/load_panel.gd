extends Control
## Lista os 3 espaços de salvamento. Emite chosen(slot) ou closed.

signal chosen(slot: int)
signal closed

const UITheme := preload("res://scripts/ui/ui_theme.gd")

var title := "CARREGAR JOGO"
var focus_slot := 0          # espaço que recebe o foco ao abrir (0 = o primeiro com jogo salvo)



func _ready() -> void:
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)   # já está na árvore: precisa zerar os offsets também
    var dim := ColorRect.new()
    dim.color = Color(0.02, 0.03, 0.06, 0.78)
    dim.set_anchors_preset(Control.PRESET_FULL_RECT)
    dim.mouse_filter = Control.MOUSE_FILTER_STOP
    add_child(dim)
    var center := CenterContainer.new()
    center.set_anchors_preset(Control.PRESET_FULL_RECT)
    add_child(center)
    var panel := PanelContainer.new()
    panel.add_theme_stylebox_override("panel", UITheme.box(UITheme.PANEL_BG, UITheme.PANEL_BORDER, 1, 18, 14))
    center.add_child(panel)
    var vb := VBoxContainer.new()
    vb.add_theme_constant_override("separation", 6)
    panel.add_child(vb)
    vb.add_child(UITheme.label(title, 11, UITheme.GOLD))
    var first: Button = null
    var any := false
    for i in range(1, GameState.SLOT_COUNT + 1):
        var info := GameState.slot_info(i)
        var b := Button.new()
        b.custom_minimum_size = Vector2(380, 24)
        UITheme.style_button(b, 12)
        if info.is_empty():
            b.text = "ESPAÇO %d  —  vazio" % i
            b.disabled = true
            b.focus_mode = Control.FOCUS_NONE
        else:
            any = true
            b.text = "ESPAÇO %d  —  %s  ·  %s  ·  %s" % [i, GameState.scene_label(str(info.get("scene", ""))), GameState.format_playtime(float(info.get("playtime", 0.0))), GameState.format_date(float(info.get("saved_at", 0.0)))]
            b.pressed.connect(_choose.bind(i))
            if first == null or i == focus_slot:
                first = b
        vb.add_child(b)
    if not any:
        vb.add_child(UITheme.label("Nenhum salvamento ainda.", 11, UITheme.MUTED))
    var back := Button.new()
    back.text = "VOLTAR"
    back.custom_minimum_size = Vector2(380, 24)
    UITheme.style_button(back, 12)
    back.pressed.connect(_close)
    vb.add_child(back)
    if first != null:
        first.grab_focus()
    else:
        back.grab_focus()


func _choose(slot: int) -> void:
    AudioManager.play_sfx("ui_select", -6.0)
    chosen.emit(slot)


func _close() -> void:
    AudioManager.play_sfx("ui_back", -6.0)
    closed.emit()


func _unhandled_input(event: InputEvent) -> void:
    if event.is_action_pressed("ui_cancel"):
        get_viewport().set_input_as_handled()
        _close()
