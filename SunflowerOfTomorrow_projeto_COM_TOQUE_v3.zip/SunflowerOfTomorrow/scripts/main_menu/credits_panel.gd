extends Control
## Créditos: lê data/creditos.json (edite esse arquivo para colocar os nomes da equipe).
## Formato: {"titulo": "...", "secoes": [{"titulo": "...", "linhas": ["...", ...]}, ...]}. Esc/B ou VOLTAR fecha.

signal closed

const UITheme := preload("res://scripts/ui/ui_theme.gd")
const DATA_PATH := "res://data/creditos.json"


func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)   # já está na árvore: precisa zerar os offsets também
    var dim := ColorRect.new()
    dim.color = Color(0.02, 0.03, 0.06, 0.84)
    dim.set_anchors_preset(Control.PRESET_FULL_RECT)
    dim.mouse_filter = Control.MOUSE_FILTER_STOP
    add_child(dim)
    var center := CenterContainer.new()
    center.set_anchors_preset(Control.PRESET_FULL_RECT)
    add_child(center)
    var panel := PanelContainer.new()
    panel.add_theme_stylebox_override("panel", UITheme.box(UITheme.PANEL_BG, UITheme.PANEL_BORDER, 1, 22, 16))
    center.add_child(panel)
    var vb := VBoxContainer.new()
    vb.add_theme_constant_override("separation", 10)
    panel.add_child(vb)
    var data := _load()
    var title := UITheme.label(str(data.get("titulo", "CRÉDITOS")), 11, UITheme.GOLD)
    vb.add_child(title)
    var scroll := ScrollContainer.new()
    scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    scroll.custom_minimum_size = Vector2(340, clampf(get_viewport_rect().size.y - 130.0, 120.0, 230.0))
    scroll.follow_focus = true
    vb.add_child(scroll)
    var col := VBoxContainer.new()
    col.add_theme_constant_override("separation", 4)
    col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    scroll.add_child(col)
    for sec in data.get("secoes", []):
        var st := UITheme.label(str(sec.get("titulo", "")), 10, UITheme.GOLD)
        var m := MarginContainer.new()
        m.add_theme_constant_override("margin_top", 8)
        m.add_child(st)
        col.add_child(m)
        for line in sec.get("linhas", []):
            var l := UITheme.label(str(line), 11, UITheme.INK)
            l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
            l.custom_minimum_size = Vector2(320, 0)
            col.add_child(l)
    var back := Button.new()
    back.text = "VOLTAR"
    UITheme.style_button(back, 11)
    back.pressed.connect(_close)
    vb.add_child(back)
    back.grab_focus()
    modulate.a = 0.0
    create_tween().tween_property(self, "modulate:a", 1.0, 0.16)
    _auto_scroll(scroll)


func _load() -> Dictionary:
    if not FileAccess.file_exists(DATA_PATH):
        return {}
    var parsed = JSON.parse_string(FileAccess.get_file_as_string(DATA_PATH))
    return parsed if typeof(parsed) == TYPE_DICTIONARY else {}


## Rolagem lenta e contínua até o fim (se a lista for maior que a área visível).
func _auto_scroll(scroll: ScrollContainer) -> void:
    await get_tree().create_timer(1.2).timeout
    if not is_instance_valid(scroll):
        return
    var extra := scroll.get_v_scroll_bar().max_value - scroll.size.y
    if extra > 4.0:
        create_tween().tween_property(scroll, "scroll_vertical", int(extra), maxf(extra / 14.0, 1.0))


func _close() -> void:
    AudioManager.play_sfx("ui_back", -6.0)
    closed.emit()


func _unhandled_input(event: InputEvent) -> void:
    if event.is_action_pressed("ui_cancel"):
        get_viewport().set_input_as_handled()
        _close()
