extends Control
## Configurações (usadas no menu principal e no menu de pausa). Tudo é aplicado NA HORA por GameSettings e salvo em arquivo.
##   VÍDEO:     modo de janela · resolução · V-Sync · limite de FPS · escala de pixels
##   EFEITOS:   partículas (neve, folhas) · iluminação
##   ÁUDIO:     volume geral · música · efeitos
## Navegação por teclado/gamepad: cima/baixo escolhem a linha; esquerda/direita (ou confirmar) mudam o valor. Esc/B volta.

signal closed

const UITheme := preload("res://scripts/ui/ui_theme.gd")

## Linha de escolha: "<  valor  >". Serve para listas (resolução, FPS...) e para liga/desliga (dois valores).
class Stepper extends Button:
    signal stepped(index: int)
    var labels: Array = []
    var index := 0
    var locked := false

    func setup(texts: Array, idx: int) -> void:
        labels = texts
        index = clampi(idx, 0, maxi(texts.size() - 1, 0))
        _refresh()

    func set_index(i: int) -> void:
        index = clampi(i, 0, maxi(labels.size() - 1, 0))
        _refresh()

    func set_locked(on: bool) -> void:
        locked = on
        _refresh()

    func _refresh() -> void:
        text = ("<   %s   >" % str(labels[index])) if labels.size() > 0 else ""
        modulate.a = 0.45 if locked else 1.0

    func _step(d: int) -> void:
        if locked or labels.size() == 0:
            return
        index = (index + d + labels.size()) % labels.size()
        _refresh()
        AudioManager.play_sfx("ui_move", -10.0)
        stepped.emit(index)

    func _gui_input(event: InputEvent) -> void:
        if event.is_action_pressed("ui_left"):
            _step(-1)
            accept_event()
        elif event.is_action_pressed("ui_right") or event.is_action_pressed("ui_accept"):
            _step(1)
            accept_event()
        elif event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
            _step(-1 if event.position.x < size.x * 0.33 else 1)
            accept_event()

var _list: VBoxContainer
var _scroll: ScrollContainer
var _mode: Stepper
var _res: Stepper
var _vsync: Stepper
var _fps: Stepper
var _pixel: Stepper
var _fill: Stepper
var _snow: Stepper
var _lights: Stepper
var _s_master: HSlider
var _s_music: HSlider
var _s_sfx: HSlider
var _fps_hint: Label
var _res_hint: Label
var _modes: Array = []          # valores de GameSettings.MODE_* na ordem exibida
var _resolutions: Array[Vector2i] = []
var _first: Control


func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS          # funciona também com o jogo pausado
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)   # já está na árvore: precisa zerar os offsets também
    var dim := ColorRect.new()
    dim.color = Color(0.02, 0.03, 0.06, 0.84)
    dim.set_anchors_preset(Control.PRESET_FULL_RECT)
    dim.mouse_filter = Control.MOUSE_FILTER_STOP
    add_child(dim)
    var center := CenterContainer.new()
    center.set_anchors_preset(Control.PRESET_FULL_RECT)
    add_child(center)
    var panel := PanelContainer.new()
    panel.add_theme_stylebox_override("panel", UITheme.box(UITheme.PANEL_BG, UITheme.PANEL_BORDER, 1, 18, 14))
    center.add_child(panel)
    var vb := VBoxContainer.new()
    vb.add_theme_constant_override("separation", 8)
    panel.add_child(vb)
    vb.add_child(UITheme.label("CONFIGURAÇÕES", 11, UITheme.GOLD))
    _scroll = ScrollContainer.new()
    _scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    _scroll.follow_focus = true
    vb.add_child(_scroll)
    _list = VBoxContainer.new()
    _list.add_theme_constant_override("separation", 6)
    _list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _scroll.add_child(_list)
    _build_rows()
    var foot := HBoxContainer.new()
    foot.alignment = BoxContainer.ALIGNMENT_END
    foot.add_theme_constant_override("separation", 8)
    vb.add_child(foot)
    var reset := Button.new()
    reset.text = "RESTAURAR PADRÃO"
    UITheme.style_button(reset, 11)
    reset.pressed.connect(_on_reset)
    foot.add_child(reset)
    var back := Button.new()
    back.text = "VOLTAR"
    UITheme.style_button(back, 11)
    back.pressed.connect(_close)
    foot.add_child(back)
    get_viewport().size_changed.connect(_fit_height)
    _fit_height()
    _refresh_all()
    _first.grab_focus()
    modulate.a = 0.0
    create_tween().tween_property(self, "modulate:a", 1.0, 0.16)


## A área rolável acompanha a altura disponível (a lista é longa para a tela de 360 px de altura).
func _fit_height() -> void:
    var h := get_viewport_rect().size.y
    _scroll.custom_minimum_size = Vector2(440.0, clampf(h - 120.0, 120.0, 250.0))


func _build_rows() -> void:
    _section("VÍDEO")
    var texts: Array = ["Janela"]
    _modes = [GameSettings.MODE_WINDOWED]
    texts.append("Tela cheia")
    _modes.append(GameSettings.MODE_FULLSCREEN)
    if GameSettings.supports_window_modes():
        texts.append("Janela sem bordas")
        _modes.append(GameSettings.MODE_BORDERLESS)
    _mode = _stepper("Modo de janela", texts, _on_mode)
    _first = _mode
    if GameSettings.supports_window_modes():
        _resolutions = GameSettings.available_resolutions()
        var rt: Array = []
        for r in _resolutions:
            rt.append("%d × %d" % [r.x, r.y])
        _res = _stepper("Resolução da janela", rt, _on_resolution)
        _res_hint = _hint()
    _vsync = _stepper("V-Sync", ["DESLIGADO", "LIGADO"], _on_vsync)
    var ft: Array = []
    for f in GameSettings.FPS_OPTIONS:
        ft.append("Ilimitado" if f == 0 else "%d FPS" % f)
    _fps = _stepper("Limite de FPS", ft, _on_fps)
    _fps_hint = _hint()
    _pixel = _stepper("Escala de pixels", ["Inteira (mais nítida)", "Ajustada à janela"], _on_pixel)
    _hint_text("Inteira: pixels perfeitos, com faixas pretas se a janela não for múltipla de 640×360. Ajustada: preenche a janela.")
    _fill = _stepper("Preencher a tela", ["Manter 16:9 (com bordas)", "Preencher a tela"], _on_fill)
    _hint_text("Em telas mais compridas que 16:9 (a maioria dos celulares), o jogo ocupa a tela toda e mostra um pouco mais do cenário nas laterais.")
    _section("EFEITOS")
    _snow = _stepper("Partículas (neve, folhas)", ["DESLIGADO", "LIGADO"], _on_snow)
    _lights = _stepper("Efeitos de iluminação", ["DESLIGADO", "LIGADO"], _on_lights)
    _section("ÁUDIO")
    _s_master = _slider("Volume geral", GameSettings.master_volume, _on_master)
    _s_music = _slider("Música", GameSettings.music_volume, _on_music)
    _s_sfx = _slider("Efeitos sonoros", GameSettings.sfx_volume, _on_sfx)


func _section(title: String) -> void:
    var l := UITheme.label(title, 10, UITheme.GOLD)
    var m := MarginContainer.new()
    m.add_theme_constant_override("margin_top", 6)
    m.add_child(l)
    _list.add_child(m)


func _row(text: String, control: Control) -> void:
    var h := HBoxContainer.new()
    h.add_theme_constant_override("separation", 10)
    var l := UITheme.label(text, 11, UITheme.INK)
    l.custom_minimum_size = Vector2(160, 0)
    h.add_child(l)
    control.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    h.add_child(control)
    _list.add_child(h)


func _stepper(text: String, labels: Array, on_step: Callable) -> Stepper:
    var s := Stepper.new()
    UITheme.style_button(s, 11)
    s.alignment = HORIZONTAL_ALIGNMENT_CENTER
    s.custom_minimum_size = Vector2(230, 20)
    s.setup(labels, 0)
    s.stepped.connect(on_step)
    _row(text, s)
    return s


func _slider(text: String, value: float, on_change: Callable) -> HSlider:
    var s := HSlider.new()
    s.min_value = 0.0
    s.max_value = 1.0
    s.step = 0.05
    s.value = value
    s.custom_minimum_size = Vector2(230, 18)
    s.value_changed.connect(on_change)
    s.drag_ended.connect(_on_drag_ended)
    _row(text, s)
    return s


func _hint() -> Label:
    var l := UITheme.label("", 9, UITheme.MUTED)
    l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    l.custom_minimum_size = Vector2(400, 0)
    _list.add_child(l)
    return l


func _hint_text(t: String) -> void:
    _hint().text = t


## Reflete o estado atual de GameSettings nos controles (ao abrir e depois de "restaurar padrão").
func _refresh_all() -> void:
    _mode.set_index(_modes.find(GameSettings.window_mode))
    if _res != null:
        _resolutions = GameSettings.available_resolutions()
        var rt: Array = []
        for r in _resolutions:
            rt.append("%d × %d" % [r.x, r.y])
        _res.setup(rt, _resolutions.find(GameSettings.resolution))
        _res.set_locked(GameSettings.window_mode != GameSettings.MODE_WINDOWED)
        _res_hint.text = "Em tela cheia e sem bordas o jogo usa a resolução da tela." if GameSettings.window_mode != GameSettings.MODE_WINDOWED else ""
    _vsync.set_index(1 if GameSettings.vsync else 0)
    _fps.set_index(GameSettings.FPS_OPTIONS.find(GameSettings.fps_limit))
    _pixel.set_index(0 if GameSettings.pixel_integer else 1)
    _fill.set_index(1 if GameSettings.fill_screen else 0)
    _snow.set_index(1 if GameSettings.fx_snow else 0)
    _lights.set_index(1 if GameSettings.fx_lights else 0)
    _s_master.set_value_no_signal(GameSettings.master_volume)
    _s_music.set_value_no_signal(GameSettings.music_volume)
    _s_sfx.set_value_no_signal(GameSettings.sfx_volume)
    _update_fps_hint()


func _update_fps_hint() -> void:
    var hz := GameSettings.refresh_rate()
    if GameSettings.vsync:
        _fps_hint.text = "V-Sync ligado: a taxa acompanha o monitor%s." % ((" (%d Hz)" % hz) if hz > 0 else "")
    else:
        _fps_hint.text = "Sem V-Sync a imagem pode apresentar rasgos."


# --------------------------------------------------------------- reações
func _on_mode(i: int) -> void:
    GameSettings.set_window_mode(int(_modes[i]))
    if _res != null:
        _res.set_locked(GameSettings.window_mode != GameSettings.MODE_WINDOWED)
        _res_hint.text = "Em tela cheia e sem bordas o jogo usa a resolução da tela." if GameSettings.window_mode != GameSettings.MODE_WINDOWED else ""


func _on_resolution(i: int) -> void:
    GameSettings.set_resolution(_resolutions[i])


func _on_vsync(i: int) -> void:
    GameSettings.set_vsync(i == 1)
    _update_fps_hint()


func _on_fps(i: int) -> void:
    GameSettings.set_fps_limit(int(GameSettings.FPS_OPTIONS[i]))


func _on_pixel(i: int) -> void:
    GameSettings.set_pixel_integer(i == 0)


func _on_fill(i: int) -> void:
    GameSettings.set_fill_screen(i == 1)


func _on_snow(i: int) -> void:
    GameSettings.set_fx_snow(i == 1)


func _on_lights(i: int) -> void:
    GameSettings.set_fx_lights(i == 1)


func _on_master(v: float) -> void:
    GameSettings.master_volume = v
    GameSettings.apply_audio()


func _on_music(v: float) -> void:
    GameSettings.music_volume = v
    GameSettings.apply_audio()


func _on_sfx(v: float) -> void:
    GameSettings.sfx_volume = v
    GameSettings.apply_audio()


func _on_drag_ended(_changed: bool) -> void:
    AudioManager.play_sfx("ui_select", -6.0)     # amostra do volume de efeitos
    GameSettings.save_settings()


func _on_reset() -> void:
    AudioManager.play_sfx("ui_select", -6.0)
    GameSettings.reset_defaults()
    _refresh_all()


func _close() -> void:
    GameSettings.save_settings()
    AudioManager.play_sfx("ui_back", -6.0)
    closed.emit()


func _unhandled_input(event: InputEvent) -> void:
    if event.is_action_pressed("ui_cancel"):
        get_viewport().set_input_as_handled()
        _close()
