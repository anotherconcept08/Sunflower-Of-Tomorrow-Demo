extends Control
## Menu principal (inspirado na referência assets/ui/menu / tools/arte/menu_referencia.png):
##   cenário animado ao fundo (menu_background.gd), logotipo à esquerda, lista de opções com moldura deslizante (menu_list.gd)
##   e a frase de Alen no canto. Opções: CONTINUAR · NOVO JOGO · CONFIGURAÇÕES · CRÉDITOS · SAIR.
## A interface é medida pela ALTURA da janela e o fundo cobre qualquer proporção (aspecto "expandido" só enquanto o menu está aberto).
## CONTINUAR carrega o último salvamento; com mais de um salvamento, abre a lista de espaços (o antigo "CARREGAR JOGO").
## A música (assets/audio/music/menu_theme.ogg) entra em fade-in e toca em loop até iniciar o jogo.

const UITheme := preload("res://scripts/ui/ui_theme.gd")
const MenuList := preload("res://scripts/ui/menu_list.gd")
const MenuBackground := preload("res://scripts/main_menu/menu_background.gd")
const SettingsPanel := preload("res://scripts/main_menu/settings_panel.gd")
const CreditsPanel := preload("res://scripts/main_menu/credits_panel.gd")
const LoadPanel := preload("res://scripts/main_menu/load_panel.gd")
const ConfirmPanel := preload("res://scripts/main_menu/confirm_panel.gd")
const DemoInfo := preload("res://scripts/core/demo_info.gd")
const LOGO := preload("res://assets/ui/menu/sot_logo.png")
const QUOTE := "“Mesmo no inverno,\n  o girassol ainda sonha\n  com o sol.”"
const AUTHOR := "– Alen Hader"

var _bg: Control
var _logo: TextureRect
var _list: Control
var _items: Array = []
var _quote: Label
var _author: Label
var _ver: Label
var _black: ColorRect
var _busy := false
var _built := false
var _last_h := 0.0


func _ready() -> void:
    set_anchors_preset(Control.PRESET_FULL_RECT)
    GameState.playing = false
    GameSettings.set_menu_aspect(true)          # o menu preenche a janela em qualquer proporção
    _bg = MenuBackground.new()
    add_child(_bg)
    _logo = TextureRect.new()
    _logo.texture = LOGO
    _logo.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    _logo.stretch_mode = TextureRect.STRETCH_SCALE
    _logo.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
    _logo.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _logo.modulate.a = 0.0
    add_child(_logo)
    _items = [
        {"id": "continue", "text": "CONTINUAR", "disabled": not GameState.has_any_save()},
        {"id": "new", "text": "NOVO JOGO"},
        {"id": "settings", "text": "CONFIGURAÇÕES"},
        {"id": "credits", "text": "CRÉDITOS"},
    ]
    if not OS.has_feature("web"):               # no navegador não existe "sair"
        _items.append({"id": "quit", "text": "SAIR"})
    _list = MenuList.new()
    add_child(_list)
    _list.chosen.connect(_on_chosen)
    _quote = _make_quote(QUOTE)
    _author = _make_quote(AUTHOR)
    _ver = _make_quote(DemoInfo.LABEL)
    _black = ColorRect.new()
    _black.color = Color(0.015, 0.02, 0.035)
    _black.set_anchors_preset(Control.PRESET_FULL_RECT)
    _black.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(_black)
    resized.connect(_layout)
    _layout()
    _intro()
    AudioManager.stop_ambience(1.5)
    AudioManager.set_muffled(false, 0.0)
    AudioManager.set_music_intensity(1.0, 0.0)
    AudioManager.play_music("menu", 4.5)


func _exit_tree() -> void:
    GameSettings.set_menu_aspect(false)         # o jogo mantém 16:9


func _make_quote(text: String) -> Label:
    var l := Label.new()
    l.text = text
    l.add_theme_color_override("font_color", Color(0.84, 0.84, 0.88, 0.80))
    l.add_theme_constant_override("line_spacing", -1)       # linhas da frase mais juntas, como na referência
    l.modulate.a = 0.0
    l.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(l)
    return l


## Posições e tamanhos saem da ALTURA da janela (proporções medidas na referência de 1672×941).
func _layout() -> void:
    var h := size.y
    if h < 10.0:
        h = get_viewport_rect().size.y
    var logo_h := h * 0.182
    _logo.size = Vector2(logo_h * float(LOGO.get_width()) / float(LOGO.get_height()), logo_h)
    _logo.position = Vector2(h * 0.0786, h * 0.153)
    var item_h := h * 0.0446
    var gap := h * 0.0129
    var width := h * 0.34
    var font_px := maxi(int(roundf(h * 0.0278)), 8)
    if not _built:
        _built = true
        _list.setup(_items, font_px, item_h, gap, width)
    elif absf(h - _last_h) > 0.5:
        _list.resize_metrics(font_px, item_h, gap, width)
    _last_h = h
    _list.position = Vector2(h * 0.107, h * 0.395)
    _quote.add_theme_font_size_override("font_size", maxi(int(roundf(h * 0.0215)), 7))
    _author.add_theme_font_size_override("font_size", maxi(int(roundf(h * 0.0195)), 7))
    _quote.position = Vector2(h * 0.083, h * 0.735)
    _author.position = Vector2(h * 0.083, h * 0.842)
    var w := size.x if size.x > 10.0 else get_viewport_rect().size.x
    _ver.add_theme_font_size_override("font_size", maxi(int(roundf(h * 0.018)), 7))
    _ver.position = Vector2(w - _ver.get_minimum_size().x - h * 0.03, h - h * 0.05)


## Entrada em cena: a tela clareia, o logotipo surge, as opções aparecem uma a uma e por fim a frase.
func _intro() -> void:
    _set_menu_active(false)
    create_tween().tween_property(_black, "modulate:a", 0.0, 2.4).from(1.0)
    var lp := _logo.position
    _logo.position = lp + Vector2(0, 6)
    var t := create_tween().set_parallel(true)
    t.tween_property(_logo, "modulate:a", 1.0, 1.4).set_delay(0.9)
    t.tween_property(_logo, "position", lp, 1.6).set_delay(0.9).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
    t.tween_property(_quote, "modulate:a", 1.0, 1.6).set_delay(2.6)
    t.tween_property(_author, "modulate:a", 1.0, 1.6).set_delay(3.0)
    t.tween_property(_ver, "modulate:a", 0.75, 1.6).set_delay(3.2)
    _list.play_intro(1.5)
    await get_tree().create_timer(2.1).timeout
    if not _busy:
        _set_menu_active(true)
        _list.focus_first()


func _set_menu_active(on: bool) -> void:
    _list.set_active(on)


# ------------------------------------------------------------------ ações
## Atalho de TESTE: F10 no menu abre um jogo novo (em espaço livre) já na manhã do Capítulo I, sem jogar o prólogo.
func _unhandled_key_input(event: InputEvent) -> void:
    if not OS.is_debug_build():            # a demo exportada (release) não tem o atalho
        return
    if _busy or not (event is InputEventKey) or not event.pressed or event.echo or event.keycode != KEY_F10:
        return
    var free := GameState.first_free_slot()
    if free == 0:
        push_warning("F10: nenhum espaço de salvamento livre; apague um para usar o atalho.")
        return
    GameState.new_game(free)
    GameState.set_flag("prologue_done", true)
    GameState.set_flag("planted", true)
    GameState.start_chapter1()
    _launch()


func _on_chosen(id: String) -> void:
    match id:
        "continue":
            _on_continue()
        "new":
            _on_new()
        "settings":
            _open_overlay(SettingsPanel.new(), "settings")
        "credits":
            _open_overlay(CreditsPanel.new(), "credits")
        "quit":
            _on_quit()


func _on_continue() -> void:
    var used := 0
    for i in range(1, GameState.SLOT_COUNT + 1):
        if not GameState.slot_info(i).is_empty():
            used += 1
    if used <= 1:
        var n := GameState.latest_slot()
        if n > 0 and GameState.load_slot(n):
            _launch()
        return
    var p := LoadPanel.new()
    p.title = "CONTINUAR"
    p.focus_slot = GameState.latest_slot()
    _open_overlay(p, "continue")
    p.chosen.connect(_on_slot_chosen.bind(p))


func _on_slot_chosen(slot: int, p: Control) -> void:
    p.queue_free()
    if GameState.load_slot(slot):
        _launch()
    else:
        _set_menu_active(true)


func _on_new() -> void:
    var free := GameState.first_free_slot()
    if free > 0:
        GameState.new_game(free)
        _launch()
        return
    var old := GameState.oldest_slot()
    var msg := "Todos os espaços de salvamento estão em uso.\nUm novo jogo vai substituir o mais antigo (espaço %d)." % old
    var yes: bool = await _confirm(msg, "SUBSTITUIR", "VOLTAR")
    if yes:
        GameState.delete_slot(old)
        GameState.new_game(old)
        _launch()


func _open_overlay(p: Control, button_id: String) -> void:
    _set_menu_active(false)
    add_child(p)
    p.closed.connect(_on_overlay_closed.bind(p, button_id))


func _on_overlay_closed(p: Control, button_id: String) -> void:
    p.queue_free()
    _set_menu_active(true)
    _list.focus_id(button_id)


func _on_quit() -> void:
    _busy = true
    AudioManager.stop_music(1.2)
    var t := create_tween()
    t.tween_property(_black, "modulate:a", 1.0, 1.2)
    await t.finished
    get_tree().quit()


func _confirm(text: String, yes_text: String, no_text: String) -> bool:
    _set_menu_active(false)
    var p := ConfirmPanel.new()
    p.setup(text, yes_text, no_text)
    add_child(p)
    var result: bool = await p.answered
    p.queue_free()
    _set_menu_active(true)
    _list.focus_id("new")
    return result


## A música do menu some lentamente enquanto a tela escurece; o prólogo começa só com ambiente.
func _launch() -> void:
    if _busy:
        return
    _busy = true
    _set_menu_active(false)
    AudioManager.stop_music(3.5)
    var target: String = GameState.SCENES[GameState.scene_id]
    SceneRouter.go(target, 2.6, 1.0, 3.0)
