extends Node2D
## Partículas de passos (lascas de neve ou terra). Usa top_level para desenhar em coordenadas do mundo
## e show_behind_parent para ficar atrás do sprite do jogador.

var _p: Array = []      # [x, y, vx, vy, vida, vida_max, tamanho]
var _colors := {"snow": Color(0.92, 0.95, 1.0), "dirt": Color(0.40, 0.31, 0.22)}
var _surface := "wood"


func _ready() -> void:
    top_level = true
    show_behind_parent = true


func set_surface(s: String) -> void:
    _surface = s


func emit(pos: Vector2, surface: String, strong: bool) -> void:
    if not _colors.has(surface):
        return
    var n := 5 if strong else 3
    for i in n:
        _p.append([pos.x + randf_range(-3.0, 3.0), pos.y, randf_range(-16.0, 16.0), randf_range(-28.0, -10.0), 0.0, randf_range(0.30, 0.55), float(randi_range(1, 2))])


func _process(delta: float) -> void:
    if _p.is_empty():
        return
    for q in _p:
        q[4] += delta
        q[0] += q[2] * delta
        q[1] += q[3] * delta
        q[3] += 95.0 * delta
    _p = _p.filter(func(q): return q[4] < q[5])
    queue_redraw()


func _draw() -> void:
    var col: Color = _colors.get(_surface, Color.WHITE)
    for q in _p:
        var a: float = 1.0 - float(q[4]) / float(q[5])
        draw_rect(Rect2(floorf(q[0]), floorf(q[1]), q[6], q[6]), Color(col, a))
