extends CharacterBody2D
## Alen com ciclos de animação (assets/characters/alen/alen_sheet.png, gerada por tools/arte/animar_alen.py
## a partir dos sprites da ficha): idle com respiração, andar e correr em 3 direções (lado espelhado).
## Movimento com aceleração e freio, passos sincronizados com os quadros de contato e poeira nos pés.
## A origem do nó fica nos PÉS.

const WALK_SPEED := 78.0
const RUN_SPEED := 122.0
const ACCEL := 640.0
const FRICTION := 980.0
const SHEET := preload("res://assets/characters/alen/alen_sheet.png")
const FRAME_W := 40
const FRAME_H := 54
const FEET_ROW := 51                 # linha dos pés dentro do quadro
const Puffs := preload("res://scripts/player/step_puffs.gd")
# nome -> [linha da folha, nº de quadros, quadros por segundo]
const ANIMS := {
    "idle_down": [0, 2, 1.4], "idle_side": [1, 2, 1.4], "idle_up": [2, 2, 1.4],
    "walk_down": [3, 4, 7.0], "walk_side": [4, 4, 7.0], "walk_up": [5, 4, 7.0],
    "run_down": [7, 4, 11.0], "run_side": [6, 4, 11.0], "run_up": [5, 4, 11.0],
}

var controls_enabled: bool = true
var surface: String = "wood":        # "wood", "snow" ou "dirt" -> sons de passos e poeira
    set(v):
        surface = v
        if _puffs != null:
            _puffs.set_surface(v)
var facing: float = 1.0
var _view := "down"                   # "down", "side" ou "up"
var _anim := "idle_down"
var _anim_t := 0.0
var _last_idx := -1
var _running := false
var _nearest = null
var _spr: Sprite2D
var _puffs


func _ready() -> void:
    collision_layer = 1
    collision_mask = 1
    motion_mode = CharacterBody2D.MOTION_MODE_FLOATING
    var shape := CollisionShape2D.new()
    var rect := RectangleShape2D.new()
    rect.size = Vector2(16, 10)
    shape.shape = rect
    shape.position = Vector2(0, -5)
    add_child(shape)
    add_to_group("player")
    _puffs = Puffs.new()
    add_child(_puffs)
    _puffs.set_surface(surface)
    _spr = Sprite2D.new()
    _spr.texture = SHEET
    _spr.hframes = 4
    _spr.vframes = 8
    _spr.centered = false
    _spr.offset = Vector2(-FRAME_W * 0.5, -(FEET_ROW + 1))
    _spr.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
    add_child(_spr)
    _spr.frame_coords = Vector2i(0, 0)


func _physics_process(delta: float) -> void:
    var can_move := controls_enabled and not Dialogue.active
    var dir := Vector2.ZERO
    if can_move:
        dir = Input.get_vector("move_left", "move_right", "move_up", "move_down")
    _running = can_move and dir.length() > 0.1 and Input.is_action_pressed("run")
    var target := dir * (RUN_SPEED if _running else WALK_SPEED)
    var rate := ACCEL if dir.length() > 0.1 else FRICTION
    velocity = velocity.move_toward(target, rate * delta)
    move_and_slide()
    var spd := velocity.length()
    var moving := spd > 8.0
    if moving:
        if absf(velocity.x) > absf(velocity.y) * 1.15:
            _view = "side"
            facing = signf(velocity.x)
        elif absf(velocity.y) > absf(velocity.x) * 1.15:
            _view = "up" if velocity.y < 0.0 else "down"
    _animate(delta, moving, spd)
    if can_move:
        _update_nearest()
    else:
        _clear_nearest()


func _animate(delta: float, moving: bool, spd: float) -> void:
    var fast := spd > WALK_SPEED * 1.25
    var anim_name := ("run_" if (moving and fast) else "walk_" if moving else "idle_") + _view
    if anim_name != _anim:
        _anim = anim_name
        _anim_t = 0.0
        _last_idx = -1
    var info: Array = ANIMS[anim_name]
    var fps: float = info[2]
    if moving:
        var ref := RUN_SPEED if anim_name.begins_with("run") else WALK_SPEED
        fps *= clampf(spd / ref, 0.55, 1.4)
    _anim_t += delta * fps
    var frames: int = info[1]
    var idx := int(_anim_t) % frames
    if idx != _last_idx:
        _last_idx = idx
        if moving and idx % 2 == 0:        # quadros de contato (passada): som e poeira
            _on_step()
    var row: int = info[0]
    _spr.frame_coords = Vector2i(idx, row)
    _spr.flip_h = _view == "side" and facing < 0.0


func _on_step() -> void:
    AudioManager.play_sfx_group("step_" + surface, -9.0 if _running else -12.0, 0.08)
    _puffs.emit(global_position + Vector2(0, -1), surface, _running)


func _unhandled_input(event: InputEvent) -> void:
    if not controls_enabled or Dialogue.active:
        return
    if event.is_action_pressed("interact") and _nearest != null and is_instance_valid(_nearest):
        get_viewport().set_input_as_handled()
        _nearest.activate(self)


func _update_nearest() -> void:
    var best = null
    var best_d := 100000.0
    for n in get_tree().get_nodes_in_group("interactable"):
        if not n.enabled:
            continue
        var d: float = global_position.distance_to(n.global_position)
        if d <= n.radius and d < best_d:
            best_d = d
            best = n
    if best == _nearest:
        return
    _clear_nearest()
    _nearest = best
    if _nearest != null:
        _nearest.set_highlight(true)


func _clear_nearest() -> void:
    if _nearest != null and is_instance_valid(_nearest):
        _nearest.set_highlight(false)
    _nearest = null


func _draw() -> void:
    # sombra suave sob os pés (elipse achatada)
    draw_set_transform(Vector2(0, -2), 0.0, Vector2(1.0, 0.35))
    draw_circle(Vector2.ZERO, 12.0, Color(0, 0, 0, 0.20))
    draw_circle(Vector2.ZERO, 8.0, Color(0, 0, 0, 0.18))
    draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
