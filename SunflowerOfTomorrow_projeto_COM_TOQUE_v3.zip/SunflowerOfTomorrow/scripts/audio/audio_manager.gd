extends Node
## Autoload "AudioManager": música, ambientes e efeitos.
## Barramentos (criados em código): Master > Music  |  Master > SFX > Ambience
## Arquivos ausentes são ignorados em silêncio (assim os placeholders podem ser trocados à vontade).

const MUSIC := {
    "menu": "res://assets/audio/music/menu_theme.ogg",
}
const AMBIENCE := {
    "bedroom": "res://assets/audio/ambience/bedroom_room_tone.ogg",
    "town": "res://assets/audio/ambience/town_wind.ogg",
    "garden": "res://assets/audio/ambience/garden_wind.ogg",
    "radio": "res://assets/audio/ambience/src_radio.ogg",
    "crackle": "res://assets/audio/ambience/src_crackle.ogg",
    "library": "res://assets/audio/ambience/library_room.ogg",
    "crowd": "res://assets/audio/ambience/crowd_murmur.ogg",
}
const SFX := {
    "ui_move": "res://assets/audio/sfx/ui_move.wav",
    "ui_select": "res://assets/audio/sfx/ui_select.wav",
    "ui_back": "res://assets/audio/sfx/ui_back.wav",
    "text_blip": "res://assets/audio/sfx/text_blip.wav",
    "door_open": "res://assets/audio/sfx/door_open.wav",
    "door_close": "res://assets/audio/sfx/door_close.wav",
    "paper": "res://assets/audio/sfx/paper.wav",
    "cloth": "res://assets/audio/sfx/cloth.wav",
    "water": "res://assets/audio/sfx/water.wav",
    "wood_creak": "res://assets/audio/sfx/wood_creak.wav",
    "dig": "res://assets/audio/sfx/dig.wav",
    "seed_drop": "res://assets/audio/sfx/seed_drop.wav",
    "car_pass": "res://assets/audio/sfx/car_pass.wav",
    "far_door": "res://assets/audio/sfx/far_door.wav",
    "twig": "res://assets/audio/sfx/twig.wav",
    "drip": "res://assets/audio/sfx/drip.wav",
    "radio_static": "res://assets/audio/sfx/radio_static.wav",
    "final_note": "res://assets/audio/sfx/final_note.wav",
    # Capítulo I
    "boom_far": "res://assets/audio/sfx/boom_far.wav",
    "boom_far2": "res://assets/audio/sfx/boom_far2.wav",
    "metal_rattle": "res://assets/audio/sfx/metal_rattle.wav",
    "tin_clink": "res://assets/audio/sfx/tin_clink.wav",
    "console_on": "res://assets/audio/sfx/console_on.wav",
    "cart_click": "res://assets/audio/sfx/cart_click.wav",
    "boot_snow": "res://assets/audio/sfx/boot_snow.wav",
    "game_shoot": "res://assets/audio/sfx/game_shoot.wav",
    "game_hit": "res://assets/audio/sfx/game_hit.wav",
    "game_boom": "res://assets/audio/sfx/game_boom.wav",
    "game_hurt": "res://assets/audio/sfx/game_hurt.wav",
    "game_win": "res://assets/audio/sfx/game_win.wav",
    "game_lose": "res://assets/audio/sfx/game_lose.wav",
    "game_start": "res://assets/audio/sfx/game_start.wav",
    "game_alert": "res://assets/audio/sfx/game_alert.wav",
}
const SFX_GROUPS := {
    "step_wood": ["res://assets/audio/sfx/step_wood_1.wav", "res://assets/audio/sfx/step_wood_2.wav", "res://assets/audio/sfx/step_wood_3.wav"],
    "step_snow": ["res://assets/audio/sfx/step_snow_1.wav", "res://assets/audio/sfx/step_snow_2.wav", "res://assets/audio/sfx/step_snow_3.wav"],
    "step_dirt": ["res://assets/audio/sfx/step_dirt_1.wav", "res://assets/audio/sfx/step_dirt_2.wav", "res://assets/audio/sfx/step_dirt_3.wav"],
}
const SILENT_DB := -60.0

var _music: Array[AudioStreamPlayer] = []
var _amb: Array[AudioStreamPlayer] = []
var _sfx_pool: Array[AudioStreamPlayer] = []
var _music_i := 0
var _amb_i := 0
var _sfx_next := 0
var _music_id := ""
var _amb_id := ""
var _cache: Dictionary = {}
var _tweens: Dictionary = {}
var _music_lpf: AudioEffectLowPassFilter
var _music_amp: AudioEffectAmplify
var _amb_lpf: AudioEffectLowPassFilter
var _muffle_tween: Tween


func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    _ensure_bus("Music", "Master")
    _ensure_bus("SFX", "Master")
    _ensure_bus("Ambience", "SFX")
    _music_lpf = AudioEffectLowPassFilter.new()
    _music_lpf.cutoff_hz = 20500.0
    _music_amp = AudioEffectAmplify.new()
    _amb_lpf = AudioEffectLowPassFilter.new()
    _amb_lpf.cutoff_hz = 20500.0
    AudioServer.add_bus_effect(AudioServer.get_bus_index("Music"), _music_lpf)
    AudioServer.add_bus_effect(AudioServer.get_bus_index("Music"), _music_amp)
    AudioServer.add_bus_effect(AudioServer.get_bus_index("Ambience"), _amb_lpf)
    for i in 2:
        _music.append(_make_player("Music"))
        _amb.append(_make_player("Ambience"))
    for i in 8:
        _sfx_pool.append(_make_player("SFX"))
    GameSettings.apply_audio()


# ---------------------------------------------------------------- música
## Toca uma música com fade-in até level_db (0 = volume pleno; use valores negativos para música de fundo).
## Se a mesma música já estiver tocando, NÃO reinicia.
func play_music(id: String, fade_in: float = 3.0, fade_out: float = 3.0, level_db: float = 0.0) -> void:
    if id == _music_id and _music[_music_i].playing:
        return
    var stream := _load_stream(MUSIC.get(id, ""))
    _music_id = id if stream != null else ""
    _music_i = _switch_layer(_music, _music_i, stream, fade_in, fade_out, level_db)


## Fade-out e parada da música atual.
func stop_music(fade_out: float = 2.0) -> void:
    _music_id = ""
    _fade_to(_music[_music_i], SILENT_DB, fade_out, true)


## Intensidade 0..1: 0 = abafada e mais baixa (ex.: durante um diálogo), 1 = plena.
func set_music_intensity(level: float, time: float = 2.0) -> void:
    level = clampf(level, 0.0, 1.0)
    var t := create_tween().set_parallel(true)
    t.tween_property(_music_lpf, "cutoff_hz", lerpf(1400.0, 20500.0, level), time)
    t.tween_property(_music_amp, "volume_db", lerpf(-9.0, 0.0, level), time)


# -------------------------------------------------------------- ambientes
## Ambiente contínuo ("bedroom", "town", "garden"). Idempotente: repetir a chamada não reinicia.
func play_ambience(id: String, fade_in: float = 3.0, fade_out: float = 3.0) -> void:
    if id == _amb_id and _amb[_amb_i].playing:
        return
    var stream := _load_stream(AMBIENCE.get(id, ""))
    _amb_id = id if stream != null else ""
    _amb_i = _switch_layer(_amb, _amb_i, stream, fade_in, fade_out)


func stop_ambience(fade_out: float = 2.0) -> void:
    _amb_id = ""
    _fade_to(_amb[_amb_i], SILENT_DB, fade_out, true)


## Ajusta o volume do ambiente atual (usado no plano final: o vento "abaixa").
func set_ambience_level(db: float, time: float = 2.0) -> void:
    _fade_to(_amb[_amb_i], db, time)


## Abafa o ambiente (som "de dentro" do quarto). Ao sair, o vento "abre" gradualmente.
func set_muffled(on: bool, time: float = 1.5) -> void:
    if _muffle_tween != null and _muffle_tween.is_valid():
        _muffle_tween.kill()
    var target := 900.0 if on else 20500.0
    if time <= 0.0:
        _amb_lpf.cutoff_hz = target
        return
    _muffle_tween = create_tween()
    _muffle_tween.tween_property(_amb_lpf, "cutoff_hz", target, time).set_trans(Tween.TRANS_SINE)


## Fonte sonora posicional (AudioStreamPlayer2D) — some com a distância.
func make_positional(id: String, parent: Node, pos: Vector2, max_distance: float = 260.0, volume_db: float = -8.0) -> AudioStreamPlayer2D:
    var stream := _load_stream(AMBIENCE.get(id, ""))
    if stream == null:
        return null
    _prepare_loop(stream, true)
    var p := AudioStreamPlayer2D.new()
    p.stream = stream
    p.bus = "Ambience"
    p.max_distance = max_distance
    p.attenuation = 1.6
    p.volume_db = volume_db
    p.position = pos
    parent.add_child(p)
    p.play()
    return p


# ---------------------------------------------------------------- efeitos
func play_sfx(id: String, volume_db: float = 0.0, pitch: float = 1.0, jitter: float = 0.0) -> void:
    _play_stream(_load_stream(SFX.get(id, "")), volume_db, pitch, jitter)


## Sorteia uma variação do grupo (passos). Evita o efeito "metralhadora" de repetir o mesmo arquivo.
func play_sfx_group(group: String, volume_db: float = 0.0, jitter: float = 0.06) -> void:
    var list: Array = SFX_GROUPS.get(group, [])
    if list.is_empty():
        return
    _play_stream(_load_stream(list[randi() % list.size()]), volume_db, 1.0, jitter)


# ---------------------------------------------------------------- internos
func _ensure_bus(bus_name: String, send_to: String) -> void:
    if AudioServer.get_bus_index(bus_name) != -1:
        return
    AudioServer.add_bus()
    var idx := AudioServer.bus_count - 1
    AudioServer.set_bus_name(idx, bus_name)
    AudioServer.set_bus_send(idx, send_to)


func _make_player(bus: String) -> AudioStreamPlayer:
    var p := AudioStreamPlayer.new()
    p.bus = bus
    add_child(p)
    return p


func _switch_layer(players: Array[AudioStreamPlayer], cur: int, stream: AudioStream, fade_in: float, fade_out: float, level_db: float = 0.0) -> int:
    _fade_to(players[cur], SILENT_DB, fade_out, true)
    if stream == null:
        return cur
    var nxt := 1 - cur
    var p: AudioStreamPlayer = players[nxt]
    _prepare_loop(stream, true)
    p.stream = stream
    p.volume_db = SILENT_DB
    p.play()
    _fade_to(p, level_db, fade_in)
    return nxt


func _fade_to(p: AudioStreamPlayer, db: float, time: float, stop_after: bool = false) -> void:
    if _tweens.has(p) and _tweens[p] != null and (_tweens[p] as Tween).is_valid():
        (_tweens[p] as Tween).kill()
    var t := create_tween()
    _tweens[p] = t
    t.tween_property(p, "volume_db", db, maxf(time, 0.01)).set_trans(Tween.TRANS_SINE)
    if stop_after:
        t.tween_callback(p.stop)


func _prepare_loop(stream: AudioStream, loop: bool) -> void:
    if stream is AudioStreamOggVorbis:
        (stream as AudioStreamOggVorbis).loop = loop
    elif stream is AudioStreamMP3:
        (stream as AudioStreamMP3).loop = loop


func _load_stream(path: String) -> AudioStream:
    if path == "":
        return null
    if _cache.has(path):
        return _cache[path]
    if not ResourceLoader.exists(path):
        push_warning("AudioManager: arquivo ausente (ignorado): " + path)
        _cache[path] = null
        return null
    var s := load(path) as AudioStream
    _cache[path] = s
    return s


func _play_stream(stream: AudioStream, volume_db: float, pitch: float, jitter: float) -> void:
    if stream == null:
        return
    var p: AudioStreamPlayer = _sfx_pool[_sfx_next]
    _sfx_next = (_sfx_next + 1) % _sfx_pool.size()
    p.stream = stream
    p.volume_db = volume_db
    p.pitch_scale = maxf(0.1, pitch + randf_range(-jitter, jitter))
    p.play()
