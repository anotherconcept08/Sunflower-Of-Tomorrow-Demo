extends CanvasLayer
## Autoload "Dialogue": caixa de diálogo, texto digitado, escolhas e ramificações simples.
##
## Formato dos arquivos em res://data/dialogue/*.json:
##   { "id_do_dialogo": { "start": "n1", "nodes": { "n1": { ... } } } }
## Campos de um nó:
##   speaker  : nome exibido ("" = narração em primeira pessoa)
##   text     : texto (com "choices", vira o enunciado da pergunta)
##   next     : id do próximo nó ("" ou ausente = fim)
##   wait     : pausa em segundos ANTES de mostrar o nó (caixa vazia = silêncio)
##   sfx      : id de efeito sonoro tocado ao entrar no nó
##   set      : { "flag": valor }  grava flags no GameState
##   echo     : false = não repete a escolha como fala do Alen
##   face     : expressão do retrato de Alen (normal, irritado, triste, surpreso, sarcastico, envergonhado)
##   choices  : [ { text, say?, narr?, next, set?, if?, ifnot? } ]
##   branch   : { flag, equals?, yes, no }  desvio imediato, sem texto

signal finished(dialogue_id: String)

const UITheme := preload("res://scripts/ui/ui_theme.gd")
const FILES := [
    "res://data/dialogue/prologue_bedroom.json",
    "res://data/dialogue/prologue_house.json",
    "res://data/dialogue/prologue_town.json",
    "res://data/dialogue/prologue_garden.json",
    "res://data/dialogue/chapter1_casa.json",
    "res://data/dialogue/chapter1_centro.json",
    "res://data/dialogue/chapter1_praca.json",
    "res://data/dialogue/chapter1_biblioteca.json",
    "res://data/dialogue/chapter1_final.json",
]
const CHARS_PER_SECOND := 42.0
const SPEAKER_PITCH := {
    "Alen": 1.0, "Marcus": 0.8, "Eleanor": 1.18, "Pai": 0.72, "Mãe": 1.1, "": 0.92,
    "Olivier": 0.9, "Garoto": 0.9, "Helena": 1.05, "Nina": 1.2, "Tiago": 0.88, "Sd. Ferraz": 0.7, "Cb. Menezes": 0.75, "Sd. Lopes": 1.0,
    "Sd. Teixeira": 0.72, "Dona Íris": 1.08, "Seu Aurélio": 0.82, "Dona Cândida": 1.12, "Seu Tobias": 0.78, "Seu Hermes": 0.76,
    "Lúcia": 1.15, "Dona Rute": 1.06, "Pedro": 1.3, "Lia": 1.35, "Menino": 1.32, "Menina": 1.36, "Alto-falante": 0.85,
    "Senhora": 1.1, "Homem": 0.8, "Mulher": 1.12, "Velho": 0.78, "Voluntária": 1.15, "Voluntário": 0.9,
}
## Retrato de cada personagem falante (assets/ui/portraits/<arquivo>_normal.png). Quem não está aqui fala sem retrato.
const PORTRAITS := {
    "Marcus": "marcus", "Eleanor": "eleanor", "Pai": "pai", "Mãe": "mae",
    "Olivier": "olivier", "Garoto": "olivier", "Helena": "helena", "Nina": "nina", "Tiago": "tiago",
    "Sd. Ferraz": "ferraz", "Cb. Menezes": "menezes", "Sd. Lopes": "lopes", "Dona Íris": "iris", "Seu Aurélio": "aurelio",
}

var active: bool = false
var _started_ms: int = 0

var _db: Dictionary = {}
var _current_id := ""
var _node: Dictionary = {}
var _speaker := ""
var _typing := false
var _waiting := false
var _in_choice := false
var _choice_sfx := false
var _chars := 0.0
var _last_blip := -1

var _root: Control
var _panel: PanelContainer
var _name_label: Label
var _text: RichTextLabel
var _arrow: Label
var _choice_box: VBoxContainer
var _portrait_frame: PanelContainer
var _portrait: TextureRect


func _ready() -> void:
    layer = 50
    _load_all()
    _build_ui()


# ------------------------------------------------------------------ API
## Executa um diálogo e retorna quando ele termina:  await Dialogue.play("marcus_intro")
func play(dialogue_id: String) -> void:
    if active:
        return
    if not _db.has(dialogue_id):
        push_warning("Dialogue: id não encontrado: " + dialogue_id)
        return
    active = true
    _started_ms = Time.get_ticks_msec()
    _current_id = dialogue_id
    _root.visible = true
    _goto(str(_db[dialogue_id].get("start", "")))
    if active:
        await finished


# ------------------------------------------------------------- carregamento
func _load_all() -> void:
    for path in FILES:
        if not FileAccess.file_exists(path):
            push_warning("Dialogue: arquivo não encontrado: " + path)
            continue
        var parsed = JSON.parse_string(FileAccess.get_file_as_string(path))
        if typeof(parsed) != TYPE_DICTIONARY:
            push_error("Dialogue: JSON inválido em " + path)
            continue
        for id in parsed.keys():
            _db[id] = parsed[id]


# ---------------------------------------------------------------------- UI
func _build_ui() -> void:
    _root = Control.new()
    _root.set_anchors_preset(Control.PRESET_FULL_RECT)
    _root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _root.visible = false
    add_child(_root)

    _panel = PanelContainer.new()
    _panel.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
    _panel.offset_left = 28.0
    _panel.offset_right = -28.0
    _panel.offset_top = -108.0
    _panel.offset_bottom = -18.0
    _panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _panel.add_theme_stylebox_override("panel", UITheme.box(UITheme.PANEL_BG, UITheme.PANEL_BORDER, 1, 14, 8))
    _root.add_child(_panel)

    var hb := HBoxContainer.new()
    hb.add_theme_constant_override("separation", 12)
    _panel.add_child(hb)
    _portrait_frame = PanelContainer.new()
    _portrait_frame.add_theme_stylebox_override("panel", UITheme.box(Color(0.03, 0.04, 0.07, 1.0), UITheme.PANEL_BORDER, 1, 1, 1))
    _portrait = TextureRect.new()
    _portrait.custom_minimum_size = Vector2(64, 56)
    _portrait.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    _portrait.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
    _portrait.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
    _portrait_frame.add_child(_portrait)
    hb.add_child(_portrait_frame)
    var vb := VBoxContainer.new()
    vb.add_theme_constant_override("separation", 2)
    vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    hb.add_child(vb)

    _name_label = UITheme.label("", 11, UITheme.GOLD)
    vb.add_child(_name_label)

    _text = RichTextLabel.new()
    _text.bbcode_enabled = true
    _text.scroll_active = false
    _text.fit_content = false
    _text.size_flags_vertical = Control.SIZE_EXPAND_FILL
    _text.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _text.add_theme_font_size_override("normal_font_size", 13)
    _text.add_theme_color_override("default_color", UITheme.INK)
    var f := UITheme.font()
    if f != null:
        _text.add_theme_font_override("normal_font", f)
    vb.add_child(_text)

    _arrow = UITheme.label("»", 11, UITheme.GOLD)
    _arrow.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    vb.add_child(_arrow)

    _choice_box = VBoxContainer.new()
    _choice_box.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
    _choice_box.grow_horizontal = Control.GROW_DIRECTION_BEGIN
    _choice_box.grow_vertical = Control.GROW_DIRECTION_BEGIN
    _choice_box.offset_left = -28.0
    _choice_box.offset_right = -28.0
    _choice_box.offset_top = -114.0
    _choice_box.offset_bottom = -114.0
    _choice_box.add_theme_constant_override("separation", 3)
    _choice_box.visible = false
    _root.add_child(_choice_box)


# ---------------------------------------------------------------- retrato
## Rosto de Alen por expressão (normal, irritado, triste, surpreso, sarcastico, envergonhado).
## Pensamentos (speaker vazio) usam o rosto de Alen, mais apagado. NPCs usam o busto do sprite.
func _update_portrait(speaker: String, face: String) -> void:
    var path := ""
    if speaker == "Alen" or speaker == "":
        path = "res://assets/ui/portraits/alen_%s.png" % face
    elif PORTRAITS.has(speaker):
        path = "res://assets/ui/portraits/%s_normal.png" % str(PORTRAITS[speaker])
    if path != "" and ResourceLoader.exists(path):
        _portrait.texture = load(path)
        _portrait_frame.visible = true
        _portrait_frame.modulate = Color(1, 1, 1, 0.7) if speaker == "" else Color(1, 1, 1, 1)
    else:
        _portrait_frame.visible = false


# --------------------------------------------------------------- fluxo
func _goto(node_id: String) -> void:
    var nodes: Dictionary = _db[_current_id].get("nodes", {})
    var guard := 0
    while nodes.has(node_id) and nodes[node_id].has("branch") and guard < 20:
        node_id = _eval_branch(nodes[node_id]["branch"])
        guard += 1
    if node_id == "" or not nodes.has(node_id):
        _finish()
        return
    _node = nodes[node_id]
    _apply_sets(_node.get("set", {}))
    if _node.has("sfx"):
        AudioManager.play_sfx(str(_node["sfx"]), -2.0)
    var wait := float(_node.get("wait", 0.0))
    if wait > 0.0:
        _clear_choices()
        _text.text = ""
        _name_label.visible = false
        _arrow.visible = false
        _typing = false
        _waiting = false
        await get_tree().create_timer(wait).timeout
    if _node.has("choices"):
        _show_choices()
    else:
        _show_line()


func _eval_branch(b: Dictionary) -> String:
    var value = GameState.get_flag(str(b.get("flag", "")), false)
    var ok: bool
    if b.has("equals"):
        ok = str(value) == str(b["equals"])
    else:
        ok = bool(value)
    return str(b.get("yes", "")) if ok else str(b.get("no", ""))


func _show_line() -> void:
    _clear_choices()
    _speaker = str(_node.get("speaker", ""))
    var text := str(_node.get("text", ""))
    _name_label.text = _speaker
    _name_label.visible = _speaker != ""
    _name_label.add_theme_color_override("font_color", UITheme.GOLD if _speaker == "Alen" else UITheme.MUTED)
    _update_portrait(_speaker, str(_node.get("face", "normal")))
    _text.text = ("[color=#b7c2d6]%s[/color]" % text) if _speaker == "" else text
    _text.visible_characters = 0
    _chars = 0.0
    _last_blip = -1
    _typing = true
    _waiting = false
    _arrow.visible = false


func _process(delta: float) -> void:
    if not _typing:
        return
    _chars += delta * CHARS_PER_SECOND
    var total := _text.get_total_character_count()
    var shown := mini(int(_chars), total)
    _text.visible_characters = shown
    var blip := floori(shown / 3.0)
    if blip != _last_blip:
        _last_blip = blip
        AudioManager.play_sfx("text_blip", -16.0, float(SPEAKER_PITCH.get(_speaker, 1.0)), 0.04)
    if shown >= total:
        _end_typing()


func _end_typing() -> void:
    _typing = false
    _text.visible_characters = -1
    _arrow.visible = true
    _waiting = true


func _input(event: InputEvent) -> void:
    if not active or _in_choice:
        return
    var pressed := event.is_action_pressed("interact")
    if event is InputEventMouseButton:
        var mb := event as InputEventMouseButton
        if mb.pressed and mb.button_index == MOUSE_BUTTON_LEFT and Time.get_ticks_msec() - _started_ms > 180:
            pressed = true
    if not pressed:
        return
    get_viewport().set_input_as_handled()
    if _typing:
        _end_typing()      # pula a animação de escrita
    elif _waiting:
        _waiting = false
        _goto(str(_node.get("next", "")))


# ---------------------------------------------------------------- escolhas
func _show_choices() -> void:
    _in_choice = true
    _typing = false
    _waiting = false
    _arrow.visible = false
    var prompt := str(_node.get("text", ""))
    _speaker = str(_node.get("speaker", ""))
    _name_label.text = _speaker
    _name_label.visible = _speaker != ""
    _update_portrait(_speaker, str(_node.get("face", "normal")))
    _text.text = ("[color=#b7c2d6]%s[/color]" % prompt) if _speaker == "" else prompt
    _text.visible_characters = -1
    _clear_choices()
    _choice_sfx = false
    var first: Button = null
    for c in _node["choices"]:
        if c.has("if") and not bool(GameState.get_flag(str(c["if"]), false)):
            continue
        if c.has("ifnot") and bool(GameState.get_flag(str(c["ifnot"]), false)):
            continue
        var b := Button.new()
        b.text = str(c.get("text", "..."))
        UITheme.style_button(b, 12)
        b.custom_minimum_size = Vector2(250, 20)
        b.pressed.connect(_on_choice.bind(c))
        b.focus_entered.connect(_on_choice_focus)
        b.mouse_entered.connect(b.grab_focus)
        _choice_box.add_child(b)
        if first == null:
            first = b
    _choice_box.visible = true
    if first == null:
        _in_choice = false
        _goto(str(_node.get("next", "")))
        return
    first.grab_focus()
    _choice_sfx = true


func _on_choice_focus() -> void:
    if _choice_sfx:
        AudioManager.play_sfx("ui_move", -12.0)


func _on_choice(c: Dictionary) -> void:
    AudioManager.play_sfx("ui_select", -6.0)
    _apply_sets(c.get("set", {}))
    _in_choice = false
    _clear_choices()
    var say := str(c.get("say", c.get("text", "")))
    var next_id := str(c.get("next", ""))
    if _node.get("echo", true) == false or say == "":
        _goto(next_id)
        return
    var narr := bool(c.get("narr", false))
    _node = {"speaker": "" if narr else "Alen", "text": say, "next": next_id, "face": str(c.get("face", "normal"))}
    _show_line()


func _clear_choices() -> void:
    for ch in _choice_box.get_children():
        _choice_box.remove_child(ch)
        ch.queue_free()
    _choice_box.visible = false


func _apply_sets(sets: Dictionary) -> void:
    for k in sets.keys():
        GameState.set_flag(str(k), sets[k])


func _finish() -> void:
    active = false
    _typing = false
    _waiting = false
    _in_choice = false
    _clear_choices()
    _root.visible = false
    finished.emit(_current_id)
