extends RefCounted
## Cartões de capítulo (fade para preto + título). Funções estáticas que usam um nó da cena para criar tweens/timers.

const UITheme := preload("res://scripts/ui/ui_theme.gd")


## Escurece a tela, mostra "title" e "subtitle", espera "hold" segundos e devolve (a camada fica; o chamador troca de cena).
static func show_end(host: Node, title: String, subtitle: String, hold: float = 5.0) -> void:
    var cl := CanvasLayer.new()
    cl.layer = 70
    host.add_child(cl)
    var black := ColorRect.new()
    black.color = Color(0.015, 0.02, 0.035)
    black.set_anchors_preset(Control.PRESET_FULL_RECT)
    black.modulate.a = 0.0
    cl.add_child(black)
    var t := host.create_tween()
    t.tween_property(black, "modulate:a", 1.0, 3.0)
    await t.finished
    var box := VBoxContainer.new()
    box.set_anchors_preset(Control.PRESET_FULL_RECT)
    box.alignment = BoxContainer.ALIGNMENT_CENTER
    box.modulate.a = 0.0
    var l1 := UITheme.label(title, 16, UITheme.INK)
    var l2 := UITheme.label(subtitle, 10, UITheme.GOLD)
    l1.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    l2.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    box.add_child(l1)
    box.add_child(l2)
    cl.add_child(box)
    var t2 := host.create_tween()
    t2.tween_property(box, "modulate:a", 1.0, 2.0)
    await t2.finished
    await host.get_tree().create_timer(hold).timeout


## Preto instantâneo que clareia (ou escurece) em "time" segundos. Devolve o ColorRect para quem quiser removê-lo.
static func fade_layer(host: Node, to_alpha: float, time: float, start_alpha: float = -1.0) -> ColorRect:
    var cl := CanvasLayer.new()
    cl.layer = 60
    host.add_child(cl)
    var black := ColorRect.new()
    black.color = Color(0.015, 0.02, 0.035)
    black.set_anchors_preset(Control.PRESET_FULL_RECT)
    black.modulate.a = start_alpha if start_alpha >= 0.0 else (1.0 - to_alpha)
    cl.add_child(black)
    var t := host.create_tween()
    t.tween_property(black, "modulate:a", to_alpha, time)
    await t.finished
    return black
