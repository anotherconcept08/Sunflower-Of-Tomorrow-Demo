extends Control
## Lista de opções do menu (menu principal e pausa): texto à esquerda e uma moldura fina que DESLIZA até a opção em foco,
## com a seta ▷ desenhada ao lado. Teclado, mouse e gamepad; a opção ativa desliza alguns pixels e muda de cor.
## Uso: var l = MenuList.new(); l.setup([{"id": "new", "text": "NOVO JOGO"}, ...], 10, 16.0, 4.5, 121.0); add_child(l)
##      l.chosen.connect(func(id): ...)

signal chosen(id: String)
signal moved(id: String)

const COL_TEXT := Color(0.80, 0.80, 0.84)
const COL_TEXT_ON := Color(0.99, 0.96, 0.87)
const COL_DIM := Color(0.40, 0.42, 0.50)
const SLIDE := 4.0                       # quanto o texto ativo desliza para a direita

## Moldura animada (fundo escuro translúcido + contorno fino + seta).
class Frame extends Control:
    func _draw() -> void:
        var r := Rect2(Vector2.ZERO, size)
        draw_rect(r, Color(0, 0, 0, 0.32))
        var c := Color(0.93, 0.91, 0.85, 0.92)
        var a := r.position + Vector2(0.5, 0.5)
        var b := r.end - Vector2(0.5, 0.5)
        draw_polyline(PackedVector2Array([a, Vector2(b.x, a.y), b, Vector2(a.x, b.y), a]), c, 1.0, true)
        var h := size.y * 0.5
        var x0 := -size.y * 0.80
        var tri := PackedVector2Array([Vector2(x0, h - 4.5), Vector2(x0 + 7.0, h), Vector2(x0, h + 4.5), Vector2(x0, h - 4.5)])
        draw_polyline(tri, Color(0.88, 0.86, 0.80, 0.92), 1.0, true)

var _items: Array = []
var _buttons: Array = []
var _boxes: Array = []
var _frame: Frame
var _tween: Tween
var _font_px := 10
var _item_h := 16.0
var _gap := 4.5
var _width := 121.0
var _pad := 8.0
var _active := true
var _sfx := false
var _index := -1


func setup(items: Array, font_px: int, item_h: float, gap: float, width: float) -> void:
    _items = items
    _font_px = font_px
    _item_h = item_h
    _gap = gap
    _width = width
    _pad = item_h * 0.5
    _build()


## Refaz com novas medidas (janela redimensionada) mantendo a opção em foco.
func resize_metrics(font_px: int, item_h: float, gap: float, width: float) -> void:
    var keep := _index
    _index = -1
    _font_px = font_px
    _item_h = item_h
    _gap = gap
    _width = width
    _pad = item_h * 0.5
    _build()
    if keep >= 0 and keep < _buttons.size() and _active:
        _focus(keep, false)


func _build() -> void:
    for c in get_children():
        c.queue_free()
    _buttons.clear()
    _boxes.clear()
    var n := _items.size()
    custom_minimum_size = Vector2(_width, float(n) * _item_h + float(maxi(n - 1, 0)) * _gap)
    size = custom_minimum_size
    _frame = Frame.new()
    _frame.size = Vector2(_width, _item_h)
    _frame.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _frame.modulate.a = 0.0
    add_child(_frame)
    for i in n:
        var it: Dictionary = _items[i]
        var b := Button.new()
        b.flat = true
        b.text = str(it.get("text", ""))
        b.alignment = HORIZONTAL_ALIGNMENT_LEFT
        b.position = Vector2(0.0, float(i) * (_item_h + _gap))
        b.custom_minimum_size = Vector2.ZERO
        b.add_theme_font_size_override("font_size", _font_px)
        var f: Font = null
        if ResourceLoader.exists("res://assets/fonts/ui.ttf"):
            f = load("res://assets/fonts/ui.ttf") as Font
        if f != null:
            b.add_theme_font_override("font", f)
        b.add_theme_color_override("font_color", COL_TEXT)
        b.add_theme_color_override("font_hover_color", COL_TEXT_ON)
        b.add_theme_color_override("font_focus_color", COL_TEXT_ON)
        b.add_theme_color_override("font_pressed_color", COL_TEXT_ON)
        b.add_theme_color_override("font_disabled_color", COL_DIM)
        var sb := StyleBoxEmpty.new()
        sb.content_margin_left = _pad
        sb.content_margin_right = 4.0
        for st in ["normal", "hover", "pressed", "focus", "disabled"]:
            b.add_theme_stylebox_override(st, sb)
        var disabled: bool = bool(it.get("disabled", false))
        b.disabled = disabled
        b.focus_mode = Control.FOCUS_NONE if disabled else Control.FOCUS_ALL
        b.pressed.connect(_on_pressed.bind(i))
        b.focus_entered.connect(_on_focus.bind(i))
        b.mouse_entered.connect(_on_hover.bind(i))
        add_child(b)
        # o tamanho é definido DEPOIS das fontes/estilos: antes disso o Godot limita ao mínimo da fonte padrão (16 px)
        # e o botão fica mais alto que a moldura, deixando o texto deslocado para baixo.
        b.size = Vector2(_width, _item_h)
        _buttons.append(b)
        _boxes.append(sb)
    _link_focus()


## Cima/baixo percorrem só as opções habilitadas, com volta ao início.
func _link_focus() -> void:
    var ok: Array = []
    for i in _buttons.size():
        if not _buttons[i].disabled:
            ok.append(i)
    for k in ok.size():
        var b: Control = _buttons[ok[k]]
        var up: Control = _buttons[ok[(k - 1 + ok.size()) % ok.size()]]
        var dn: Control = _buttons[ok[(k + 1) % ok.size()]]
        b.focus_neighbor_top = b.get_path_to(up)
        b.focus_neighbor_bottom = b.get_path_to(dn)
        b.focus_neighbor_left = b.get_path_to(b)
        b.focus_neighbor_right = b.get_path_to(b)
        b.focus_previous = b.get_path_to(up)
        b.focus_next = b.get_path_to(dn)


func first_enabled() -> int:
    for i in _buttons.size():
        if not _buttons[i].disabled:
            return i
    return -1


func focus_first() -> void:
    var i := first_enabled()
    if i >= 0:
        _buttons[i].grab_focus()
    _sfx = true


func focus_id(id: String) -> void:
    for i in _items.size():
        if str(_items[i].get("id", "")) == id and not _buttons[i].disabled:
            _buttons[i].grab_focus()
            return


func current_id() -> String:
    if _index >= 0 and _index < _items.size():
        return str(_items[_index].get("id", ""))
    return ""


## Liga/desliga a interação (quando um painel abre por cima do menu).
func set_active(on: bool) -> void:
    _active = on
    for i in _buttons.size():
        var b: Button = _buttons[i]
        b.mouse_filter = Control.MOUSE_FILTER_STOP if on else Control.MOUSE_FILTER_IGNORE
        b.focus_mode = Control.FOCUS_ALL if (on and not b.disabled) else Control.FOCUS_NONE
    if _frame != null:
        var t := create_tween()
        t.tween_property(_frame, "modulate:a", 1.0 if on else 0.35, 0.18)


## Entrada: as opções surgem uma a uma (fade + deslize); a moldura aparece no fim.
func play_intro(delay: float = 0.0) -> void:
    for i in _buttons.size():
        var b: Button = _buttons[i]
        b.modulate.a = 0.0
        b.position.x = -14.0
        var t := create_tween()
        t.set_parallel(true)
        t.tween_property(b, "modulate:a", 1.0, 0.45).set_delay(delay + 0.09 * float(i))
        t.tween_property(b, "position:x", 0.0, 0.55).set_delay(delay + 0.09 * float(i)).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)


func _on_hover(i: int) -> void:
    if _active and not _buttons[i].disabled:
        _buttons[i].grab_focus()


func _on_focus(i: int) -> void:
    _focus(i, true)


func _focus(i: int, play_sound: bool) -> void:
    if i == _index:
        return
    var animate := _index >= 0
    if _index >= 0 and _index < _boxes.size():
        create_tween().tween_property(_boxes[_index], "content_margin_left", _pad, 0.14)
    _index = i
    create_tween().tween_property(_boxes[i], "content_margin_left", _pad + SLIDE, 0.16).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
    var target := Vector2(0.0, float(i) * (_item_h + _gap))
    if _tween != null and _tween.is_valid():
        _tween.kill()
    if animate:
        _tween = create_tween()
        _tween.tween_property(_frame, "position", target, 0.20).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
    else:
        _frame.position = target
    if _frame.modulate.a < 0.9:
        create_tween().tween_property(_frame, "modulate:a", 1.0 if _active else 0.35, 0.35)
    if play_sound and _sfx:
        AudioManager.play_sfx("ui_move", -10.0)
    moved.emit(str(_items[i].get("id", "")))


func _on_pressed(i: int) -> void:
    if not _active:
        return
    AudioManager.play_sfx("ui_select", -6.0)
    chosen.emit(str(_items[i].get("id", "")))
