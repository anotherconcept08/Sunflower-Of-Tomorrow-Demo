extends RefCounted
## Cores e estilos compartilhados da interface (apenas funções estáticas).
## Uso: const UITheme := preload("res://scripts/ui/ui_theme.gd")

const INK := Color(0.910, 0.886, 0.824)
const MUTED := Color(0.624, 0.690, 0.784)
const DIM := Color(0.290, 0.337, 0.416)
const GOLD := Color(0.914, 0.769, 0.416)
const PANEL_BG := Color(0.05, 0.08, 0.14, 0.92)
const PANEL_BORDER := Color(0.29, 0.34, 0.45, 0.9)


## Fonte de interface. Se existir assets/fonts/ui.ttf (ou .otf renomeado), ela é usada.
static func font() -> Font:
    if ResourceLoader.exists("res://assets/fonts/ui.ttf"):
        return load("res://assets/fonts/ui.ttf") as Font
    return null


static func label(text: String, size: int = 12, color: Color = INK) -> Label:
    var l := Label.new()
    l.text = text
    l.add_theme_font_size_override("font_size", size)
    l.add_theme_color_override("font_color", color)
    var f := font()
    if f != null:
        l.add_theme_font_override("font", f)
    return l


static func box(bg: Color, border: Color = Color(0, 0, 0, 0), border_w: int = 0, mx: int = 10, my: int = 6) -> StyleBoxFlat:
    var s := StyleBoxFlat.new()
    s.bg_color = bg
    s.border_color = border
    s.set_border_width_all(border_w)
    s.set_corner_radius_all(2)
    s.content_margin_left = mx
    s.content_margin_right = mx
    s.content_margin_top = my
    s.content_margin_bottom = my
    return s


static func menu_box(active: bool) -> StyleBoxFlat:
    var s := StyleBoxFlat.new()
    s.bg_color = Color(1.0, 0.92, 0.65, 0.07) if active else Color(0, 0, 0, 0)
    s.border_color = GOLD
    s.border_width_left = 2 if active else 0
    s.content_margin_left = 12
    s.content_margin_right = 8
    s.content_margin_top = 3
    s.content_margin_bottom = 3
    return s


## Botão do menu principal: texto alinhado à esquerda, barra dourada à esquerda no foco/hover.
static func style_menu_button(b: Button, size: int = 13) -> void:
    b.alignment = HORIZONTAL_ALIGNMENT_LEFT
    b.add_theme_font_size_override("font_size", size)
    var f := font()
    if f != null:
        b.add_theme_font_override("font", f)
    b.add_theme_color_override("font_color", MUTED)
    b.add_theme_color_override("font_hover_color", GOLD)
    b.add_theme_color_override("font_focus_color", GOLD)
    b.add_theme_color_override("font_pressed_color", INK)
    b.add_theme_color_override("font_disabled_color", DIM)
    var normal := menu_box(false)
    var active := menu_box(true)
    b.add_theme_stylebox_override("normal", normal)
    b.add_theme_stylebox_override("disabled", normal)
    b.add_theme_stylebox_override("hover", active)
    b.add_theme_stylebox_override("focus", active)
    b.add_theme_stylebox_override("pressed", active)


## Botão retangular (escolhas de diálogo, painéis).
static func style_button(b: Button, size: int = 12) -> void:
    b.alignment = HORIZONTAL_ALIGNMENT_LEFT
    b.add_theme_font_size_override("font_size", size)
    var f := font()
    if f != null:
        b.add_theme_font_override("font", f)
    b.add_theme_color_override("font_color", INK)
    b.add_theme_color_override("font_hover_color", GOLD)
    b.add_theme_color_override("font_focus_color", GOLD)
    b.add_theme_color_override("font_disabled_color", DIM)
    var normal := box(Color(0.07, 0.11, 0.19, 0.95), Color(0.22, 0.29, 0.42), 1, 10, 4)
    var active := box(Color(0.10, 0.15, 0.25, 1.0), GOLD, 1, 10, 4)
    b.add_theme_stylebox_override("normal", normal)
    b.add_theme_stylebox_override("disabled", normal)
    b.add_theme_stylebox_override("hover", active)
    b.add_theme_stylebox_override("focus", active)
    b.add_theme_stylebox_override("pressed", active)
