extends RefCounted
## Tela "FIM DA DEMO": agradecimento, tempo de jogo, botão de feedback (se DemoInfo.FEEDBACK_URL estiver preenchido) e voltar ao menu.
## Uso: await DemoEnd.show_panel(self)   (devolve quando o jogador escolhe VOLTAR AO MENU)

const UITheme := preload("res://scripts/ui/ui_theme.gd")
const DemoInfo := preload("res://scripts/core/demo_info.gd")


static func _fmt_time(seconds: float) -> String:
    var s := int(seconds)
    var h := s / 3600
    var m := (s % 3600) / 60
    if h > 0:
        return "%d h %02d min" % [h, m]
    return "%d min" % maxi(m, 1)


static func show_panel(host: Node) -> void:
    var cl := CanvasLayer.new()
    cl.layer = 80
    cl.process_mode = Node.PROCESS_MODE_ALWAYS
    host.add_child(cl)
    var black := ColorRect.new()
    black.color = Color(0.015, 0.02, 0.035)
    black.set_anchors_preset(Control.PRESET_FULL_RECT)
    cl.add_child(black)
    var center := CenterContainer.new()
    center.set_anchors_preset(Control.PRESET_FULL_RECT)
    cl.add_child(center)
    var vb := VBoxContainer.new()
    vb.add_theme_constant_override("separation", 10)
    vb.modulate.a = 0.0
    center.add_child(vb)

    var title := UITheme.label("FIM DA DEMO", 16, UITheme.INK)
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    vb.add_child(title)
    var sub := UITheme.label("Sunflower of Tomorrow  ·  " + DemoInfo.LABEL, 10, UITheme.GOLD)
    sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    vb.add_child(sub)

    var msg := "Obrigado por jogar!\nVocê passou cerca de %s com Alen." % _fmt_time(GameState.playtime)
    if DemoInfo.FEEDBACK_URL != "":
        msg += "\nSua opinião ajuda muito: onde travou, o que gostou e o que não entendeu."
    else:
        msg += "\nConte para quem te enviou a demo: onde travou, o que gostou e o que não entendeu."
    var body := UITheme.label(msg, 11, UITheme.MUTED)
    body.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    body.custom_minimum_size = Vector2(380, 0)
    vb.add_child(body)

    var done := [false]
    var back := Button.new()
    back.text = "VOLTAR AO MENU"
    UITheme.style_button(back, 11)
    back.pressed.connect(func(): done[0] = true)
    if DemoInfo.FEEDBACK_URL != "":
        var fb := Button.new()
        fb.text = "ABRIR FORMULÁRIO DE FEEDBACK"
        UITheme.style_button(fb, 11)
        fb.pressed.connect(func(): OS.shell_open(DemoInfo.FEEDBACK_URL))
        vb.add_child(fb)
    vb.add_child(back)

    var t := host.create_tween()
    t.tween_property(vb, "modulate:a", 1.0, 1.4)
    await t.finished
    back.grab_focus()
    while not done[0]:
        await host.get_tree().process_frame
    cl.queue_free()
