extends CanvasLayer
## Controles de toque (celular / tablet): joystick flutuante à esquerda + botões E (interagir), CORRER e PAUSA à direita.
## Eles enviam as MESMAS ações do teclado (move_*, interact, run, ui_cancel), então nenhuma fase precisa saber que existe toque.
## - Só aparecem em jogo (não no menu principal) e somem durante cutscenes, pausa e fim de demo.
## - Celular/web mobile: ligados desde o início. PC: ligam no primeiro toque na tela e desligam ao usar teclado/controle.
## - Nos diálogos os botões somem: tocar em qualquer lugar da tela avança o texto (o diálogo já aceita clique/toque).

const UITheme := preload("res://scripts/ui/ui_theme.gd")
const DemoInfo := preload("res://scripts/core/demo_info.gd")

const STICK_R := 42.0      # raio da base do joystick (em pixels do jogo: 640x360)
const KNOB_R := 16.0
const DEAD := 9.0
const ACT_R := 27.0
const RUN_R := 21.0
const PAUSE_R := 15.0
const MIN_HOLD_MS := 80    # toque curtíssimo ainda vira pelo menos ~5 quadros de "pressionado"

var touch_mode: bool = false

var _always_touch := false
var _stick_idx := -1
var _stick_origin := Vector2.ZERO
var _stick_pos := Vector2.ZERO
var _act_idx := -1
var _run_idx := -1
var _pause_idx := -1
var _run_on := false
var _cur: Dictionary = {}
var _pressed_at: Dictionary = {}
var _pending_release: Array = []
var _ctl: Control
var _show := {"stick": false, "act": false, "pause": false}
var _waiting := false     # uma cena está esperando o jogador apertar E (ex.: plantar no jardim)


func _ready() -> void:
    layer = 40
    process_mode = Node.PROCESS_MODE_ALWAYS
    _always_touch = GameSettings.is_mobile_device()
    touch_mode = _always_touch
    _ctl = Control.new()
    _ctl.set_anchors_preset(Control.PRESET_FULL_RECT)
    _ctl.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _ctl.visible = false
    _ctl.draw.connect(_draw_ui)
    add_child(_ctl)


## Texto de ajuda dos controles conforme o modo atual.
func hint_text() -> String:
    return DemoInfo.CONTROLS_TEXT_TOUCH if touch_mode else DemoInfo.CONTROLS_TEXT


# ------------------------------------------------------------ posições
func _vp() -> Vector2:
    return get_viewport().get_visible_rect().size

# Margens seguras (entalhe da câmera / cantos arredondados): os botões ficam longe delas.
func _ins() -> Dictionary:
    return GameSettings.safe_insets()

func act_center() -> Vector2:
    var s := _vp()
    var i := _ins()
    return Vector2(s.x - i.right - 58.0, s.y - i.bottom - 66.0)

func run_center() -> Vector2:
    var s := _vp()
    var i := _ins()
    return Vector2(s.x - i.right - 124.0, s.y - i.bottom - 40.0)

func pause_center() -> Vector2:
    var s := _vp()
    var i := _ins()
    return Vector2(s.x - i.right - 24.0, i.top + 24.0)

func stick_rest() -> Vector2:
    var s := _vp()
    var i := _ins()
    return Vector2(i.left + 78.0, s.y - i.bottom - 78.0)

func _in_stick_zone(p: Vector2) -> bool:
    var s := _vp()
    return p.x < s.x * 0.5 and p.y > s.y * 0.22


# ------------------------------------------------------------ contexto
func _update_context() -> void:
    var scene := get_tree().current_scene
    var in_game := scene != null and not scene.scene_file_path.ends_with("main_menu.tscn")
    var mini := get_tree().get_first_node_in_group("touch_gameplay") != null
    var player := get_tree().get_first_node_in_group("player")
    var cut: bool = player != null and not player.controls_enabled and not mini
    var talking: bool = Dialogue.active
    _waiting = get_tree().get_first_node_in_group("touch_wait_press") != null
    var ok := touch_mode and in_game and not get_tree().paused
    _show.stick = ok and not talking and not cut
    # no diálogo nenhum botão aparece (tocar em qualquer lugar avança o texto); numa espera por "E" (sem controle do jogador) só o botão E
    _show.act = ok and not talking and (_waiting or not cut)
    _show.pause = ok and not talking and not cut


func _process(_delta: float) -> void:
    _update_context()
    if not _show.stick:
        _end_stick()
    if not _show.act and _act_idx != -1:
        _end_act()
    if not _show.pause:
        _pause_idx = -1
    _set_action("run", 1.0 if (_run_on and _show.stick) else 0.0)
    _flush_releases()
    _dispatch_deferred()
    var vis: bool = touch_mode and (_show.stick or _show.act or _show.pause)
    _ctl.visible = vis
    if vis:
        _ctl.queue_redraw()


# ------------------------------------------------------------ entrada
func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        touch_mode = true
        if event.pressed:
            _touch_down(event.index, event.position)
        else:
            _touch_up(event.index)
    elif event is InputEventScreenDrag:
        if event.index == _stick_idx:
            var off: Vector2 = event.position - _stick_origin
            if off.length() > STICK_R:
                off = off.normalized() * STICK_R
            _stick_pos = _stick_origin + off
            _apply_stick()
    elif not _always_touch and (event is InputEventKey or event is InputEventJoypadButton) and event.pressed:
        touch_mode = false


func _touch_down(idx: int, p: Vector2) -> void:
    if _show.act and _act_idx == -1 and p.distance_to(act_center()) <= ACT_R * 1.3:
        _act_idx = idx
        _buzz()
        # Em diálogo, o toque já chega como clique do mouse e avança o texto; mandar a ação também pularia duas vezes.
        if not (Dialogue.active and _mouse_emulated()):
            _set_action("interact", 1.0)
        return
    if _show.stick and _run_idx == -1 and p.distance_to(run_center()) <= RUN_R * 1.3:
        _run_idx = idx
        _run_on = not _run_on
        _buzz()
        return
    if _show.pause and _pause_idx == -1 and p.distance_to(pause_center()) <= PAUSE_R * 1.8:
        _pause_idx = idx
        _set_action("ui_cancel", 1.0)
        _set_action("ui_cancel", 0.0, true)
        _buzz()
        return
    if _show.stick and _stick_idx == -1 and _in_stick_zone(p):
        var s := _vp()
        _stick_idx = idx
        var ins := _ins()
        _stick_origin = Vector2(clampf(p.x, ins.left + STICK_R + 6.0, s.x * 0.5 - 6.0), clampf(p.y, s.y * 0.22 + STICK_R, s.y - ins.bottom - STICK_R - 6.0))
        _stick_pos = _stick_origin + (p - _stick_origin).limit_length(STICK_R)
        _apply_stick()
        return
    # esperando "E" numa cena: um toque em qualquer lugar da tela também vale
    if _waiting and _show.act and _act_idx == -1:
        _act_idx = idx
        _buzz()
        _set_action("interact", 1.0)


func _touch_up(idx: int) -> void:
    if idx == _stick_idx:
        _end_stick()
    if idx == _act_idx:
        _end_act()
    if idx == _run_idx:
        _run_idx = -1
    if idx == _pause_idx:
        _pause_idx = -1


func _mouse_emulated() -> bool:
    return bool(ProjectSettings.get_setting("input_devices/pointing/emulate_mouse_from_touch", true))


func _buzz() -> void:
    Input.vibrate_handheld(12)


# ------------------------------------------------------------ joystick
func _apply_stick() -> void:
    var d := Vector2.ZERO
    var v := _stick_pos - _stick_origin
    if v.length() >= DEAD:
        var n := v.normalized()
        d.x = 1.0 if n.x >= 0.45 else (-1.0 if n.x <= -0.45 else 0.0)
        d.y = 1.0 if n.y >= 0.45 else (-1.0 if n.y <= -0.45 else 0.0)
    _set_action("move_right", 1.0 if d.x > 0.0 else 0.0)
    _set_action("move_left", 1.0 if d.x < 0.0 else 0.0)
    _set_action("move_down", 1.0 if d.y > 0.0 else 0.0)
    _set_action("move_up", 1.0 if d.y < 0.0 else 0.0)


func _end_stick() -> void:
    if _stick_idx == -1 and not _cur.get("move_left", 0.0) and not _cur.get("move_right", 0.0) and not _cur.get("move_up", 0.0) and not _cur.get("move_down", 0.0):
        return
    _stick_idx = -1
    for a in ["move_left", "move_right", "move_up", "move_down"]:
        _set_action(a, 0.0)


func _end_act() -> void:
    _act_idx = -1
    _set_action("interact", 0.0, true)


# ------------------------------------------------------------ ações
func _set_action(action: String, strength: float, min_hold: bool = false) -> void:
    var cur: float = _cur.get(action, 0.0)
    if strength > 0.0:
        if _pending_release.has(action):
            _pending_release.erase(action)
            _cur[action] = 0.0
            _send(action, false)
            cur = 0.0
        if cur <= 0.0:
            _cur[action] = 1.0
            _pressed_at[action] = Time.get_ticks_msec()
            _send(action, true)
    elif cur > 0.0:
        if min_hold:
            _release(action)
        else:
            _pending_release.erase(action)
            _cur[action] = 0.0
            _send(action, false)


func _release(action: String) -> void:
    var held := Time.get_ticks_msec() - int(_pressed_at.get(action, 0))
    if held < MIN_HOLD_MS:
        if not _pending_release.has(action):
            _pending_release.append(action)
        return
    _cur[action] = 0.0
    _send(action, false)


func _flush_releases() -> void:
    for a in _pending_release.duplicate():
        if Time.get_ticks_msec() - int(_pressed_at.get(a, 0)) >= MIN_HOLD_MS:
            _pending_release.erase(a)
            _cur[a] = 0.0
            _send(a, false)


## Movimento e correr são lidos por consulta (Input.get_vector / is_action_pressed): basta ajustar o estado da ação.
## Interagir e pausa também são lidos como EVENTO (diálogo, jogador, menu de pausa), então precisam de um InputEventAction de verdade.
## (Vários InputEventAction no mesmo quadro se perdem na Godot; por isso o joystick não usa eventos.)
const EVENT_ACTIONS := ["interact", "ui_cancel"]
var _deferred: Array = []

func _dispatch_deferred() -> void:
    var list := _deferred
    _deferred = []
    for item in list:
        var ev := InputEventAction.new()
        ev.action = item[0]
        ev.pressed = item[1]
        ev.strength = 1.0 if item[1] else 0.0
        Input.parse_input_event(ev)

func _send(action: String, pressed: bool) -> void:
    if action in EVENT_ACTIONS:
        _deferred.append([action, pressed])      # enviado no _process, nunca de dentro do tratamento de um toque
    elif pressed:
        Input.action_press(action, 1.0)
    else:
        Input.action_release(action)


# ------------------------------------------------------------ desenho
func _draw_ui() -> void:
    if _show.stick:
        var on := _stick_idx != -1
        var o := _stick_origin if on else stick_rest()
        var k := _stick_pos if on else o
        _ctl.draw_circle(o, STICK_R, Color(0.06, 0.08, 0.13, 0.42 if on else 0.30))
        _ctl.draw_arc(o, STICK_R, 0.0, TAU, 48, Color(0.84, 0.86, 0.92, 0.65 if on else 0.40), 1.5, true)
        _ctl.draw_circle(k, KNOB_R, Color(0.92, 0.94, 0.98, 0.72 if on else 0.45))
        _button(run_center(), RUN_R, "CORRER", 7, _run_on, _run_idx != -1)
    if _show.act:
        _button(act_center(), ACT_R, "E", 18, false, _act_idx != -1)
    if _show.pause:
        var c := pause_center()
        _button(c, PAUSE_R, "", 8, false, _pause_idx != -1)
        _ctl.draw_rect(Rect2(c + Vector2(-4.5, -5.0), Vector2(3.0, 10.0)), Color(0.92, 0.94, 0.98, 0.8))
        _ctl.draw_rect(Rect2(c + Vector2(1.5, -5.0), Vector2(3.0, 10.0)), Color(0.92, 0.94, 0.98, 0.8))


func _button(c: Vector2, r: float, label: String, size: int, toggled: bool, held: bool) -> void:
    var fill := Color(0.06, 0.08, 0.13, 0.40)
    var line := Color(0.84, 0.86, 0.92, 0.55)
    if toggled:
        fill = Color(0.80, 0.62, 0.20, 0.55)
        line = Color(1.0, 0.86, 0.45, 0.85)
    if held:
        fill = fill.lightened(0.25)
        fill.a = 0.7
    _ctl.draw_circle(c, r, fill)
    _ctl.draw_arc(c, r, 0.0, TAU, 40, line, 1.5, true)
    if label != "":
        var f: Font = UITheme.font()
        if f == null:
            f = ThemeDB.fallback_font
        var w := f.get_string_size(label, HORIZONTAL_ALIGNMENT_LEFT, -1, size).x
        var base := c.y + (f.get_ascent(size) - f.get_descent(size)) * 0.5
        _ctl.draw_string(f, Vector2(c.x - w * 0.5, base), label, HORIZONTAL_ALIGNMENT_LEFT, -1, size, Color(0.95, 0.96, 1.0, 0.92))
