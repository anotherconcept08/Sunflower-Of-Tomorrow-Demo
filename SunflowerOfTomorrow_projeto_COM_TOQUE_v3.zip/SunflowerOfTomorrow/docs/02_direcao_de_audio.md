# PARTE C — Direção de áudio

> **Nota honesta sobre a sua música:** não consigo *ouvir* o arquivo; medi apenas duração (4:13), formato (MP3, 48 kHz, estéreo, ~192 kbps) e nível (começa em torno de –22 dB RMS e termina mais baixo, em torno de –28 dB). As escolhas de loop abaixo se baseiam nisso. Se o final da faixa não for um decaimento natural, ajuste o crossfade (`tools/refazer_loop_menu.py ... 8`).

## 1. Princípios
1. **O som é narrativa**, não preenchimento: o prólogo tem música em **um único lugar** (o menu) e **uma nota** no final.
2. **Silêncio planejado:** quarto inteiro, jardim inteiro, plantio e imagem final têm *apenas ambiente*.
3. **Camadas poucas e legíveis:** nunca mais de ~4 camadas simultâneas.
4. **Interior ≠ exterior:** o quarto é *abafado* (filtro passa-baixa a 900 Hz no barramento Ambience); ao sair, o filtro “abre” em 4 s.

## 2. Camadas, prioridade e volume relativo
| Prioridade | Camada | Barramento | Nível aprox. | Observação |
|---|---|---|---|---|
| 1 | Interface e blips de fala | SFX | –6 a –16 dB | `ui_move` –10, `ui_select` –6, `text_blip` –16 (tom por personagem) |
| 2 | Ações do jogador | SFX | –12 a –2 dB | passos –12 (3 variações, jitter ±0,08), objetos –10 a –2 |
| 3 | Ambiente contínuo | Ambience | 0 dB (arquivo já normalizado baixo) | um por vez; crossfade 3–5 s |
| 4 | Fontes posicionais | Ambience | –10 a –12 dB | `AudioStreamPlayer2D` com `max_distance` 180–200 px |
| 5 | Ocasionais ao longe | SFX | –14 a –16 dB | carro, porta, galho; intervalo aleatório |
| 6 | Música | Music | 0 dB (barramento) | só no menu; nota final em –4 dB (SFX) |

## 3. Som por ambiente
| Cena | Contínuo | Ocasionais | Do jogador | Música | Notas |
|---|---|---|---|---|---|
| **Menu** | — (ambiente parado) | — | `ui_move`, `ui_select`, `ui_back` | `menu_theme` em loop, fade-in 4,5 s | Ao iniciar: música cai em 3,5 s *antes* do quarto aparecer |
| **1. Quarto (abertura)** | `bedroom_room_tone` (abafado) | estalo de madeira aos ~3 s (–14 dB) | — | **nenhuma** | Título surge em silêncio |
| **2. Acordar** | idem | goteiras nos baldes da cozinha (`drip`, atenuadas pela distância) | passos de madeira; papel (caderno/foto); tecido (casaco); água (planta); blips | **nenhuma** | Sons de interface dos diálogos discretos |
| **3. Porta** | cidade sobe em 5 s; abafamento abre em 4 s | — | rangido de porta –2 dB | **nenhuma** | Fade para luz fria |
| **4. Cidade** | `town_wind` | `car_pass`, `far_door` a cada 14–26 s; rádio (`src_radio`) e lenha (`src_crackle`) posicionais | passos de neve | **nenhuma** (reserva: guitarra esparsa, ver §5) | Volume do rádio varia com a distância |
| **5. Jardim** | `garden_wind` (vento + folhas) | `twig` a cada 18–34 s | passos de terra | **nenhuma** | Identidade: mais vento, menos humano |
| **6. Semente** | vento desce a –18 dB em 6 s no final | — | `dig`, `seed_drop` | só `final_note` | Ver §6 |

## 4. Lista de efeitos (placeholders gerados; troque mantendo os nomes)
| Arquivo | Uso |
|---|---|
| `ui_move.wav`, `ui_select.wav`, `ui_back.wav` | navegar, confirmar, voltar (curtos, secos, sem “brilho” de fantasia) |
| `text_blip.wav` | tique de digitação (pitch: Alen 1,0 · Marcus 0,8 · Eleanor 1,18) |
| `door_open.wav`, `door_close.wav` | porta do quarto |
| `paper.wav` | caderno, foto, edital, pacote, lata |
| `cloth.wav` | casaco, levantar |
| `water.wav` | regar a muda |
| `wood_creak.wav` | estalo do quarto |
| `step_wood_1-3`, `step_snow_1-3`, `step_dirt_1-3` | passos por superfície |
| `dig.wav`, `seed_drop.wav` | plantar |
| `car_pass.wav`, `far_door.wav`, `twig.wav` | ocasionais |
| `drip.wav` | goteiras da cozinha |
| `radio_static.wav` | chiado ocasional do rádio da sala (mais baixo com a distância e se o volume foi abaixado) |
| `final_note.wav` | a nota final (sinusoides em ré, ataque suave, 8 s) |
| `ambience/bedroom_room_tone`, `town_wind`, `garden_wind`, `src_radio`, `src_crackle` (.ogg) | loops de 8–14 s sem emenda |

## 5. Direção musical (para um compositor)
- **Identidade:** uma janela fria com uma lâmpada quente do outro lado. Intimidade, espaço, ar entre as notas.
- **Instrumentos:** piano próximo com martelos audíveis e pedal; guitarra limpa em dedilhado, reverb curto; pads texturais quase inaudíveis; ruídos orgânicos (respiração do piano, madeira, vento filtrado).
- **Andamento:** 56–66 BPM, compasso livre; melodias **incompletas**, notas sustentadas, pausas de 2–4 s; modo menor com sexta maior (dórico) ou ambíguo.
- **Imperfeições:** uma nota levemente atrasada, um pedal que range. Nada de percussão.
- **Intensidade (0–5):** Menu 3 · Quarto 0 · Porta 0 · Cidade 0–1 (reserva) · Jardim 0 · Plantio 0 · Final 1 (uma nota).
- **Reserva opcional (não implementada):** “Cidade” — 3 notas de guitarra espaçadas, só *depois* da conversa com Marcus; entraria com `AudioManager.play_music("town", 6.0)` e sairia ao entrar no jardim. O código já aceita novas entradas no dicionário `MUSIC`.
- **Referências sem copiar:** descreva ao compositor “piano íntimo, pouca melodia, muito silêncio, sem cordas épicas”. Não passe músicas protegidas como alvo de imitação.

### Menu
Sua faixa: loop de **4:07** (a faixa de 4:13 com 6 s de crossfade fim→início). Fade-in 4,5 s. Ao entrar no jogo, `stop_music(3.5)`; a tela escurece em 2,6 s, fica 1 s no escuro e o quarto clareia em 3 s **só com ambiente**.

## 6. Implementação na Godot (arquivo: `scripts/audio/audio_manager.gd`)
**Organização:** `assets/audio/music|ambience|sfx`. Ambiente e música usam 2 `AudioStreamPlayer` cada (crossfade); efeitos usam um *pool* de 8; sons à distância usam `AudioStreamPlayer2D`. Barramentos criados no código: `Music`, `SFX`, `Ambience` (envia para `SFX`). O volume geral/música/efeitos do menu mexe nesses barramentos.

```gdscript
AudioManager.play_music("menu", 4.5)            # inicia com fade-in; repetir NÃO reinicia (mesma música já tocando)
AudioManager.stop_music(3.5)                     # fade-out e parada
AudioManager.set_music_intensity(0.3, 2.0)       # 0..1: abafa (passa-baixa) e abaixa; 1 = plena
AudioManager.play_ambience("town", 5.0)          # ambiente com crossfade; idempotente
AudioManager.set_muffled(true, 0.0)              # som "de dentro"; set_muffled(false, 4.0) abre
AudioManager.play_sfx("paper", -4.0)             # efeito ao interagir
AudioManager.play_sfx_group("step_snow", -12.0)  # variação aleatória (passos)
AudioManager.make_positional("radio", self, Vector2(400, 190), 200.0, -10.0)  # AudioStreamPlayer2D
```
**Como o fade funciona:** `_fade_to()` cria um `Tween` em `volume_db` e guarda uma referência por player, matando o anterior (evita brigas). **Como evita reinício:** `play_music()` compara o id com o que já toca e o player está `playing`.
**Loop:** `AudioStreamOggVorbis.loop = true` é ligado em código antes de tocar (vale para `.ogg`; `AudioStreamMP3` também tem `loop`). Se preferir, marque *Loop* no painel Importar do `.ogg`.

### Como o loop do menu foi construído
1. Decodifica a música (48 kHz estéreo). 2. Pega os **6 s finais** e os **6 s iniciais** e mistura com *crossfade de potência constante* (cos/sen). 3. O arquivo novo = *[esse trecho misturado] + [o meio original]*. O último sample do arquivo é exatamente o anterior ao primeiro sample do trecho misturado, então **fim → início é contínuo** (medido: salto 0,00044, igual ao salto entre amostras vizinhas da música original). 4. Exporta `.ogg`. Para outra música: `python3 tools/refazer_loop_menu.py entrada.mp3 saida.ogg 6`.

### Silêncio e transição entre ambientes
Cada fase chama `play_ambience("...")`; a anterior faz fade-out no mesmo instante (`_switch_layer`). `set_muffled` controla se o ambiente soa “de dentro” ou “de fora”. Na cena 6, `set_ambience_level(-18, 6)` leva o vento quase a zero antes da nota final.

## Expansão: rádio, sala e música baixinha
- **Rádio (sala):** fonte posicional (`AudioStreamPlayer2D`, alcance 380 px) que murmura como voz distante; o texto das notícias aparece como **legenda** que fica nítida de perto (de longe só algumas palavras, o resto vira “···”) e some durante diálogos. O som do rádio é um **placeholder** (ruído com cadência de fala): troque `assets/audio/ambience/src_radio.ogg` por gravação real de locutor, se quiser.
- **Escolha do rádio:** “Abaixar o volume” derruba o som em ~12 dB e encurta o alcance da legenda; muda a primeira fala do pai.
- **Música:** só o quarto, o desabamento, a planta e o final ficam sem música. Na **sala e na cozinha** a faixa do menu toca **bem baixa e abafada** (nível –22 dB, filtro passa-baixa; `AudioManager.play_music("menu", 7.0, 4.0, -22.0)`); ao sair da casa ela some em 3 s.
- **Casa viva:** rangidos e porta distante a cada 24–46 s (–24 dB), goteiras nos baldes, estalo do fogão posicional, vento posicional no desabamento, e o ambiente **abre** (some o abafamento) ao chegar perto do desabamento.
