# Menu principal, Configurações e Pausa (reformulação)

> **Estado:** escrito e verificado só por scripts estáticos (`tools/verificar_menu.py`, `verificar_projeto.py`, `verificar_cap1.py`) e por uma simulação em Python do layout. **Nada foi executado na Godot** (não havia o programa nem rede neste ambiente). Veja a seção 7 antes de confiar em qualquer item como “funcionando”.

## 1. O que mudou
| Parte | Arquivo(s) | Resumo |
|---|---|---|
| Menu principal | `scripts/main_menu/main_menu.gd` | nova identidade da referência; opções CONTINUAR · NOVO JOGO · CONFIGURAÇÕES · CRÉDITOS · SAIR; logotipo, frase de Alen e entrada animada |
| Fundo animado | `scripts/main_menu/menu_background.gd`, `assets/ui/menu/menu_parallax.gdshader`, `sot_bg.png`, `sot_depth.png`, `sot_sky.png` | parallax por profundidade, nuvens, névoa, luzes que piscam, sol que respira, neve em 3 camadas |
| Lista de opções | `scripts/ui/menu_list.gd` (novo, reutilizável) | moldura que desliza até a opção em foco, texto que desliza e muda de cor, seta ▷, teclado/mouse/gamepad |
| Configurações | `scripts/main_menu/settings_panel.gd` (reescrito) + `scripts/core/game_settings.gd` (reescrito) | vídeo, desempenho, efeitos e áudio; aplica na hora e salva |
| Pausa | `scripts/ui/pause_menu.gd` (reescrito) | CONTINUAR · CONFIGURAÇÕES · VOLTAR AO MENU PRINCIPAL · SAIR DO JOGO, com confirmação |
| Confirmações | `scripts/main_menu/confirm_panel.gd` | agora aceita 2 ou mais opções (`setup_options` + sinal `picked`), mantendo `setup`/`answered` |
| Créditos | `scripts/main_menu/credits_panel.gd` + `data/creditos.json` | **edite o JSON** para colocar os nomes da equipe |
| Progresso não salvo | `scripts/save_system/game_state.gd` (`dirty`) | vira `true` quando uma flag muda e `false` ao salvar/carregar/novo jogo |
| Efeitos que obedecem às opções | `snow_layer.gd`, `level_base.gd` (`fx_lights()`), `town.gd`, `house.gd`, `ch1_*.gd` | neve/folhas e brilhos desenhados em código ligam/desligam |

Arte: `tools/gerar_menu_sot.py` reconstrói o cenário **limpo** (sem logotipo, opções e frase embutidos) a partir da referência (`tools/arte/menu_referencia.png`), extrai o logotipo com transparência e gera o mapa de profundidade e a máscara do céu.

## 2. Menu principal
- **Animações:** neve contínua (3 camadas), nuvens pintadas derivando (±1,4% da largura, ciclo ~60 s), névoa lenta, 8 luzes (lampiões e janelas) que cintilam e “piscam” de vez em quando, brilho do sol que respira, balanço lento de câmera + leve acompanhamento do mouse (parallax por profundidade).
- **Interface:** na entrada a tela clareia, o logotipo sobe, as opções surgem uma a uma, a moldura desliza entre as opções (0,2 s) e a frase aparece por último.
- **Resoluções/proporções:** posições e tamanhos saem da **altura** da janela (medidas na referência de 1672×941). Enquanto o menu está aberto o aspecto é “expandido” (`GameSettings.set_menu_aspect(true)`): o fundo cobre a janela em qualquer proporção (recorta mantendo Alen à direita). Ao entrar no jogo volta a 16:9 (`_exit_tree`).
- **CONTINUAR:** com um único salvamento carrega direto; com mais de um abre a lista de espaços (o antigo “CARREGAR JOGO”, com o mais recente em foco). Fica apagado se não há salvamento.
- **SAIR:** escondido no navegador.
- **Atalho de teste:** F10 abre um jogo novo (em espaço livre) já no Capítulo I.

## 3. Configurações (todas aplicadas na hora e salvas em `user://settings.cfg`)
| Opção | Como é aplicada |
|---|---|
| Modo de janela: Janela / Tela cheia / Janela sem bordas | `DisplayServer.window_set_mode/flag`. Tela cheia = exclusiva no Windows, tela cheia do sistema nos demais; sem bordas = janela sem moldura do tamanho da tela. No navegador/celular só aparecem Janela e Tela cheia |
| Resolução da janela | lista de 1280×720 até 3840×2160 **filtrada pelo que cabe na tela** (+ a atual salva); fica travada fora do modo Janela |
| V-Sync | `window_set_vsync_mode` |
| Limite de FPS: 30 / 60 / 120 / 144 / 240 / Ilimitado | `Engine.max_fps` (0 = ilimitado); a dica mostra a taxa do monitor |
| Escala de pixels: Inteira / Ajustada à janela | `Window.content_scale_stretch` (inteira = pixels perfeitos, com faixas pretas se a janela não for múltipla de 640×360; ajustada = preenche) |
| Partículas (neve, folhas) | `SnowLayer` e a neve da janela da casa mostram/escondem na hora |
| Efeitos de iluminação | brilhos, feixes de luz e halos desenhados em código (menu, casa, cidade, biblioteca…). Brilhos já pintados nas imagens não mudam |
| Volume geral / música / efeitos | barramentos de áudio (como antes) |
| Restaurar padrão | `GameSettings.reset_defaults()` — vídeo, desempenho, efeitos **e** áudio; aplica, salva e atualiza a tela |

**Escala de renderização:** *não implementada de propósito.* O jogo é 2D em modo `canvas_items`, que já desenha na resolução nativa da janela; a escala de renderização da Godot (`scaling_3d_scale`) só vale para 3D. No lugar entrou a opção “Escala de pixels”. Reduzir a resolução interna exigiria o modo `viewport`, que deixaria o texto e o menu em baixa resolução.
**Arquivos antigos:** chaves antigas (`fullscreen`, índice de `resolution`) são lidas e convertidas.

## 4. Pausa
- Esc abre/fecha (`level_base.gd` abre; `pause_menu.gd` fecha). Enquanto aberto, `get_tree().paused = true`: o personagem e o cenário congelam; o menu, os tweens da interface e o `SceneRouter`/`AudioManager` seguem (`PROCESS_MODE_ALWAYS`).
- **Configurações** abre o mesmo painel do menu principal; as mudanças valem imediatamente, durante a partida.
- **Voltar ao menu principal:** se `GameState.dirty`, pergunta *Salvar e voltar / Voltar sem salvar / Cancelar*; senão volta direto. **Sair do jogo:** sempre confirma (com a opção de salvar quando há progresso não salvo).
- Esc dentro de Configurações ou de uma confirmação só volta um passo.
- Não abre durante diálogos, transições de cena nem quando o jogador está sem controle (cenas roteirizadas e o minijogo, que usa Esc para sair).

## 5. Reutilizar
- Nova tela de opções: acrescente a variável e o setter em `GameSettings`, a chave em `load_settings`/`save_settings` e uma linha `_stepper(...)` em `settings_panel.gd`.
- Novo efeito que deve obedecer às opções: `if fx_lights():` (níveis) ou `GameSettings.fx_snow` / `GameSettings.changed`.
- Lista de opções em qualquer menu: `MenuList` (`setup`, `chosen`, `set_active`, `focus_id`).

## 6. Decisões para você confirmar
1. **“Carregar jogo”** saiu da lista (você pediu 5 opções); ficou dentro de CONTINUAR quando há mais de um salvamento.
2. **Créditos:** o texto é provisório (`data/creditos.json`). Só afirmei “Another Concept” e “Godot”.
3. **Fonte:** o jogo usa a fonte padrão da Godot; a da referência não está no projeto. Para usar a sua, coloque `assets/fonts/ui.ttf` (o `UITheme` e o `MenuList` já carregam se existir).
4. O fundo antigo do menu (tábuas de madeira) ficou nos assets, sem uso.
5. Em janelas que não são múltiplo de 640×360 (ex.: 1600×900) a escala inteira deixa faixas pretas no jogo; use “Ajustada à janela” se preferir preencher.

## 7. O que ainda precisa ser testado na Godot
Tudo, em especial: (a) a entrada animada e o foco por teclado/mouse/gamepad; (b) o shader de parallax (nome dos parâmetros conferido, visual não); (c) trocar modo de janela/resolução/V-Sync/FPS e reabrir o jogo para ver se persistiram; (d) mudar a escala de pixels em janelas de proporções diferentes; (e) a pausa: Esc, Configurações com o jogo congelado, voltar ao menu com/sem progresso não salvo, sair; (f) neve e luzes desligadas dentro de uma fase; (g) CONTINUAR com 0, 1 e 3 salvamentos e NOVO JOGO com os espaços cheios; (h) desempenho do fundo animado em máquinas fracas.
Checklist e limites conhecidos também em `README.md`.
