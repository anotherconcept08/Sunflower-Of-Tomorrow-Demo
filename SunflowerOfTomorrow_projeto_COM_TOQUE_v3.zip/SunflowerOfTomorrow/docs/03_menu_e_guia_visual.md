# PARTES D e E — Menu principal e guia visual

## D1. O menu (arte do projeto)
O menu usa **a sua imagem** (`docs/referencias/menu_referencia.png`): uma cidade em ruínas sob neve, o logotipo SUNFLOWER OF TOMORROW com cipó e gelo, uma placa de madeira e o girassol brotando entre as pedras. Frase-guia da ficha: *“Mesmo no caos, ainda existe um pouco de luz.”*

### Como foi montado
| Camada | O que é | Como |
|---|---|---|
| Fundo | `assets/ui/menu/menu_bg.png` (994×559) | sua imagem recortada para 16:9 (15 px de cada lado), com o poste da placa **estendido** para caber a 5ª tábua; exibida em 640×360 com filtro linear |
| Neve | 70 flocos de 1 px | `snow_layer.gd`, deriva lenta por cima da imagem |
| Tábuas | 5 `TextureButton` × 3 estados | `plank_N_normal/focus/disabled.png`: as tábuas foram refeitas a partir da tábua “EXIT” da sua imagem (pontas limpas + trecho central espelhado), com os rótulos em português em fonte pixelada |
| Fade | preto → imagem em 2,6 s; tábuas surgem em 1,6 s após 1,8 s | — |

O **logotipo está dentro da imagem** (em inglês, como no seu mockup). Para trocar, edite `menu_bg.png` ou apague o título da imagem e use um `Label`.

### Estados dos botões
| Estado | Visual |
|---|---|
| Normal | tábua cinza, texto branco com contorno escuro |
| Foco / hover / pressionado | tábua mais clara e quente, texto **dourado** (`ui_move` discreto) |
| Desabilitado (CONTINUAR sem save) | tábua escurecida, texto cinza, sem foco |

### Opções e navegação
| Botão | Comportamento |
|---|---|
| CONTINUAR | só habilitado com salvamento válido; carrega o **mais recente** |
| NOVO JOGO | primeiro espaço livre; se os 3 estão ocupados, **confirmação discreta** (“substituir o mais antigo?”, foco em VOLTAR) |
| CARREGAR JOGO | lista dos 3 espaços (cena, tempo, data) |
| CONFIGURAÇÕES | volume geral/música/efeitos (ao vivo), tela cheia, resolução da janela; salva ao fechar |
| SAIR | fade e `quit()`; oculto no navegador |

**Entradas:** teclado (↑/↓ percorrem as tábuas, com volta ao início; Enter/Espaço confirmam; Esc fecha painéis), mouse (hover move o foco), gamepad (direcional/analógico, A confirma, B volta).

### Música
`menu_theme.ogg` (sua faixa) em loop sem emenda; detalhes em `docs/02_direcao_de_audio.md`.

## E. Guia visual do capítulo
O estilo vem das suas duas imagens: **pixel art sombria, paleta fria e dessaturada, contorno escuro, neve e gelo, um único ponto quente** (girassol, janelas acesas).

| Item | Decisão | Por quê |
|---|---|---|
| Resolução de referência | **1920×1080** | alvo mais comum |
| Resolução-base | **640×360**, escala inteira (3× em 1080p, 2× em 720p) | pixels sem distorção |
| Personagem | Alen ≈ **46 px** de altura (26×46), pés na origem do nó | derivado da ficha (a arte original tem ~3,35 px por pixel; reduzida para a grade nativa) |
| Cenários | PNG em **1 px = 1 px** (`assets/environments/`) | mesma densidade do personagem |
| Profundidade | céu fixo · ruínas distantes com **parallax** (0,4–0,45) · cenário principal · `y_sort` para jogador e NPCs | cidade “viva”, sem custo |
| Paleta | cinza-azulado `#1c2533→#6a7c94`, tijolo `#5a4640`, neve `#dfe6ee`, madeira `#4a3a30`, quente `#f2c26b` (só janelas/girassol/sol) | contraste frio × quente |
| Câmera | quarto: fixa (deriva só na abertura) · cidade/jardim: segue com suavização e limites | espaço vazio no quarto |
| Luz | feixe da janela e brilho das janelas **simulados** (polígonos com alfa); raio de sol no final | simples e seguro; para luz real use `PointLight2D` + `CanvasModulate` |
| Partículas | neve 60 (cidade), folhas 26 (jardim), poeira 9 (quarto), fumaça de 3 chaminés | poucas e com função |
| Interface | caixa de diálogo com **retrato** (64×56) à esquerda, nome dourado, seta “»” | igual ao exemplo “Na cena” da ficha |

### Alen Hader (sprites e rostos da ficha)
- **Poses da ficha:** *Parado, Andando (baixo), Andando (cima), Correndo, Interagindo, Conversando, Dano e Morto* estão em `assets/characters/alen/` (um quadro cada).
- **Animação (`alen_sheet.png`, gerada por `tools/arte/animar_alen.py`):** cada pose é separada em corpo e pernas, e as pernas são alternadas para formar ciclos. 4 colunas × 8 linhas de 40×54 px: *idle* com respiração (2 quadros) e *andar* (4 quadros: passada, passagem, passada oposta, passagem) para baixo/lado/cima, *correr* de lado e para baixo. Lado esquerdo = espelhamento.
- **No jogo (`player.gd`):** movimento com **aceleração e freio**; **Shift** (ou botão X do gamepad) corre (122 px/s contra 78); a velocidade da animação acompanha a velocidade real (analógico); **passos e poeira/neve** saem nos quadros de contato, sincronizados; a sombra acompanha os pés. Idle “respira”.
- **Limite honesto:** os quadros extras são derivados de UMA pose por direção (as pernas alternam, o tronco não balança tanto quanto uma animação desenhada à mão). Para animação final, desenhe 4–6 quadros por direção e substitua a folha mantendo as linhas e o tamanho 40×54.
- **Rostos:** 6 expressões (normal, irritado, triste, surpreso, sarcástico, envergonhado) como retratos. Qualquer fala de Alen aceita `"face": "sarcastico"` no JSON; falas de pensamento mostram o rosto mais apagado.

### NPCs (honestidade sobre o que são)
Marcus e Eleanor **não vieram da sua ficha**: são **variações dos sprites do Alen** (recoloração, gorro/cabelo grisalho, cachecol, casaco longo, escala 1,10 e 0,94) para que combinem com o estilo. Funcionam como placeholders de boa qualidade, mas têm o mesmo rosto/pose-base do Alen. O ideal é você me enviar (ou encomendar) fichas como a do Alen para Marcus, Eleanor e Sophia. Os retratos de Marcus e Eleanor são bustos do próprio sprite, ampliados 2×.

### Cenários gerados
`tools/gerar_cenarios.py` (usa `tools/pixlib.py`) desenha em código: tijolos, janelas (inclusive quebradas ou tapadas), gelo nos beirais, rua de paralelepípedos com neve, postes, árvores nuas, araucária, pinheiros, galpão, cerca, e a **casa inteira** (`house.png`, 1400×360). Materiais de **remendo** reutilizáveis em `pixlib.py`: compensado com parafusos, chapa de zinco enferrujada, lona azul com fita, papelão com fita e recado, tijolo de outro lote com cimento irregular, fita adesiva, tábuas novas no piso velho, colcha de retalhos. Rode `python3 tools/gerar_cenarios.py all` para refazer; as posições de portas, janelas e objetos **seguem as coordenadas dos scripts** (não as mova sem ajustar `town.gd`, `garden.gd`, `house.gd`).

### A casa de Alen (`house.png`)
Meio destruída e remendada, em três espaços com clima próprio: **quarto** (frio e azulado, com remendos de compensado, lona, papelão e fita), **sala/cozinha** (verde-oliva desbotado, o cômodo quente: fogão a lenha com brasa animada, chapa de zinco, pia com cano enfaixado, janela de colcha pregada em X, geladeira-armário com bilhete, porta do fundo pregada, mesa que manca, tapete de retalhos, dois baldes com goteiras animadas) e **entrada desabada** (azulada e clara: teto no chão, vigas, escada que termina no ar, neve entrando, buraco no piso, lona batendo ao vento, materiais de remendo). O tom de cor muda suavemente de um cômodo para o outro e o som **abre** perto do desabamento.

### Arte final (o que substituir depois)
Cenários (cidade, jardim e `house.png`): troque os PNG mantendo tamanho e posições (ou redesenhe sobre eles). Personagens: sprite sheets com 4 direções × idle/andar. Menu: `menu_bg.png` e as tábuas em `assets/ui/menu/`.

## Expansão: quarto “Older Brother Core” e sala dos pais
**Quarto (`house.png`, x 96–544):** pôsteres de bandas **fictícias** em arte original (HOLLOW CITY, PAPER STATIC, LATE BUS, SEM VOLTA — nenhuma capa protegida), prateleira de CDs, computador de tubo com teclado/mouse, mini system, fones, guitarra, calendário de 2008, relógio parado, cobertor escuro e travesseiro gasto, cadeira com roupas e a jaqueta, apostilas no chão, janela embaçada com neve, abajur de luz amarelada (calor pequeno num quarto frio). Interações novas: computador, aparelho de som, guitarra, material escolar e a janela (3 falas).

**Sala (x 544–924):** poltrona do pai e sofá da mãe (remendados), rádio de válvula, TV coberta por renda, remédios, tabela de racionamento, abajur de pé, janela com neve, tapete gasto, jornal de 2008. Paleta quente (bege, madeira, âmbar) contra o azul do quarto e do desabamento.

**Pais:** `assets/characters/pai_sentado.png` e `mae_sentada.png` + retratos `pai_normal.png` e `mae_normal.png`. São **variações dos sprites do Alen** (pose encolhida para o pai, tronco para a mãe), com cobertor/manta e caneca; funcionam como placeholders até haver arte própria (`tools/arte/criar_pais.py`). Respiram devagar, não têm colisão própria e os móveis deixam um corredor livre na frente.

**Cidade:** a farmácia fechada (“SEM ESTOQUE. NÃO INSISTA.”) foi desenhada no prédio da direita do mercado.
