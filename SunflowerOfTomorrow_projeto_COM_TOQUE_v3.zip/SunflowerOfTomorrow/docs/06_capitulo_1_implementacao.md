# Capítulo I — Um Lugar Para Escapar: implementação, mapa, testes e limites

> Escrito junto com o código. **Nada aqui foi testado dentro da Godot** (não havia binário nem rede no ambiente de desenvolvimento). Tudo o que está marcado “verificado” foi checado por scripts estáticos; o resto é intenção a confirmar jogando.

## 1. Decisões de continuidade (leia antes de jogar)
- **Declan City x Pinhal Alto.** O prólogo já chamava a cidade de *Pinhal Alto*, mas só uma fala a cita. Em vez de apagar o nome, **Declan City é a cidade e Pinhal Alto é o bairro alto onde Alen mora** (a rua do prólogo). Nenhuma fala do prólogo foi alterada.
- **Data.** O prólogo mostra o jornal de **setembro de 2008** como o primeiro dia da crise e o prazo de **31 de março** como algo que “ainda falta”. O capítulo se passa em **dezembro de 2008** (calendário da biblioteca, cartazes): bate com os dois.
- **Rótulo “Capítulo I”.** O prólogo se chamava “CAPÍTULO I — PRÓLOGO”. Como o novo capítulo também é o Capítulo I, mudei só os rótulos do prólogo: cartão de título (“SUNFLOWER OF TOMORROW / PRÓLOGO”) e cartão final (“…· Prólogo”).
- **Ligação com o prólogo.** O fim do prólogo (cartão “FIM DO PRÓLOGO”) agora leva direto à **manhã seguinte**, na casa de Alen. O gancho “amanhã eu volto, pra ver” rende: a **Estrada do Moinho amanheceu fechada por uma barricada** (e o jardim fica inacessível neste capítulo). Salvamentos que já tinham terminado o prólogo continuam no Capítulo I.
- Alen ganhou uma casa **inalterada**; os pais continuam doentes e sem nome; Marcus continua varrendo (com falas novas); a guerra aparece só como consequência (barricadas, filas, estrondos distantes, toque de recolher).

## 2. Mapa (andar para a esquerda = ir para o centro)
```
 Casa de Alen ─ Pinhal Alto (rua do prólogo) ─◄─ Rua das Lojas ─◄─ Praça do Relógio ─◄─ Área humanitária ─ Biblioteca
 (Estrada do Moinho bloqueada →)              │ locadora (interior)   │ posto de controle   │ fila, água, caminhão    (recepção · distribuição ·
                                              │ padaria (interior)    │ capela, correios    │ teatro de meias          depósito · abrigo · estantes ·
                                              │ beco → casa abandonada│ mural dos desaparec.│                          canto dos jogos + Olivier)
                                              │ Rua das Ferrarias (bloqueada)
```
| Fase (`GameState.SCENES`) | Script | Tamanho | O que há |
|---|---|---|---|
| `house` (existente) | `house.gd` (modo Cap. I) | 1780 | manhã com os pais, cartão de ração; volta: caixa, jantar, cena final |
| `town` (existente) | `town.gd` (modo Cap. I) | 2240 | barricada do Moinho (Sd. Ferraz), varal, Marcus, Seu Tobias, crianças na amarelinha, saída à esquerda |
| `centro` | `ch1_centro.gd` | 2240 | 9 fachadas com história, Rua das Ferrarias (barricada, Cb. Menezes), ruína, ônibus, banca de trocas |
| `locadora` | `ch1_locadora.gd` | 800 | loja abandonada (pistas da Another Concept) |
| `padaria` | `ch1_padaria.gd` | 800 | forno aceso, Dona Íris, pão para o abrigo e para casa |
| `casa_vazia` | `ch1_casa_vazia.gd` | 900 | casa deixada às pressas; chave usada, nave desenhada no vidro |
| `praca` | `ch1_praca.gd` | 2000 | relógio parado, mural, correios, banco, capela, posto de controle (Sd. Lopes) |
| `humanitaria` | `ch1_humanitaria.gd` | 1900 | filas, caminhão, água, avisos, alto-falante, teatro de meias, porta da biblioteca (Tiago) |
| `biblioteca` | `ch1_biblioteca.gd` | 2440 | 6 áreas, ~14 NPCs, Helena, Olivier, TV animada, minijogo |

**Barricadas com função real** (colisões, não decoração): Estrada do Moinho (bairro), Rua das Ferrarias (centro), Avenida Central / posto de controle (praça). Cada uma tem soldado com fala própria (rígido, cansado, discretamente solidário).

## 3. Fluxo e flags
1. Casa: falar com mãe (dá o cartão: `c1_card`) e pai (`c1_pai_talked`; pede o livro “Contos de Outros Mundos”) → sair.
2. Ida: bairro → centro → praça → área humanitária → biblioteca. Opcionais: locadora, padaria (`c1_bread`, `c1_roll`), casa abandonada (`c1_saw_ship`), banca (`c1_candy`), posto (`c1_med_hint`).
3. Biblioteca: Helena entrega a ração (`c1_food` — liga a **viagem de volta**: luz de entardecer e falas “_back”). A porta de saída só abre depois de **conhecer Olivier** (`c1_oliv_met`).
4. Olivier: conversa livre (hub), **Space Travelers** (`c1_played`, `st_result`, `st_deaths`, `st_score`), despedida (`c1_oliv_bye`, `c1_biscuit`). Empréstimo no caderno da mesa de leitura: `c1_item` = `guitar` | `book` | `none` (pode trocar).
5. Volta: casa → caixa na mesa (`c1_unpacked`) → conversar com os pais (`c1_mae_ret_done`, `c1_pai_ret_done`, reagem a pêssego/pão/barra/livro) → cama → cena da noite (varia com `c1_item`) → “FIM DO CAPÍTULO I” → menu.
O texto de todos os 206 diálogos, com ramificações e flags, está em `docs/05_roteiro_capitulo_1.md` (gerado).

## 4. Sistemas novos
- `scripts/world/ch1_level.gd` — base das fases: `npc()`, `prop()` (objetos ordenados por profundidade: NPC “atrás do balcão”), `look()` / `look2()` (falas antes/depois da ração), `add_edge_exit()` (sair pela borda), `enter()` (portas), `apply_dusk()`.
- `scripts/minigame/space_travelers.gd` — shoot’em up de ~1,5–3 min (3 vidas, drones, atiradores, sentinelas, chefe “Guardião MK-1”), comentários do Olivier durante a partida, resultado devolvido à biblioteca (`win` | `lose` | `quit`). Esc encerra.
- `scripts/ui/chapter_card.gd` — cartões de fim de capítulo e fades.
- `tools/roteiro_cap1/*.py` + `tools/gerar_dialogos_cap1.py` — escreva os diálogos em mini-linguagem compacta; o compilador gera `data/dialogue/chapter1_*.json` e o roteiro legível. **Edite os `.py`, não os JSON.**
- `tools/gerar_cap1.py` (cenários e sprites do minijogo), `tools/arte/criar_npcs_cap1.py` (personagens e retratos), `tools/gerar_audio_cap1.py` (sons). Tudo é **placeholder de boa qualidade** para você substituir mantendo os nomes de arquivo.

## 5. Como testar
- **Atalho:** no menu principal, **F10** abre um jogo novo (em espaço livre) já na manhã do Capítulo I.
- Roteiro de teste sugerido: (a) sair de casa sem falar com os pais (deve bloquear); (b) tentar passar pela barricada do Moinho, da Ferrarias e do posto; (c) entrar em locadora, padaria e casa abandonada e sair; (d) na biblioteca, tentar sair sem ração e sem ver Olivier; (e) jogar o minijogo vencendo, perdendo e saindo com Esc; (f) escolher cada item do empréstimo; (g) voltar para casa e ver as três cenas finais (jogo, livro, nada); (h) salvar/continuar no meio (em cada fase).
- `python3 tools/verificar_projeto.py` e `python3 tools/verificar_cap1.py` (estáticos).

## 6. Estimativa de duração (por contagem de texto, não por teste)
O capítulo tem ~11,2 mil palavras e 870 nós de diálogo contra ~2,5 mil palavras e 267 nós do prólogo, mais ~19 mil px de caminho de ida e volta (~4 min andando). **Estimativa:** ~15 min indo direto ao objetivo; **~45–60 min explorando e lendo quase tudo** (incluindo o minijogo). A meta de 45–90 min só é atingida por quem explora; é uma estimativa a confirmar com playtest.

## 7. O que NÃO está pronto / riscos
- **Nunca abri na Godot.** Prováveis pontos de ajuste: posições de interações e colisões (calculadas a partir dos desenhos, nunca vistas em movimento), ordem de profundidade de NPCs e balcões, tamanho de alguns textos na caixa de diálogo, dificuldade e ritmo do minijogo, volume dos sons novos.
- Sprites e sons são **placeholders**; Olivier tem um retrato só (sem variações de expressão); soldados e moradores são parados (sem rotas).
- **Guitar Legends** existe como item e narrativa (cena final), não como minijogo.
- Interiores jogáveis: locadora, padaria, casa abandonada, biblioteca e casa de Alen. Outras lojas têm só fachada e texto (de propósito).
- Sem “desbloqueio” das áreas bloqueadas: elas só indicam que a cidade continua além.
