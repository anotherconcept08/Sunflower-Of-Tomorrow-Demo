# PARTES F e G — Implementação na Godot e plano de produção

> **Estado honesto do projeto:** a arte (menu, Alen, retratos, cenários) foi **conferida visualmente em simulações feitas em Python**, e o código foi escrito e **verificado estaticamente** (`python3 tools/verificar_projeto.py`: caminhos, ids de diálogo, sons, estrutura dos JSONs, indentação). **Ele ainda não foi aberto na Godot**, porque não havia o editor onde o criei. Trate a primeira abertura como o primeiro teste: se algo acusar erro, a seção “Se algo falhar” (no fim) lista as causas mais prováveis. Requer **Godot 4.3+** (renderizador Compatibility).

## F1. Como abrir
1. Godot 4.3+ → *Importar* → selecione `project.godot`. Aguarde o primeiro *import* dos áudios (barra no canto inferior direito).
2. **F5** roda o menu. **F6** roda a cena aberta (por exemplo `scenes/garden/garden.tscn` para testar o jardim direto).
3. Controles: **WASD/setas** movem · **Shift** (ou botão X) corre · **E / Espaço / Enter** interagem e avançam texto (apertar enquanto digita **pula a animação**) · **Esc** pausa · **gamepad**: analógico/direcional, **A** interage, **B** pausa/volta · mouse: clique avança diálogo e escolhe opções.

## F2. Estrutura de pastas
```
res://
  project.godot            resolução 640×360, stretch canvas_items + integer, filtro Nearest, autoloads
  assets/
    audio/music|ambience|sfx   música do menu (sua) + placeholders sonoros
    characters/                marcus_*.png, eleanor_*.png, pai_sentado.png, mae_sentada.png (variações) ; alen/ (sprites da ficha + alen_sheet.png)
    environments/              town_sky|far|main.png, garden_sky|far|main.png, house.png 1780×360 (gerados)
    ui/menu/                   menu_bg.png + plank_1..5_normal|focus|disabled.png
    ui/portraits/              alen_<expressão>.png (6) + marcus_normal.png + eleanor_normal.png
    fonts/                     ui.ttf opcional
  data/dialogue/               prologue_bedroom|house|town|garden.json — TODO o texto do jogo
  docs/                        este material + referencias/ (seu mockup do menu e a ficha do Alen)
  scenes/                      main_menu · house · town · garden · characters/player.tscn
  scripts/
    core/        game_settings.gd (autoload), scene_router.gd (autoload)
    audio/       audio_manager.gd (autoload)
    save_system/ game_state.gd (autoload)
    dialogue/    dialogue_manager.gd (autoload)  — agora com retratos
    player/      player.gd (folha de animação, aceleração, correr), step_puffs.gd (poeira/neve nos passos)
    world/       level_base.gd, house.gd, town.gd, garden.gd, interactable.gd, npc.gd, snow_layer.gd
    ui/          ui_theme.gd, pause_menu.gd
    main_menu/   main_menu.gd (TextureButtons sobre a sua arte), settings_panel.gd, load_panel.gd, confirm_panel.gd
  tools/         gerar_cenarios.py (+ pixlib.py), gerar_roteiro.py, gerar_audio_placeholder.py, refazer_loop_menu.py, verificar_projeto.py, arte/
```
**Por que cenas finas?** Cada `.tscn` contém só o nó raiz e o script; os filhos (colisões, interações, HUD, câmera, jogador) nascem no `_ready()`. Assim não existe nó faltando nem sinal desconectado no editor, e é fácil de ler/aprender: tudo está nos scripts. Quando houver arte, você pode **mover** partes para o editor (veja F5).

## F3. Sistemas e onde estão
| # | Sistema | Arquivo | Como funciona |
|---|---|---|---|
| 1 | Personagem 2D | `player/player.gd` | `CharacterBody2D` com aceleração/freio, `Input.get_vector`, `move_and_slide()` (flutuante, top-down), **animação por folha** (idle/andar/correr), passos e poeira sincronizados com os quadros de contato |
| 2 | Interação | `world/interactable.gd` + player | grupo `"interactable"`; o jogador escolhe o mais próximo dentro do `radius`; mostra “E”; ao interagir chama `activate()` |
| 3–4 | Diálogo e caixa com nome | `dialogue/dialogue_manager.gd` | autoload `Dialogue`; `await Dialogue.play("id")` |
| 5 | Avanço e pular digitação | idem | `RichTextLabel.visible_characters` animado em `_process`; interagir completa o texto; de novo, avança |
| 6 | Escolhas | idem | botões com foco (teclado/mouse/gamepad); “ecoam” como fala de Alen; `set`, `if`, `ifnot`, `branch` |
| 7 | Mudança de ambiente | `core/scene_router.gd`, `level_base.go_to_level` | fade (cor configurável) + `change_scene_to_file`; sinal `revealed` |
| 8 | Música e transição | `audio/audio_manager.gd` | ver `docs/02` |
| 9 | Menu funcional | `main_menu/*` | ver `docs/03` |
| 10 | Configurações de áudio/tela | `settings_panel.gd`, `core/game_settings.gd` | `AudioServer.set_bus_volume_db`, `DisplayServer.window_set_mode/size`, `ConfigFile` em `user://settings.cfg` |
| 11 | Salvar/carregar | `save_system/game_state.gd` | 3 espaços JSON em `user://saves/`; salva automaticamente ao entrar em cada cena e ao terminar |
| 12 | Fluxo do prólogo | `world/house.gd`, `town.gd`, `garden.gd` + flags | cada fase decide o que acontece em `_start()` e nos *hooks* de interação |

### Formato de diálogo (`data/dialogue/*.json`)
```json
"id": { "start": "n1", "nodes": {
  "n1": {"speaker": "Marcus", "text": "Olha só. Vivo.", "next": "n2", "wait": 0.5, "sfx": "paper", "set": {"flag": true}},
  "n2": {"speaker": "Alen", "text": "", "choices": [{"text": "…", "next": "n3", "set": {"alen_tone": "dry"}}]},
  "n3": {"branch": {"flag": "alen_tone", "equals": "dry", "yes": "n4", "no": "n5"}} } }
```
Campos: `speaker` (vazio = narração), `text`, `next` (vazio = fim), `wait` (segundos de caixa vazia antes), `sfx`, `set`, `echo:false`, `choices[{text, say, narr, next, set, if, ifnot}]`, `branch{flag, equals?, yes, no}`.

### Como as partes se conectam
```
MainMenu ─ NOVO/CONTINUAR ─> GameState (flags, slot) ─> SceneRouter.go() ─> Fase._ready()
Fase._ready: _build() (cenário, colisões, interações) → Player + Camera → _start() (som, eventos)
Player ─ "interact" ─> Interactable.activate() ─> hook da fase  OU  Dialogue.play(id)
Dialogue ─ lê JSON ─> escreve flags (GameState) ─> fase lê flags nos hooks ─> AudioManager / SceneRouter
```
Flags principais: `intro_done, has_coat, plant_watered, door_choice, read_notice, marcus_met, got_package, alen_tone, has_pinhao, eleanor_met, has_seed, eleanor_ok, planted, prologue_done` e contadores `seen_<objeto>`.

## F4. Hierarquia de nós (criada em tempo de execução)
**Fase (`Node2D`, `y_sort_enabled`, script da fase):** `Sprite2D` de fundo ×3 (z –30/–20/–10; a camada –20 tem parallax) · `Npc` (Marcus/Eleanor) · `CanvasLayer HUD (10)` [Label objetivo, Label dica] · `StaticBody2D` × N [`CollisionShape2D`] · `Interactable` × N · `Player` [`CollisionShape2D`] · `Camera2D` · `PauseMenu (CanvasLayer 60)` · `Timer` (sons ocasionais) · `CanvasLayer 4 > SnowLayer` · `AudioStreamPlayer2D` (rádio, lenha).
**Menu (`Control`):** `TextureRect` (fundo) · `SnowLayer` · `Control` com 5 `TextureButton` (tábuas) · `ColorRect` preto (fade) · painéis (`LoadPanel`, `SettingsPanel`, `ConfirmPanel`) sob demanda.
**Autoloads (Projeto → Configurações → Autoload):** `GameSettings`, `AudioManager`, `GameState`, `SceneRouter`, `Dialogue` — nesta ordem.

## F5. Trocar a arte provisória por arte final
1. **Cenários:** substitua `assets/environments/*.png` mantendo tamanho e posições (ou redesenhe sobre eles). O jogo só carrega o PNG (`add_bg`/`add_parallax`); colisões e interações continuam em código.
2. **Alen:** troque os PNG de `assets/characters/alen/` (mesmo nome, pés na base) ou use `AnimatedSprite2D` em `player.gd` (um quadro por direção hoje; o “andar” é balanço de 2 px).
3. **NPCs:** `assets/characters/marcus_*.png` e `eleanor_*.png` são variações do Alen; substitua por arte própria e ajuste `town.gd`/`garden.gd` (`Npc.texture`, `flip`, `broom`).
4. **Retratos:** `assets/ui/portraits/<personagem>_<expressão>.png`; Marcus/Eleanor aceitam o mesmo padrão (`marcus_triste.png`…) se você criar e adicionar `"face"` nas falas deles (hoje só Alen usa expressões; a função `_update_portrait` do diálogo usa `marcus_normal`/`eleanor_normal`).
5. **Menu:** `menu_bg.png` + `plank_N_*.png`; posições das tábuas em `PLANK_POS` (px da imagem) no `main_menu.gd`.
6. **Fonte:** `assets/fonts/ui.ttf`. 7. **Sons:** substitua arquivos mantendo os nomes. 8. **Luz real:** `CanvasModulate` + `PointLight2D`.
9. **Exportar:** em *Exportar → Recursos*, inclua `data/*` nos “filtros para exportar arquivos não-recurso”, senão os `.json` de diálogo não vão no pacote.

## G. Plano de produção (todas as fases já têm uma primeira versão em placeholder)
| Fase | Objetivo | Arquivos | Resultado | Critério de conclusão | Problemas comuns |
|---|---|---|---|---|---|
| **1. Estrutura e movimentação** | projeto roda; Alen anda e colide | `project.godot`, `player.gd`, `level_base.gd`, `interactable.gd` | Alen anda no quarto sem atravessar móveis | 60 fps; “E” aparece perto de objetos | autoload fora de ordem; jogador “preso” (colisão grande): ajuste `rect.size` em `player.gd` |
| **2. Casa e interações** | cenas 1–3 completas | `house.gd`, `prologue_bedroom.json`, `prologue_house.json`, `assets/environments/house.png` | abertura sem texto + 6 interações no quarto + 11 na casa + saída | título aparece aos ~9 s; sair só com a jaqueta; goteiras, fogão e neve animados | tecla do diálogo repetindo: verifique que `interact` não está duplicada no Mapa de Entrada |
| **3. Diálogos** | motor de diálogo e escolhas | `dialogue_manager.gd`, JSONs | texto digitado, pular, escolhas, flags | todas as escolhas levam adiante; `tools/verificar_projeto.py` = OK | JSON com vírgula sobrando; id inexistente (aviso no Output) |
| **4. Cidade e jardim** | cenas 4–6 | `town.gd`, `garden.gd`, JSONs | rua explorável, Marcus, jardim, Eleanor, semente, plantio | percorrer o prólogo completo em 10–20 min | câmera tremendo: confirme Nearest/snap em `project.godot` |
| **5. Som e ambientação** | camadas e silêncios | `audio_manager.gd`, `assets/audio` | ambiente por cena, passos, rádio posicional, nota final | nunca mais de 4 camadas; música só no menu | ruído no loop: refaça com `refazer_loop_menu.py`; áudio mudo: barramentos Music/SFX/Ambience |
| **6. Menu principal** | menu memorável e funcional | `main_menu/*` | janela de inverno + girassol, música em loop, 5 opções funcionais | CONTINUAR desabilitado sem save; configurações persistem | foco “perdido” após fechar painel: veja `_set_menu_active` |
| **7. Transições, testes e polimento** | costurar tudo | todos | prólogo sem emendas bruscas | checklist abaixo 100% | fade preso: `SceneRouter._busy` não pode ficar `true` |

### Checklist de testes
- [ ] Abre sem erros vermelhos no painel *Saída*.
- [ ] Menu: título só aparece após ~2,4 s; música entra em fade; deixe tocar 4 min: o ponto de volta não deve ser perceptível. (Atalho para ouvir a emenda: no editor remoto, `AudioManager._music[AudioManager._music_i].seek(240.0)`.)
- [ ] NOVO JOGO começa o quarto **sem música**; CONTINUAR só existe depois do 1º salvamento (após a cena 1).
- [ ] Preencher os 3 espaços e escolher NOVO JOGO → confirmação aparece.
- [ ] Configurações: volumes mudam ao vivo; tela cheia; fechar e reabrir o jogo mantém.
- [ ] Casa: examinar as interações do quarto 3× cada; atravessar o vão da porta, a sala (fogão, pia, remendos, geladeira, porta pregada, mesa) e a entrada desabada (escada, desabamento, caixa de ferramentas); a porta da frente sem a jaqueta recusa; “Ficar mais um minuto” volta ao controle; o som abafado “abre” perto do desabamento.
- [ ] Movimento: andar nas 4 direções (espelhamento do lado esquerdo), **Shift** corre, soltar o direcional freia suavemente, passos sincronizados com a passada, poeira na neve e na terra.
- [ ] Cidade: sem falar com Marcus a saída recusa; com as 3 combinações de tom; com e sem o pacote; pinhão e mural alteram Marcus/Eleanor.
- [ ] Jardim: semente antes de Eleanor → “melhor perguntar antes”; plantar; final; cartão; volta ao menu com CONTINUAR.
- [ ] Teclado, mouse e gamepad; 1280×720 e 1920×1080.

### Próximas melhorias
Arte final e animações; luz real; música original do jardim/cidade; trocar “Alen” (nome provisório) em `GameState`/JSON; mais variações de passos; legendas descritivas de som (acessibilidade); remapeamento de controles; Capítulo II (usar os ganchos da tabela em `docs/01`).

## Se algo falhar (causas mais prováveis)
1. **Versão:** abaixo da 4.3, `window/stretch/scale_mode` e alguns métodos podem não existir → atualize para 4.3+.
2. **“Parse Error” em algum `.gd`:** envie a mensagem exata (arquivo:linha). Candidatos que merecem olhar primeiro: `const X := Color("#...")` (troque por `Color(r,g,b)` se a sua versão reclamar), expressões com `:=` sobre valor `Variant`, e `super(delta)` em `town.gd`.
3. **Sem som / “arquivo ausente” no Output:** espere o import terminar ou use *Projeto → Recarregar projeto atual*.
4. **Diálogo não encontrado / vazio:** JSON inválido; o Output informa o arquivo.
5. **Imagem “quebrada”/linear demais:** só o menu usa filtro linear (de propósito, por ser imagem de alta resolução); personagens e cenários usam *Nearest*.
6. **Sprite do jogador/NPC não aparece:** espere o *import* dos PNG; se persistir, *Projeto → Recarregar projeto atual*.
7. **Menu sem música em build exportada:** inclua `.ogg`/`.wav` (recursos; entram sozinhos) e `data/*` (não-recurso).

## Expansão (contexto histórico, quarto, sala e pais) — o que mudou, arquivo por arquivo
| Arquivo | Mudança |
|---|---|
| `scripts/world/house.gd` | mundo 1780×360; deslocamento `KX = 380` para cozinha/desabamento; sala com colisões, pais (`Npc`), rádio (som posicional, legenda por clareza, chiado), conversa interrompida automática, música baixa na sala, novos hooks (`_on_radio`, `_on_pai`, `_on_mae`), porta da frente pede `parents_met`, objetivo “Passe pela sala.” |
| `scripts/dialogue/dialogue_manager.gd` | `FILES` inclui `prologue_house.json`; retratos e tom de voz de Pai/Mãe |
| `scripts/audio/audio_manager.gd` | `play_music(id, fade_in, fade_out, level_db)` (música de fundo baixa); sfx `drip` e `radio_static` |
| `scripts/main_menu/main_menu.gd` | restaura a intensidade da música ao voltar ao menu |
| `scripts/world/town.gd` | interação da farmácia |
| `data/dialogue/prologue_bedroom.json` | janela (3 falas), computador, som, guitarra, material escolar, `door_parents`, fala da porta ajustada |
| `data/dialogue/prologue_house.json` | cozinha/desabamento (já existia) + pais, rádio, jornal, remédios, TV, janela da sala, conversa interrompida |
| `data/dialogue/prologue_town.json` | farmácia; Marcus responde ao pedido da mãe (`meds_errand`) |
| `assets/environments/house.png`, `town_main.png` | refeitos (`tools/gerar_cenarios.py`) |
| `tools/arte/criar_pais.py`, `tools/gerar_audio_placeholder.py` | sprites dos pais; `radio_static.wav` |
Nada foi duplicado: os sistemas de movimento, interação, diálogo, áudio e transição são os mesmos. Os nomes e caminhos antigos foram mantidos (`house.tscn`, ids de diálogo, flags); só foram **acrescentados** ids e flags (`overheard`, `parents_met`, `pai_talked`, `mae_talked`, `meds_errand`, `radio_seen`, `radio_low`).

### Testes novos (checklist)
- [ ] Ao sair do quarto, o chiado/legenda do rádio aparecem pelo vão da porta; ao chegar em x≈586 a **conversa interrompida** dispara uma vez.
- [ ] Pai e mãe: abrir cada conversa, as 3 respostas do pai e as 2 da mãe; abaixar o rádio por qualquer caminho muda a fala do pai e o som.
- [ ] Sem falar com nenhum dos pais, a porta da frente responde “Não vou sair sem avisar.”
- [ ] Interações do quarto (computador, som, guitarra, material escolar, janela) e da sala (rádio, jornal, remédios, TV, janela) têm área funcional e não conflitam.
- [ ] Os pais não bloqueiam a passagem: existe corredor em frente à poltrona/sofá e por baixo da mesinha de centro.
- [ ] Com `meds_errand`, Marcus responde sobre o remédio e a farmácia tem fala extra.
