# SUNFLOWER OF TOMORROW — Capítulo I: Prólogo
## Visão criativa e roteiro

# PARTE A — Visão criativa

## Contexto histórico: uma realidade alternativa de 2008
O mundo de *Sunflower of Tomorrow* começou a desandar em **2008**, mas **não é o 2008 real**. A história real é só **inspiração**: a crise financeira (a quebra de um grande banco), a escalada de um conflito na fronteira leste, crises humanitárias (fome, deslocamento, doenças, falta de infraestrutura) e guerras longas no deserto, “as tropas que nunca voltam”. No jogo, isso vira **uma sucessão de tragédias que se acumulam** — economias quebradas, governos instáveis, fronteiras fechadas, escassez de comida e de remédio, famílias que perdem a esperança aos poucos —, nunca uma explosão nem um vilão.

**Regras de escrita**
- O jogo **nunca cita nomes reais** (bancos, países, líderes): só “o banco”, “a fronteira leste”, “o governo”.
- O contexto aparece **como vida cotidiana**, em fragmentos curtos e inquietantes. Nada de documentário; ninguém explica a crise (os pais são pessoas comuns).
- O “agora” do prólogo **não é datado**. “2008” aparece no jornal que o pai guardou e no calendário do quarto (o ano em que tudo começou); o resto sugere que já passou tempo.
- **O mistério é intencional.** O prólogo faz três perguntas e não responde nenhuma: (1) o que realmente aconteceu com o mundo? (2) o que está acontecendo com a família de Alen? (3) ainda existe futuro ali?

**Onde o contexto aparece**
| Onde | Como |
|---|---|
| Rádio de pilha na sala | fragmentos (bolsa em queda, combates na fronteira, postos sem antibióticos, ajuda parada, “economize a bateria”, “neve, de novo”) com chiado; **de longe só algumas palavras, de perto a frase inteira** |
| Jornal de setembro de 2008 (mesinha de centro) | só o primeiro dia da crise foi guardado; o horóscopo promete “mudanças positivas à vista” |
| Conversa interrompida dos pais | “...se fecharem a estrada também, como é que a gente—” / “Shh. O Alen.” |
| Casa | remédios divididos com tesoura, tabela de racionamento (luz, água, remédio), TV coberta para poupar luz, prateleiras vazias, remendos para economizar |
| Quarto | pôsteres de turnês que nunca aconteceram (datas riscadas), calendário de 2008, computador apagado “porque a luz tem hora marcada”, escola que fechou |
| Cidade | farmácia “SEM ESTOQUE. NÃO INSISTA.”, edital de venda do jardim, casas fechadas, ruas sem luz |

## Premissa
Numa manhã fria em **Pinhal Alto**, cidade serrana de geada, araucárias e prédios em ruínas que ninguém explica, **Alen Hader** (16 anos) acorda no quarto de adolescente de meados dos anos 2000 que o mundo não o deixou terminar de viver, atravessa uma casa remendada onde os **pais, doentes, ouvem o rádio** e sai para a rua com uma lista que quase nada riscou. Ninguém lhe pede nada de grande. Ele caminha, é provocado por um vizinho, é reconhecido pelo jeito de andar por uma velha jardineira e, num jardim que pode ser vendido em março, planta uma semente na estação errada. O prólogo termina antes de saber se ela cresce.

## Temas
- **Continuar sem garantia.** O girassol é a possibilidade de tentar mesmo quando o amanhã não promete nada. Ninguém no prólogo diz isso; o jogador deduz.
- **Lugares e frases incompletos.** A fotografia com o rosto cortado pela dobra, o “Você anda igual a alguém que eu conhecia…”, a mensagem que Alen não responde.
- **Humor como sobrevivência.** Alen, Marcus e Eleanor se defendem com ironia; a melancolia convive com graça.
- **Cuidado que não resolve nada, mas importa.** Regar uma muda, varrer uma calçada, tirar o que secou, cobrir uma semente.

## Sinopse
Alen acorda sem ritual dramático: o quarto, a luz cinza, uma lista no caderno, uma planta que insiste. Veste a jaqueta (“um pequeno ato de fé”) e sai. Na rua, Marcus, que varre a calçada do Armazém Dias, o provoca, sonda e — sem dizer — o empurra para a estrada do Moinho, onde mora o que sobrou de um jardim. Lá, Eleanor tira o que secou, desconfia do jeito de andar de Alen e menciona, sem explicar, que alguém já andou igual. Ele acha uma lata com sementes de girassol. Eleanor avisa que a geada talvez pegue, “provavelmente”, e o deixa sozinho. Alen planta com as próprias mãos, diz que não sabe se vai crescer e que amanhã volta pra ver. Um raio baixo de sol toca a terra; uma nota; o título.

## Arco emocional de Alen
| Momento | Estado | Como aparece (sem explicar) |
|---|---|---|
| Quarto | Em suspenso | lista do caderno com “responder aquela mensagem” há 11 dias; foto dobrada; muda murchando |
| Porta | Pequeno esforço | a jaqueta como “ato de fé”; a escolha de sair ou ficar mais um minuto |
| Cidade | Evita a intimidade, mas responde | humor seco (ou gentil, ou calado) com Marcus; guarda um pinhão “inútil” no bolso |
| Jardim | É reconhecido | “Você anda igual a alguém que eu conhecia”; as iniciais L. e E. no banco |
| Semente | Decide algo mínimo | planta na estação errada; “amanhã eu volto” (um compromisso minúsculo, não uma cura) |

**Alen Hader** (ficha de personagem do projeto) — 16 anos, 1,62 m, **reservado, introspectivo, sarcástico às vezes, leal, sensível mesmo quando não demonstra**. Frase-guia: “Algumas pessoas só precisam de um lugar seguro pra existir.” / “Mesmo no caos, ainda existe um pouco de luz.” Manias: faz listas, coleciona coisas sem função, nota detalhes. Veste jaqueta xadrez sobre camiseta preta e leva mochila. Decide: regar ou não a muda, o tom com Marcus, plantar. Tem seis expressões de rosto (normal, irritado, triste, surpreso, sarcástico, envergonhado), usadas no retrato dos diálogos.

## Personagens apresentados
- **Marcus** — sarcástico e reservado, ligado à história da cidade (varre a calçada do Armazém Dias, conhece o edital e o jardim). Não revela: também evita aquela estrada (“meu joelho tem opinião sobre ladeira”).
- **Eleanor** — jardineira velha, humor seco, fala de plantas sem sermão. Não revela: quem é a pessoa a quem Alen se parece e o que a une ao jardim (iniciais L. e E.).
- **Sophia** — *não aparece* neste prólogo, de propósito: introduzi-la sem função seria pressa. Há apenas dois rastros dela (garrafa térmica e livro no banco; a “mensagem” sem resposta).

## Suposições assumidas (revise à vontade)
1. A cidade é serrana do sul do Brasil (geada, araucária, pinhão): torna o inverno e o girassol plausíveis.
2. L. (da foto/banco) é alguém ligado a Alen e a Eleanor; o prólogo **não** diz quem nem o que aconteceu.
3. Alen (16) mora num quarto de uma casa que divide com outras pessoas; **a situação familiar fica em aberto** de propósito (nenhum adulto de casa aparece no prólogo).
3b. A cidade tem ruínas (como no menu), mas o prólogo **não explica** o que as causou; as pessoas seguem a vida (Marcus varre a calçada, o rádio fala do tempo).
4. Escolhas do prólogo afetam **como Alen fala e como os outros reagem**; o caminho principal é um só.
5. Marcus, Eleanor e Sophia seguem o briefing. “Alen Hader” vem da sua ficha.

## Ganchos plantados (todos com destino planejado)
| Gancho | Onde aparece | Destino sugerido |
|---|---|---|
| A mensagem sem resposta | caderno (`notebook_1`) | Capítulo II: de quem é e por que Alen evita |
| Quem tirou a foto / quem é L. | foto, banco do jardim, Eleanor | Capítulo II–III |
| Edital de venda do jardim (março) | mural, Marcus | Pressão de tempo dos capítulos seguintes |
| Garrafa térmica e livro no banco | cidade (`bench_book`) | Introdução de Sophia |
| O que Eleanor não explica (“Um dia eu explico. Ou não.”) | jardim | Bulbos que “dormem” florescem na primavera |
| O que os pais não dizem (“...se fecharem a estrada também...”) | rádio, conversa interrompida | O que está vindo; o que “a estrada” significa |
| Remédio que não chega (pedido da mãe; Marcus “tô tentando”; farmácia sem estoque) | sala, cidade | Missão de longo prazo da família |
| Bilhete “Volto no sábado. Não esquece de regar.” (mesma letra da foto) | geladeira (`fridge_note`) | Quem partiu? Liga a muda, a foto e “L.” |
| Porta do fundo pregada (“Fui eu que preguei. Acho que fui eu.”) | sala (`closed_door_1`) | O cômodo fechado: de quem era? |
| A segunda cadeira, mantida arrumada | mesa (`table_2`) | Um lugar vazio que Alen não ocupa |
| Escada que sobe para o nada (11 degraus; eram 16) | entrada desabada | O segundo andar perdido |
| Alen volta “amanhã, pra ver” | fala final | Abertura do Capítulo II |

---

## Escolhas e consequências (resumo)
| Escolha | Opções | O que muda | O que permanece igual |
|---|---|---|---|
| Regar a muda (quarto) | Regar / Deixar | Terra escura no cenário; uma fala de Alen no bilhete da geladeira (“Hoje eu reguei. Isso conta.”) e outra no plantio (“A do quarto eu reguei hoje” ou “Tomara que eu me saia melhor…”) | O resto da história |
| Resposta a Marcus | gentil / seca / calado | `alen_tone`: reação de Marcus agora e de Eleanor depois; uma fala extra de Alen se for seco | Caminho e destino |
| “Pra onde vai?” | volta / não sei / não é da sua conta | Tom da resposta de Marcus | Informação dada |
| “O que tem no fim da estrada?” | perguntar / ir embora | Se Alen recebe o **pacote de dobradiça** (muda a abertura de Eleanor) | Ele pode ir ao jardim de qualquer modo |
| Apresentar-se a Eleanor | Alen / só passando / calado | Como Eleanor “arquiva” Alen | Ela sempre repara no jeito de andar |
| “Quem?” / “Muita gente anda igual” | duas respostas | Ela se esquiva de duas maneiras | O mistério continua |
| Pinhão (opcional) | pegar ou ignorar | Habilita o diálogo sobre plantar sem ver o resultado | — |
| Rádio | abaixar / deixar | Volume e legenda do rádio mudam; a primeira fala do pai muda (“Obrigado por abaixar o rádio.”) | O que as notícias dizem |
| Pai | “Tá doendo muito?” / olhar os remédios / “Eu abaixo o rádio.”; aula amanhã: “Tenho.” / “A escola fechou de novo.” / silêncio | Só o tom: o pai sempre tranquiliza e manda Alen descansar | Libera a saída (`parents_met`) |
| Mãe | “Tô sem fome.” / “Depois eu como.”; remédio / olhar | Como ela reage; Alen recebe o **pedido de perguntar a Marcus** (`meds_errand`) | Libera a saída (`parents_met`) |
| Sair / ficar mais um minuto | duas opções | Nada (permite olhar o quarto uma última vez) | — |

---

## A CASA DE ALEN (cenário das cenas 1 a 3)
A casa **ainda tenta funcionar como um lar** — e é **meio destruída e toda remendada** (a destruição se concentra no fim da casa; o resto é lar gasto e consertado com o que dá). O jogador a atravessa da esquerda para a direita:
1. **Quarto** — estética *Older Brother Core*: pôsteres de bandas **fictícias** (HOLLOW CITY, PAPER STATIC, LATE BUS, SEM VOLTA), prateleira de CDs, **computador de tubo** com teclado e mouse, mini system e fones, **guitarra elétrica** encostada, calendário de 2008, relógio parado (“pilha pro relógio”), cama com cobertor xadrez escuro e travesseiro gasto, cadeira com roupas jogadas (e a jaqueta), material escolar no chão, janela embaçada com neve, abajur de luz amarelada. Remendos: lona no teto, papelão e fita na janela, chapa de zinco, tábua nova no piso.
2. **Sala** — o cômodo dos pais: **poltrona do pai** (cobertor xadrez sobre as pernas) e **sofá da mãe** (caneca e manta de tricô), ambos remendados com retalhos; **rádio de válvula** no aparador; **TV coberta por renda** com um vaso; mesinha de **remédios** quase vazia, copo d’água, lenços usados; **tabela de racionamento** na parede; prateleira quase vazia; abajur de pé; **jornal de 2008** na mesinha de centro; **janela com neve** e a cidade em silêncio.
3. **Cozinha** — fogão a lenha (o único calor forte), pia com cano enfaixado de fita, janela de colcha pregada em X, geladeira-armário com o bilhete, porta do fundo pregada, mesa que manca, dois baldes de goteira, remendos de compensado, zinco, lona, papelão e tijolo por toda parte.
4. **Entrada desabada** — metade do teto no chão, vigas caídas, escada que termina no ar, neve entrando, buraco no piso, materiais de remendo na porta da frente.

**Transição entre os espaços (áudio):** do quarto (som abafado) ouve-se o rádio da sala *antes* de ver os pais; a legenda das notícias vai ficando nítida conforme Alen chega perto; na sala toca, bem baixinha, a melancolia da música do menu (só ali e na cozinha); no desabamento o ambiente “abre” (vento de fora). Rangidos da casa, goteiras e chiado de rádio ocasionais.

**Os pais** (“Pai” e “Mãe”; sem nomes): vivos, doentes, cansados, sem exagero. Ela tenta tranquilizar e está assustada; ele se preocupa com remédio, dinheiro e o futuro do filho. **Nenhum dos dois explica a crise.** Falam curto, com pausas e subtexto, e demonstram afeto com pequenos gestos (“Come mesmo assim”, “fecha bem a porta, que o frio entra”). Alen, introspectivo, hesita, olha os remédios, fica em silêncio quando não sabe o que dizer — e **não sai de casa sem falar com eles** (a porta da frente pede isso).

---

## CENA 1 — O silêncio do quarto (sem diálogo)
- **Duração:** ~16 s de cena + título; o jogador não perde nada se ficar parado.
- **Enquadramento:** plano aberto do quarto inteiro (448×256, no meio da tela de 640×360) com o calor do fogão da sala aparecendo na borda direita, pelo vão da porta; bordas escuras em vinheta. **Câmera:** deriva lenta de 14 px na horizontal e 5 px na vertical em 18 s (curva senoidal), sem zoom (zoom fracionário faz o pixel art tremer).
- **Luz:** fria e natural; o feixe da janela balança ±2% de intensidade; poeira (9 pontos) cai devagar dentro do feixe. **Cortina:** deslocamento senoidal de ~4 px.
- **Paleta:** azuis-acinzentados, marrons dessaturados; único calor: o amarelo apagado da foto.
- **Sons:** entra só *room tone* (muito baixo) + o vento da fresta, **abafado** (filtro passa-baixa a 900 Hz); em ~3 s um estalo de madeira; nenhuma música.
- **Título (~9 s):** “CAPÍTULO I” (pequeno) e “PRÓLOGO” (maior), no canto inferior esquerdo, fade-in de 2,2 s e 2,8 s, permanece ~3 s e some em 2,2 s. Sem animação adicional.
- **Fim:** som de tecido; o jogador assume o controle; objetivo discreto no canto superior esquerdo: “Prepare-se para sair.”

## CENA 3 — A porta (transição sonora e visual)
Ao escolher “Sair”: rangido de porta; o ambiente da **cidade** começa a subir em 5 s *antes* da imagem mudar; o filtro de abafamento “abre” em 4 s (o som de dentro se revela som de fora); o fade vai para **luz fria e pálida** (#b9c6d8), não para preto; a cena nova clareia em 2,8 s.

## CENA 6 — A última imagem
Depois de “Mas amanhã eu volto. Pra ver.”: o vento cai para –18 dB em 6 s; a câmera sobe 34 px em 9 s; aos 2,5 s um raio baixo de sol aparece sobre a terra (único calor da imagem); aos 5,5 s entra **uma única nota** de piano (ré), sem melodia; ~7 s de silêncio quase total; fade para o cartão **FIM DO PRÓLOGO**. O jogo salva e volta ao menu (agora com CONTINUAR habilitado).

### Sobre a fala final
Sua versão (“Não sei se vai crescer.” / pausa / “Mas acho que posso esperar.”) é boa, mas “esperar” é passivo. Usei **“Mas amanhã eu volto. Pra ver.”**: continua humilde e incerta, e ainda transforma o tema (“continuar tentando”) numa ação concreta e minúscula, que também abre o Capítulo II. Se preferir a sua, troque o texto do nó `n2` de `plant_end` em `data/dialogue/prologue_garden.json`.

---


# PARTE B — Roteiro completo dos diálogos

> Texto gerado a partir de `data/dialogue/*.json` (a fonte de verdade que o jogo lê). Para mudar uma fala, edite o JSON e rode `python3 tools/gerar_roteiro.py` para atualizar este documento.
> Convenções: **—** / *(narração)* = pensamento de Alen em primeira pessoa, sem nome na caixa. `nX` = id do nó. “→ nX” indica salto; sem seta, segue para a linha seguinte. “pausa” = caixa vazia (silêncio) antes da fala.

## Cena 2 — Acordar (quarto)

#### `bed_1` — Cama — 1º exame
- **Condição para iniciar:** Aproximar-se da cama e apertar interagir
- **Sons:** tecido (opcional)
- **Animação / expressão:** Alen olha para a cama; sem animação extra
- **Consequência narrativa:** Nenhuma (caracteriza Alen).
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `b1` *(narração)* Dormi, mais ou menos.
- `b2` *(narração)* O travesseiro discorda. *(pausa 0.7 s)* → *fim*

#### `bed_2` — Cama — 2º exame
- **Condição para iniciar:** Examinar a cama pela segunda vez
- **Sons:** —
- **Animação / expressão:** —
- **Consequência narrativa:** Nenhuma (caracteriza Alen).
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `b1` *(narração)* Eu poderia arrumar.
- `b2` *(narração)* Poderia. *(pausa 0.9 s)* → *fim*

#### `bed_3` — Cama — 3º exame em diante (humor opcional)
- **Condição para iniciar:** Examinar a cama pela terceira vez ou mais
- **Sons:** —
- **Animação / expressão:** —
- **Consequência narrativa:** Nenhuma (caracteriza Alen).
- **Condição para encerrar:** Repete a cada novo exame.

- `b1` *(narração)* Não vou arrumar. Não é uma decisão, é uma tendência. → *fim*

#### `photo_1` — Fotografia — 1º exame
- **Condição para iniciar:** Aproximar-se do criado-mudo e interagir
- **Sons:** papel (sfx 'paper' opcional no nó 1)
- **Animação / expressão:** Câmera fixa; destaque no objeto
- **Consequência narrativa:** Planta o gancho: quem é ela? quem tirou a foto?
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `f1` *(narração)* Uma foto antiga, dobrada no meio. Eu devia ter uns oito anos.
- `f2` *(narração)* Estou rindo de alguma coisa fora do quadro. Alguém segura a minha mão — o rosto dela caiu justo em cima da dobra.
- `f3` *(narração)* Atrás de nós, um borrão amarelo. E quem tirou a foto? Isso eu nunca soube. *(pausa 0.6 s)* → *fim*

#### `photo_2` — Fotografia — 2º exame (interação opcional que revela Alen)
- **Condição para iniciar:** Examinar a foto pela segunda vez
- **Sons:** paper
- **Animação / expressão:** —
- **Consequência narrativa:** Liga a foto ao jardim sem explicar (o quintal da foto é o jardim do jogo).
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `f1` *(narração)* No verso, uma letra inclinada que não é a minha:
- `f2` *(narração)* “Janeiro. Passou o dia inteiro falando do quintal.” *(pausa 0.6 s; som: paper)*
- `f3` *(narração)* ...Eu falava? *(pausa 1.0 s)* → *fim*

#### `photo_3` — Fotografia — 3º exame em diante
- **Condição para iniciar:** Examinar a foto pela terceira vez ou mais
- **Sons:** —
- **Animação / expressão:** —
- **Consequência narrativa:** Nenhuma (caracteriza Alen).
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `f1` *(narração)* Deixo a foto virada pra cima. Não sei por que isso importa. → *fim*

#### `window_1` — Janela — a neve e a cidade em silêncio
- **Condição para iniciar:** Aproximar-se da janela e interagir (1ª vez)
- **Sons:** vento pela fresta
- **Animação / expressão:** A cortina balança, a neve cai, o vidro está embaçado
- **Consequência narrativa:** Mostra a cidade vazia sem explicar.
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `w1` *(narração)* O vidro está embaçado por dentro. Passo o dedo e abro uma janelinha: neve, telhados e nenhuma luz acesa na casa da frente. → *fim*

#### `window_2` — Janela — a fresta
- **Condição para iniciar:** Examinar a janela pela 2ª vez
- **Sons:** vento pela fresta
- **Animação / expressão:** —
- **Consequência narrativa:** Nenhuma (caracteriza Alen).
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `w1` *(narração)* O vento entra por uma fresta que ninguém nunca consertou. → *fim*

#### `notebook_1` — Caderno — 1º exame
- **Condição para iniciar:** Aproximar-se da escrivaninha e interagir
- **Sons:** paper (abrir o caderno)
- **Animação / expressão:** —
- **Consequência narrativa:** Gancho: a mensagem sem resposta (Capítulo II).
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `c1` *(narração)* Meu caderno. Capa dura, cantos arredondados de tanto ir e voltar da mochila. *(som: paper)*
- `c2` *(narração)* Na última página: “pão / pilha pro relógio / responder aquela mensagem”.
- `c3` *(narração)* Os dois primeiros estão riscados. O terceiro está lá faz onze dias. *(pausa 0.7 s)* → *fim*

#### `notebook_2` — Caderno — 2º exame em diante
- **Condição para iniciar:** Examinar o caderno de novo
- **Sons:** paper
- **Animação / expressão:** —
- **Consequência narrativa:** Nenhuma (caracteriza Alen).
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `c1` *(narração)* Abro de novo, como se a lista fosse mudar. Não mudou. *(som: paper)* → *fim*

#### `plant_1` — Planta junto à janela (estabelece o símbolo, discretamente)
- **Condição para iniciar:** Aproximar-se do aparador sob a janela e interagir (1ª vez)
- **Sons:** água (se regar) · vento da fresta
- **Animação / expressão:** Se regar, a terra do vaso escurece no cenário
- **Consequência narrativa:** Escolha: regar ou não. Muda o cenário (terra escura) e a fala de Alen em `plant_end`, no jardim.
- **Condição para encerrar:** Nó p3b ou p4.

- `p1` *(narração)* Uma muda num pote de iogurte. As folhas de baixo amareleceram; as de cima ainda insistem.
- `p2` **—**: Ainda tem um resto de água no copo. — *o jogador escolhe:*
    - ▸ “Regar” → `p3` *(grava `plant_watered=true`)*
    - ▸ “Deixar pra depois” → `p4`
- `p3` *(narração)* A terra escurece depressa. As folhas continuam do mesmo jeito. *(som: water)*
- `p3b` *(narração)* Não sei o que eu esperava. *(pausa 0.8 s)* → *fim*
- `p4` *(narração)* Depois. → *fim*

#### `plant_after` — Planta — depois de regada
- **Condição para iniciar:** Examinar a planta depois de regá-la
- **Sons:** —
- **Animação / expressão:** —
- **Consequência narrativa:** Nenhuma (caracteriza Alen).
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `pa1` *(narração)* A terra ainda está escura do último gole. As folhas, do mesmo jeito. Talvez seja cedo. → *fim*

#### `coat_1` — Jaqueta xadrez (item necessário para sair)
- **Condição para iniciar:** Aproximar-se da cadeira com a jaqueta e interagir (1ª vez)
- **Sons:** tecido (cloth)
- **Animação / expressão:** A jaqueta sai da cadeira (o sprite de Alen já a veste)
- **Consequência narrativa:** Grava `has_coat`; objetivo muda para “Saia.”.
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `k1` *(narração)* A jaqueta passou a noite na cadeira e pegou o clima do quarto.
- `k2` *(narração)* Vestir é um pequeno ato de fé. *(pausa 0.6 s)* → *fim*

#### `coat_after` — Jaqueta — depois de vestida
- **Condição para iniciar:** Examinar a cadeira depois de vestir a jaqueta
- **Sons:** —
- **Animação / expressão:** —
- **Consequência narrativa:** Nenhuma (caracteriza Alen).
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `ka1` *(narração)* Jaqueta: ok. Chaves: no bolso. Ânimo: em falta, mas isso não estava na lista. → *fim*

#### `window_3` — Janela — a neve
- **Condição para iniciar:** Examinar a janela pela 3ª vez ou mais
- **Sons:** —
- **Animação / expressão:** —
- **Consequência narrativa:** Nenhuma (caracteriza Alen).
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `w1` *(narração)* A neve não cai: desiste de ficar no ar, devagar. Eu acompanho até o chão. → *fim*

#### `computer_1` — Computador antigo
- **Condição para iniciar:** Aproximar-se da escrivaninha (lado esquerdo) e interagir
- **Sons:** —
- **Animação / expressão:** Monitor de tubo apagado, teclado e mouse antigos
- **Consequência narrativa:** Retrato de Alen: adolescente de meados dos anos 2000.
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `pc1` *(narração)* O computador. Monitor de tubo que pesa mais do que eu e um teclado com duas teclas sem letra. Foram as que mais usei.
- `pc2` *(narração)* No reflexo da tela apagada, um garoto com o cabelo no olho. Finjo que não vi. *(pausa 0.6 s)* → *fim*

#### `computer_2` — Computador — de novo
- **Condição para iniciar:** Examinar o computador outra vez
- **Sons:** —
- **Animação / expressão:** —
- **Consequência narrativa:** Mostra a economia doméstica sem explicar a crise.
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `pc1` *(narração)* Eu ligaria. Mas a luz da casa tem hora marcada, e meu pai faz a conta todo fim de mês achando que eu não sei. → *fim*

#### `stereo_1` — Aparelho de som e CDs
- **Condição para iniciar:** Aproximar-se da escrivaninha (meio) e interagir
- **Sons:** —
- **Animação / expressão:** —
- **Consequência narrativa:** Nenhuma (caracteriza Alen).
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `sx1` *(narração)* O aparelho de som. Três CDs gravados à mão e uma etiqueta: NÃO EMPRESTAR. Ninguém nunca pediu emprestado.
- `sx2` *(narração)* Os fones estão pendurados no monitor, no lugar de sempre. *(pausa 0.5 s)* → *fim*

#### `stereo_2` — Aparelho de som — de novo
- **Condição para iniciar:** Examinar o aparelho outra vez
- **Sons:** CD que pula e para (sfx opcional)
- **Animação / expressão:** —
- **Consequência narrativa:** Nenhuma (caracteriza Alen).
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `sx1` *(narração)* Aperto play. O disco gira, pula e para. Faz tempo que o laser está cansado.
- `sx2` *(narração)* Continuo ouvindo na cabeça. Ela ainda funciona sem pilha. *(pausa 0.8 s)* → *fim*

#### `guitar_1` — Guitarra
- **Condição para iniciar:** Aproximar-se da guitarra, entre o criado-mudo e a janela
- **Sons:** —
- **Animação / expressão:** —
- **Consequência narrativa:** Nenhuma (caracteriza Alen).
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `gt1` *(narração)* A guitarra encostada na parede. Seis cordas, três acordes e uma teimosia enorme.
- `gt2` *(narração)* Combina com o dono. *(pausa 0.6 s)* → *fim*

#### `guitar_2` — Pôsteres e as turnês canceladas
- **Condição para iniciar:** Examinar a guitarra de novo
- **Sons:** —
- **Animação / expressão:** —
- **Consequência narrativa:** Sinal de que o mundo parou (shows cancelados), sem explicar.
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `gt1` *(narração)* Nos pôsteres em volta: datas de turnê. Nenhuma aconteceu.
- `gt2` *(narração)* Eu risquei as datas uma a uma, pra ficar organizado. *(pausa 0.8 s)* → *fim*

#### `school_1` — Material escolar
- **Condição para iniciar:** Aproximar-se do chão ao lado da cadeira
- **Sons:** —
- **Animação / expressão:** —
- **Consequência narrativa:** Prepara a pergunta do pai (“Você ainda tem aula amanhã?”).
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `sc1` *(narração)* Uma pilha de apostilas, um caderno de física e uma calculadora sem pilha.
- `sc2` *(narração)* Aula amanhã, diz meu pai. Faz três semanas que “amanhã” não vale. *(pausa 0.7 s)* → *fim*

#### `school_2` — Material escolar — de novo
- **Condição para iniciar:** Examinar de novo
- **Sons:** —
- **Animação / expressão:** —
- **Consequência narrativa:** Nenhuma (caracteriza Alen).
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `sc1` *(narração)* Deixo tudo onde está. Se eu arrumo, parece que desisti de usar. → *fim*

#### `door_parents` — Porta da frente — sem falar com os pais
- **Condição para iniciar:** Interagir com a porta tendo a jaqueta mas sem ter falado com nenhum dos pais
- **Sons:** —
- **Animação / expressão:** —
- **Consequência narrativa:** Garante a cena com os pais sem criar objetivo de missão.
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `dp1` *(narração)* Não vou sair sem avisar. Passo pela sala primeiro. → *fim*

## Cena 2b — A casa (sala, cozinha e entrada desabada)

#### `stove_1` — Fogão a lenha — 1º exame
- **Condição para iniciar:** Aproximar-se do fogão e interagir
- **Sons:** estalo da lenha (posicional)
- **Animação / expressão:** A brasa e a luz quente oscilam: é o único calor da casa
- **Consequência narrativa:** Nenhuma (caracteriza Alen e a casa).
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `st1` *(narração)* O fogão a lenha. É a única coisa da casa que nunca precisou de remendo. Teimosia de ferro.
- `st2` *(narração)* Ainda tem brasa da noite. *(pausa 0.5 s)* → *fim*

#### `stove_2` — Fogão a lenha — 2º exame
- **Condição para iniciar:** Examinar o fogão de novo
- **Sons:** madeira
- **Animação / expressão:** —
- **Consequência narrativa:** Pequeno cuidado de Alen, sem explicação.
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `st1` *(narração)* Ponho mais um pedaço de lenha. Não precisava. Faço mesmo assim. → *fim*

#### `sink_1` — Pia e canos
- **Condição para iniciar:** Aproximar-se da pia
- **Sons:** pingos nos baldes (sfx 'drip', distância atenua)
- **Animação / expressão:** Goteiras caem nos dois baldes e fazem ondas
- **Consequência narrativa:** Nenhuma (caracteriza Alen e a casa).
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `sk1` *(narração)* A pia tem um balde embaixo do cano. O cano tem fita em volta. A fita já foi remendada com outra fita.
- `sk2` *(narração)* A casa funciona por camadas. *(pausa 0.7 s)* → *fim*

#### `patches_1` — Os remendos da parede — 1º exame
- **Condição para iniciar:** Aproximar-se da parede entre a pia e a janela
- **Sons:** —
- **Animação / expressão:** —
- **Consequência narrativa:** Mania de Alen: contar coisas.
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `pa1` *(narração)* As paredes são mais remendo que parede. Compensado, chapa, lona, papelão e um tijolo que não é do mesmo lote de ninguém.
- `pa2` *(narração)* Eu lembro de onde veio cada pedaço. Conto como outros contam ovelhas. *(pausa 0.6 s)* → *fim*

#### `patches_2` — Os remendos da parede — 2º exame
- **Condição para iniciar:** Examinar a parede de novo
- **Sons:** —
- **Animação / expressão:** —
- **Consequência narrativa:** Nenhuma (caracteriza Alen e a casa).
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `pa1` *(narração)* Ontem eram dezessete. Hoje, dezoito, com o da pia.
- `pa2` *(narração)* A casa vence por pouco. *(pausa 0.7 s)* → *fim*

#### `quilt_window` — Janela de colcha
- **Condição para iniciar:** Aproximar-se da janela da cozinha
- **Sons:** —
- **Animação / expressão:** —
- **Consequência narrativa:** Nenhuma (caracteriza Alen e a casa).
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `qw1` *(narração)* A janela da cozinha é uma colcha de retalhos pregada em X. A luz que passa tem cor de sopa fria. → *fim*

#### `fridge_note` — Geladeira e o bilhete (gancho principal da casa)
- **Condição para iniciar:** Aproximar-se da geladeira e interagir (1ª vez)
- **Sons:** papel
- **Animação / expressão:** —
- **Consequência narrativa:** Liga a letra do bilhete à da foto (a mulher “L.”) e a muda do quarto (“regar”). Se Alen regou a muda, comenta. Gancho: quem partiu, e quando?
- **Condição para encerrar:** Nó f4 (ou f6 se regou).

- `f1` *(narração)* A geladeira não liga faz tempo. Virou armário.
- `f2` *(narração)* Um bilhete preso por um ímã de pizzaria: “Volto no sábado. Não esquece de regar.” *(som: paper)*
- `f3` *(narração)* A letra é inclinada. Eu conheço essa letra. *(pausa 0.8 s)*
- `f4` *(narração)* Não diz qual sábado. *(pausa 1.0 s)*
- `f5` **SE** `plant_watered` → `f6` · **SENÃO** → ``
- `f6` *(narração)* Hoje eu reguei. Isso conta. *(pausa 0.6 s)* → *fim*

#### `fridge_note_again` — Bilhete — de novo
- **Condição para iniciar:** Examinar a geladeira outra vez
- **Sons:** —
- **Animação / expressão:** —
- **Consequência narrativa:** Nenhuma (caracteriza Alen e a casa).
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `fn1` *(narração)* “Volto no sábado.” Continua sem dizer qual. → *fim*

#### `closed_door_1` — Porta do fundo, pregada
- **Condição para iniciar:** Aproximar-se da porta ao lado da geladeira
- **Sons:** —
- **Animação / expressão:** —
- **Consequência narrativa:** Gancho: o cômodo fechado (de quem era?).
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `cd1` *(narração)* A porta do fundo está fechada, com uma tábua pregada de lado a lado.
- `cd2` *(narração)* Fui eu que preguei. Acho que fui eu. *(pausa 0.9 s)* → *fim*

#### `closed_door_2` — Porta do fundo — de novo
- **Condição para iniciar:** Examinar a porta outra vez
- **Sons:** —
- **Animação / expressão:** —
- **Consequência narrativa:** Nenhuma (caracteriza Alen e a casa).
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `cd1` *(narração)* Eu não abro. Não é que esteja trancada. → *fim*

#### `table_1` — Mesa que manca
- **Condição para iniciar:** Aproximar-se da mesa pelo lado de baixo
- **Sons:** —
- **Animação / expressão:** —
- **Consequência narrativa:** Nenhuma (caracteriza Alen e a casa).
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `tb1` *(narração)* A mesa manca. Um caderno de matemática dobrado segura a perna. Finalmente serve pra alguma coisa. → *fim*

#### `table_2` — As duas cadeiras
- **Condição para iniciar:** Examinar a mesa de novo
- **Sons:** —
- **Animação / expressão:** —
- **Consequência narrativa:** Gancho: um lugar mantido vazio.
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `tb1` *(narração)* Duas cadeiras. Uso só a que não balança.
- `tb2` *(narração)* A outra eu mantenho arrumada. Por hábito. *(pausa 0.8 s)* → *fim*

#### `stairs_1` — Escada para o nada
- **Condição para iniciar:** Aproximar-se da escada quebrada
- **Sons:** vento pelo desabamento (posicional)
- **Animação / expressão:** Neve entra pela abertura
- **Consequência narrativa:** Nenhuma (caracteriza Alen e a casa).
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `sr1` *(narração)* A escada sobe até um pedaço de céu. Já foi o segundo andar.
- `sr2` *(narração)* Não subo. Não tem mais pra onde subir. *(pausa 0.8 s)* → *fim*

#### `stairs_2` — Escada — de novo
- **Condição para iniciar:** Examinar a escada outra vez
- **Sons:** —
- **Animação / expressão:** —
- **Consequência narrativa:** Nenhuma (caracteriza Alen e a casa).
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `sr1` *(narração)* Onze degraus. Eram dezesseis. Eu conto, mesmo sabendo. → *fim*

#### `collapse_1` — O desabamento
- **Condição para iniciar:** Aproximar-se do meio da entrada desabada
- **Sons:** o ambiente “abre”: o som abafado de dentro vira vento de fora
- **Animação / expressão:** Feixe frio de luz, neve que cai e lona batendo ao vento
- **Consequência narrativa:** Nenhuma (caracteriza Alen e a casa).
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `cl1` *(narração)* O teto desceu numa noite e nunca mais subiu. A neve entra como visita que não avisa.
- `cl2` *(narração)* Cobri com lona, com tábua e com esperança. A neve gosta mais da esperança. *(pausa 0.8 s)* → *fim*

#### `collapse_2` — O buraco no chão
- **Condição para iniciar:** Examinar o desabamento de novo
- **Sons:** —
- **Animação / expressão:** —
- **Consequência narrativa:** Nenhuma (caracteriza Alen e a casa).
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `cl1` *(narração)* Fico longe do pedaço de chão que cedeu. Ele também não avisa. → *fim*

#### `toolbox_1` — Caixa de ferramentas
- **Condição para iniciar:** Aproximar-se da caixa perto da porta da frente
- **Sons:** —
- **Animação / expressão:** —
- **Consequência narrativa:** Mostra que Alen conserta a casa sozinho.
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `tx1` *(narração)* A caixa de ferramentas tem mais fita do que prego. O martelo tem o cabo remendado.
- `tx2` *(narração)* Remendei a ferramenta que remenda. Ninguém diga que não tenho método. *(pausa 0.7 s)* → *fim*

#### `parents_overheard` — Conversa interrompida
- **Condição para iniciar:** Automática: a primeira vez que Alen se aproxima da sala (x ≈ 586)
- **Sons:** rádio com interferência; o sussurro cessa quando ele aparece
- **Animação / expressão:** Alen para; a mãe sorri rápido demais
- **Consequência narrativa:** Planta o medo (estradas, fronteiras) sem explicar. Não grava escolhas.
- **Condição para encerrar:** Nó o6; o jogador volta ao controle.

- `o1` **Mãe:** ...se fecharem a estrada também, como é que a gente—
- `o2` **Pai:** Shh. O Alen. *(pausa 0.5 s)*
- `o3` *(narração)* A voz do rádio continua falando sozinha. *(pausa 0.9 s)*
- `o4` **Mãe:** Bom dia, filho. Dormiu? *(pausa 0.6 s)*
- `o5` **Alen:** Mais ou menos.
- `o6` *(narração)* Ela sorri rápido demais. Finjo que não ouvi o resto. → *fim*

#### `pai_1` — Pai (poltrona) — conversa
- **Condição para iniciar:** Interagir com o pai (sentado na poltrona, coberto por um cobertor)
- **Sons:** rádio ao fundo, blips graves, tosse curta (opcional)
- **Animação / expressão:** O pai respira devagar, encolhido; o retrato dele aparece na caixa de diálogo
- **Consequência narrativa:** A escolha de abaixar o rádio (aqui ou no próprio rádio) muda a abertura do pai e o volume do rádio. As respostas só mudam o tom: o pai sempre termina tranquilizando e dizendo para Alen descansar. Grava `parents_met` (libera a saída).
- **Condição para encerrar:** Nó z.

- `b0` **SE** `radio_low` → `a1` · **SENÃO** → `c1`
- `a1` **Pai:** Obrigado por abaixar o rádio. → `q`
- `c1` **Pai:** Alen. Você pode abaixar um pouco o rádio?
- `c2` **Pai:** A cabeça não anda boa. *(pausa 0.5 s)*
- `q` **Alen** — *o jogador escolhe:*
    - ▸ “Tá doendo muito?” → `d1`
    - ▸ “(Olhar os remédios na mesinha.)” → `d2` *(narração)*
    - ▸ “Eu abaixo o rádio.” → `d3` *(grava `radio_low=true`)*
- `d1` **Pai:** É só o frio.
- `d1b` **Pai:** Passa. *(pausa 0.7 s)* → `f`
- `d2` **Pai:** Disseram que os medicamentos chegariam esta semana.
- `d2b` **Pai:** Vai ver chegam. *(pausa 0.8 s)* → `f`
- `d3` **Pai:** Obrigado, filho.
- `f` **Pai:** Você ainda tem aula amanhã, não tem?
- `g` **Alen** — *o jogador escolhe:*
    - ▸ “Tenho.” → `h1`
    - ▸ “A escola fechou de novo.” → `h2`
    - ▸ “(Ficar em silêncio.)” → `h3` *(narração)*
- `h1` **Pai:** Então vai dormir cedo. → `z`
- `h2` **Pai:** Fechou, abre. Sempre abre de novo. *(pausa 0.6 s)* → `z`
- `h3` **Pai:** Eu sei, filho. Eu sei. *(pausa 0.6 s)*
- `z` **Pai:** Não precisa se preocupar com a gente. Tenta descansar. *(grava `pai_talked=true`, `parents_met=true`)* → *fim*

#### `pai_again` — Pai — de novo
- **Condição para iniciar:** Falar com o pai depois da primeira conversa
- **Sons:** —
- **Animação / expressão:** —
- **Consequência narrativa:** Nenhuma (caracteriza Alen).
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `pg1` **Pai:** Vai com calma. E fecha bem a porta, que o frio entra. → *fim*

#### `mae_1` — Mãe (sofá) — conversa
- **Condição para iniciar:** Interagir com a mãe (sentada no sofá, com uma caneca e uma manta)
- **Sons:** rádio ao fundo, blips médios
- **Animação / expressão:** A mãe segura a caneca com as duas mãos; desvia o olhar primeiro
- **Consequência narrativa:** Grava `meds_errand`: Marcus comenta o pedido (“Chegou nada…”) e a farmácia da rua ganha uma fala extra. Grava `parents_met`.
- **Condição para encerrar:** Nó v1 ou v2b.

- `m1` **Mãe:** Você comeu alguma coisa?
- `m1c` **Alen** — *o jogador escolhe:*
    - ▸ “Tô sem fome.” → `m2`
    - ▸ “Depois eu como.” → `m3`
- `m2` **Mãe:** Eu sei. Come mesmo assim.
- `m2b` **Mãe:** Tem pão de ontem na bancada. *(pausa 0.5 s)* → `q1`
- `m3` **Mãe:** “Depois” é a palavra que o seu pai usa pro médico. *(pausa 0.6 s)*
- `q1` **Mãe:** Seu pai diz que é só resfriado. Diz isso desde sexta.
- `q2` **Alen** — *o jogador escolhe:*
    - ▸ “Vocês já tomaram o remédio?” → `s1`
    - ▸ “(Ficar olhando pra ela.)” → `s3` *(narração)*
- `s1` **Mãe:** Metade hoje, metade amanhã. Dá pra fazer durar. *(pausa 0.8 s)*
- `s2` *(narração)* Metade. Fico olhando a caixa e não sei o que dizer. → `t`
- `s3` **Mãe:** Vai, filho. Vai respirar um pouco.
- `t` **Mãe:** Passa no armazém do Marcus? Pergunta se chegou alguma coisa. *(grava `meds_errand=true`)*
- `u` **Alen** — *o jogador escolhe:*
    - ▸ “Pergunto.” → `v1`
    - ▸ “E se não tiver?” → `v2`
- `v1` **Mãe:** Obrigada. *(grava `mae_talked=true`, `parents_met=true`)* → *fim*
- `v2` **Mãe:** Então você volta e a gente pensa em outra coisa.
- `v2b` **Mãe:** A gente sempre pensa em outra coisa. *(pausa 0.7 s; grava `mae_talked=true`, `parents_met=true`)* → *fim*

#### `mae_again` — Mãe — de novo
- **Condição para iniciar:** Falar com a mãe depois da primeira conversa
- **Sons:** —
- **Animação / expressão:** —
- **Consequência narrativa:** Nenhuma (caracteriza Alen).
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `mg1` **Mãe:** Pergunta pro Marcus, tá? E volta antes de escurecer. → *fim*

#### `radio_1` — Rádio de válvula (as notícias)
- **Condição para iniciar:** Aproximar-se do rádio, no aparador entre a TV e a poltrona
- **Sons:** voz abafada com chiado; dial âmbar; o chiado cai se o volume for abaixado
- **Animação / expressão:** Dial âmbar pisca; a legenda das notícias fica nítida de perto
- **Consequência narrativa:** Escolha: abaixar (poupa o pai; o rádio e a legenda ficam mais baixos) ou deixar (Alen quer saber). Grava `radio_low`, que muda a fala do pai.
- **Condição para encerrar:** Nó r3 ou r4.

- `r1` *(narração)* O rádio de pilha do meu pai. O dial brilha âmbar, e a voz entra e sai como se falasse de dentro de um poço. *(grava `radio_seen=true`)*
- `r2` **—**: O volume está alto o bastante pra atravessar a casa. — *o jogador escolhe:*
    - ▸ “Abaixar o volume” → `r3` *(grava `radio_low=true`)*
    - ▸ “Deixar como está” → `r4`
- `r3` *(narração)* Giro o botão. A voz vira um sussurro de outra sala. *(som: radio_static)* → *fim*
- `r4` *(narração)* Deixo. Alguém precisa saber o que está acontecendo, mesmo que ninguém queira. → *fim*

#### `radio_again` — Rádio — de novo
- **Condição para iniciar:** Examinar o rádio outra vez
- **Sons:** —
- **Animação / expressão:** —
- **Consequência narrativa:** Nenhuma.
- **Condição para encerrar:** Nó ra1 ou rb1.

- `ra0` **SE** `radio_low` → `ra1` · **SENÃO** → `rb1`
- `ra1` *(narração)* Está baixo. Ainda escuto uma palavra de vez em quando: “fronteira”. → *fim*
- `rb1` *(narração)* Continua falando. Eu continuo sem entender o fim das frases. → *fim*

#### `newspaper_1` — Jornal de 2008 (contexto histórico)
- **Condição para iniciar:** Aproximar-se da mesinha de centro e interagir
- **Sons:** papel
- **Animação / expressão:** —
- **Consequência narrativa:** Manchetes fictícias, inspiradas na crise de 2008, sem nomes reais.
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `nw1` *(narração)* Um jornal de setembro de 2008, que meu pai nunca jogou fora. *(som: paper)*
- `nw2` *(narração)* “BANCO QUEBRA; POUPADORES CERCAM AS AGÊNCIAS.” Embaixo, menor: “FRONTEIRA FECHADA, MILHARES ESPERAM.”
- `nw3` *(narração)* Nos dias seguintes as manchetes só pioraram. Ele guardou só esta, a primeira. *(pausa 0.8 s)* → *fim*

#### `newspaper_2` — Jornal — o horóscopo
- **Condição para iniciar:** Examinar o jornal outra vez
- **Sons:** —
- **Animação / expressão:** —
- **Consequência narrativa:** Nenhuma (caracteriza Alen e o mundo).
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `nw1` *(narração)* Na página de dentro, o horóscopo: “Mudanças positivas à vista.” Alguém circulou o “à vista” com caneta. → *fim*

#### `meds_1` — Remédios na mesinha
- **Condição para iniciar:** Aproximar-se da mesinha entre a poltrona e o abajur
- **Sons:** —
- **Animação / expressão:** —
- **Consequência narrativa:** Mostra a escassez de medicamentos.
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `md1` *(narração)* Três frascos âmbar e uma caixa quase vazia, cortada ao meio com tesoura pra dividir as doses.
- `md2` *(narração)* Um copo d'água, lenços usados e um bilhete: “Seg. ½ — Ter. ½ — Qua. ?” *(pausa 0.8 s)* → *fim*

#### `meds_2` — Remédios — de novo
- **Condição para iniciar:** Examinar a mesinha outra vez
- **Sons:** —
- **Animação / expressão:** —
- **Consequência narrativa:** Nenhuma (caracteriza Alen e o mundo).
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `md1` *(narração)* Não toco. Contar remédio dá a mesma sensação de contar tempo. → *fim*

#### `tv_1` — TV desligada
- **Condição para iniciar:** Aproximar-se do aparador da TV
- **Sons:** —
- **Animação / expressão:** —
- **Consequência narrativa:** Economia doméstica: objeto improvisado.
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `tv1` *(narração)* A TV está coberta por uma toalha de renda, com um vaso em cima. Desligada pra economizar luz. Virou móvel. → *fim*

#### `tv_2` — Tabela de racionamento
- **Condição para iniciar:** Examinar a TV de novo
- **Sons:** —
- **Animação / expressão:** —
- **Consequência narrativa:** Nenhuma (caracteriza Alen e o mundo).
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `tv1` *(narração)* Na parede, a tabela de racionamento: LUZ 4h, ÁGUA 2, REMÉDIO ½. A última linha está riscada de vermelho e reescrita embaixo, com letra menor. → *fim*

#### `window_sala_1` — Janela da sala — a cidade em silêncio
- **Condição para iniciar:** Aproximar-se da janela da sala, à direita do sofá
- **Sons:** vento
- **Animação / expressão:** Neve cai na janela; cortinas de renda
- **Consequência narrativa:** Mostra que a crise não está restrita àquela casa.
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `ws1` *(narração)* Pela janela da sala: telhados cobertos de neve, nenhuma chaminé acesa na rua de baixo e a casa da frente de portas fechadas. → *fim*

#### `window_sala_2` — Janela da sala — as luzes
- **Condição para iniciar:** Examinar a janela da sala outra vez
- **Sons:** —
- **Animação / expressão:** —
- **Consequência narrativa:** Nenhuma (caracteriza Alen e o mundo).
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `ws1` *(narração)* Antes eu contava as luzes acesas da rua à noite. Dava vinte e duas. Parei quando deu nove. *(pausa 0.7 s)* → *fim*

## Cena 3 — A porta (entrada da casa)

#### `door_nocoat` — Porta — sem a jaqueta
- **Condição para iniciar:** Interagir com a porta antes de pegar a jaqueta
- **Sons:** —
- **Animação / expressão:** —
- **Consequência narrativa:** Convida o jogador a explorar a casa antes de sair.
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `dn1` *(narração)* Sem a jaqueta eu não passo da esquina. → *fim*

#### `door_ready` — Porta — pronto para sair
- **Condição para iniciar:** Interagir com a porta da frente (no fim da casa) tendo a jaqueta
- **Sons:** porta (rangido + trinco) ao sair; vento de fora entra antes da imagem
- **Animação / expressão:** Fade para luz fria e pálida (#b9c6d8), não para preto
- **Consequência narrativa:** “Sair” inicia a transição para a cidade; “Ficar” permite olhar o quarto mais uma vez (sem custo).
- **Condição para encerrar:** Escolha “Sair” (a cena de transição assume).

- `d1` **—**: A casa continua do mesmo jeito: remendo sobre remendo, e os dois lá dentro, tentando. Só eu estou de saída. — *o jogador escolhe:*
    - ▸ “Sair” → `fim` *(grava `door_choice="leave"`)*
    - ▸ “Ficar mais um minuto” → `d2` *(grava `door_choice="stay"`)*
- `d2` *(narração)* Mais um minuto. Só pra conferir o que não esqueci. → *fim*

## Cena 4 — A cidade durante o inverno

#### `house_door` — Porta de casa (de fora)
- **Condição para iniciar:** Interagir com a porta da pensão
- **Sons:** —
- **Animação / expressão:** —
- **Consequência narrativa:** Nenhuma (caracteriza Alen).
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `h1` *(narração)* Já saí. Voltar agora seria trapaça. → *fim*

#### `window_radio` — Janela acesa com rádio
- **Condição para iniciar:** Aproximar-se da janela iluminada
- **Sons:** rádio posicional (AudioStreamPlayer2D), mais alto perto da janela
- **Animação / expressão:** Luz da janela com oscilação lenta
- **Consequência narrativa:** Nenhuma (caracteriza Alen).
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `r1` *(narração)* A janela está acesa. Lá dentro, um rádio dá a previsão do tempo pra ninguém em particular.
- `r2` *(narração)* Máxima de quatro graus. Surpresa nenhuma. *(pausa 0.6 s)* → *fim*

#### `smoke_house` — Casa com chaminé
- **Condição para iniciar:** Aproximar-se da casa do fim da rua
- **Sons:** estalo de lenha posicional
- **Animação / expressão:** Fumaça subindo da chaminé
- **Consequência narrativa:** Nenhuma (caracteriza Alen).
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `s1` *(narração)* Cheiro de lenha. Alguém acordou mais cedo que eu, o que não é difícil. → *fim*

#### `notice_board` — Mural de avisos (detalhe opcional)
- **Condição para iniciar:** Interagir com o mural
- **Sons:** paper
- **Animação / expressão:** —
- **Consequência narrativa:** Grava `read_notice`: Marcus comenta o edital em `marcus_intro`. Gancho: o jardim será vendido.
- **Condição para encerrar:** Último nó.

- `n1` *(narração)* O mural da cidade. Rifa de bicicleta, aula de violão, um gato perdido — alguém riscou “perdido” e escreveu “voltou”. *(som: paper)*
- `n2` *(narração)* Uma folha amarelada, presa por duas tachinhas: *(grava `read_notice=true`)*
- `n3` *(narração)* “EDITAL. Venda de terreno rural, antiga chácara, final da Estrada do Moinho. Propostas até 31 de março.”
- `n4` *(narração)* Março. Ainda falta. *(pausa 0.8 s)*
- `n5` *(narração)* Não sei por que li duas vezes. *(pausa 0.8 s)* → *fim*

#### `notice_again` — Mural — de novo
- **Condição para iniciar:** Interagir com o mural outra vez
- **Sons:** —
- **Animação / expressão:** —
- **Consequência narrativa:** Nenhuma (caracteriza Alen).
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `na1` *(narração)* Continua dizendo março. → *fim*

#### `bench_book` — Banco com garrafa térmica e livro (detalhe opcional)
- **Condição para iniciar:** Interagir com o banco
- **Sons:** —
- **Animação / expressão:** —
- **Consequência narrativa:** Gancho para Sophia (Capítulo II): objetos de alguém que ainda não apareceu.
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `bb1` *(narração)* Uma garrafa térmica e um livro de capa gasta num banco. Ninguém por perto.
- `bb2` *(narração)* Tem uma folha seca marcando a página. Não é meu. Deixo onde está. *(pausa 0.6 s)* → *fim*

#### `pinhao` — Pinhão (detalhe opcional que revela uma mania de Alen)
- **Condição para iniciar:** Interagir com o pé da araucária
- **Sons:** galho/estalo (sfx 'twig')
- **Animação / expressão:** —
- **Consequência narrativa:** Grava `has_pinhao`: Eleanor comenta o pinhão no bolso, no jardim.
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `pi1` *(narração)* Pinhões no chão, caídos da araucária. A maioria rachada pela geada.
- `pi2` *(narração)* Pego um inteiro. É duro, frio e inútil. Guardo no bolso. *(grava `has_pinhao=true`)*
- `pi3` *(narração)* Eu faço isso: coleciono coisas sem função. Pelo menos não pesam. *(pausa 0.6 s)* → *fim*

#### `pinhao_after` — Pinhão — de novo
- **Condição para iniciar:** Interagir de novo com o pé da araucária
- **Sons:** —
- **Animação / expressão:** —
- **Consequência narrativa:** Nenhuma (caracteriza Alen).
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `pia1` *(narração)* Já tenho um. Não precisa de dois. → *fim*

#### `sign_road` — Placa da estrada
- **Condição para iniciar:** Interagir com a placa
- **Sons:** —
- **Animação / expressão:** —
- **Consequência narrativa:** Nenhuma (caracteriza Alen).
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `sg1` *(narração)* ESTRADA DO MOINHO, diz a placa. Embaixo, outra mais nova, quase colada: “Sem saída”.
- `sg2` *(narração)* A de baixo parece mais sincera. *(pausa 0.6 s)* → *fim*

#### `exit_locked` — Fim da estrada — antes de falar com Marcus
- **Condição para iniciar:** Interagir com a saída da cidade sem ter falado com Marcus
- **Sons:** —
- **Animação / expressão:** —
- **Consequência narrativa:** Empurra o jogador para a conversa com Marcus, sem barreira artificial.
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `x1` *(narração)* Não tenho motivo pra ir por aí. Ainda. → *fim*

#### `marcus_intro` — Marcus — primeira conversa (personagem secundário)
- **Condição para iniciar:** Interagir com Marcus (na calçada do Armazém Dias) pela primeira vez
- **Sons:** vassoura (loop leve que para durante a conversa) · blips de voz grave · papel ao receber o pacote
- **Animação / expressão:** Marcus para de varrer e se apoia na vassoura; volta a varrer ao fim
- **Consequência narrativa:** Três escolhas, todas só mudam COMO Alen fala e como os outros reagem: `alen_tone` = gentle/dry/quiet (muda a primeira frase de Eleanor); a pergunta sobre a estrada decide se Alen recebe o pacote (`got_package`, muda a abertura de Eleanor). Tudo converge para o mesmo caminho. Se a mãe de Alen pediu para perguntar por remédio (`meds_errand`), Marcus responde (“Chegou nada…”) e revela que está tentando conseguir.
- **Condição para encerrar:** Nó q6 ou bye. Grava `marcus_met` (libera a saída da cidade).

- `a1` **Marcus:** Olha só. Vivo.
- `a2` **Marcus:** Achei que o inverno tinha te levado. Ou a preguiça. Aqui as duas se confundem.
- `tone` **Alen** — *o jogador escolhe:*
    - ▸ “Bom dia pra você também.” → `tg` *(grava `alen_tone="gentle"`)*
    - ▸ “Preguiça. Com certeza.” → `td` *(grava `alen_tone="dry"`)*
    - ▸ “(Dar de ombros.)” → `tq` *(grava `alen_tone="quiet"`; narração)*
- `tg` **Marcus:** Bom dia é exagero. Tá dois graus e a vassoura congelou. → `dest`
- `td` **Marcus:** Honesto. Isso é novo. → `dest`
- `tq` **Marcus:** Resposta curta, vassoura longa. Eu respeito.
- `dest` **Marcus:** E vai pra onde? Com essa cara de quem deixou o destino em casa.
- `dch` **Alen** — *o jogador escolhe:*
    - ▸ “Só dar uma volta.” → `d1`
    - ▸ “Não sei ainda.” → `d2`
    - ▸ “Não é da sua conta, Marcus.” → `d3`
- `d1` **Marcus:** Uma volta. Em Pinhal Alto. Dá uns quatro minutos, cinco se você parar pra olhar o bueiro. → `bn`
- `d2` **Marcus:** Pelo menos não inventou um destino. Cuidado, honestidade vira hábito. → `bn`
- `d3` **Marcus:** Verdade. Mas é a minha calçada, e você tá em cima dela.
- `bn` **SE** `read_notice` → `m1` · **SENÃO** → `mq`
- `m1` **Marcus:** Te vi parado ali no mural. Ninguém para no mural.
- `m2` **Marcus:** O “março” daquele papel é pra dar tempo de todo mundo fingir que não viu. → `mq`
- `n8` **Marcus:** Se a volta passar pelo fim da estrada do Moinho...
- `n9` **Marcus:** ...esquece. Vai pro lado que quiser. *(pausa 0.9 s; grava `marcus_met=true`)*
- `ask` **Alen** — *o jogador escolhe:*
    - ▸ “O que tem no fim da estrada?” → `q1`
    - ▸ “Tá bom. Até mais.” → `bye`
- `q1` **Marcus:** Um jardim. O que sobrou dele.
- `q2` **Marcus:** A Eleanor ainda vai lá todo dia. Eu levaria uma coisa pra ela, mas meu joelho tem opinião sobre ladeira.
- `q3` **Alen:** Seu joelho gosta de todas as outras ladeiras.
- `q4` **Marcus:** Meu joelho é seletivo.
- `q5` **Marcus:** Tem um pacotinho na bancada. Dobradiça pro portão dela. Se passar por lá. *(pausa 0.8 s)*
- `q6` *(narração)* Marcus me entrega um pacote embrulhado em jornal. *(som: paper; grava `got_package=true`)* → *fim*
- `bye` **Marcus:** Boa. Ninguém precisa de tudo respondido antes do café. → *fim*
- `mq` **SE** `meds_errand` → `e1` · **SENÃO** → `n8`
- `e1` **Alen:** Minha mãe mandou perguntar se chegou remédio.
- `e2` **Marcus:** Chegou nada. *(pausa 0.6 s)*
- `e3` **Marcus:** Quando chegar, você é o primeiro a saber.
- `e4` **Marcus:** Diz pra ela que eu tô tentando. *(pausa 0.8 s)* → `n8`

#### `marcus_again` — Marcus — conversas seguintes
- **Condição para iniciar:** Falar com Marcus depois da primeira conversa
- **Sons:** blip grave
- **Animação / expressão:** Marcus não retoma a vassoura até o diálogo acabar
- **Consequência narrativa:** Nenhuma.
- **Condição para encerrar:** Nó g1 ou g2.

- `g0` **SE** `got_package` → `g1` · **SENÃO** → `g2`
- `g1` **Marcus:** Dobradiça. Eleanor. Ladeira. Você sabe o caminho. → *fim*
- `g2` **Marcus:** Mudou de ideia sobre a volta? Tá frio demais pra mudar de ideia. → *fim*

#### `pharmacy_1` — Farmácia fechada (comércio em decadência)
- **Condição para iniciar:** Interagir com a porta da farmácia
- **Sons:** vento
- **Animação / expressão:** —
- **Consequência narrativa:** Mostra a escassez de remédios fora de casa; se Alen recebeu o pedido da mãe, comenta.
- **Condição para encerrar:** Último nó.

- `ph1` *(narração)* FARMÁCIA. Na porta, um papel escrito à mão: “SEM ESTOQUE. NÃO INSISTA.”
- `ph2` *(narração)* Tem uma marca de punho na madeira, logo abaixo. Alguém insistiu mesmo assim. *(pausa 0.7 s)*
- `ph3` **SE** `meds_errand` → `ph4` · **SENÃO** → ``
- `ph4` *(narração)* Minha mãe mandou perguntar. A porta já respondeu. → *fim*

#### `pharmacy_again` — Farmácia — de novo
- **Condição para iniciar:** Interagir com a porta outra vez
- **Sons:** —
- **Animação / expressão:** —
- **Consequência narrativa:** Nenhuma (caracteriza Alen).
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `pg21` *(narração)* Alguém trocou a fita do papel hoje. Tem gente que ainda cuida da notícia ruim. → *fim*

## Cena 5 — O jardim abandonado

#### `gate_broken` — Portão quebrado
- **Condição para iniciar:** Interagir com o portão
- **Sons:** ferro rangendo ao vento (opcional)
- **Animação / expressão:** —
- **Consequência narrativa:** Nenhuma (caracteriza Alen).
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `g1` *(narração)* O portão pende de um lado só. Está preso por um parafuso e muita teimosia. → *fim*

#### `stalks` — Girassóis secos (detalhe)
- **Condição para iniciar:** Interagir com a fileira de caules
- **Sons:** folhas secas
- **Animação / expressão:** —
- **Consequência narrativa:** Mostra que havia girassóis ali, sem dizer nada além.
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `st1` *(narração)* Caules secos, altos demais pra serem mato. Alguém plantou isso. Em fileira, com régua.
- `st2` *(narração)* Uma das cabeças ainda pende, preta e oca. Os passarinhos aproveitaram tudo. *(pausa 0.6 s)* → *fim*

#### `bench_initials` — Banco com iniciais (detalhe)
- **Condição para iniciar:** Interagir com o banco
- **Sons:** —
- **Animação / expressão:** —
- **Consequência narrativa:** Gancho: L. (a mulher da foto) e E. (Eleanor).
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `bi1` *(narração)* Duas iniciais riscadas com canivete no encosto: L. e E.
- `bi2` *(narração)* Uma está mais funda. Alguém passou o canivete duas vezes. *(pausa 0.7 s)* → *fim*

#### `watering_can` — Regador (detalhe)
- **Condição para iniciar:** Interagir com o regador
- **Sons:** —
- **Animação / expressão:** —
- **Consequência narrativa:** Nenhuma (caracteriza Alen).
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `wc1` *(narração)* Um regador enferrujado, com um resto de água em cima de gelo. Alguém ainda usa isso. → *fim*

#### `eleanor_intro` — Eleanor — primeira conversa
- **Condição para iniciar:** Interagir com Eleanor (ajoelhada junto aos canteiros) pela primeira vez
- **Sons:** vento do jardim · folhas secas · blips de voz mais aguda · papel (se entregar o pacote) · sem música
- **Animação / expressão:** Eleanor nunca vira o rosto antes de falar; só se levanta na pausa do nó n4. Alen: postura recolhida; no nó o2b ela desvia o olhar
- **Consequência narrativa:** Abertura muda conforme `got_package`; a observação sobre Alen muda conforme `alen_tone` (dry/gentle/quiet); se Alen guardou o pinhão, Eleanor fala de plantar sem ver o resultado. Nada explica o símbolo do girassol.
- **Condição para encerrar:** Nó n17 (grava `eleanor_met`).

- `n1` **Eleanor:** O portão. Você veio empurrando com o ombro, imagino. Ele só abre pra quem insiste.
- `n2` **Eleanor:** Ah. Achei que era o Marcus.
- `br1` **SE** `got_package` → `y1` · **SENÃO** → `z1`
- `y1` *(narração)* Entrego o pacote embrulhado em jornal. *(som: paper)*
- `y2` **Eleanor:** Dobradiça. Pedi em setembro.
- `y3` **Eleanor:** O Marcus entrega as coisas no tempo dele. É o tempo mais lento do estado. → `n4`
- `z1` **Eleanor:** O Marcus não mandou a dobradiça, né.
- `z2` **Alen:** Não sabia que era pra mandar.
- `z3` **Eleanor:** Claro que não. Deixa eu adivinhar: o joelho dele tem opinião sobre ladeira.
- `n4` **Eleanor:** E você é... *(pausa 0.5 s)*
- `n5` **Alen** — *o jogador escolhe:*
    - ▸ “Alen.” → `a1`
    - ▸ “Só estava passando.” → `b1`
    - ▸ “(Olhar o jardim em volta.)” → `c1` *(narração)*
- `a1` **Eleanor:** Alen.
- `a2` **Eleanor:** Tá. Guardei. *(pausa 0.8 s)* → `tb`
- `b1` **Eleanor:** Ninguém passa por aqui. A estrada acaba na cerca.
- `b2` **Eleanor:** Mas pode ficar. Passando também é um jeito de estar. → `tb`
- `c1` **Eleanor:** O jardim faz isso. As pessoas chegam e esquecem o que iam dizer.
- `tb` **SE** `alen_tone` = `dry` → `t1` · **SENÃO** → `tb2`
- `tb2` **SE** `alen_tone` = `gentle` → `t2` · **SENÃO** → `t3`
- `t1` **Eleanor:** O Marcus te passou o sarcasmo ou você já veio com ele? → `n8`
- `t2` **Eleanor:** Você tem boa educação. Isso o Marcus não te ensinou. → `n8`
- `t3` **Eleanor:** Você fala pouco. Combina com o jardim.
- `n8` **Eleanor:** Você anda igual a alguém que eu conhecia. *(pausa 0.9 s)*
- `n9` **Alen** — *o jogador escolhe:*
    - ▸ “Muita gente anda igual.” → `o1`
    - ▸ “Quem?” → `o2`
- `o1` **Eleanor:** Pode ser. *(pausa 0.7 s)* → `pn`
- `o2` **Eleanor:** Alguém. *(pausa 1.0 s)*
- `o2b` **Eleanor:** Deixa. Velha tem esse direito: começar frases e não terminar.
- `pn` **SE** `has_pinhao` → `p1` · **SENÃO** → `n12`
- `p1` **Eleanor:** Isso no seu bolso é pinhão?
- `p2` **Alen:** Achei no chão.
- `p3` **Eleanor:** Araucária leva décadas pra virar alguma coisa. Quem planta nem chega a ver.
- `p4` **Eleanor:** Planta mesmo assim. Eu acho isso bonito. E um pouco burro.
- `p5` **Alen** — *o jogador escolhe:*
    - ▸ “Dá pra ser as duas coisas.” → `q1`
    - ▸ “Eu ia dizer só a segunda.” → `q2`
- `q1` **Eleanor:** Dá. É a minha especialidade. → `n12`
- `q2` **Eleanor:** Viu? Já estamos de acordo.
- `n12` **Eleanor:** Isto aqui já foi mais... tudo. *(pausa 0.6 s)*
- `n13` **Eleanor:** Eu venho todo dia tirar o que secou. Não adianta nada, a gente sabe.
- `n13b` **Eleanor:** Mas o chá é bom e a vista é melhor que a da minha cozinha.
- `n14` **Eleanor:** Olha à vontade. Só não pisa nos canteiros da esquerda — tem bulbo dormindo ali.
- `n15` **Alen:** Dormindo?
- `n16` **Eleanor:** Dormindo. Um dia eu explico. Ou não.
- `n17` **Eleanor:** O galpão tá aberto, se quiser olhar. Tem mais ferrugem que coisa útil. *(grava `eleanor_met=true`)* → *fim*

#### `eleanor_idle` — Eleanor — conversa curta
- **Condição para iniciar:** Falar com Eleanor de novo, antes de achar a semente
- **Sons:** —
- **Animação / expressão:** —
- **Consequência narrativa:** Nenhuma (caracteriza Alen).
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `ei1` **Eleanor:** O galpão tá aberto. Cuidado com a viga baixa. → *fim*

## Cena 6 — A semente

#### `seed_find` — Achar a semente
- **Condição para iniciar:** Interagir com a lata de biscoito junto ao galpão (1ª vez)
- **Sons:** metal (tampa) · papel
- **Animação / expressão:** Sem música; só vento do jardim
- **Consequência narrativa:** Grava `has_seed`. Sem grande revelação: um pacote velho numa lata.
- **Condição para encerrar:** Último nó.

- `sf1` *(narração)* Atrás de ferramentas sem cabo, uma lata de biscoito amassada. A tampa cede com um estalo.
- `sf2` *(narração)* Dentro, pacotinhos de papel desbotado. Quase todos vazios.
- `sf3` *(narração)* Um deles ainda tem peso. Na frente, o desenho de uma flor e letras apagadas: GIRASSOL. “Plantar após a última geada.” *(pausa 0.4 s)*
- `sf4` *(narração)* A última geada, pelo visto, ainda não foi. *(pausa 0.9 s; grava `has_seed=true`)* → *fim*

#### `tin_after` — Lata — depois de achar a semente
- **Condição para iniciar:** Interagir de novo com a lata
- **Sons:** —
- **Animação / expressão:** —
- **Consequência narrativa:** Nenhuma (caracteriza Alen).
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `ta1` *(narração)* Mais nada na lata além de ferrugem e a lembrança de biscoitos. → *fim*

#### `eleanor_seeds` — Eleanor — a semente
- **Condição para iniciar:** Falar com Eleanor tendo achado a semente (`has_seed`) e ainda sem `eleanor_ok`
- **Sons:** papel · vento · passos se afastando (a figura de Eleanor some em fade)
- **Animação / expressão:** Eleanor sai de cena; Alen fica sozinho no jardim
- **Consequência narrativa:** Libera o canteiro (`eleanor_ok`). Ela nunca diz o que o girassol significa: só fala de geada, probabilidade e terra dura.
- **Condição para encerrar:** Último nó.

- `s1` *(narração)* Mostro o pacote de sementes. Ela o vira nas mãos, como se pesasse.
- `s2` **Eleanor:** Girassol. Do ano retrasado, pelo papel.
- `s3` **Eleanor:** Essa lata não é aberta desde...
- `s4` **Eleanor:** ...faz tempo. *(pausa 1.0 s)*
- `s5` **Alen:** Dá pra plantar?
- `s6` **Eleanor:** Semente é mais teimosa que gente. Dá.
- `s7` **Eleanor:** Mas é inverno. Se plantar agora, a geada pega. Provavelmente.
- `s8` **Alen:** Provavelmente.
- `s9` **Eleanor:** Já errei no “provavelmente” antes. Duas vezes. Ou três. *(pausa 0.7 s)*
- `s10` **Eleanor:** O canteiro junto à cerca, lá no fundo, tá livre. A terra tá dura, vai ter que ser com as mãos.
- `s11` **Eleanor:** Eu vou ver se a chaleira ainda lembra como se faz chá. Fica à vontade. *(grava `eleanor_ok=true`)* → *fim*

#### `bed_empty` — Canteiro livre — sem semente
- **Condição para iniciar:** Interagir com o canteiro sem `has_seed`
- **Sons:** —
- **Animação / expressão:** —
- **Consequência narrativa:** Nenhuma (caracteriza Alen).
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `be1` *(narração)* Um canteiro vazio junto à cerca. Terra dura, pedras em volta, nada pra plantar. → *fim*

#### `bed_ask_first` — Canteiro livre — sem permissão
- **Condição para iniciar:** Interagir com o canteiro tendo a semente mas sem ter falado com Eleanor sobre ela
- **Sons:** —
- **Animação / expressão:** —
- **Consequência narrativa:** Motiva falar com Eleanor de forma natural, sem objetivo de missão.
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `ba1` *(narração)* Tenho a semente. Mas a terra não é minha. Melhor perguntar antes. → *fim*

#### `bed_planted` — Canteiro — depois de plantar
- **Condição para iniciar:** Interagir com o canteiro depois de plantar
- **Sons:** —
- **Animação / expressão:** —
- **Consequência narrativa:** Nenhuma (caracteriza Alen).
- **Condição para encerrar:** Última linha avançada; o jogador pode examinar de novo.

- `bp1` *(narração)* A terra está como deixei: escura, um pouco mais alta. Nada acontece. Por ora, tudo bem. → *fim*

#### `plant_start` — Plantar — preparação
- **Condição para iniciar:** Interagir com o canteiro tendo semente e permissão
- **Sons:** vento · nada de música
- **Animação / expressão:** Câmera parada; Alen se agacha
- **Consequência narrativa:** Segue a sequência interativa: cavar ×3, deixar a semente, cobrir ×2 (tecla de interação).
- **Condição para encerrar:** Último nó; a sequência de plantio continua em código.

- `ps1` *(narração)* A semente é pequena, listrada, quase sem peso.
- `ps2` **Alen:** Estação errada. Eu sei. *(pausa 0.8 s)*
- `ps3` *(narração)* A terra está fria e dura. Só dá pra cavar com as mãos. *(pausa 0.8 s)* → *fim*

#### `plant_end` — Fala final
- **Condição para iniciar:** Ao terminar de cobrir a semente
- **Sons:** somente ambiente (o vento começa a baixar); nenhuma música
- **Animação / expressão:** Alen de pé diante da terra; sem gestos grandes
- **Consequência narrativa:** Falas iniciais variam por `alen_tone` (humor seco) e `plant_watered` (a muda do quarto). As duas últimas são iguais para todos.
- **Condição para encerrar:** Nó n2. Em seguida: câmera sobe, raio de sol baixo, uma única nota, cartão “FIM DO PRÓLOGO”.

- `a0` **SE** `alen_tone` = `dry` → `d1` · **SENÃO** → `a1`
- `d1` **Alen:** Isso foi dramático demais pra uma semente.
- `a1` **SE** `plant_watered` → `w1` · **SENÃO** → `w2`
- `w1` **Alen:** A do quarto eu reguei hoje. Já é um começo. → `n1`
- `w2` **Alen:** Tomara que eu me saia melhor com essa do que com a do quarto.
- `n1` **Alen:** Não sei se vai crescer. *(pausa 1.4 s)*
- `n2` **Alen:** Mas amanhã eu volto. Pra ver. *(pausa 2.6 s)* → *fim*
