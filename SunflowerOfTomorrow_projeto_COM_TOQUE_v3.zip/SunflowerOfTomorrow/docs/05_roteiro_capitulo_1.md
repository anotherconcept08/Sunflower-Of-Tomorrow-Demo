# Capítulo I — Um Lugar Para Escapar: roteiro dos diálogos

> Gerado por `python3 tools/gerar_dialogos_cap1.py` a partir de `tools/roteiro_cap1/*.py`. O jogo lê `data/dialogue/chapter1_*.json`.
> Convenções: *(narração)* = pensamento de Alen; `nX` = nó; “→” = salto; pausa = silêncio antes da fala.

## Casa e bairro

#### `c1_wake`
- `n1` *(narração)* Amanhã chegou, que era o combinado.
- `n2` *(narração)* A muda do quarto continua viva. O caderno continua com uma linha só. O meu estômago também só tem uma linha, e ela diz “comida”.
- `n3` *(narração)* Do outro lado da parede, o rádio já está falando sozinho. *(pausa 0.6 s)* → *fim*

#### `c1_mae_1`
- `n1` **Mãe:** Dormiu? *(pausa 0.4 s)*
- `n2` **Alen:**  — *o jogador escolhe:*
    - ▸ “Mais ou menos.” → `n3`
    - ▸ “O frio acordou a casa inteira.” → `n4`
- `n3` **Mãe:** Mais ou menos já é mais do que a maioria. *(pausa 0.5 s)* → `n5`
- `n4` **Mãe:** Acordou. Mas a casa não reclamou, que eu ouvi.
- `n5` **Mãe:** Essa caneca é sua. Ainda está morna.
- `n6` *(narração)* Ela me estende a caneca com as duas mãos. Uma delas treme um pouco. Faço de conta que é por causa do frio.
- `n7` **Mãe:** E esse aqui — *(pausa 0.5 s)*
- `n8` *(narração)* Ela abre o outro punho. Dentro, um cartão dobrado em quatro, mole de tanto ser apertado.
- `n9` *(narração)* “CARTÃO DE RAÇÃO Nº 117 — FAMÍLIA HADER — 3 PESSOAS.” Carimbo da Prefeitura, azul, já meio apagado.
- `n10` **Mãe:** Biblioteca, no centro. Disseram que o balcão abriu de novo hoje.
- `n11` **Alen:** Eu sei onde é.
- `n12` **Mãe:** Sabe. Eu que fico repetindo, pra ouvir que alguém sabe. *(pausa 0.6 s)*
- `n13` **Mãe:** Traz o que tiver. Se tiver pão, traz pão. Se não tiver pão, arroz. Se não tiver arroz...
- `n14` **Alen:** Eu trago o que tiver, mãe.
- `n15` **Alen:**  — *o jogador escolhe:*
    - ▸ “Eu volto antes de escurecer.” → `n16`
    - ▸ “A senhora está bem?” → `n17`
    - ▸ “(Pegar o cartão em silêncio.)” → `n19`
- `n16` **Mãe:** É bom. A rua fica estranha quando escurece. *(pausa 0.5 s)* → `n19`
- `n17` **Mãe:** Estou ótima. *(pausa 0.9 s)*
- `n18` **Mãe:** Estou cansada, que é diferente. *(pausa 0.6 s)*
- `n19` **Mãe:** Ah. E Alen... não discute com ninguém hoje. Hoje todo mundo está com a paciência no fim. *(grava `c1_card=true`, `c1_mae_talked=true`)* → *fim*

#### `c1_mae_again`
- `n1` **Mãe:** Já está com o cartão? *(pausa 0.3 s)*
- `n2` **Alen:** Estou.
- `n3` **Mãe:** Então vai logo. Antes que eu invente mais recomendação. → *fim*

#### `c1_pai_1`
- `n1` **Pai:** Alen. *(pausa 0.4 s)*
- `n2` *(narração)* Ele não levanta os olhos do livro. Está aberto na mesma página desde ontem; eu sei porque a página tem uma dobra no canto que não estava aí.
- `n3` **Pai:** Vai pela Rua das Lojas. Não pela avenida. Os soldados fecharam a avenida e a estrada do Moinho esta noite.
- `n4` *(narração)* Estrada do Moinho. Fechada. *(pausa 0.8 s)*
- `n5` **Alen:**  — *o jogador escolhe:*
    - ▸ “Fecharam por quê?” → `n6`
    - ▸ “Eu não vou discutir com soldado.” → `n7`
    - ▸ “(Não dizer nada.)” → `n10`
- `n6` **Pai:** O rádio disse “por segurança”. É o que o rádio diz quando sabe e não pode dizer. *(pausa 0.5 s)* → `n10`
- `n7` **Pai:** Você discute com o rádio.
- `n8` **Alen:** O rádio merece.
- `n9` **Pai:** Merece. Mesmo assim, se um soldado pedir pra voltar, volta. *(pausa 0.4 s)*
- `n10` **Pai:** E leva isto.
- `n11` *(narração)* Ele tira o cachecol do próprio pescoço e me estende. Hoje é o único calor extra que ele tem.
- `n12` **Alen:**  — *o jogador escolhe:*
    - ▸ “O senhor precisa mais.” → `n13`
    - ▸ “Obrigado.” → `n15`
- `n13` **Pai:** Eu estou dentro de casa, com um cobertor e uma poltrona. Você vai pra fora do mundo. *(pausa 0.5 s)*
- `n14` **Pai:** Leva. → `n16`
- `n15` **Pai:** Não agradece. Devolve inteiro.
- `n16` **Pai:** Mais uma coisa. Se a biblioteca ainda tiver “Contos de Outros Mundos”, dá uma olhada. *(pausa 0.4 s)*
- `n17` **Pai:** Estou devendo a mim mesmo o último conto há dois anos.
- `n18` *(narração)* Ele diz isso como se fosse uma piada. Rio como se fosse. *(grava `c1_pai_talked=true`, `c1_scarf=true`, `c1_book_asked=true`)* → *fim*

#### `c1_pai_again`
- `n1` **Pai:** Cachecol?
- `n2` **Alen:** Estou com ele.
- `n3` **Pai:** Ótimo. Então o resto da lista é com Deus e com a Dona Helena, que lá é quem manda. *(pausa 0.5 s)* → *fim*

#### `c1_radio_c1`
- `n1` *(narração)* O rádio de válvula chia, acha uma estação e perde de novo.
- `n2` *(narração)* “...a prefeitura de Declan City informa que o toque de recolher passa a valer às vinte horas em todos os setores...”
- `n3` *(narração)* “...repetimos: as vinte horas.” *(pausa 0.5 s)*
- `n4` *(narração)* Vinte horas. A luz da casa volta às vinte. Até nisso eles combinaram. → *fim*

#### `c1_door_nocard`
- `n1` *(narração)* Sem o cartão eu vou até lá pra voltar de mãos vazias.
- `n2` *(narração)* A mãe está com ele. Ou estava. → *fim*

#### `c1_door_parents`
- `n1` *(narração)* Eu não saio sem falar com os dois. Seria a primeira vez que eu saio e a casa fica me olhando pelas costas. → *fim*

#### `c1_door_ready`
- `n1` *(narração)* A porta da frente. Do outro lado, a rua, a neve e um dia inteiro de coisas que dão errado por motivos que ninguém explica.
- `n2` *(narração)* Lista de hoje: um cartão, uma biblioteca, uma caixa.
- `n3`  — *o jogador escolhe:*
    - ▸ “Sair.” → `n4` *(grava `door_choice`)*
    - ▸ “Mais um minuto.” → `n5`
- `n4` *(narração)* Fecho a porta devagar, pra não acordar a casa. Ela já está acordada. *(pausa 0.5 s)* → *fim*
- `n5` *(narração)* Tudo bem. Um minuto não custa nada. É o que a gente tem de sobra. → *fim*

#### `c1_marcus_1`
- `n1` **Marcus:** Olha só quem acordou antes do sol e depois do café, que não tem. *(pausa 0.3 s)*
- `n2` **SE** `planted` → `n3` · **SENÃO** → `n5`
- `n3` **Marcus:** Soube que você foi lá no Moinho ontem. *(pausa 0.4 s)*
- `n4` **Marcus:** Pois então. Ontem à noite chegou um caminhão, dois jipes e uma ordem. A estrada fechou. → `n6`
- `n5` **Marcus:** Ontem à noite chegou um caminhão, dois jipes e uma ordem. A estrada do Moinho fechou.
- `n6` **Alen:**  — *o jogador escolhe:*
    - ▸ “Fechou até quando?” → `n7`
    - ▸ “Eu preciso passar lá. Eu tinha dito que voltava.” → `n8`
    - ▸ “E eu com isso? Vou pra biblioteca.” → `n11`
- `n7` **Marcus:** Até a ordem mudar. Ninguém sabe quando a ordem muda; só sabem quando ela chega. → `n12`
- `n8` **Marcus:** Disse pra quem?
- `n9` **Alen:** Pra ninguém. Pra terra. *(pausa 0.5 s)*
- `n10` **Marcus:** Então a terra espera. Ela é boa nisso. Melhor que a gente. *(pausa 0.5 s)* → `n12`
- `n11` **Marcus:** Esse é o espírito. Teimoso e com destino.
- `n12` **Marcus:** Biblioteca. Certo. Vai pela esquerda da rua: dobra depois da casa onde você mora e segue reto, até a rua das lojas. Não corre, não discute, não olha torto.
- `n13` **Marcus:** E o remédio da sua mãe... ainda nada. Mas se chegar no comboio, a lista fica lá. A Dona Helena anota tudo. *(pausa 0.5 s)*
- `n14` **Alen:** Obrigado, Marcus.
- `n15` **Marcus:** Não agradece, joga uma moeda no chapéu do próximo azarado. *(grava `c1_marcus_met=true`)* → *fim*

#### `c1_marcus_2`
- `n1` **Marcus:** Ainda aqui? Já era pra estar na fila.
- `n2` **Alen:** A fila anda.
- `n3` **Marcus:** A fila não anda, ela se muda de lugar. Vai. *(pausa 0.4 s)* → *fim*

#### `c1_marcus_back`
- `n1` **Marcus:** Voltou inteiro e com caixa. Tá bom demais pra ser uma segunda-feira. *(pausa 0.3 s)*
- `n2` **Alen:**  — *o jogador escolhe:*
    - ▸ “É só arroz e feijão.” → `n3`
    - ▸ “Tinha fila. Muita gente.” → `n4`
- `n3` **Marcus:** Arroz e feijão é uma boa notícia que ninguém comemora. → `n5`
- `n4` **Marcus:** Sempre tem. Dá pra ver quem tá bem pela cara de quem já foi. *(pausa 0.4 s)*
- `n5` **Marcus:** Vai pra casa. Alimenta teu pessoal. E amanhã a gente fala de estrada. *(pausa 0.5 s)* → *fim*

#### `c1_barricada_1`
- `n1` *(narração)* A estrada do Moinho. O que era cerca e sinalização é agora um muro de sacos de areia, uma barra listrada de vermelho e branco e ouriços de ferro pintados de cinza.
- `n2` *(narração)* Um soldado de capacete me observa, de pé, de braços cruzados, como quem decidiu a conversa antes de ela começar.
- `n3` **Sd. Ferraz:** Volta.
- `n4` **Alen:**  — *o jogador escolhe:*
    - ▸ “Eu só queria passar.” → `n5`
    - ▸ “Tem um jardim no fim dessa estrada.” → `n6`
    - ▸ “Tá.” → `n7`
- `n5` **Sd. Ferraz:** Todo mundo só queria passar. *(pausa 0.4 s)* → `n8`
- `n6` **Sd. Ferraz:** Tem muita coisa no fim dessa estrada, garoto. Nenhuma que eu possa te deixar ver. *(pausa 0.5 s)* → `n8`
- `n7` **Sd. Ferraz:** Bom garoto. *(pausa 0.4 s)*
- `n8` **Sd. Ferraz:** Ordem 114 do Comando Regional. Acesso proibido. Não me pediram o motivo; me pediram a barra.
- `n9` *(narração)* Ele diz isso sem raiva. Parece o resumo de uma noite inteira.
- `n10` *(narração)* Penso em uma semente coberta de terra. “Amanhã eu volto, pra ver.” Hoje é amanhã. A terra vai ter que esperar mais um pouco. *(grava `c1_barricada_seen=true`)* → *fim*

#### `c1_barricada_2`
- `n1` **Sd. Ferraz:** Já falei.
- `n2` **Alen:** Eu sei. Só vim olhar. *(pausa 0.4 s)*
- `n3` **Sd. Ferraz:** Olhar não é proibido. Por enquanto. *(pausa 0.5 s)* → *fim*

#### `c1_barricada_back`
- `n1` **Sd. Ferraz:** Ainda por aqui?
- `n2` **Alen:** Vim de volta da biblioteca. Estou indo pra casa.
- `n3` **Sd. Ferraz:** Então vai. E... pega a rua da frente. A de trás tem gelo. *(pausa 0.4 s)*
- `n4` *(narração)* É a coisa mais gentil que ele disse o dia todo. Ele provavelmente nega depois. → *fim*

#### `c1_sign_centro`
- `n1` *(narração)* Uma placa pintada à mão: “← CENTRO · Biblioteca 1,2 km”.
- `n2` *(narração)* Embaixo, em letra menor e outra tinta: “(a pé; não corra)”. → *fim*

#### `c1_candida_1`
- `n1` **Dona Cândida:** A roupa nunca seca. Eu sei. *(pausa 0.4 s)*
- `n2` **Dona Cândida:** Mas pendurar faz bem. É como falar um bom dia pra casa.
- `n3` **Alen:**  — *o jogador escolhe:*
    - ▸ “Tá fazendo frio demais.” → `n4`
    - ▸ “A senhora precisa de ajuda?” → `n5`
- `n4` **Dona Cândida:** Frio demais pra quê, filho? Pra secar? Pra viver? Pra viver ainda dá. *(pausa 0.4 s)* → `n7`
- `n5` **Dona Cândida:** Ah, não. Mas se passar uma vizinha, diz que a minha camisa azul está pendurada ali e que ela pode vir ver se é dela.
- `n6` **Dona Cândida:** O vento levou a dela pra cá. Ele não é muito bom em endereços.
- `n7` *(narração)* Ela prende o último pregador. A camisa azul vira um pedaço de gelo com mangas. → *fim*

#### `c1_candida_back`
- `n1` **Dona Cândida:** Voltando com a caixa? Ótimo. Quem carrega comida anda mais reto. *(pausa 0.4 s)*
- `n2` **Alen:** É verdade?
- `n3` **Dona Cândida:** É. Reparei nos meus vizinhos. E na minha camisa. *(pausa 0.5 s)* → *fim*

#### `c1_tobias_1`
- `n1` *(narração)* Seu Tobias mexe no botão de um rádio de pilha. A agulha vai do chiado para outro chiado e depois para a missa.
- `n2` **Seu Tobias:** Esse rádio pega três estações: o chiado, o outro chiado e a missa. *(pausa 0.5 s)*
- `n3` **Seu Tobias:** Hoje o chiado está muito bom. Quer ouvir?
- `n4` **Alen:**  — *o jogador escolhe:*
    - ▸ “Quero.” → `n5`
    - ▸ “Prefiro a missa.” → `n6`
- `n5` *(narração)* Ele aumenta o volume. É só chiado mesmo. Mas é um chiado cheio de conversa. → `n7`
- `n6` **Seu Tobias:** A missa tem boa dicção e poucas surpresas. Respeito. *(pausa 0.4 s)*
- `n7` **Seu Tobias:** Se escutar uma voz de verdade dizendo o que tá acontecendo, vem me avisar. Tô há três semanas esperando uma voz de verdade. → *fim*

#### `c1_tobias_2`
- `n1` **Seu Tobias:** Chiado. Missa. Chiado. *(pausa 0.4 s)*
- `n2` **Seu Tobias:** Hoje é um dia de poucas novidades. → *fim*

#### `c1_criancas_giz`
- `n1` *(narração)* Duas crianças desenham uma amarelinha na neve com um pedaço de carvão. O céu, no fim, é maior do que o resto todo.
- `n2` **Menino:** Não pisa na linha! Isso aqui é sério!
- `n3` **Menina:** Ele inventou as regras agora. A primeira regra é que ele ganha.
- `n4` **Menino:** A primeira regra é que não pode rir do chefe do jogo.
- `n5` *(narração)* Ela ri. Eu quase. → *fim*

#### `c1_criancas_giz_2`
- `n1` **Menino:** Quer jogar?
- `n2` **Alen:** Não posso, tenho uma missão.
- `n3` **Menino:** Missão de quê?
- `n4` **Alen:** De caixa.
- `n5` **Menino:** Missão de caixa é a mais chata. *(pausa 0.4 s)*
- `n6` **Menina:** É a mais importante, bobo.
- `n7` *(narração)* Eu não sabia que alguém ia dizer isso hoje. Fico ouvindo a frase mais um pouco depois de sair andando. → *fim*

#### `c1_criancas_giz_back`
- `n1` **Menino:** Ganhou a missão?
- `n2` **Alen:** Ganhei a caixa.
- `n3` **Menina:** Então ganhou tudo.
- `n4` **Menino:** Mentira. O céu da amarelinha é meu. → *fim*

#### `c1_laundry_sign`
- `n1` *(narração)* Um bilhete preso no varal com pregador: “Quem achar uma meia verde com furo no calcanhar: é minha. Não devolve. Só me avisa que ela está bem.”
- `n2` *(narração)* Rio. Rio de verdade, curto, pelo nariz. Faz bastante tempo. *(pausa 0.5 s)* → *fim*

## Rua das Lojas e interiores

#### `c1_centro_sign_back`
- `n1` *(narração)* “PINHAL ALTO →”. Alguém acrescentou, embaixo, com tinta branca: “(casa)”.
- `n2` *(narração)* A placa não pediu opinião, mas concordo. → *fim*

#### `c1_oficina_1`
- `n1` *(narração)* Oficina Santos. A porta de enrolar está meio aberta, como uma pálpebra que desistiu.
- `n2` *(narração)* Lá dentro, no escuro, um carro sem rodas apoiado em tijolos e um macaco hidráulico esquecido bem no meio.
- `n3` *(narração)* Quem sai com pressa leva o que é importante e esquece o que é pesado. → *fim*

#### `c1_oficina_2`
- `n1` *(narração)* Um calendário preso na parede: “Paisagens da Suíça — 2007”.
- `n2` *(narração)* O mês de agosto mostra um lago azul. Daqui dá pra ver direitinho: o lago não tem nada a ver com a gente. → *fim*

#### `c1_locadora_fachada`
- `n1` *(narração)* VÍDEO PONTO. “ALUGUE UM MUNDO”, diz o letreiro apagado. Na vitrine, caixas de jogos viradas de lado, todas com as capas descoloridas pela luz de uma época em que havia luz de sobra.
- `n2` *(narração)* Uma das caixas tem uma nave azul na capa. Não consigo ler o nome daqui. → *fim*

#### `c1_locadora_porta`
- `n1` *(narração)* A porta da locadora está encostada. Tem um papel preso com fita no vidro, escrito à mão: “Fechado para balanço. Volto na segunda.”
- `n2` *(narração)* Não diz qual segunda. Empurro a porta mesmo assim. Com cuidado, como quem entra em um lugar que ainda espera alguém. *(pausa 0.4 s)* → *fim*

#### `c1_ferrarias_1`
- `n1` *(narração)* A Rua das Ferrarias. Sacos de areia, uma barreira, um jipe verde com a lona coberta de neve e uma faixa de “ÁREA INTERDITADA” atravessada de lado a lado.
- `n2` *(narração)* Um soldado está sentado em um caixote ao lado do jipe, de capacete no joelho. Parece mais cansado do que a rua inteira.
- `n3` **Cb. Menezes:** Pode passar reto. A rua é aqui, mas o seu caminho não é.
- `n4` **Alen:**  — *o jogador escolhe:*
    - ▸ “O que tem aí dentro?” → `n5`
    - ▸ “Estou indo pra biblioteca.” → `n6`
    - ▸ “O senhor está bem?” → `n7`
- `n5` **Cb. Menezes:** Casas. Gente que não sai. Uma padaria sem teto. E uma ordem pra eu ficar aqui até a ordem mudar. *(pausa 0.4 s)* → `n9`
- `n6` **Cb. Menezes:** Reto, até a praça. Passa pelo relógio e vira à esquerda. Não pega a avenida — o posto lá é do pessoal mais nervoso. → `n9`
- `n7` **Cb. Menezes:** Seis horas em pé. Se eu sento, eu durmo. Se eu durmo, o sargento aparece. *(pausa 0.5 s)*
- `n8` **Cb. Menezes:** Mas obrigado por perguntar. Ninguém pergunta.
- `n9` *(narração)* Ele coloca o capacete de volta. A conversa acabou, mas ele ficou menos duro por um instante. *(grava `c1_menezes_met=true`)* → *fim*

#### `c1_ferrarias_2`
- `n1` **Cb. Menezes:** Reto, praça, relógio, esquerda.
- `n2` **Alen:** Eu lembro.
- `n3` **Cb. Menezes:** Eu repito pra mim mesmo. Pra ver se ainda sei falar. → *fim*

#### `c1_ferrarias_back`
- `n1` **Cb. Menezes:** Voltando? Tem comida na caixa?
- `n2` **Alen:** Tem.
- `n3` **Cb. Menezes:** Então a manhã valeu. A minha ainda não. *(pausa 0.5 s)* → *fim*

#### `c1_televale_1`
- `n1` *(narração)* TELE VALE. Quatro televisores de tubo na vitrine, todos apagados. Na tela escura de cada um, um pedaço do meu reflexo, em quatro tamanhos.
- `n2` *(narração)* Um papel colado no vidro: “CONSERTAMOS. VOLTAMOS EM BREVE.”
- `n3` *(narração)* “Breve” foi riscado e escrito de novo, três vezes, em canetas diferentes. → *fim*

#### `c1_televale_2`
- `n1` *(narração)* Pela fresta da porta, um calendário parado em setembro. Todos os calendários da cidade parecem ter combinado. → *fim*

#### `c1_padaria_fachada`
- `n1` *(narração)* PÃO & PROSA. É a única chaminé da rua com fumaça. O cheiro chega antes de eu entender o que é: massa quente. *(pausa 0.6 s)*
- `n2` *(narração)* Fico parado na calçada, de olhos fechados, por mais tempo do que a decência permite. → *fim*

#### `c1_padaria_porta`
- `n1` *(narração)* A porta está destrancada. O sino da entrada dá um tilintar rouco, como quem não é usado desde a última boa notícia. → *fim*

#### `c1_padaria_lousa`
- `n1` *(narração)* Uma lousa na calçada: “HOJE: SÓ 1 PÃO.”
- `n2` *(narração)* Embaixo, em outra letra, mais miúda: “Por pessoa. Não adianta chorar, eu também choro.” → *fim*

#### `c1_mercearia_1`
- `n1` *(narração)* MERCEARIA. Janelas tapadas com tábuas, porta de ferro fechada, um aviso: “SÓ COM CARTÃO.”
- `n2` *(narração)* Mas dá pra ver pela fresta o que sobrou: as marcas das prateleiras na parede. Dá pra saber até onde o arroz chegava. → *fim*

#### `c1_mercearia_2`
- `n1` *(narração)* Embaixo da porta, um pedaço de papel dobrado com a letra de criança: “Seu João: eu devo uma bala. Quando abrir eu pago.”
- `n2` *(narração)* O Seu João não vai ler. Mas alguém ainda deve uma bala, e isso é uma forma de acreditar que a loja volta. → *fim*

#### `c1_beco_1`
- `n1` *(narração)* O Beco do Sapateiro. Um corredor estreito entre duas paredes, com um varal de roupas duras de gelo e uma porta de madeira ao fundo.
- `n2` *(narração)* A porta está entreaberta. Não tem ninguém na janela. Não tem cheiro de fumaça. *(pausa 0.5 s)*
- `n3` *(narração)* Entro. Sem fazer barulho, porque a casa parece ouvir. *(pausa 0.4 s)* → *fim*

#### `c1_moda_1`
- `n1` *(narração)* MODA ELEGANCE. Dois manequins de roupa de festa na vitrine, olhando para a rua com o orgulho dos que nunca foram convidados.
- `n2` *(narração)* Cada um ainda tem uma etiqueta de preço pendurada. Os preços ficaram onde o mundo era mais barato. → *fim*

#### `c1_moda_2`
- `n1` *(narração)* Uma das manequins está sem o braço. Alguém levou, ou ela perdeu num acidente de moda.
- `n2` *(narração)* Não consigo decidir se eu rio ou se eu respeito. → *fim*

#### `c1_cafe_1`
- `n1` *(narração)* CAFÉ DO LARGO. Cadeiras viradas sobre as mesas, correntes nas pernas das mesas de fora, um toldo azul com gelo caindo em pedaços.
- `n2` *(narração)* Na lousa: “VOLTAMOS QUANDO A FARINHA VOLTAR.” → *fim*

#### `c1_cafe_2`
- `n1` *(narração)* Alguém riscou “farinha” e escreveu “esperança”. Depois riscou “esperança” e escreveu “farinha” de novo.
- `n2` *(narração)* Acho que foi a mesma pessoa. Acho que ela estava tentando ser honesta. → *fim*

#### `c1_sebo_1`
- `n1` *(narração)* O LIVRO AZUL. Sebo, troca e doação. Na vitrine, livros inchados pela umidade, empilhados em ordem alfabética e com dignidade.
- `n2` *(narração)* Um cartaz: “DOE UM LIVRO. A BIBLIOTECA PRECISA → ” e uma seta apontando para o fim da rua. → *fim*

#### `c1_sebo_2`
- `n1` *(narração)* No meio da vitrine: “Manual do Jardineiro Iniciante”. *(pausa 0.6 s)*
- `n2` *(narração)* Eu não vou comentar.
- `n3` *(narração)* Mas gravo o título. *(pausa 0.5 s)* → *fim*

#### `c1_ruina_1`
- `n1` *(narração)* O prédio do fim da rua perdeu uma parte da frente. Dá pra ver o interior de dois andares, como uma casa de boneca aberta.
- `n2` *(narração)* Uma fita de “RISCO” atravessa a calçada. Passo do outro lado, longe, por educação. → *fim*

#### `c1_ruina_2`
- `n1` *(narração)* No que sobrou da parede da entrada, alguém escreveu com giz: “MARIA: ESTAMOS NA BIBLIOTECA, BLOCO C. — MÃE.”
- `n2` *(narração)* Embaixo, outra letra: “Visto às 9h. Ela já foi.” *(pausa 0.7 s)*
- `n3` *(narração)* Embaixo desse, a primeira letra de novo: “Obrigada.”
- `n4` *(narração)* Eu não tenho o que acrescentar. Fico lendo até a mensagem virar mais um pedaço do chão. → *fim*

#### `c1_onibus_1`
- `n1` *(narração)* Um ônibus da Linha 12, parado com as portas fechadas e a placa de “SUSPENSA” no para-brisa. Os pneus estão murchos e cobertos de neve, como se a gente tivesse dado um tempo pra eles. → *fim*

#### `c1_onibus_2`
- `n1` *(narração)* No último banco, um guarda-chuva preto. Aberto. Pendurado no encosto, esperando uma chuva.
- `n2` *(narração)* Em Declan City, a chuva demorou. A neve não precisou de guarda-chuva. → *fim*

#### `c1_banca_1`
- `n1` **Seu Aurélio:** Troca-se! Troca-se tudo, menos dinheiro! *(pausa 0.4 s)*
- `n2` *(narração)* A banca tem pilhas, meias de lã, um sapato direito, panelas, um rádio de carro, quatro livros sem capa e uma galinha de borracha.
- `n3` **Alen:**  — *o jogador escolhe:*
    - ▸ “Eu não tenho nada pra trocar.” → `n4`
    - ▸ “O que o senhor aceita?” → `n5`
    - ▸ “A galinha é de borracha?” → `n6`
- `n4` **Seu Aurélio:** Todo mundo tem. Eu aceito história. *(pausa 0.4 s)* → `n7`
- `n5` **Seu Aurélio:** Pilha, linha, remédio, sapato, boa notícia. Boa notícia vale mais que remédio, mas é raríssima. *(pausa 0.4 s)* → `n7`
- `n6` **Seu Aurélio:** É. E tem mais valor do que a maioria das galinhas de verdade, hoje em dia.
- `n7` **Seu Aurélio:** Me conta uma coisa que aconteceu com você nesta semana. Uma que não seja triste. Se for verdadeira, eu troco por uma bala de menta. *(pausa 0.4 s)*
- `n8` **Alen:**  — *o jogador escolhe:*
    - ▸ “Eu plantei uma semente de girassol. Em dezembro.” → `n9` *(só se `planted`)*
    - ▸ “Achei uma lata de sementes no meio de um jardim abandonado.” → `n11`
    - ▸ “Não tenho nada de bom.” → `n13`
- `n9` **Seu Aurélio:** Girassol. Em dezembro. *(pausa 0.6 s)*
- `n10` **Seu Aurélio:** O senhor da terra deve estar rindo. Toma a bala. Essa é de primeira. *(grava `c1_candy=true`)* → *fim*
- `n11` **Seu Aurélio:** Isso é história, sim. Meio curta. Mas honesta.
- `n12` **Seu Aurélio:** Toma a bala. *(grava `c1_candy=true`)* → *fim*
- `n13` **Seu Aurélio:** Todo mundo tem. Mas não precisa ser hoje. Passa na volta. *(pausa 0.5 s)* → *fim*

#### `c1_banca_2`
- `n1` **Seu Aurélio:** Se achar uma meia de lã com um furo no calcanhar, é da Dona Cândida. Ela nunca vem buscar, mas eu guardo. → *fim*

#### `c1_banca_back`
- `n1` **Seu Aurélio:** Voltou! E tá de caixa. Isso eu troco por duas balas. *(pausa 0.3 s)*
- `n2` **Alen:** Não é pra troca.
- `n3` **Seu Aurélio:** Eu sei. Eu só queria falar em voz alta. → *fim*

#### `c1_loc_cartaz_space`
- `n1` *(narração)* Um cartaz: uma nave azul, estrelas e um robô vermelho enorme bloqueando a tela.
- `n2` *(narração)* “ANOTHER CONCEPT apresenta SPACE TRAVELERS.”
- `n3` *(narração)* “1 nave. 3 vidas. 0 piedade.” *(pausa 0.4 s)*
- `n4` *(narração)* Não sei o que é. Mas o robô tem cara de quem recebeu mal o convite. *(grava `c1_saw_space=true`)* → *fim*

#### `c1_loc_cartaz_guitar`
- `n1` *(narração)* “GUITAR LEGENDS. Toque como se alguém estivesse ouvindo.”
- `n2` *(narração)* A guitarra do cartaz não tem o braço no tamanho certo. Mas a atitude é impecável. *(grava `c1_saw_guitar=true`)* → *fim*

#### `c1_loc_neon`
- `n1` *(narração)* O letreiro de neon está apagado, mas as letras ainda guardam a forma. “VÍDEO PONTO”. Alguém desenhou um ponto grande depois do “O”, a canetinha, para ficar mais completo. → *fim*

#### `c1_loc_balcao`
- `n1` *(narração)* A gaveta do caixa está aberta e vazia. Sobrou uma moeda de um centavo, o que diz muito sobre inflação. → *fim*

#### `c1_loc_nota`
- `n1` *(narração)* Presa na caixa registradora com um clipe: “Fui buscar minha mãe em outra cidade. Quem quiser alugar, deixa o dinheiro na caixa e anota o título no caderno. Eu confio. — Valdo.”
- `n2` *(narração)* Ao lado, o caderno. As anotações vão até setembro. A última, de novembro, diz: “Pagamento adiantado, R$ 5. Dona Marta. (Nada alugado. Só pra ajudar.)”
- `n3` *(narração)* Fico um tempo sem saber o que fazer com as mãos. Fecho o caderno com cuidado, pra não amassar a confiança. *(pausa 0.6 s)* → *fim*

#### `c1_loc_fitas`
- `n1` *(narração)* Prateleiras e mais prateleiras de fitas: “Os Caçadores de Domingo”, “Verão em Sintra 2”, “O Retorno do Retorno”, “Papagaio contra o Mundo”.
- `n2` *(narração)* Nunca vi nenhum desses. Todos têm um selo de “DEVOLVA ATÉ SEXTA”. Com a pressa que a vida tem, estão todos atrasados. → *fim*

#### `c1_loc_tv`
- `n1` *(narração)* A TV do balcão está desligada. Dentro do aparelho, uma fita presa, com uma etiqueta: “FIM DE SEMANA 3”.
- `n2` *(narração)* Imagino o filme que ela estava passando quando a luz foi cortada. Prefiro que seja uma comédia. → *fim*

#### `c1_loc_devolucao`
- `n1` *(narração)* A caixa de devolução ainda tem coisas: dois jogos, três fitas e um bilhete: “Desculpa. Estava arranhado quando eu peguei.”
- `n2` *(narração)* Um dos jogos se chama “Mundo de Tinta”. É da mesma empresa. Another Concept. O logotipo é um círculo com uma linha no meio, como um olho fechado.
- `n3` *(narração)* Não pego. Não é meu, mesmo que ninguém venha buscar. Fica anotado: Another Concept. “Mundo de Tinta”. *(pausa 0.5 s)* → *fim*

#### `c1_loc_ficha`
- `n1` *(narração)* Um fichário de sócios, com uma ficha aberta: “Sócio 007. Pendências: devolver SPACE TRAVELERS (desde 1998). Multa acumulada: infinita.”
- `n2` *(narração)* Alguém escreveu com outra caneta: “Vale a multa.” → *fim*

#### `c1_loc_saida`
- `n1` *(narração)* A porta da locadora. Do outro lado, a rua. Mas antes eu dou uma última olhada no cartaz da nave. *(pausa 0.4 s)*
- `n2` *(narração)* Saio. → *fim*

#### `c1_pad_iris_1`
- `n1` **Dona Íris:** Fecha a porta, o calor escapa! *(pausa 0.3 s)*
- `n2` *(narração)* Uma mulher de avental branco e cabelo preso sova uma massa sobre a mesa com a firmeza de quem faz isso desde antes de ter motivo.
- `n3` **Dona Íris:** Se veio comprar, não tem. Se veio dar bom dia, tem de sobra.
- `n4` **Alen:**  — *o jogador escolhe:*
    - ▸ “Bom dia. Cheira muito bem aqui.” → `n5`
    - ▸ “Eu vou pra biblioteca. A senhora precisa de alguma coisa?” → `n6`
    - ▸ “Eu não tenho dinheiro.” → `n7`
- `n5` **Dona Íris:** Cheira porque eu tenho um forno, e o forno tem uma ideia fixa. *(pausa 0.4 s)* → `n8`
- `n6` **Dona Íris:** Biblioteca? Ora, pois então. *(pausa 0.5 s)* → `n8`
- `n7` **Dona Íris:** Eu também não, filho. A gente trabalha com outra moeda.
- `n8` **Dona Íris:** A Helena me mandou três sacos de farinha. Foi o que sobrou do comboio de terça. Dá dez pães. Cinco vão pro abrigo, três pro posto, dois pra quem aparecer. *(pausa 0.4 s)*
- `n9` **Dona Íris:** Você apareceu.
- `n10` **Alen:**  — *o jogador escolhe:*
    - ▸ “Posso levar os do abrigo?” → `n11`
    - ▸ “A senhora nem me conhece.” → `n12`
- `n11` **Dona Íris:** Pode, pode. Cinco, no saco de pano. Entrega pra Helena, e diz que é da Íris, que ela já sabe. → `n15`
- `n12` **Dona Íris:** Conheço o jeito. O jeito de quem anda com pressa e com medo. Isso eu conheço de longe. *(pausa 0.4 s)*
- `n13` **Dona Íris:** Leva os do abrigo?
- `n14` **Alen:** Levo.
- `n15` *(narração)* Ela embrulha cinco pães quentes em um saco de pano e o saco quase me queima as mãos. Gosto disso. É um calor que não vem do fogão da sala nem da caneca. *(grava `c1_bread=true`)*
- `n16` **Dona Íris:** E esse aqui — *(pausa 0.4 s)*
- `n17` *(narração)* Ela separa um sexto pão e coloca na minha mão.
- `n18` **Dona Íris:** Quem carrega, prova. É a regra da casa. Não é presente: é salário.
- `n19` **Alen:** Eu... posso levar pra casa?
- `n20` **Dona Íris:** Pode levar pra onde quiser. Regra da casa é essa também. *(grava `c1_roll=true`, `c1_iris_met=true`)* → *fim*

#### `c1_pad_iris_2`
- `n1` **Dona Íris:** Já entregou os pães?
- `n2` **Alen:** Estou indo.
- `n3` **Dona Íris:** Então vai, antes que eles esfriem e eu fique com raiva. → *fim*

#### `c1_pad_iris_back`
- `n1` **Dona Íris:** Voltou pelo calor, né? Eu sei como é.
- `n2` **Alen:** Passei pra agradecer.
- `n3` **Dona Íris:** Não agradece. Se você agradece, eu me sinto obrigada a fazer mais pão. E aí falta farinha. → *fim*

#### `c1_pad_forno`
- `n1` *(narração)* O forno de tijolos está aceso. É o lugar mais quente da rua. Percebo que fiquei parado mais tempo do que precisava.
- `n2` *(narração)* O fogo tem uma cor que a casa nunca viu: laranja de verdade. → *fim*

#### `c1_pad_farinha`
- `n1` *(narração)* FARINHA. Três sacos, um deles já aberto. A Dona Íris disse que três sacos são “um começo”.
- `n2` *(narração)* Gosto da palavra. Começo. Ainda mais para um saco de farinha. → *fim*

#### `c1_pad_gato`
- `n1` *(narração)* Um gato cinza dorme sobre o último saco de farinha, como se soubesse o valor. Provavelmente sabe.
- `n2` **Dona Íris:** Esse é o Miolo! Dorme em cima do que é caro. Não toca, que ele cobra. *(pausa 0.3 s)* → *fim*

#### `c1_pad_lousa`
- `n1` *(narração)* A lousa da parede ainda tem os preços de antes: PÃO FRANCÊS, PÃO DOCE, BOLO DO DIA. Todos riscados com giz.
- `n2` *(narração)* No lugar de “BOLO DO DIA”, a Dona Íris escreveu: “SÓ HOJE: AMASSAR PRA SOBREVIVER.” → *fim*

#### `c1_pad_balcao`
- `n1` *(narração)* No balcão, três pãezinhos dourados sobre um pano, com um cartão: “ENCOMENDADO — BIBLIOTECA.”
- `n2` *(narração)* Eu olho. Eu não toco. Eu sou educado até a fome. → *fim*

#### `c1_pad_saida`
- `n1` *(narração)* O sino da porta toca de novo, desta vez como quem agradece. → *fim*

#### `c1_casa_entrada`
- `n1` *(narração)* Uma casa pequena, uma sala, uma cozinha e, atrás da divisória, um quarto. O ar é parado, mais frio do que na rua.
- `n2` *(narração)* Um lugar em que alguém morou até a pressa decidir o contrário. → *fim*

#### `c1_casa_mesa`
- `n1` *(narração)* A mesa está posta para o jantar de um dia que não aconteceu. Quatro pratos, quatro garfos, uma jarra com um resto de gelo no fundo.
- `n2` *(narração)* Alguém saiu com cuidado, pra não quebrar nada. E nada quebrou. *(pausa 0.5 s)* → *fim*

#### `c1_casa_bilhete`
- `n1` *(narração)* Um bilhete debaixo da jarra: “Fomos para a casa da tia Cleusa. Voltamos quando abrirem a estrada. Se alguém precisar de abrigo, a chave está debaixo do vaso. A casa é de vocês enquanto estivermos fora. Cuidem da planta. — Marta.”
- `n2` *(narração)* Releio duas vezes. Cuidem da planta. *(pausa 0.6 s)* → *fim*

#### `c1_casa_vaso`
- `n1` *(narração)* Debaixo do vaso da porta, a chave. O vaso está vazio, a terra dura de gelo.
- `n2` *(narração)* A chave não tem ferrugem nem pó. Está limpa. Alguém usa essa chave. *(pausa 0.5 s; grava `c1_key_used=true`)* → *fim*

#### `c1_casa_canecas`
- `n1` *(narração)* Na prateleira, cinco canecas diferentes, cada uma com um nome pintado à mão: Pai, Mãe, Teo, Bia, Visita.
- `n2` *(narração)* A de “Visita” está de ponta-cabeça no escorredor. Alguém lavou. Recentemente. *(pausa 0.5 s)* → *fim*

#### `c1_casa_foto`
- `n1` *(narração)* Uma foto na parede: um pai, uma mãe, um menino de uns dez anos e uma menina com um laço enorme. Todos olhando para o fotógrafo como se ele tivesse acabado de contar uma piada.
- `n2` *(narração)* Eu me pergunto qual foi a piada. Eu me pergunto se ainda tem graça. → *fim*

#### `c1_casa_calendario`
- `n1` *(narração)* O calendário da parede está parado em setembro. Alguém riscou os dias até o 14. O 15 está circulado em vermelho.
- `n2` *(narração)* Sem explicação. A casa inteira fica no silêncio de quem sabe e não conta. → *fim*

#### `c1_casa_fogao`
- `n1` *(narração)* O fogão está frio, com uma chaleira em cima e um pano de prato dobrado em três. A gente sempre sabe quem deixou a casa em ordem pra ela esperar bem. → *fim*

#### `c1_casa_casaco`
- `n1` *(narração)* Um casaco de adulto, pendurado atrás da porta. No bolso, uma bala de menta e um bilhete de ônibus da linha 12.
- `n2` *(narração)* Não pego nada. Mas fica anotado que tem bala de menta num casaco. É importante saber onde moram as pequenas coisas. → *fim*

#### `c1_casa_trem`
- `n1` *(narração)* Um trem de brinquedo parado no meio do tapete, virado para a porta. Esperando o apito de alguém. → *fim*

#### `c1_casa_mochila`
- `n1` *(narração)* Uma mochila escolar, ainda com o caderno aberto. “Dever: escreva uma frase sobre o que você quer ser quando crescer.”
- `n2` *(narração)* Embaixo, na letra torta de um garoto: “Quando eu crescer eu quero ser” — e a frase para aí.
- `n3` *(narração)* Eu não termino a frase por ele. Mas pensei em três finais antes de conseguir fechar o caderno. *(pausa 0.5 s)* → *fim*

#### `c1_casa_cama`
- `n1` *(narração)* A cama do quarto está desfeita de um jeito que não é de quem saiu correndo. É de quem dormiu ali. Recentemente. *(pausa 0.5 s)*
- `n2` *(narração)* Há uma marca de cabeça no travesseiro, e um cobertor dobrado no pé da cama com cuidado de quem não quer ser notado. *(grava `c1_saw_bed=true`)* → *fim*

#### `c1_casa_janela`
- `n1` *(narração)* A janela do quarto está embaçada pelo frio. No vidro, desenhado com o dedo, alguém fez uma pequena nave espacial, com asas, uma cauda, e uma fileira de estrelas no alto.
- `n2` *(narração)* As bordas ainda estão nítidas. O desenho é novo. *(grava `c1_saw_ship=true`)* → *fim*

#### `c1_casa_neve`
- `n1` *(narração)* Um buraco no teto do quarto. A neve entra e forma uma montanhazinha em cima do tapete.
- `n2` *(narração)* Dentro de casa, nevando. Na minha, é o telhado que eu remendo. Aqui, ninguém remendou. Dá uma pontada esquisita. *(pausa 0.4 s)* → *fim*

#### `c1_casa_saida`
- `n1` *(narração)* Antes de sair, eu coloco o bilhete do jeito que estava. Alinho o vaso. Quem quer que use esta casa, que continue achando tudo como achou. → *fim*

## Praça e área humanitária

#### `c1_praca_sign`
- `n1` *(narração)* Uma placa de metal com uma seta: “← BIBLIOTECA · ABRIGO Nº 3”.
- `n2` *(narração)* Alguém pintou por baixo um coração torto, a tinta rosa. Tem gente com sobra de tinta rosa em Declan City, e eu respeito. → *fim*

#### `c1_banco_1`
- `n1` *(narração)* BANCO POPULAR. Quatro colunas, quatro janelas quebradas e uma grade de ferro baixada até o chão.
- `n2` *(narração)* Na grade, um papel: “FECHADO POR TEMPO INDETERMINADO. NÃO INSISTA.” → *fim*

#### `c1_banco_2`
- `n1` *(narração)* Embaixo do aviso, alguém deixou dois bilhetes. Um diz “MEU DINHEIRO ESTÁ AÍ DENTRO.” O outro, com outra letra: “O DE TODO MUNDO.”
- `n2` *(narração)* O terceiro bilhete, em tinta fraca: “Mas eu só queria meu dinheiro.” *(pausa 0.5 s)*
- `n3` *(narração)* Dá pra ler uma cidade inteira em três pedaços de papel. → *fim*

#### `c1_correios_1`
- `n1` *(narração)* CORREIOS. A porta está fechada com um cadeado novo e uma corrente velha. No vidro, um aviso: “Correspondência para a fronteira leste: SUSPENSA.”
- `n2` *(narração)* Em frente, uma caixa vermelha de cartas. Está bem cheia. → *fim*

#### `c1_mulher_cartas`
- `n1` *(narração)* Uma mulher de cachecol amarelo coloca um envelope na caixa vermelha com os dois dedos, como se fosse algo que respira.
- `n2` **Mulher:** Quarenta e duas cartas. Nenhuma passa da fronteira. *(pausa 0.4 s)*
- `n3` **Mulher:** Eu escrevo mesmo assim. É como falar sozinha com endereço.
- `n4` **Alen:**  — *o jogador escolhe:*
    - ▸ “E alguém responde?” → `n5`
    - ▸ “Posso levar alguma?” → `n6`
    - ▸ “A senhora devia ficar menos tempo no frio.” → `n7`
- `n5` **Mulher:** Responder, não. Mas a caixa continua aqui. Ela me faz companhia. *(pausa 0.5 s)* → *fim*
- `n6` **Mulher:** Leva se você for pra fronteira. Não vai? Então fica pra mim mesmo. *(pausa 0.5 s)* → *fim*
- `n7` **Mulher:** Obrigada, querido. Eu devia. Eu também devia muita coisa. → *fim*

#### `c1_mulher_cartas_2`
- `n1` **Mulher:** Quarenta e três. → *fim*

#### `c1_correio_caixa`
- `n1` *(narração)* A caixa vermelha de cartas está cheia até a boca. Sobrou um canto de papel azul para fora, com um nome: “Para Joana, em mãos.”
- `n2` *(narração)* Não é pra mim, não é de ninguém aqui. Mas reparo na letra, tão bem desenhada que parece escrita com respeito. → *fim*

#### `c1_desaparecidos_1`
- `n1` *(narração)* Uma parede de madeira coberta de papéis. “PROCURA-SE.” Fotos fracas, nomes, datas, ruas.
- `n2` *(narração)* Fotografias de gente ainda sorrindo, de gente que se parece com o meu vizinho, de crianças em fantasia de Carnaval.
- `n3` *(narração)* Não consigo olhar para todas ao mesmo tempo. Escolho uma de cada vez, como quem atravessa um rio pelas pedras. → *fim*

#### `c1_desaparecidos_2`
- `n1` *(narração)* Um papel diz: “QUIM, 7 anos, boné azul, última vez na Rua das Flores. Responde por Quim.”
- `n2` *(narração)* Em cima, com outra letra e canetinha verde: “ENCONTRADO — ESTÁ COMIGO. OBRIGADA A TODOS.”
- `n3` *(narração)* O verde é a cor mais forte da parede inteira. → *fim*

#### `c1_desaparecidos_3`
- `n1` *(narração)* No canto de baixo, alguém prendeu uma foto sem nome. Um grupo de pessoas num piquenique, todos com a mão levantada num aceno.
- `n2` *(narração)* No verso, com letra apertada: “Quem reconhecer alguém, por favor, diga o nome. Só o nome.”
- `n3` *(narração)* Digo, baixinho, o nome de ninguém. Por respeito. *(pausa 0.5 s)* → *fim*

#### `c1_sopa`
- `n1` *(narração)* Em cima do banco, uma panela grande com tampa, enrolada em uma toalha. Um papel preso por uma colher: “TOME UM POUCO. SE SOBRAR, DEVOLVE A PANELA.”
- `n2` **Alen:**  — *o jogador escolhe:*
    - ▸ “Tomar um pouco.” → `n3`
    - ▸ “Deixar para quem precisa mais.” → `n5`
- `n3` *(narração)* Sirvo um pouco na tampa. Sopa de nada com gosto de cebola. É a melhor coisa que comi esta semana, e eu não vou contar isso pra ninguém.
- `n4` *(narração)* Ponho a tampa no lugar. Deixo a colher como achei. → *fim*
- `n5` *(narração)* Fico olhando a panela. Não tomo. A caixa de casa pesa mais do que o meu estômago.
- `n6` *(narração)* Deixo o recado intacto, que é a melhor maneira de respeitar um recado. → *fim*

#### `c1_relogio_1`
- `n1` *(narração)* No pedestal, uma placa de bronze: “AOS QUE FICARAM.” O relógio da torre parou às quatro e dez.
- `n2` *(narração)* Quatro e dez de quando, de qual dia, ninguém me contou. → *fim*

#### `c1_relogio_2`
- `n1` *(narração)* Vejo duas pessoas olhando do relógio parado para o relógio de pulso e voltando, como quem pede desculpas ao tempo.
- `n2` *(narração)* A hora oficial de Declan City, hoje, é a que cada um traz no punho. → *fim*

#### `c1_fonte`
- `n1` *(narração)* A fonte congelou. Embaixo do gelo, moedas de todos os tamanhos, como desejos suspensos.
- `n2` *(narração)* Imagino o gelo derretendo e todos os desejos sendo atendidos de uma vez só. Daria um caos delicioso. → *fim*

#### `c1_jornais`
- `n1` *(narração)* A banca de jornais está trancada, mas ainda tem uma edição pendurada no cordão da vitrine. “15 DE SETEMBRO. MANTENHAM A CALMA.”
- `n2` *(narração)* O jornal parou de ser publicado no mesmo dia em que o relógio. Parece coisa combinada. *(pausa 0.5 s)* → *fim*

#### `c1_xadrez`
- `n1` *(narração)* Um senhor de chapéu joga xadrez sozinho num banco coberto de neve. Os dois lados do tabuleiro têm a mesma cara de preocupação.
- `n2` **Seu Hermes:** Joga? *(pausa 0.4 s)*
- `n3` **Alen:**  — *o jogador escolhe:*
    - ▸ “Pouco.” → `n4`
    - ▸ “Não posso, estou com pressa.” → `n7`
    - ▸ “Quem está ganhando?” → `n8`
- `n4` **Seu Hermes:** Pouco é melhor que ninguém. Senta do lado preto. Os brancos estão ocupados.
- `n5` **Alen:** Ocupados com quê?
- `n6` **Seu Hermes:** Em ganhar. → *fim*
- `n7` **Seu Hermes:** Todo mundo está. Vai. O tabuleiro espera. Ele sempre foi a coisa mais paciente da minha vida, depois da minha mulher. → *fim*
- `n8` **Seu Hermes:** Eu. E também eu. Não é tão emocionante quanto parece. *(pausa 0.4 s)* → *fim*

#### `c1_xadrez_2`
- `n1` **Seu Hermes:** Cavalo pra frente. Cavalo pra trás. Aprendi isso na guerra, mas não era xadrez. *(pausa 0.4 s)*
- `n2` *(narração)* Ele ri sozinho. Eu não sei se devo rir. → *fim*

#### `c1_posto_sinal`
- `n1` *(narração)* “AVENIDA CENTRAL — SÓ VEÍCULOS AUTORIZADOS.” Embaixo, em letras pequenas: “Pedestres: usar a Rua das Lojas.”
- `n2` *(narração)* Alguém riscou “autorizados” e escreveu “armados”. Uma segunda pessoa riscou “armados” e escreveu “cansados”. A terceira rabiscou tudo e desenhou um sol. → *fim*

#### `c1_posto_lopes_1`
- `n1` *(narração)* Uma soldada de capacete de lado, fuzil ao ombro e um chá numa caneca de metal. Ela me vê e baixa um pouco o queixo.
- `n2` **Sd. Lopes:** Avenida fechada. Mas você já sabia.
- `n3` **Alen:**  — *o jogador escolhe:*
    - ▸ “Sabia. Estou indo pra biblioteca.” → `n4`
    - ▸ “O que tem na avenida?” → `n5`
    - ▸ “A senhora está bebendo chá no meio disso tudo?” → `n7`
- `n4` **Sd. Lopes:** Pelo lado esquerdo da praça, depois da capela. Cuidado com o gelo, tá escorregadio. *(pausa 0.4 s)* → `n10`
- `n5` **Sd. Lopes:** A avenida. Mais avenida. *(pausa 0.5 s)*
- `n6` **Sd. Lopes:** E uma parte da cidade que me pediram pra não olhar. Eu cumpro. Mas eu olho. *(pausa 0.4 s)* → `n10`
- `n7` **Sd. Lopes:** É a única coisa quente que me deixam trazer. Quer um gole? *(pausa 0.5 s)*
- `n8` **Alen:** Não, obrigado. Mas é gentil. *(pausa 0.3 s)*
- `n9` **Sd. Lopes:** Aqui ninguém é gentil de graça. Anota aí.
- `n10` **Sd. Lopes:** Seu pai e sua mãe sabem que você está aqui? *(pausa 0.5 s)*
- `n11` **Alen:** Sabem. Estão em casa. Doentes. *(pausa 0.4 s)*
- `n12` **Sd. Lopes:** Dá o número da ração pra Dona Helena. Ela mantém uma lista de remédios. Se vier no comboio de sexta, pela avenida, ela sabe antes de mim. *(pausa 0.6 s)*
- `n13` **Sd. Lopes:** Não repete que eu disse isso. *(grava `c1_lopes_met=true`, `c1_med_hint=true`)* → *fim*

#### `c1_posto_lopes_2`
- `n1` **Sd. Lopes:** Sexta. Avenida. Helena. Mais nada que eu possa dizer. *(pausa 0.5 s)*
- `n2` **Sd. Lopes:** Anda, antes que o meu sargento me veja conversando. → *fim*

#### `c1_posto_lopes_back`
- `n1` **Sd. Lopes:** Voltando com caixa, né? Dá pra ver. Você anda como o povo daqui: mais pesado do lado em que carrega. *(pausa 0.4 s)*
- `n2` **Alen:** Eu tento disfarçar.
- `n3` **Sd. Lopes:** Não disfarça. Esse peso é o certo. → *fim*

#### `c1_posto_jipe`
- `n1` *(narração)* Um jipe verde com a lona cheia de neve. Ainda tem as marcas dos pneus da noite passada, cada vez mais fundas, como se cada viagem tivesse sido mais difícil que a anterior. → *fim*

#### `c1_posto_barreira`
- `n1` *(narração)* A barreira listrada de vermelho e branco é a única coisa colorida da avenida. Baixada. Silenciosa.
- `n2` *(narração)* Tem gelo pendurado no braço dela, como cabelo de gente velha. → *fim*

#### `c1_hotel_1`
- `n1` *(narração)* HOTEL CENTRAL. O fogo pegou um andar e parou, como se tivesse mudado de ideia. As janelas pretas olham pra praça sem expressão.
- `n2` *(narração)* Um hotel que um dia teve quartos, hóspedes e uma vista. Hoje tem uma ótima vista da própria falta de hóspedes. → *fim*

#### `c1_hotel_2`
- `n1` *(narração)* Na porta, um aviso colado com fita: “NÃO ENTRE. ISSO NÃO É UM ABRIGO. O ABRIGO É NA BIBLIOTECA.”
- `n2` *(narração)* Embaixo, em letra de criança: “E É MUITO MAIS QUENTE.” → *fim*

#### `c1_capela_1`
- `n1` *(narração)* Uma capela pequena de torre torta. Pela porta entreaberta, dá pra ver um brilho de velas e uma mulher ajeitando um lenço no banco da frente.
- `n2` *(narração)* Não entro. É como entrar na sala de alguém: dá vontade de pedir licença, mesmo sem ninguém por perto. → *fim*

#### `c1_capela_doacoes`
- `n1` *(narração)* Uma caixa de madeira com um recado: “DEIXE O QUE SOBRAR. LEVE O QUE FALTAR.”
- `n2` *(narração)* Dentro: um par de luvas de criança, tricotadas em cores que não combinam, uma lata de sardinha, um cobertor dobrado e um pé de sapato.
- `n3` *(narração)* Eu não tenho nada que sobre. Mas fico com a frase. *(pausa 0.5 s)* → *fim*

#### `c1_hum_cadastro`
- `n1` *(narração)* “CADASTRO NOVO. FILA B.” Uma fila comprida de gente em cobertores e casacos, mochilas, uma criança dormindo em pé.
- `n2` *(narração)* A tenda tem um balcão dobrável e uma voluntária de colete azul que repete, a cada três minutos, o mesmo “próximo, por favor”. Hoje ela está bem educada. → *fim*

#### `c1_fila_1`
- `n1` **Senhora:** Estou aqui desde as cinco da manhã. Não é pra reclamar! É só pra constar. *(pausa 0.4 s)*
- `n2` *(narração)* Ela prende o casaco com a mão e olha pra frente, firme.
- `n3` **Alen:**  — *o jogador escolhe:*
    - ▸ “A senhora quer sentar?” → `n4`
    - ▸ “O que a senhora veio fazer?” → `n5`
- `n4` **Senhora:** Se eu sentar, perco o lugar. E se eu perder o lugar, perco a manhã. Prefiro as costas doendo. *(pausa 0.5 s)* → *fim*
- `n5` **Senhora:** Cadastrar a minha casa, que não existe mais. Pra ter um papel que prove que ela existiu. → *fim*

#### `c1_fila_2`
- `n1` **Homem:** Escuta, é aqui a fila do pão ou a fila de cadastro?
- `n2` **Voluntária:** É a do cadastro, senhor.
- `n3` **Homem:** E a do pão?
- `n4` **Voluntária:** Do outro lado. É a mais curta.
- `n5` **Homem:** Então por que eu estou aqui? *(pausa 0.5 s)*
- `n6` **Voluntária:** Porque o senhor entrou na fila errada com muita convicção.
- `n7` *(narração)* O homem fica um segundo parado, depois dá risada. A fila inteira dá um pouco de risada junto, daquelas que saem baixinho. → *fim*

#### `c1_fila_velho`
- `n1` **Velho:** Cinco da manhã. Eu trouxe uma cadeira, mas deixei em casa. Esqueci por quê. *(pausa 0.4 s)*
- `n2` *(narração)* Ele sorri com os olhos, não com a boca. Alguém pôs um cobertor nos ombros dele, e ele não parece ter notado quem foi. → *fim*

#### `c1_caminhao_1`
- `n1` *(narração)* Um caminhão de suprimentos, verde, com uma lona aberta. Dois soldados e dois voluntários passam caixas de mão em mão numa corrente, sem conversar, num ritmo que parece música.
- `n2` *(narração)* Cada caixa tem um número. A caixa 114 passa por mim e eu sinto um pouco de vergonha por querer uma delas. → *fim*

#### `c1_caixas`
- `n1` *(narração)* Pilha de caixas de papelão carimbadas: ARROZ, FEIJÃO, ÓLEO, LEITE EM PÓ, SAL.
- `n2` *(narração)* Numa delas, alguém escreveu a mão: “NÃO CONGELAR.” A caixa está a três graus negativos, ao ar livre. Acho que é fé. → *fim*

#### `c1_agua_1`
- `n1` *(narração)* Um tanque cinza com três torneiras e uma placa: “ÁGUA — 5 LITROS POR PESSOA.” Uma fila curta, com baldes e garrafas.
- `n2` **Menino:** Eu prefiro neve derretida. Tem gosto de nuvem. *(pausa 0.4 s)*
- `n3` **Mulher:** Tem gosto de chaminé, isso sim.
- `n4` **Menino:** Chaminé de nuvem. → *fim*

#### `c1_agua_2`
- `n1` *(narração)* Uma voluntária enche, uma por uma, as garrafas de uma família. Cada garrafa recebe um pequeno “pronto” em voz baixa, como se fosse uma bênção. → *fim*

#### `c1_avisos_1`
- `n1` *(narração)* Quadro de avisos do Abrigo Nº 3.
- `n2` *(narração)* “AULA IMPROVISADA: 14h, SALA B. Traga lápis. Se não tiver lápis, traga a vontade.”
- `n3` *(narração)* “PROCURA-SE: cobertor de lã (qualquer cor), para uma senhora de 83 anos que não quer ser chamada de senhora.” → *fim*

#### `c1_avisos_2`
- `n1` *(narração)* “GRATIDÃO: a quem deixou os sapatos de criança na capela: serviram. — Lúcia (e a Bia, que agora tem sapato novo)”
- `n2` *(narração)* Fico um tempo ali, sem querer ir embora. A coisa que me segura é uma palavra: serviram. → *fim*

#### `c1_avisos_3`
- `n1` *(narração)* “TOQUE DE RECOLHER: 20h. QUEM ESTIVER NA RUA APÓS ESSE HORÁRIO SERÁ ORIENTADO A VOLTAR PARA CASA, ABRIGO OU BASE MILITAR MAIS PRÓXIMA.”
- `n2` *(narração)* Alguém escreveu embaixo: “Orientado = escoltado.” E outro: “Mas educadamente.” → *fim*

#### `c1_alto_falante`
- `n1` **Alto-falante:** ...atenção, moradores de Declan City. O comboio de suprimentos de sexta-feira segue previsto pela Avenida Central. Repetimos... *(som: radio_static)*
- `n2` **Alto-falante:** ...as atividades de distribuição continuam até às dezoito horas... *(pausa 0.4 s)*
- `n3` *(narração)* Ao longe, abafado, algo grave bate duas vezes. Ninguém olha. Todo mundo para um segundo e depois continua. *(som: boom_far)* → *fim*

#### `c1_teatro_1`
- `n1` *(narração)* Uma barraquinha de papelão: “TEATRO DE MEIAS. HOJE: ‘O REI QUE PERDEU O SAPATO’. ENTRADA FRANCA. APLAUSOS OBRIGATÓRIOS.”
- `n2` *(narração)* Dentro, um menino com uma meia vermelha em cada mão faz a voz grossa de um rei e a voz fina de uma rainha, trocando de uma para a outra sem respirar.
- `n3` **Menino:** “Meu sapato! Meu reino por um sapato!” “Majestade, o sapato está no seu pé.” “Então por que eu não sinto?” “Porque o senhor está de meia.” *(pausa 0.5 s)*
- `n4` **Alen:**  — *o jogador escolhe:*
    - ▸ “Aplaudir.” → `n5`
    - ▸ “Ficar em silêncio, impressionado.” → `n6`
- `n5` *(narração)* Eu aplaudo. O menino faz uma reverência com a meia vermelha. O público é de um: eu. É um bom público. *(grava `c1_puppet=true`)* → *fim*
- `n6` **Menino:** Aplauso é obrigatório. Tá na placa. *(pausa 0.4 s)*
- `n7` *(narração)* Eu aplaudo. Com atraso, mas aplaudo. *(grava `c1_puppet=true`)* → *fim*

#### `c1_teatro_2`
- `n1` **Menino:** Hoje tem outra peça. “A Rainha Que Esqueceu o Nome”. É um drama.
- `n2` **Alen:** Termina bem?
- `n3` **Menino:** Ainda estou decidindo. → *fim*

#### `c1_teatro_back`
- `n1` **Menino:** A peça mudou! A rainha lembrou o nome!
- `n2` **Alen:** Qual era?
- `n3` **Menino:** Não conta. É o final. *(pausa 0.4 s)* → *fim*

#### `c1_hum_ruina`
- `n1` *(narração)* O prédio ao lado perdeu a parede da frente. Dá pra ver a sala de alguém: um sofá, um quadro torto, um papel de parede de flores.
- `n2` *(narração)* Não existe nada mais íntimo do que uma sala sem parede. Olho um pouco e viro o rosto, pra devolver a privacidade. → *fim*

#### `c1_hum_lamp`
- `n1` *(narração)* O poste da esquina ainda tem lâmpada. Está apagada, mas alguém amarrou nele uma fita vermelha, com um laço.
- `n2` *(narração)* Acho que é uma promessa de luz. Gosto de promessas pequenas e amarradas. → *fim*

#### `c1_porta_bib_1`
- `n1` *(narração)* Um rapaz de colete azul e prancheta guarda a porta grande da biblioteca. Quando me vê, abre um sorriso curto, de quem decidiu ser simpático hoje.
- `n2` **Tiago:** Cartão de ração?
- `n3` **Alen:** Tenho. Nº 117. Hader. *(pausa 0.3 s)*
- `n4` **Tiago:** Hader. Três pessoas. Pode entrar. Balcão da Dona Helena, no corredor da esquerda. Limpa os pés no capacho; se ela vir neve no chão, o discurso é longo. *(pausa 0.5 s)*
- `n5` **Alen:**  — *o jogador escolhe:*
    - ▸ “Obrigado.” → `n6`
    - ▸ “Ela é brava?” → `n7`
- `n6` **Tiago:** Por nada. Faz parte do cargo. *(pausa 0.4 s)* → `n8`
- `n7` **Tiago:** Ela é exata. É diferente. Quem é exato não precisa ser bravo. *(pausa 0.4 s)*
- `n8` *(narração)* A porta tem uma fresta de luz amarela. Atrás dela, o cheiro: papel, lã molhada, sopa, poeira boa. *(grava `c1_tiago_door=true`)* → *fim*

#### `c1_porta_bib_2`
- `n1` **Tiago:** Pode entrar, pode entrar! Só não carrega neve nas botas. *(pausa 0.3 s)* → *fim*

#### `c1_porta_bib_back`
- `n1` **Tiago:** Voltando pra casa? Boa viagem, meu amigo. Chega inteiro. *(pausa 0.3 s)*
- `n2` **Alen:** Vou tentar.
- `n3` **Tiago:** A gente não pede mais que isso. → *fim*

## Biblioteca e Olivier

#### `c1_bib_entrada`
- `n1` *(narração)* Dentro, o ar muda. Menos vento, mais cheiro: papel, lã molhada, sopa, poeira boa.
- `n2` *(narração)* É uma biblioteca. Também é um refeitório, um dormitório e uma sala de espera. As estantes estão no mesmo lugar de sempre, mas as pessoas pararam de falar baixo, porque não dá.
- `n3` *(narração)* Em Declan City, ainda existe um lugar em que alguém quis manter as luzes acesas e os livros arrumados. Eu respiro. Uma respiração inteira. *(pausa 0.6 s)* → *fim*

#### `c1_nina_1`
- `n1` **Nina:** Bem-vindo! Isso aqui é mais ou menos um hotel, um refeitório e uma escola ao mesmo tempo. A gente ainda está decidindo o que mais. *(pausa 0.4 s)*
- `n2` *(narração)* Uma garota de gorro laranja e colete azul, com uma prancheta e um lápis preso na orelha, olha pra mim como se já tivesse me esperado a manhã inteira.
- `n3` **Nina:** Cartão na mão? Ótimo. Corredor da esquerda, balcão da Dona Helena. Ela vai fazer cara de exata. Não é cara de brava. *(pausa 0.3 s)*
- `n4` **Alen:**  — *o jogador escolhe:*
    - ▸ “Tem regra aqui?” → `n5`
    - ▸ “Posso explorar depois?” → `n7`
    - ▸ “Obrigado.” → `n8`
- `n5` **Nina:** Tem cinco. A número um é cartão, a dois é silêncio, a três é criança com adulto, a quatro é que o fogão é da Dona Rute, e a cinco é que ninguém dorme na fila.
- `n6` **Nina:** A quatro é a mais importante. Já perdi um bolo por causa dela. *(pausa 0.4 s)* → `n9`
- `n7` **Nina:** Pode, pode! Só não mexe nos jogos do canto sem pedir. E se o garoto da televisão disser que você perdeu, não acredita: ele mente sobre pontos. *(pausa 0.3 s)* → `n9`
- `n8` **Nina:** De nada. É o meu emprego, e eu gosto dele. *(pausa 0.4 s)*
- `n9` *(narração)* Ela volta pra prancheta. Eu volto pra rotina de caminhar e não esbarrar em ninguém. *(grava `c1_nina_met=true`)* → *fim*

#### `c1_nina_2`
- `n1` **Nina:** Corredor da esquerda, balcão da Helena. Você consegue. *(pausa 0.3 s)* → *fim*

#### `c1_nina_back`
- `n1` **Nina:** Pegou a caixa? Ótimo! Então agora você só precisa não derrubar. *(pausa 0.3 s)*
- `n2` **Alen:** Eu vou tentar.
- `n3` **Nina:** É o que a gente faz o dia inteiro. → *fim*

#### `c1_regras`
- `n1` *(narração)* “REGRAS DO ABRIGO.” Uma folha grande, escrita à mão, em cinco linhas:
- `n2` *(narração)* “1. Um cartão = uma caixa. 2. Silêncio (dentro do possível). 3. Crianças com adultos. 4. Fogão: só a Dona Rute. 5. Ninguém dorme na fila.”
- `n3` *(narração)* A regra 2 tem um “(dentro do possível)” escrito por cima, com outra caneta. O possível mudou de lugar. → *fim*

#### `c1_cabides`
- `n1` *(narração)* Um cabideiro de madeira com casacos pendurados, sem dono visível. Cada casaco tem uma etiqueta com nome, ou um desenho: um sol, uma estrela, um peixe.
- `n2` *(narração)* O meu eu levo. Eu só quero ver se eu entendo a lógica dos desenhos. → *fim*

#### `c1_capacho`
- `n1` *(narração)* No chão, um capacho escrito “SECAR OS PÉS”. Em volta, marcas de neve em forma de bota de todos os tamanhos.
- `n2` *(narração)* A neve no capacho é o único mapa honesto do que esse lugar recebeu hoje. → *fim*

#### `c1_banco_entrada`
- `n1` *(narração)* Um senhor dorme sentado no banco, a cabeça caída sobre o peito e as mãos sobre o joelho, como quem espera um ônibus que não vem.
- `n2` *(narração)* Passo devagar. A gente aprende rápido a andar em silêncio perto de quem dormiu. → *fim*

#### `c1_bib_exit_nofood`
- `n1` *(narração)* Ainda não peguei a caixa. Eu não volto pra casa de mãos vazias; seria dar a notícia ruim sem precisar. → *fim*

#### `c1_porta_saida_wait`
- `n1` *(narração)* Eu ainda não olhei o fundo da biblioteca. Tem uma luz azul que mexe, lá no canto. Uma televisão, parece.
- `n2` *(narração)* Não custa dar uma volta antes de ir. → *fim*

#### `c1_porta_saida_ok`
- `n1` *(narração)* Pego a caixa nos dois braços e ajeito o peso. A porta abre pra um dia mais baixo do que quando eu entrei. → *fim*

#### `c1_helena_1`
- `n1` *(narração)* Atrás do balcão, uma mulher de cardigã verde-petróleo, óculos presos a um cordão e cabelo em um coque que desafia a gravidade confere uma lista, a caneta presa entre os dedos.
- `n2` **Helena:** Cartão. *(pausa 0.3 s)*
- `n3` *(narração)* Entrego. Ela lê sem olhar pra mim. A caneta anda pela linha como se tivesse medo de pisar fora.
- `n4` **Helena:** Hader. Rua do Moinho, catorze. Três pessoas, quinzena. *(pausa 0.5 s)*
- `n5` *(narração)* Ela levanta os olhos por cima dos óculos.
- `n6` **Helena:** Hader. Você é filho do homem que devolve os livros no prazo?
- `n7` **Alen:**  — *o jogador escolhe:*
    - ▸ “Sou. Ele lia mais do que falava.” → `n8`
    - ▸ “Sou. Mas eu nunca olhei o prazo.” → `n9`
    - ▸ “(Assentir.)” → `n10`
- `n8` **Helena:** Eu sei. Os melhores leitores falam pouco. *(pausa 0.4 s)* → `n11`
- `n9` **Helena:** Ele olhava por você. Quinze anos sem um atraso. Eu guardei a ficha dele. Devia estar em exposição. *(pausa 0.4 s)* → `n11`
- `n10` **Helena:** Eu sei. A gente não precisa falar disso agora. *(pausa 0.4 s)*
- `n11` **Helena:** Ele não anda bem, não é?
- `n12` **Alen:** Não.
- `n13` **Helena:** Eu soube quando o livro parou de voltar. Não me importa o livro. Me importa a pessoa. *(pausa 0.5 s)*
- `n14` *(narração)* Ela diz isso rápido, sem olhar. Como quem sabe que se parar, não consegue continuar.
- `n15` **Helena:** Vamos ao que importa. Arroz, feijão, óleo, leite em pó. O sal acabou semana passada; hoje vai açúcar mascavo. Sua mãe vai achar o gosto curioso. *(pausa 0.4 s)*
- `n16` *(narração)* Ela faz um sinal com a cabeça. Um rapaz de colete azul, que eu já vi na porta, aparece com uma caixa de papelão, amarrada com barbante.
- `n17` **SE** `c1_bread` → `n18` · **SENÃO** → `n27`
- `n18` **Helena:** E isso? *(pausa 0.4 s)*
- `n19` **Alen:** Pães. Da Dona Íris. Ela disse que a senhora já sabe.
- `n20` **Helena:** Aquela mulher vai me matar de afeto. Cinco pães quentes. Ela deve ter aberto o último saco de farinha só pra isso. *(pausa 0.5 s)*
- `n21` *(narração)* Ela fica um segundo em silêncio, a mão no saco, sentindo o calor.
- `n22` **Helena:** Espera. *(pausa 0.4 s)*
- `n23` *(narração)* Ela se vira, abre uma gaveta de metal e tira uma lata com um rótulo desbotado: pêssego em calda.
- `n24` **Helena:** Isso é de uma doação de setembro. Estava guardada pra quando alguém merecesse. Hoje alguém merece. *(pausa 0.6 s)*
- `n25` **Alen:** Eu só carreguei o saco.
- `n26` **Helena:** A gente nunca sabe quando uma coisa pequena é grande. Leva. *(pausa 0.4 s; grava `c1_peach=true`)* → `n28`
- `n27` *(narração)* Ela confere os itens da caixa com um dedo, como quem reza, e passa o barbante duas vezes.
- `n28` **Helena:** Assina aqui. E aqui. E aqui. Eles gostam de assinatura. *(pausa 0.5 s)*
- `n29` *(narração)* Assino três vezes. Na terceira, minha letra já parece outra pessoa.
- `n30` *(narração)* Ela carimba o cartão: um carimbo azul, “RETIRADO”, na data de hoje.
- `n31` **Alen:**  — *o jogador escolhe:*
    - ▸ “A senhora mantém uma lista de remédios?” → `n32`
    - ▸ “Obrigado, dona Helena.” → `n37`
- `n32` **Helena:** Mantenho. Nome, dosagem, quem precisa. Você tem a receita? *(pausa 0.4 s)*
- `n33` **Alen:** A minha mãe tem. E o meu pai.
- `n34` **Helena:** Dois. Então são o 23 e o 24. *(pausa 0.5 s)*
- `n35` **Helena:** O comboio de sexta pode trazer antibiótico. Pode trazer outra coisa. Eu não prometo. Prometo anotar. *(pausa 0.6 s)*
- `n36` **Alen:** Já é mais do que eu tinha. *(grava `c1_meds_listed=true`)* → `n38`
- `n37` **Helena:** Não agradece. A caixa é da cidade. Eu só fiscalizo. *(pausa 0.4 s)*
- `n38` **Helena:** A sala de jogos fica depois das estantes. Não corre, não grita e não fala com o rapaz da televisão se ele estiver perdendo. Ele mente sobre os pontos.
- `n39` **Alen:** O rapaz da televisão?
- `n40` **Helena:** Você vai saber quando ver. *(grava `c1_food=true`)*
- `n41` *(narração)* Pego a caixa. É mais pesada do que eu pensei e mais leve do que eu precisava. A mão da minha mãe já está nela, de algum jeito. *(pausa 0.6 s)* → *fim*

#### `c1_helena_2`
- `n1` **Helena:** O que mais?
- `n2` **Alen:**  — *o jogador escolhe:*
    - ▸ “Quem é o rapaz da televisão?” → `n3`
    - ▸ “Como eu levo um livro emprestado?” → `n5`
    - ▸ “O que tem no depósito?” → `n7`
    - ▸ “Nada, obrigado.” → `n8`
- `n3` **Helena:** Chegou em novembro. Veio do norte. Come pouco, joga muito. Eu deixo.
- `n4` **Helena:** Ele cuida do console melhor que muito adulto cuida da própria casa. Isso não é pouco. *(pausa 0.4 s)* → `n2`
- `n5` **Helena:** Caderno de empréstimos, na mesa de leitura. Anota seu nome e o título. A biblioteca é de todo mundo; só pede pra devolver.
- `n6` **Helena:** E se perder, escreve uma carta explicando. Eu leio todas. → `n2`
- `n7` **Helena:** Remédio, fórmula pra bebê e o que eu não digo. O Teixeira cuida da chave. A chave cuida dele. *(pausa 0.4 s)* → `n2`
- `n8` **Helena:** Então vai, que a fila anda. E Alen... diz pro seu pai que a biblioteca guardou a ficha dele. *(pausa 0.5 s)* → *fim*

#### `c1_helena_ret`
- `n1` **Helena:** Ainda por aqui? Não tem problema. Lugar quente é pra isso. *(pausa 0.3 s)*
- `n2` **Helena:** Mas sua família está esperando, e uma caixa de comida esfria de um jeito diferente. → *fim*

#### `c1_balcao_livro`
- `n1` *(narração)* O livro-caixa de Helena está aberto no balcão: colunas e colunas de nomes, em uma letra tão regular que parece impressa.
- `n2` *(narração)* Do lado, um papelzinho: “Hoje faltam: sal, açúcar, leite em pó (fórmula), lâmpadas, esperança. — Pedir à Prefeitura (de novo).” → *fim*

#### `c1_balanca`
- `n1` *(narração)* Uma balança de mola, com o ponteiro tremendo em 3 kg, como quem faz um cálculo difícil.
- `n2` *(narração)* Alguém escreveu na base: “NÃO PRESSIONE O PRATO COM O DEDO. A BALANÇA SABE.” → *fim*

#### `c1_tiago_caixas`
- `n1` **Tiago:** Cuidado, essa é a caixa de feijão. Quem derruba feijão é obrigado a catar. *(pausa 0.4 s)*
- `n2` *(narração)* Ele faz uma pilha de caixas com uma precisão incrível e um cuidado que parece quase carinho.
- `n3` **Tiago:** A gente chega às seis, saí às oito da noite. Não é um trabalho. É um jeito de ficar de pé. *(pausa 0.4 s)* → *fim*

#### `c1_fila_dist`
- `n1` *(narração)* Uma mulher e um senhor na fila, esperando a vez. Ela segura um cartão. Ele segura outro. Os dois seguram com as duas mãos, como quem carrega um passarinho.
- `n2` **Mulher:** Dizem que hoje tem leite em pó.
- `n3` **Velho:** Dizem que tinha ontem também.
- `n4` **Mulher:** Pois então. A gente repete os boatos até eles virarem verdade. → *fim*

#### `c1_deposito_porta`
- `n1` *(narração)* Uma porta de aço com grades, um cadeado enorme e um aviso vermelho: “ACESSO RESTRITO — SOMENTE PESSOAL AUTORIZADO.”
- `n2` *(narração)* Pela grade dá pra ver uma pilha de caixas militares e outra, menor, de caixas brancas com uma cruz azul. Remédios, imagino. *(pausa 0.5 s)* → *fim*

#### `c1_teixeira_1`
- `n1` *(narração)* Um soldado de braços cruzados guarda a porta, olhando um ponto fixo em cima da minha cabeça.
- `n2` **Sd. Teixeira:** Acesso restrito.
- `n3` **Alen:**  — *o jogador escolhe:*
    - ▸ “Eu só queria saber se tem remédio.” → `n4`
    - ▸ “Eu não vou entrar.” → `n5`
    - ▸ “(Ficar olhando as caixas.)” → `n6`
- `n4` **Sd. Teixeira:** Quem cuida dos remédios é a Dona Helena. Eu cuido da porta. A porta, por si só, não tem opinião. *(pausa 0.4 s)* → *fim*
- `n5` **Sd. Teixeira:** Ótimo. Então a gente se entende. → *fim*
- `n6` **Sd. Teixeira:** Caixas brancas, caixas verdes. Cada uma com um número. Só quem tem o número entra. *(pausa 0.4 s)* → *fim*

#### `c1_teixeira_2`
- `n1` **Sd. Teixeira:** Acesso restrito. Mas pode olhar. Olhar não está no regulamento. *(pausa 0.4 s)* → *fim*

#### `c1_deposito_cartaz`
- `n1` *(narração)* Um cartaz colado ao lado da porta: “SEXTA: COMBOIO. TODOS AUTORIZADOS A ESPERAR.”
- `n2` *(narração)* A frase tem duas leituras e as duas são verdade. → *fim*

#### `c1_lucia_1`
- `n1` *(narração)* Uma mulher sentada num colchão, com um bebê embrulhado em um pano de prato, balança o corpo de um jeito antigo, sem ritmo e com muito ritmo.
- `n2` **Lúcia:** Ela só dorme quando o aquecedor estala. Eu já tentei cantar, contar, rezar. Ela só confia no aquecedor. *(pausa 0.4 s)*
- `n3` **Alen:**  — *o jogador escolhe:*
    - ▸ “Ela é linda.” → `n4`
    - ▸ “Ela tem quantos meses?” → `n5`
    - ▸ “(Sorrir de longe.)” → `fim`
- `n4` **Lúcia:** É. Também acho. Mas ela ronca igual a minha avó. *(pausa 0.4 s)* → *fim*
- `n5` **Lúcia:** Quatro. Nasceu em agosto. Foi o último mês de gente nascendo sem medo. *(pausa 0.4 s)* → *fim*

#### `c1_lucia_2`
- `n1` **Lúcia:** Ela dormiu. Shhh. Fica assim. Cuidado com o pé. *(pausa 0.5 s)* → *fim*

#### `c1_anselmo`
- `n1` *(narração)* Um senhor dorme de boca aberta, embrulhado em um cobertor xadrez, com um livro no peito subindo e descendo.
- `n2` *(narração)* Ele ronca em ré menor. Tem uma melodia até, se a gente se esforçar.
- `n3` *(narração)* A etiqueta do cobertor diz “ANSELMO”. Embaixo, outra caligrafia: “(pra devolver depois que acordar)”. → *fim*

#### `c1_criancas_cartas`
- `n1` *(narração)* Duas crianças jogam cartas em cima de um colchão, com uma pilha de botões como fichas.
- `n2` **Pedro:** Se você ganhar, eu devolvo o botão. *(pausa 0.3 s)*
- `n3` **Lia:** Ele não tem botão. Ele perdeu tudo pra mim. *(pausa 0.3 s)*
- `n4` **Pedro:** Eu tenho um de reserva.
- `n5` **Lia:** Esse é do meu casaco.
- `n6` **SE** `c1_candy` → `n7` · **SENÃO** → `n16`
- `n7` *(narração)* Eu tenho a bala de menta no bolso. *(pausa 0.5 s)*
- `n8` **Alen:**  — *o jogador escolhe:*
    - ▸ “Dar a bala pra Lia.” → `n9`
    - ▸ “Dividir entre os dois.” → `n12`
    - ▸ “Guardar.” → `n15`
- `n9` *(narração)* Lia olha a bala com a seriedade de quem recebe um diploma. Depois parte no meio com os dentes e dá a metade pro Pedro, sem dizer nada.
- `n10` **Pedro:** Isso não conta como devolver o botão.
- `n11` **Lia:** Conta como pagar a dívida. *(grava `c1_candy_given=true`, `c1_candy=0`)* → *fim*
- `n12` *(narração)* Corto a bala em dois pedaços com cuidado, usando os dentes e uma unha. As crianças olham como se eu fizesse mágica.
- `n13` **Pedro:** Uma bala só rende dois sorrisos!
- `n14` **Lia:** Rende uma conversa inteira. *(grava `c1_candy_given=true`, `c1_candy=0`)* → *fim*
- `n15` *(narração)* Guardo. Hoje a gente não precisa gastar tudo. → *fim*
- `n16` **Pedro:** Você joga?
- `n17` **Alen:** Eu só olho.
- `n18` **Lia:** Olhar também conta. Mas não ganha. *(pausa 0.3 s)* → *fim*

#### `c1_rute_1`
- `n1` **Dona Rute:** Pra trás! O fogão é meu. *(pausa 0.3 s)*
- `n2` *(narração)* Uma mulher mais baixa que a chaleira que carrega, com um pano de prato no ombro e uma colher de pau, mexe uma panela de ferro em cima do aquecedor.
- `n3` **Dona Rute:** É chá de casca de laranja. Não pergunta de onde veio a laranja.
- `n4` **Alen:**  — *o jogador escolhe:*
    - ▸ “De onde veio a laranja?” → `n5`
    - ▸ “Posso provar?” → `n7`
    - ▸ “Quem dá aula na Sala B?” → `n9`
- `n5` **Dona Rute:** Eu avisei.
- `n6` *(narração)* Ela me estende uma caneca mesmo assim. O chá tem gosto de verão que foi guardado numa gaveta. *(pausa 0.4 s)* → *fim*
- `n7` **Dona Rute:** Se for rápido. A regra da casa é uma caneca por visita.
- `n8` *(narração)* Provo. É quente e doce em um jeito que eu não tinha reparado que estava com saudade. → *fim*
- `n9` **Dona Rute:** Uma professora que chegou semana passada. Ela diz que dá aula pra quem tem vontade e pra quem não tem. Eu vou nas duas. *(pausa 0.4 s)* → *fim*

#### `c1_rute_2`
- `n1` **Dona Rute:** Hoje é quinta. Quinta é dia de sopa de macarrão. Quem não gosta aprende. *(pausa 0.4 s)* → *fim*

#### `c1_aquecedor`
- `n1` *(narração)* O aquecedor a lenha. A chaminé de lata passa por um buraco que alguém abriu na janela e vedou com um pano molhado.
- `n2` *(narração)* Dá pra ficar parado ali e sentir os dedos voltando a ser dedos. → *fim*

#### `c1_desenhos`
- `n1` *(narração)* Desenhos de crianças presos na parede com fita. Casas, sóis, um cachorro azul, três bonecos de palito de mãos dadas.
- `n2` *(narração)* Em um deles, uma nave. Em outro, uma nave. No terceiro, uma nave com um robô enorme. Alguém tem um tema. *(pausa 0.4 s)* → *fim*

#### `c1_calendario_bib`
- `n1` *(narração)* Um calendário de DEZEMBRO 2008, com cada dia riscado em X. Alguém circulou o dia da sexta, o comboio.
- `n2` *(narração)* Alguém escreveu na margem: “Dia 19: a gente aguenta.” O resto da margem está cheio de contas e anotações pequenas de gente que não perdeu a esperança de ser exata. *(pausa 0.4 s)* → *fim*

#### `c1_malas`
- `n1` *(narração)* Malas empilhadas ao lado de um colchão. Uma tem um nome e um endereço na etiqueta. O endereço não existe mais, mas a etiqueta insiste. → *fim*

#### `c1_colchao`
- `n1` *(narração)* Um colchão arrumado com cuidado: lençol esticado, travesseiro afofado, um livro aberto de bruços. Sobre o livro, uma colher.
- `n2` *(narração)* Pessoas que perderam muita coisa se agarram a pequenas ordens. → *fim*

#### `c1_lencol`
- `n1` *(narração)* Um lençol pendurado entre duas cordas separa dois colchões. Dos dois lados, ouço vozes baixas, um riso curto.
- `n2` *(narração)* É uma parede de pano. Mas é uma parede, e as pessoas respeitam. → *fim*

#### `c1_book_contos`
- `n1` *(narração)* Na prateleira de ficção, entre uma capa azul e uma verde, uma lombada: “CONTOS DE OUTROS MUNDOS”.
- `n2` *(narração)* Abro. A primeira página tem um carimbo da biblioteca e, no cantinho, a ficha com três nomes de leitores. O terceiro é “Hader”.
- `n3` *(narração)* Viro até a última página. Alguém escreveu a lápis: “volto antes do verão”. A tinta está borrada. Não há nome.
- `n4` *(narração)* É a letra mais calma que eu li hoje. *(grava `c1_found_book=true`)* → *fim*

#### `c1_book_dicionario`
- `n1` *(narração)* Um dicionário enorme, em cima de uma estante baixa, aberto numa página qualquer.
- `n2` *(narração)* A palavra no topo é “abrigo”. Três páginas depois, “acaso”. É a única coincidência que eu permito hoje. → *fim*

#### `c1_book_atlas`
- `n1` *(narração)* Um atlas de capa dura, com todos os mapas ainda no lugar. Menos um. A página do norte foi arrancada, com cuidado, rente à costura.
- `n2` *(narração)* Não sei quem. Não sei por quê. Fecho o livro como quem fecha uma porta que alguém deixou entreaberta. → *fim*

#### `c1_book_infantil`
- `n1` *(narração)* Na prateleira baixa, de criança, um livro de capa amarela: “O Urso que Esperava a Primavera”.
- `n2` *(narração)* Abro numa página. O urso olha a janela. A janela olha a neve. A neve não sabe de nada.
- `n3` *(narração)* Fecho. Não é pra mim, mas eu entendi o livro. → *fim*

#### `c1_revista`
- `n1` *(narração)* Uma revista velha na estante de periódicos: “PIXEL CLUB nº 41 — Junho de 1998”. Na capa, uma nave azul.
- `n2` *(narração)* Abro na matéria: “Space Travelers: difícil, injusto e inesquecível. NOTA: 8,5.” Mais abaixo: “Another Concept lançou três jogos e nenhum sucesso. Existe um culto ao redor deles. Ainda não sabemos quantos membros.”
- `n3` *(narração)* No rodapé, em lápis, alguém acrescentou: “Dois.” O lápis é de alguém que riu sozinho. *(pausa 0.5 s; grava `c1_read_mag=true`)* → *fim*

#### `c1_guitar_box`
- `n1` *(narração)* Numa prateleira do alto, uma caixa chata e colorida: “GUITAR LEGENDS — PC CD-ROM — Another Concept.”
- `n2` *(narração)* A guitarra da capa tem o braço curto demais pra um humano. Mas o riso do guitarrista é perfeito.
- `n3` *(narração)* Na etiqueta da biblioteca: “Jogo de ritmo. Acompanha adaptador de guitarra (perdido).”
- `n4` *(narração)* Penso na guitarra encostada na parede do meu quarto. A que eu não toco faz tempo. *(grava `c1_guitar_seen=true`)* → *fim*

#### `c1_fichario`
- `n1` *(narração)* Na ponta do balcão da recepção, uma caixa azul de fichas, com divisórias de A a Z. Abro na letra “H” por curiosidade. Dentro, uma ficha com um nome de família: o meu.
- `n2` *(narração)* “Hader. Empréstimos: 31. Atrasos: 0. Observação: ‘Devolve sempre com um marcador novo.’”
- `n3` *(narração)* Eu nunca soube dos marcadores. Fico um tempo lendo a observação. → *fim*

#### `c1_mesa_leitura`
- `n1` *(narração)* Uma menina de uns dez anos lê um livro grosso com o dedo percorrendo as linhas, os lábios mexendo sem som.
- `n2` *(narração)* Ela me olha e levanta um dedo pra pedir silêncio, sério como um juiz. Eu concordo com a cabeça. → *fim*

#### `c1_emprestimo`
- `n1` *(narração)* Sobre a mesa, o caderno de empréstimos, com uma caneta amarrada por um barbante. Na capa, a letra de Helena: “LEVE. DEVOLVA. NÃO PERCA. — H.”
- `n2` *(narração)* Eu viro as páginas. Nomes, datas, títulos. A caneta me espera. *(pausa 0.6 s)*
- `n3` **SE** `c1_item` → `n4` · **SENÃO** → `n5`
- `n4` *(narração)* Meu nome já está numa linha. Posso trocar, se quiser.
- `n5` O que levar para casa? — *o jogador escolhe:*
    - ▸ “Levar GUITAR LEGENDS (jogo de ritmo, para o computador).” → `fim` *(grava `c1_item`; só se `c1_guitar_seen`)*
    - ▸ “Levar CONTOS DE OUTROS MUNDOS (o livro do meu pai).” → `fim` *(grava `c1_item`; só se `c1_found_book`)*
    - ▸ “Não levar nada hoje.” → `fim` *(grava `c1_item`)*
    - ▸ “Procurar mais um pouco antes de decidir.” → `fim`

#### `c1_tv_luz`
- `n1` *(narração)* No fundo da biblioteca, uma luz azul que mexe. Ela faz sombra nas estantes de um jeito que as sombras se movem à frente das coisas que estão paradas.
- `n2` *(narração)* Um som fraquinho de música de oito notas se repete, alegre e teimosa, como um ruído de passarinho eletrônico. → *fim*

#### `c1_tv`
- `n1` *(narração)* Uma televisão de tubo sobre um carrinho de feira. Na tela, uma nave azul e minúscula dispara luzes contra robôs cinzentos e enormes.
- `n2` *(narração)* No canto da tela, uma palavra pisca: “SPACE TRAVELERS”. Em letras menores: “© ANOTHER CONCEPT”. O resto é cheio de ruído e de escuridão boa. *(pausa 0.4 s)* → *fim*

#### `c1_console`
- `n1` *(narração)* Um console cinza de plástico gasto, com dois controles de fios longos e embolados. Alguém costurou um pedaço de fita no cabo de um deles, com todo o cuidado.
- `n2` *(narração)* Na fita, um nome: “DONA HELENA: ESTE É DA BIBLIOTECA. NÃO PUXE PELO FIO.” → *fim*

#### `c1_cartuchos`
- `n1` *(narração)* Uma prateleira com cartuchos de jogos, em fila: “SPACE TRAVELERS”, “GUITAR LEGENDS”, “MUNDO DE TINTA”, “CORRIDA NOTURNA 3”.
- `n2` *(narração)* Todos têm o círculo com uma linha no meio, o logotipo da Another Concept. Parece um olho fechado.
- `n3` *(narração)* Embaixo, um bilhete: “JOGOS (CUIDEM DELES). — H.” → *fim*

#### `c1_cartucho_space`
- `n1` *(narração)* O cartucho de Space Travelers está na prateleira, vazio. O que está no console deve ser a cópia da biblioteca. *(pausa 0.4 s)*
- `n2` *(narração)* Tem uma etiqueta: “NÃO EMPRESTAR: O CONSOLE É O ÚNICO NA CIDADE.”
- `n3` *(narração)* Quem leva o jogo leva a metade. A outra metade fica aqui. → *fim*

#### `c1_poster_another`
- `n1` *(narração)* Um pôster: um círculo atravessado por uma linha, como um olho fechado, e estrelas ao redor. “ANOTHER CONCEPT.”
- `n2` *(narração)* Alguém escreveu a lápis embaixo: “Sonhos pequenos, bem feitos.” → *fim*

#### `c1_pufe`
- `n1` *(narração)* Dois pufes velhos e um tapete de retalhos em tons de roxo. Tem uma marca em um dos pufes onde alguém passa horas por dia.
- `n2` *(narração)* No outro, uma manta dobrada com capricho. Parece de visita. → *fim*

#### `c1_oliv_intro`
- `n1` *(narração)* O fundo da biblioteca tem uma luz azul que mexe. Uma televisão de tubo sobre um carrinho, um console cinza, fios por todo lado.
- `n2` *(narração)* Na frente, sentado de qualquer jeito num pufe, um garoto de cachecol laranja e cabelo castanho bagunçado. Controle nas duas mãos. Costas curvas. Uma perna balançando no ritmo de um jogo que eu não conheço.
- `n3` *(narração)* Na tela, uma nave azul minúscula desvia de robôs enormes.
- `n4` **Garoto:** Se você está esperando eu perder, vai ficar aí até amanhã. *(pausa 0.6 s)*
- `n5` **Alen:** Eu nem sei o que você está jogando.
- `n6` **Garoto:** Melhor ainda. Assim você não vai entender como eu consegui perder.
- `n7` **Alen:** Você acabou de dizer que não ia perder.
- `n8` **Garoto:** E você acabou de descobrir que não deve acreditar em tudo que ouve. *(pausa 0.6 s)*
- `n9` *(narração)* Ele não tira os olhos da tela. Mas o canto da boca se mexe um pouco. Um pixel só.
- `n10` *(narração)* Na tela, a nave explode em quatro pedaços e uma musiquinha de oito notas afunda, triste. *(som: game_lose)*
- `n11` **Garoto:** ...Isso não conta. Eu estava conversando.
- `n12` **Alen:** Então a culpa é minha.
- `n13` **Garoto:** É. Anota aí. *(pausa 0.5 s)*
- `n14` *(narração)* Ele larga o controle no colo. Pela primeira vez me olha de verdade, de cima a baixo, rápido, e acha uma conclusão que não conta.
- `n15` **Garoto:** Quantos anos? Doze?
- `n16` **Alen:** Dezesseis.
- `n17` **Garoto:** Parece doze.
- `n18` **Alen:** E você?
- `n19` **Garoto:** Dezoito. Não é muita diferença, mas hoje eu me sinto bem mais velho. É só uma sensação. Ignora. *(pausa 0.4 s)*
- `n20` **Garoto:** Você vai ficar aí em pé me olhando perder ou tem nome?
- `n21` **Alen:** Alen.
- `n22` **Olivier:** Olivier. Não aperta a mão, tô com o controle. *(pausa 0.4 s; grava `c1_oliv_met=true`, `c1_oliv_named=true`)*
- `n23` *(narração)* Ele não sorri, mas a perna para de balançar. Isso, nele, deve ser uma espécie de sorriso. → *fim*

#### `c1_oliv_hub`
- `n1` **SE** `c1_played` → `n31` · **SENÃO** → `n2`
- `n2` **Alen:**  — *o jogador escolhe:*
    - ▸ “Que jogo é esse?” → `n3`
    - ▸ “Vi o cartaz dele numa locadora.” → `n9` *(só se `c1_saw_space`; só se não `c1_loc_talked`)*
    - ▸ “Vi uma nave desenhada num vidro, num beco.” → `n14` *(só se `c1_saw_ship`; só se não `c1_ship_told`)*
    - ▸ “Posso ver mais um pouco?” → `n19` *(só se não `c1_watched`)*
    - ▸ “Posso tentar?” → `n23`
    - ▸ “Eu preciso ir. Tenho uma caixa pra levar.” → `n57` *(só se `c1_food`; só se não `c1_oliv_bye`)*
    - ▸ “(Voltar depois.)” → `n30`
- `n3` **Olivier:** Space Travelers. Uma nave, três vidas, uns oito tipos de robô que não gostam de visita. Você atira, desvia, atira de novo. No fim tem um chefe que parece um fogão com raiva. *(pausa 0.4 s)*
- `n4` **Alen:** Parece fácil.
- `n5` **Olivier:** É. Parece. *(pausa 0.6 s)*
- `n6` **Alen:** Quem fez?
- `n7` **Olivier:** Another Concept. Três jogos, nenhum sucesso. Tem gente que diz que foi de propósito. *(pausa 0.4 s)*
- `n8` **Olivier:** Esse eu achei aqui, no fundo da prateleira, com um bilhete dizendo “cuidem”. Cuidei. Mais ou menos. *(pausa 0.4 s)* → `n2`
- `n9` **Olivier:** Vídeo Ponto? Você entrou lá? Dentro? *(pausa 0.5 s)*
- `n10` **Alen:** Entrei. Só tinha o cartaz e uma caixa de devolução.
- `n11` **Olivier:** ...Tá. O cartaz ainda está inteiro? *(pausa 0.8 s)*
- `n12` **Alen:** Está.
- `n13` **Olivier:** Bom. Alguém devia ter levado aquele. Mas bom. *(pausa 0.4 s; grava `c1_loc_talked=true`)* → `n2`
- `n14` **Olivier:** Muita gente desenha nave. *(pausa 0.9 s)*
- `n15` **Alen:** A mão estava bem treinada.
- `n16` **Olivier:** É o desenho que a mão faz quando está entediada. E quando não tem mais o que desenhar. *(pausa 0.6 s)*
- `n17` *(narração)* Ele continua de olho na tela, mas a orelha esquerda ficou da cor do cachecol.
- `n18` **Olivier:** Você quer jogar ou não? *(grava `c1_ship_told=true`)* → `n2`
- `n19` **Olivier:** Pode. Fica de pé, que o pufe é meu. E não toca no cabo; ele só funciona de ódio. *(pausa 0.3 s)*
- `n20` *(narração)* Ele recomeça a fase. Eu nunca vi alguém jogar assim. Ele não mexe só os dedos: mexe o ombro, o pescoço, a boca em silêncio, como se cada tiro custasse alguma coisa.
- `n21` *(narração)* Os robôs vêm em fila. Ele atira, atira, desvia pra esquerda por um fio, atira de novo. Em algum momento eu percebo que estou prendendo a respiração. *(pausa 0.5 s)*
- `n22` **Olivier:** Respira. É feio ver gente azul. *(grava `c1_watched=true`)* → `n2`
- `n23` **Olivier:** Hum. Quer mesmo? *(pausa 0.5 s)*
- `n24` **Alen:** Quero.
- `n25` **Olivier:** Regras. Três vidas, sem pausa, sem choro. Se quebrar o controle, assume a dívida.
- `n26` **Alen:** A dívida de quem?
- `n27` **Olivier:** Da biblioteca. Mas eu cobro pela biblioteca.
- `n28` **Olivier:** Setas movem. O botão que lá fora você chama de “interagir”, aqui é “atirar”. Segura que ele atira sozinho. Segura. *(pausa 0.4 s)*
- `n29` *(narração)* Ele estende o controle com as duas mãos, como se eu fosse receber um bebê. Eu recebo com as duas também. *(grava `c1_play_now=true`)* → *fim*
- `n30` **Olivier:** Quando voltar eu ainda estou aqui. Ou o jogo está. É a mesma coisa. *(pausa 0.4 s)* → *fim*
- `n31` **Alen:**  — *o jogador escolhe:*
    - ▸ “Quem criou esse jogo? A Another Concept?” → `n32` *(só se não `c1_ac_talked`)*
    - ▸ “Você é de onde?” → `n36` *(só se não `c1_north_talked`)*
    - ▸ “Eu tenho uma guitarra em casa.” → `n49` *(só se `c1_guitar_seen`; só se não `c1_gl_talked`)*
    - ▸ “Quero jogar de novo.” → `n54`
    - ▸ “Eu preciso ir. Tenho uma caixa pra levar.” → `n57` *(só se `c1_food`; só se não `c1_oliv_bye`)*
    - ▸ “(Voltar depois.)” → `n56`
- `n32` **Olivier:** Três jogos. Um de nave, um de guitarra, um de tinta. Todos fizeram sucesso em exatamente quatro casas. *(pausa 0.4 s)*
- `n33` **Olivier:** Dizem que foram dois caras num apartamento. Que o logotipo é um olho fechado porque eles dormiam pouco. Eu acho que é porque eles queriam que a gente sonhasse sem precisar abrir. *(pausa 0.5 s)*
- `n34` **Alen:** Isso é bonito.
- `n35` **Olivier:** É uma teoria. Não é uma verdade. Mas é a minha. *(pausa 0.4 s; grava `c1_ac_talked=true`)* → `n31`
- `n36` **Olivier:** Do norte.
- `n37` **Alen:** Norte de onde?
- `n38` **Olivier:** De lá. *(pausa 0.8 s)*
- `n39` *(narração)* Ele diz “lá” do jeito que alguém diz um endereço que não existe mais. Mais nada. A tela continua piscando.
- `n40` **Alen:**  — *o jogador escolhe:*
    - ▸ “Tá.” → `n41`
    - ▸ “E sua família?” → `n45`
- `n41` **Olivier:** Você não insiste. *(pausa 0.8 s)*
- `n42` **Alen:** Não gosto quando fazem comigo.
- `n43` **Olivier:** Hm. Isso é raro. Guarda esse jeito. *(pausa 0.4 s)*
- `n44` **Olivier:** Cheguei faz três semanas. Durmo ali — perto do aquecedor; eu não sou bobo. O resto, um dia. Ou não. *(pausa 0.4 s; grava `c1_north_talked=true`, `c1_oliv_trust=true`)* → `n31`
- `n45` **Olivier:** Troca de assunto. Você joga mal, aliás. *(pausa 0.6 s)*
- `n46` **Alen:** Eu joguei uma vez.
- `n47` **Olivier:** Pior ainda.
- `n48` *(narração)* Ele ri. É uma risada curta, de quem estava treinando pra não rir. Eu entendi o recado e deixei quieto. *(pausa 0.4 s; grava `c1_north_talked=true`)* → `n31`
- `n49` **Olivier:** Você toca?
- `n50` **Alen:** Tocava. Ela está encostada no quarto faz tempo. *(pausa 0.4 s)*
- `n51` **Olivier:** Então pega o Guitar Legends. É um jogo de ritmo; roda no computador. Não é empréstimo oficial. Mas a Dona Helena anota tudo num caderno, e se você devolver, ela esquece que você levou. *(pausa 0.4 s)*
- `n52` **Alen:** E o seu?
- `n53` **Olivier:** O meu é este. O console é um só na cidade. Quem leva o jogo leva a metade. A outra metade fica aqui. *(pausa 0.5 s; grava `c1_gl_talked=true`)* → `n31`
- `n54` **Olivier:** Quero ver se melhora. Dedos, vai. *(pausa 0.4 s)*
- `n55` *(narração)* Ele me passa o controle sem cerimônia desta vez. *(grava `c1_play_now=true`)* → *fim*
- `n56` **Olivier:** Quando voltar eu ainda estou aqui. Ou o jogo está. *(pausa 0.4 s)* → *fim*
- `n57` **Olivier:** A caixa de ração. Certo. Quem está em casa? *(pausa 0.4 s)*
- `n58` **Alen:** Meus pais. Estão doentes.
- `n59` **Olivier:** Então vai. Não faz cara de pena; eu não vou fazer a minha. *(pausa 0.4 s)*
- `n60` **Alen:** Eu não estava fazendo.
- `n61` **Olivier:** Estava. Era pequena. Eu gostei. *(pausa 0.5 s)*
- `n62` *(narração)* Ele revira o bolso do casaco e tira uma barra de cereal embrulhada, amassada, velha.
- `n63` **Olivier:** Toma. Pro caminho.
- `n64` **Alen:** Não precisa.
- `n65` **Olivier:** Eu sei que não precisa. É a metade que eu não ia comer. *(pausa 0.6 s)*
- `n66` *(narração)* Parto a barra no meio e a metade dele continua intacta no embrulho. Ele nunca ia comer. Ele guardou a barra inteira pra alguém. *(pausa 0.6 s)*
- `n67` **Alen:** Obrigado.
- `n68` **Olivier:** Não agradece. É troca. Você volta e termina a fase. *(pausa 0.5 s)*
- `n69` **Alen:** Tá combinado.
- `n70` **Olivier:** Eu fico por aqui. Quase sempre. *(pausa 0.4 s)*
- `n71` **Alen:** Quase?
- `n72` **Olivier:** Depende de quanto o aquecedor estiver a fim. *(grava `c1_biscuit=true`, `c1_oliv_bye=true`)* → *fim*

#### `c1_oliv_before_game`
- `n1` *(narração)* O console faz um clique. A tela pisca e a musiquinha de oito notas recomeça. É uma música feita pra não deixar ninguém desistir. *(pausa 0.4 s)*
- `n2` **Olivier:** Quando eu falo “agora”, você aperta. Mas só depois. *(pausa 0.5 s)*
- `n3` **Alen:** Isso não é uma instrução.
- `n4` **Olivier:** É a única que eu tenho. → *fim*

#### `c1_oliv_after_win_clean`
- `n1` **Olivier:** ...Você nunca jogou isso, né? *(pausa 1.0 s)*
- `n2` **Alen:** Nunca.
- `n3` **Olivier:** Mentiroso. Ninguém passa a fase um sem perder uma vida. Eu perdi doze. *(pausa 0.5 s)*
- `n4` **Alen:** Eu tive sorte.
- `n5` **Olivier:** Sorte não desvia daquele atirador do canto. ...Tá. Foi sorte. Mas sorte com dedos. *(pausa 0.5 s)* → *fim*

#### `c1_oliv_after_win`
- `n1` **Olivier:** Passou. Perdeu vida, mas passou. É o jeito certo: com cicatriz. *(pausa 0.4 s)*
- `n2` **Alen:** Parecia mais fácil de fora.
- `n3` **Olivier:** Tudo parece mais fácil de fora. Anota. É a única lei do universo que eu tenho certeza. *(pausa 0.5 s)* → *fim*

#### `c1_oliv_after_lose`
- `n1` **Olivier:** Três vidas, e a terceira durou menos que a segunda. *(pausa 0.5 s)*
- `n2` **Alen:** Eu avisei que era péssimo.
- `n3` **Olivier:** Você não avisou nada. Tudo bem. Eu perdi doze vezes no primeiro dia. Esse jogo é feito pra isso. *(pausa 0.4 s)*
- `n4` **Alen:** Doze?
- `n5` **Olivier:** Quinze. Fica entre nós. *(pausa 0.4 s)* → *fim*

#### `c1_oliv_after_quit`
- `n1` **Olivier:** Saiu no meio? Sem pena. Mas o jogo não tem pausa. Isso é uma lei. *(pausa 0.5 s)*
- `n2` **Alen:** Tinha cara de que ia me derrotar.
- `n3` **Olivier:** Tem cara de que derrota todo mundo. Isso é o charme. *(pausa 0.4 s)* → *fim*

#### `c1_oliv_boom`
- `n1` *(narração)* Longe, bem longe, algo bate duas vezes. Grave. O vidro da janela mais alta estremece num ruído que a gente aprende a não notar. *(som: boom_far)*
- `n2` *(narração)* Olivier ficou parado. Não é um susto grande. É um tipo de pausa: o corpo inteiro se calando por dentro.
- `n3` *(narração)* Os dedos dele no controle estão brancos nos nós. *(pausa 0.8 s)*
- `n4` **Alen:** ...Olivier?
- `n5` **Olivier:** Tô aqui. Só pensando no próximo movimento. *(pausa 0.6 s)*
- `n6` *(narração)* Ele respira fundo e solta o ar devagar, como quem conta. Depois se vira de novo pra tela, rápido demais.
- `n7` **Alen:**  — *o jogador escolhe:*
    - ▸ “Quer que eu fale de outra coisa?” → `n8`
    - ▸ “(Ficar ao lado dele, em silêncio.)” → `n11`
- `n8` **Olivier:** Fala de qualquer coisa. De tijolo. De sopa. Do seu cachecol. *(pausa 0.6 s)*
- `n9` **Alen:** Foi meu pai que me deu.
- `n10` **Olivier:** É um bom cachecol. *(pausa 0.6 s)* → `n12`
- `n11` *(narração)* Ele não agradece. Mas, depois de um tempo, empurra o pufe uns dois dedos na minha direção.
- `n12` *(narração)* Depois de um tempo, a musiquinha recomeça e a gente volta a ser só dois garotos diante de uma tela azul. *(grava `c1_boom_done=true`, `c1_oliv_trust=true`)* → *fim*

## Volta para casa e encerramento

#### `c1_home_arrive`
- `n1` *(narração)* A casa me recebe com o mesmo cheiro de sempre: remédio velho, lenha, tempo.
- `n2` *(narração)* Mas hoje eu trago uma caixa. A casa percebe. *(pausa 0.6 s)* → *fim*

#### `c1_unpack`
- `n1` *(narração)* Ponho a caixa em cima da mesa da cozinha e desfaço o barbante, nó por nó.
- `n2` *(narração)* Arroz. Feijão. Óleo. Leite em pó. Um saquinho de açúcar mascavo, que tem cheiro de infância.
- `n3` *(narração)* Tudo alinhado em cima da mesa, como um pequeno exército que chegou a tempo.
- `n4` **SE** `c1_peach` → `n5` · **SENÃO** → `n6`
- `n5` *(narração)* E, no fundo, a lata de pêssego em calda da Dona Helena. O rótulo tem uma mancha de umidade em forma de continente.
- `n6` **SE** `c1_roll` → `n7` · **SENÃO** → `n8`
- `n7` *(narração)* Do bolso da jaqueta, o pão da Dona Íris. Está frio agora, mas o cheiro ainda está inteiro, e é o cheiro que enche a cozinha primeiro.
- `n8` *(narração)* Dá três dias, talvez quatro, se a gente for firme. É mais do que a casa tinha de manhã. *(pausa 0.5 s; grava `c1_unpacked=true`)* → *fim*

#### `c1_mae_ret`
- `n1` **Mãe:** Chegou. *(pausa 0.6 s)*
- `n2` *(narração)* Ela me olha de cima a baixo, como quem confere se eu voltei com todas as partes. Depois olha a mesa.
- `n3` **Mãe:** Arroz. Feijão. Açúcar mascavo? Você foi na biblioteca ou numa feira de domingo? *(pausa 0.4 s)*
- `n4` **Alen:** A Dona Helena disse que o sal acabou. Que a senhora ia achar o gosto curioso. *(pausa 0.3 s)*
- `n5` **Mãe:** Curioso é o que eu preciso. *(pausa 0.6 s)*
- `n6` **SE** `c1_peach` → `n7` · **SENÃO** → `n14`
- `n7` *(narração)* Ela pega a lata de pêssego em calda e a segura contra a luz, como se o rótulo fosse uma carta.
- `n8` **Mãe:** Pêssego. Eu não via pêssego desde antes de tudo isso. *(pausa 0.8 s)*
- `n9` **Alen:** A Dona Helena guardou pra quando alguém merecesse.
- `n10` **Mãe:** E você merecia? *(pausa 0.5 s)*
- `n11` **Alen:** Eu só carreguei o saco de pão.
- `n12` **Mãe:** A gente nunca sabe quando uma coisa pequena é grande. *(pausa 0.5 s)*
- `n13` *(narração)* Ela diz a mesma frase que a Dona Helena. Acho que as duas aprenderam em lugares diferentes e chegaram à mesma conclusão.
- `n14` **SE** `c1_roll` → `n15` · **SENÃO** → `n18`
- `n15` *(narração)* Eu tiro o pão frio do bolso e coloco na mão dela.
- `n16` **Mãe:** Pão. De verdade. Que cheiro... *(pausa 0.5 s)*
- `n17` *(narração)* Ela parte um pedaço pequeno e põe na boca, de olhos fechados. Um segundo que eu não esqueço. *(pausa 0.8 s)*
- `n18` **SE** `c1_biscuit` → `n19` · **SENÃO** → `n27`
- `n19` *(narração)* Eu tiro do bolso a metade da barra de cereal.
- `n20` **Alen:** Esta é pra senhora.
- `n21` **Mãe:** Quem te deu?
- `n22` **Alen:** Um garoto lá. Olivier. *(pausa 0.4 s)*
- `n23` **Mãe:** Olivier. É um nome bonito. *(pausa 0.5 s)*
- `n24` **Alen:** É só um garoto, mãe.
- `n25` **Mãe:** Eu não disse que era mais que isso. *(pausa 0.6 s)*
- `n26` *(narração)* Ela ri. É uma risada pequena, que vem da mesma gaveta que o pêssego.
- `n27` **Mãe:** Obrigada, filho. Por voltar. Por voltar antes de escurecer. *(pausa 0.6 s; grava `c1_mae_ret_done=true`)* → *fim*

#### `c1_pai_ret`
- `n1` **Pai:** Chegou inteiro. Isso eu já considero metade da missão. *(pausa 0.5 s)*
- `n2` **Alen:** A outra metade está na mesa.
- `n3` **Pai:** Eu sei. Estou sentindo o cheiro. *(pausa 0.6 s)*
- `n4` **SE** `c1_item` = `book` → `n5` · **SENÃO** → `n11`
- `n5` *(narração)* Eu tiro o livro de dentro da jaqueta. Ele fica um tempo sem se mexer, como se o livro soubesse que estava voltando pra casa.
- `n6` **Pai:** Você achou. “Contos de Outros Mundos”. Eu tinha certeza que tinham levado. *(pausa 0.5 s)*
- `n7` **Alen:** Estava na prateleira. A ficha tem três nomes. O terceiro é o senhor.
- `n8` **Pai:** Eu sei. Eu escrevi com a letra de domingo. *(pausa 0.7 s)*
- `n9` *(narração)* Ele passa o polegar pela lombada, devagar, como quem confere uma cicatriz.
- `n10` **Pai:** Obrigado, Alen. Eu estava devendo isso a mim mesmo. *(pausa 0.5 s)* → `n19`
- `n11` **SE** `c1_item` = `guitar` → `n12` · **SENÃO** → `n16`
- `n12` **Pai:** E o livro? Dos contos?
- `n13` **Alen:**  — *o jogador escolhe:*
    - ▸ “Estava lá. Mas eu levei outra coisa. Vou buscar.” → `n14` *(só se `c1_found_book`)*
    - ▸ “Não deu tempo de olhar.” → `n15`
- `n14` **Pai:** Então busca. Livro é mais paciente que gente. *(pausa 0.4 s)* → `n19`
- `n15` **Pai:** Tudo bem. Ele espera. *(pausa 0.5 s)* → `n19`
- `n16` **Pai:** E o livro dos contos? Não precisa ser hoje. Só pra eu saber que ele existe. *(pausa 0.4 s)*
- `n17` **Alen:** Se ele existir, eu trago.
- `n18` **Pai:** É bom o suficiente.
- `n19` **SE** `c1_roll` → `n20` · **SENÃO** → `n23`
- `n20` **Pai:** Isso é pão? *(pausa 0.6 s)*
- `n21` **Alen:** Da Dona Íris. Uma regra da casa. *(pausa 0.3 s)*
- `n22` **Pai:** Regra boa. O cheiro entra antes da palavra. *(pausa 0.4 s)*
- `n23` **Pai:** Alen. Eu sei que ninguém te perguntou se você queria fazer isto. Mesmo assim, você foi. *(pausa 0.5 s)*
- `n24` **Alen:** Eu só fui lá.
- `n25` **Pai:** Pois é. O mundo mede diferente do que a gente mede. *(pausa 0.6 s; grava `c1_pai_ret_done=true`)* → *fim*

#### `c1_cozinha_nao`
- `n1` *(narração)* Antes do quarto, a caixa tem que chegar na cozinha. A casa inteira está esperando por ela. → *fim*

#### `c1_bed_cedo`
- `n1` *(narração)* Não ainda. Eu volto pra casa pra ficar com a casa. O quarto espera. → *fim*

#### `c1_bed_pronto`
- `n1` *(narração)* A casa está quieta do jeito que ela fica depois que todo mundo comeu. Cheia, de um jeito silencioso. *(pausa 0.6 s)*
- `n2` *(narração)* É a hora. Subo para o quarto. *(pausa 0.4 s)* → *fim*

#### `c1_night_guitar`
- `n1` *(narração)* Oito da noite. A luz volta com um estalo, como sempre, e a casa inteira se endireita.
- `n2` *(narração)* O computador de tubo demora um minuto pra acordar. Eu coloco o CD na bandeja, que gira, tosse e aceita.
- `n3` *(narração)* “GUITAR LEGENDS — Another Concept.” A tela escurece, depois acende em vermelho e dourado. Uma música de guitarra, meio tosca, meio linda, sai do alto-falante pequeno.
- `n4` *(narração)* A guitarra de verdade está encostada na parede, ao meu lado. Parada há muito tempo. Eu ainda não encosto. *(pausa 0.6 s)*
- `n5` *(narração)* Na tela, as notas descem em colunas. Verde, vermelho, amarelo. Não tenho o adaptador, mas tenho os dedos, e os dedos lembram de coisas que a cabeça esqueceu.
- `n6` *(narração)* Toco três notas no ar. Depois três no braço da cadeira. Depois três na guitarra de verdade, sem amplificador, tão baixo que só eu ouço. *(pausa 0.5 s)*
- `n7` *(narração)* Do outro lado da parede, o meu pai para de virar a página.
- `n8` **Pai:** Continua. Eu estava esquecendo como era. *(pausa 0.5 s)* → *fim*

#### `c1_night_book`
- `n1` *(narração)* Oito da noite. A luz volta com um estalo, e a casa se endireita.
- `n2` *(narração)* Deixo a porta do quarto aberta, porque o meu pai pediu sem pedir. Pego o livro dele e leio o primeiro conto em voz baixa, só pra mim. Mas a voz sai mais alta do que eu planejei.
- `n3` *(narração)* “Na terceira lua de Kepler, um menino desenhava mapas de lugares que ainda não existiam.
- `n4` *(narração)* — Pra quê? — perguntou o robô.
- `n5` *(narração)* — Pra que alguém tenha pra onde ir, quando precisar.”
- `n6` **Pai:** Mais uma página. *(pausa 0.8 s)*
- `n7` *(narração)* Eu leio mais uma. E mais uma. Depois a voz dele deixa de responder, e eu continuo lendo mais baixo, para o escuro. *(pausa 0.4 s)* → *fim*

#### `c1_night_none`
- `n1` *(narração)* Oito da noite. A luz volta com um estalo, e a casa se endireita.
- `n2` *(narração)* Eu não trouxe nada. Mas dentro da cabeça eu tenho uma nave azul, uma música de oito notas e um garoto de cachecol laranja dizendo “respira, é feio ver gente azul.”
- `n3` *(narração)* Cantarolo a musiquinha, bem baixo. Erro a quinta nota. Volto e acerto.
- `n4` *(narração)* Do outro lado da parede, alguém ri. Baixinho, no escuro. Não sei se foi a minha mãe ou o meu pai. *(pausa 0.4 s)* → *fim*

#### `c1_night_window`
- `n1` *(narração)* Deito. A casa respira devagar. Lá fora, a neve continua a cair sobre Declan City, do jeito silencioso que ela cai. *(pausa 0.6 s)*
- `n2` *(narração)* De vez em quando, bem longe, algo bate duas vezes. Grave. A janela estremece e para. *(som: boom_far)*
- `n3` *(narração)* Nada mudou, na verdade. A estrada do Moinho continua fechada. A lista continua curta. O remédio continua sem data.
- `n4` *(narração)* Mas hoje eu descobri uma coisa pequena: existe um lugar onde alguém deixou a luz acesa e o mundo ligado. E existe um garoto de cachecol laranja que ainda não terminou a fase. *(pausa 0.8 s)*
- `n5` *(narração)* Levanto e desenho uma nave no vidro embaçado, com o dedo. Asas, uma cauda, uma fileira de estrelas no alto. Ela dura uns dois minutos. É o bastante. *(pausa 0.5 s)*
- `n6` *(narração)* Amanhã a lista tem uma palavra a mais.
- `n7` *(narração)* Biblioteca. *(pausa 1.2 s)* → *fim*

#### `c1_pai_final`
- `n1` **Pai:** Vai descansar. Amanhã a gente vê o que o dia pede. *(pausa 0.5 s)* → *fim*

#### `c1_mae_final`
- `n1` **Mãe:** Boa noite, filho. Hoje a casa está cheia. Dá pra sentir pelo cheiro. *(pausa 0.5 s)* → *fim*

#### `c1_door_back`
- `n1` *(narração)* Lá fora já escureceu, e a luz está pra voltar. A rua fica estranha quando escurece; a mãe tinha razão.
- `n2` *(narração)* Amanhã eu volto lá. Hoje a casa precisa de mim inteira. → *fim*
