extends Node
## Capturas para conferir o "preencher a tela" em várias proporções:  godot --path . res://tests/shots_fit.tscn
const OUT := "/tmp/fit/"
const DemoEnd := preload("res://scripts/ui/demo_end.gd")
const ChapterCard := preload("res://scripts/ui/chapter_card.gd")


func wait(s: float) -> void:
    await get_tree().create_timer(s).timeout


func shot(name: String) -> void:
    await RenderingServer.frame_post_draw
    get_viewport().get_texture().get_image().save_png(OUT + name + ".png")


func _ready() -> void:
    DirAccess.make_dir_recursive_absolute(OUT)
    GameSettings.fill_screen = true
    GameSettings.pixel_integer = false
    GameSettings.apply_scaling()
    GameSettings.set_menu_aspect(false)
    await wait(0.4)
    print("janela=", get_window().size, " visível=", get_viewport().get_visible_rect().size, " aspecto=", get_window().content_scale_aspect)
    TouchControls.touch_mode = true
    var keys: Array = GameState.SCENES.keys()
    for key in keys:
        GameState.new_game(1)
        GameState.set_flag("prologue_done", true)
        GameState.set_flag("planted", true)
        GameState.start_chapter1()
        var lvl: Node = load(GameState.SCENES[key]).instantiate()
        add_child(lvl)
        var g := 0
        while SceneRouter.is_busy() and g < 400:
            await wait(0.05)
            g += 1
        await wait(0.6)
        await shot("%s_a" % key)
        var wr: Rect2 = lvl.world_rect
        if wr.size.x > 900.0 and lvl.player != null:
            lvl.player.global_position.x = wr.end.x - 60.0
            await wait(0.8)
            await shot("%s_b" % key)
        lvl.queue_free()
        await wait(0.3)
    # menu principal e configurações
    GameSettings.set_menu_aspect(true)
    var menu: Node = load("res://scenes/main_menu/main_menu.tscn").instantiate()
    add_child(menu)
    await wait(7.0)
    await shot("zz_menu")
    menu.queue_free()
    await wait(0.3)
    GameSettings.set_menu_aspect(false)
    # sobreposições dentro de uma fase
    GameState.new_game(1)
    GameState.start_chapter1()
    var lv: Node = load(GameState.SCENES["centro"]).instantiate()
    add_child(lv)
    var g2 := 0
    while SceneRouter.is_busy() and g2 < 400:
        await wait(0.05)
        g2 += 1
    for n in get_tree().get_nodes_in_group("interactable"):
        n.queue_free()
    Dialogue.play("c1_book_contos")
    await wait(2.2)
    await shot("zz_dialogo")
    for i in 8:
        var e := InputEventAction.new()
        e.action = "interact"
        e.pressed = true
        Input.parse_input_event(e)
        await wait(0.2)
        var e2 := InputEventAction.new()
        e2.action = "interact"
        e2.pressed = false
        Input.parse_input_event(e2)
        await wait(0.3)
    lv.player.controls_enabled = true
    lv._pause.open()
    await wait(0.8)
    await shot("zz_pausa")
    lv._pause.close()
    var fin := [false]
    var run := func():
        await DemoEnd.show_panel(self)
        fin[0] = true
    run.call()
    await wait(2.4)
    await shot("zz_fim_demo")
    print("FIM DAS CAPTURAS")
    get_tree().quit()
