extends Node
## Tira capturas dos controles de toque (precisa de janela/OpenGL):  godot --path . res://tests/shots.tscn
const OUT := "/tmp/shots/"


func shot(name: String) -> void:
    await RenderingServer.frame_post_draw
    get_viewport().get_texture().get_image().save_png(OUT + name + ".png")
    print("captura ", name)


func wait(s: float) -> void:
    await get_tree().create_timer(s).timeout


## Os toques reais chegam em pixels da JANELA; a Godot converte para as coordenadas do jogo (640x360). Aqui fazemos o caminho inverso.
func to_window(p: Vector2) -> Vector2:
    return get_viewport().get_final_transform() * p


func touch(idx: int, pos: Vector2, down: bool) -> void:
    var e := InputEventScreenTouch.new()
    e.index = idx
    e.position = to_window(pos)
    e.pressed = down
    Input.parse_input_event(e)


func drag(idx: int, pos: Vector2) -> void:
    var e := InputEventScreenDrag.new()
    e.index = idx
    e.position = to_window(pos)
    Input.parse_input_event(e)


func _ready() -> void:
    await wait(0.5)
    GameState.new_game(1)
    GameState.set_flag("prologue_done", true)
    GameState.set_flag("planted", true)
    GameState.start_chapter1()
    var lvl: Node = load(GameState.SCENES["centro"]).instantiate()
    add_child(lvl)
    var guard := 0
    while SceneRouter.is_busy() and guard < 900:
        await wait(0.05)
        guard += 1
    for n in get_tree().get_nodes_in_group("interactable"):
        n.queue_free()
    TouchControls.touch_mode = true
    await wait(0.6)
    await shot("1_parado")
    # joystick segurado para a direita + correr ligado
    touch(0, Vector2(90, 280), true)
    drag(0, Vector2(125, 270))
    touch(2, TouchControls.run_center(), true)
    touch(2, TouchControls.run_center(), false)
    touch(1, TouchControls.act_center(), true)
    await wait(0.5)
    await shot("2_em_uso")
    touch(0, Vector2(125, 270), false)
    touch(1, TouchControls.act_center(), false)
    await wait(0.4)
    # diálogo: só o botão E
    Dialogue.play("c1_book_contos")
    await wait(2.0)
    await shot("3_dialogo")
    print("FIM DAS CAPTURAS")
    get_tree().quit()
