extends Node
## Simula toques e confere se viram as ações do jogo:  godot --headless --path . res://tests/touch_test.tscn
var fails: Array = []


func check(ok: bool, msg: String) -> void:
    print(("  ok   " if ok else "  FALHA ") + msg)
    if not ok:
        fails.append(msg)


func ms(t: int) -> void:
    await get_tree().create_timer(t / 1000.0).timeout


func frames(n: int) -> void:
    for i in n:
        await get_tree().process_frame


func touch(idx: int, pos: Vector2, down: bool) -> void:
    var e := InputEventScreenTouch.new()
    e.index = idx
    e.position = pos
    e.pressed = down
    Input.parse_input_event(e)


func drag(idx: int, pos: Vector2) -> void:
    var e := InputEventScreenDrag.new()
    e.index = idx
    e.position = pos
    Input.parse_input_event(e)


func _ready() -> void:
    await frames(2)
    GameState.new_game(1)
    GameState.set_flag("prologue_done", true)
    GameState.set_flag("planted", true)
    GameState.start_chapter1()
    var lvl: Node = load(GameState.SCENES["centro"]).instantiate()
    add_child(lvl)
    await frames(30)
    var waited := 0
    while SceneRouter.is_busy() and waited < 600:
        await frames(1)
        waited += 1
    var player = get_tree().get_first_node_in_group("player")
    check(player != null, "fase tem jogador")
    player.controls_enabled = true
    var T = TouchControls
    # PC sem toque: controles desligados; tecla não liga
    check(not T.touch_mode, "no PC os controles começam desligados")
    touch(5, Vector2(300, 100), true)
    touch(5, Vector2(300, 100), false)
    await frames(3)
    check(T.touch_mode, "primeiro toque liga os controles")
    var vp := Vector2(640, 360)
    # --- joystick
    var p0: Vector2 = player.global_position
    touch(0, Vector2(100, 280), true)
    drag(0, Vector2(145, 280))
    await frames(20)
    check(Input.is_action_pressed("move_right") and not Input.is_action_pressed("move_left"), "joystick para a direita")
    check(player.global_position.x > p0.x + 3.0, "o jogador andou para a direita")
    drag(0, Vector2(100, 232))
    await frames(3)
    check(Input.is_action_pressed("move_up") and not Input.is_action_pressed("move_right"), "joystick para cima")
    drag(0, Vector2(60, 320))
    await frames(3)
    check(Input.is_action_pressed("move_left") and Input.is_action_pressed("move_down"), "joystick na diagonal (baixo-esquerda)")
    touch(0, Vector2(60, 320), false)
    await frames(3)
    check(not (Input.is_action_pressed("move_left") or Input.is_action_pressed("move_down") or Input.is_action_pressed("move_up") or Input.is_action_pressed("move_right")), "soltar o joystick solta tudo")
    # sem objetos interativos por perto: apertar E aqui não deve abrir diálogo
    for n in get_tree().get_nodes_in_group("interactable"):
        n.queue_free()
    await frames(5)
    check(not Dialogue.active, "nenhum diálogo aberto antes dos testes de botão")
    # --- botão E (interagir)
    touch(1, T.act_center(), true)
    await frames(2)
    check(Input.is_action_pressed("interact"), "botão E pressiona 'interact'")
    touch(1, T.act_center(), false)
    await ms(150)
    check(not Input.is_action_pressed("interact"), "soltar o botão E solta 'interact'")
    # toque curtíssimo (mesmo quadro) ainda registra
    touch(1, T.act_center(), true)
    touch(1, T.act_center(), false)
    await ms(30)
    check(Input.is_action_pressed("interact"), "toque instantâneo fica pressionado por alguns quadros")
    await ms(150)
    check(not Input.is_action_pressed("interact"), "...e depois solta sozinho")
    # --- correr (liga/desliga)
    touch(2, T.run_center(), true)
    touch(2, T.run_center(), false)
    await ms(60)
    check(Input.is_action_pressed("run"), "CORRER liga")
    touch(2, T.run_center(), true)
    touch(2, T.run_center(), false)
    await ms(60)
    check(not Input.is_action_pressed("run"), "CORRER desliga")
    # --- pausa
    touch(3, T.pause_center(), true)
    touch(3, T.pause_center(), false)
    await ms(200)
    check(get_tree().paused, "botão de pausa abre o menu de pausa")
    check(not T._show.stick and not T._show.act, "controles somem enquanto pausado")
    lvl._pause.close()
    await frames(3)
    # --- diálogo: um toque avança UMA fala (sem pular a animação da próxima)
    Dialogue.play("c1_book_contos")
    await frames(5)
    check(Dialogue.active, "diálogo começou")
    check(not T._show.act and not T._show.stick and not T._show.pause, "no diálogo os botões somem (tocar em qualquer lugar avança)")
    var guard := 0
    while not Dialogue._waiting and guard < 600:
        await frames(1)
        guard += 1
    check(Dialogue._waiting, "primeira fala terminou de aparecer")
    await get_tree().create_timer(0.25).timeout
    touch(4, Vector2(320, 300), true)
    await frames(2)
    touch(4, Vector2(320, 300), false)
    check(Dialogue._typing and Dialogue._text.get_parsed_text().begins_with("Abro. A primeira"), "um toque avança exatamente uma fala (a 2ª começa a ser escrita, sem pular a animação)")
    # --- espera por "E" sem controle do jogador (plantar no jardim): o botão E precisa aparecer
    lvl.queue_free()
    await frames(3)
    var gl: Node = load(GameState.SCENES["garden"]).instantiate()
    add_child(gl)
    var w2 := 0
    while SceneRouter.is_busy() and w2 < 600:
        await frames(1)
        w2 += 1
    var gp = get_tree().get_first_node_in_group("player")
    T.touch_mode = true
    var tapped := 0
    while Dialogue.active and tapped < 60:       # o jardim abre com um diálogo: avança tocando, como o jogador
        touch(8, Vector2(320, 200), true)
        touch(8, Vector2(320, 200), false)
        await ms(450)
        tapped += 1
    check(not Dialogue.active, "diálogo de entrada do jardim termina só com toques (%d toques)" % tapped)
    gp.controls_enabled = false
    var done := [false]
    var waiter := func():
        await gl.wait_press()
        done[0] = true
    waiter.call()
    await ms(500)
    check(T._show.act and not T._show.stick and not T._show.pause, "esperando E sem controle: só o botão E aparece")
    touch(6, T.act_center(), true)
    touch(6, T.act_center(), false)
    await ms(300)
    check(done[0], "tocar no botão E continua a cena de plantar")
    done[0] = false
    waiter.call()
    await ms(500)
    touch(7, Vector2(300, 120), true)
    touch(7, Vector2(300, 120), false)
    await ms(300)
    check(done[0], "tocar em qualquer lugar também continua a cena de plantar")
    await ms(200)
    check(not T._show.act, "depois da espera os botões somem de novo (cena sem controle)")
    gl.queue_free()
    await frames(3)
    # --- a sequência COMPLETA de plantar (prólogo, jardim), jogada só com toques
    GameState.new_game(1)
    GameState.set_flag("has_seed", true)
    GameState.set_flag("eleanor_ok", true)
    var gl2: Node = load(GameState.SCENES["garden"]).instantiate()
    add_child(gl2)
    var w3 := 0
    while SceneRouter.is_busy() and w3 < 600:
        await frames(1)
        w3 += 1
    T.touch_mode = true
    var t2 := 0
    while Dialogue.active and t2 < 60:
        touch(9, Vector2(320, 200), true)
        touch(9, Vector2(320, 200), false)
        await ms(450)
        t2 += 1
    var runner := func():
        await gl2._plant_sequence()
    runner.call()
    var e_taps := 0
    var d_taps := 0
    var guard2 := 0
    while not GameState.get_flag("planted", false) and guard2 < 300:
        if Dialogue.active:
            touch(10, Vector2(320, 200), true)
            touch(10, Vector2(320, 200), false)
            d_taps += 1
        elif T._show.act:
            touch(10, T.act_center(), true)
            touch(10, T.act_center(), false)
            e_taps += 1
        await ms(350)
        guard2 += 1
    check(GameState.get_flag("planted", false), "plantar do começo ao fim só com toques (%d no E, %d em diálogos)" % [e_taps, d_taps])
    check(e_taps >= 6, "foram necessários 6 toques no E (cavar x3, semente, cobrir x2)")
    gl2.queue_free()
    await frames(3)
    # --- teclado desliga os controles no PC
    var k := InputEventKey.new()
    k.keycode = KEY_E
    k.pressed = true
    Input.parse_input_event(k)
    await frames(2)
    check(not T.touch_mode, "usar o teclado desliga os controles no PC")
    print("TOUCH ", "OK" if fails.is_empty() else "FALHOU: " + str(fails))
    get_tree().quit(0 if fails.is_empty() else 1)
