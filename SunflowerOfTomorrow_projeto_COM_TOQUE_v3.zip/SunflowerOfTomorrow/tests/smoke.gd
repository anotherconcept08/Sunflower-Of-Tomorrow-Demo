extends Node
## Teste de fumaça (rodar sem janela):  godot --headless --path . res://tests/smoke.tscn
## Confere: diálogos carregados, todas as fases abrem, salvar/carregar, tela de fim de demo e dica de controles.
const DemoEnd := preload("res://scripts/ui/demo_end.gd")
const ControlsHint := preload("res://scripts/ui/controls_hint.gd")
const DemoInfo := preload("res://scripts/core/demo_info.gd")

var fails: Array = []


func check(ok: bool, msg: String) -> void:
    if ok:
        print("  ok   ", msg)
    else:
        print("  FALHA ", msg)
        fails.append(msg)


func _ready() -> void:
    await get_tree().process_frame
    await _run()
    print("SMOKE ", "OK" if fails.is_empty() else "FALHOU: " + str(fails))
    get_tree().quit(0 if fails.is_empty() else 1)


func _run() -> void:
    print("versão: ", DemoInfo.LABEL, "  | build de depuração: ", OS.is_debug_build())
    # 1) diálogos (lidos de res://data/dialogue/*.json; na versão exportada isso prova que os JSON foram empacotados)
    var db: Dictionary = Dialogue._db
    check(db.size() >= 292, "diálogos carregados (%d)" % db.size())
    for id in ["c1_bed_pronto", "c1_night_window", "table_1"]:
        check(db.has(id), "diálogo '%s' existe" % id)
    var n1: Dictionary = db["c1_nina_1"]["nodes"]["n1"] if db.has("c1_nina_1") else {}
    check(str(n1.get("text", "")).contains("Bem-vindo! Isso"), "frases com espaço depois da pausa")
    check(FileAccess.file_exists("res://data/creditos.json"), "creditos.json empacotado")
    # 2) todas as fases
    for key in GameState.SCENES.keys():
        GameState.new_game(1)
        GameState.set_flag("prologue_done", true)
        GameState.set_flag("planted", true)
        GameState.start_chapter1()
        var ps = load(GameState.SCENES[key])
        if ps == null:
            check(false, "fase '%s' carrega" % key)
            continue
        var inst: Node = ps.instantiate()
        add_child(inst)
        for i in 25:
            await get_tree().process_frame
        check(is_instance_valid(inst), "fase '%s' roda 25 quadros" % key)
        inst.queue_free()
        await get_tree().process_frame
    # 3) salvar / carregar
    GameState.new_game(3)
    GameState.set_flag("teste_x", 5)
    check(GameState.save_game(), "salvar no espaço 3")
    GameState.flags = {}
    check(GameState.load_slot(3) and int(GameState.get_flag("teste_x", 0)) == 5, "carregar devolve as flags")
    var raw := FileAccess.get_file_as_string("user://saves/slot_3.json") if FileAccess.file_exists("user://saves/slot_3.json") else ""
    check(raw.contains("game_version"), "save guarda a versão da demo")
    GameState.delete_slot(3)
    # 4) dica de controles (só aparece uma vez)
    GameState.new_game(1)
    ControlsHint.show_once(self, 0.2)
    check(GameState.get_flag("seen_controls", false), "dica de controles marcada como vista")
    # 5) tela de fim de demo
    GameState.playtime = 3725.0
    var finished := [false]
    var runner := func():
        await DemoEnd.show_panel(self)
        finished[0] = true
    runner.call()
    for i in 200:
        await get_tree().process_frame
    var btn := _find_button(get_tree().root, "VOLTAR AO MENU")
    check(btn != null, "tela de fim de demo mostra VOLTAR AO MENU")
    if btn != null:
        btn.pressed.emit()
        for i in 5:
            await get_tree().process_frame
    check(finished[0], "tela de fim de demo termina ao escolher voltar")


func _find_button(n: Node, text: String) -> Button:
    if n is Button and (n as Button).text == text:
        return n
    for c in n.get_children():
        var r := _find_button(c, text)
        if r != null:
            return r
    return null
