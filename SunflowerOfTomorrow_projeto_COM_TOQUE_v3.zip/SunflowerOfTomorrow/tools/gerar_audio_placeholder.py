"""Gera sons PLACEHOLDER (ruído filtrado/síntese simples) para o projeto.
Substitua os arquivos em assets/audio/ por gravações/sons reais mantendo os mesmos nomes.
Uso: python3 tools/gerar_audio_placeholder.py   (requer numpy e ffmpeg)"""
import numpy as np, wave, os, subprocess, tempfile
SR = 44100
rng = np.random.default_rng(7)
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "assets", "audio")

def noise(sec): return rng.standard_normal(int(sec * SR)).astype(np.float64)
def band(x, lo=None, hi=None, order=4):
    X = np.fft.rfft(x); f = np.fft.rfftfreq(len(x), 1 / SR); H = np.ones_like(f)
    if hi: H = H / np.sqrt(1 + (f / hi) ** (2 * order))
    if lo: H = H / np.sqrt(1 + (lo / np.maximum(f, 1e-3)) ** (2 * order))
    return np.fft.irfft(X * H, len(x))
def norm(x, peak=0.8): return x / (np.max(np.abs(x)) + 1e-9) * peak
def env(n, attack, decay, power=1.0):
    t = np.arange(n) / SR; a = np.minimum(1, t / max(attack, 1e-4)); return a * np.exp(-t / decay) ** power
def slow(sec, hz):                      # modulador suave 0..1
    m = band(noise(sec), None, hz, 2); m = (m - m.min()) / (m.max() - m.min() + 1e-9); return m
def make_loop(x, xf_sec=1.5):
    n = int(xf_sec * SR); out = x[:-n].copy(); t = np.linspace(0, 1, n)
    out[:n] = out[:n] * np.sin(t * np.pi / 2) + x[-n:] * np.cos(t * np.pi / 2); return out
def wav(path, x):
    x = np.clip(x, -1, 1); d = (x * 32767).astype(np.int16)
    with wave.open(path, "wb") as w: w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes(d.tobytes())
def sfx(name, x): wav(os.path.join(ROOT, "sfx", name + ".wav"), x)
def amb(name, x):
    tmp = tempfile.mktemp(suffix=".wav"); wav(tmp, x)
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", tmp, "-c:a", "libvorbis", "-q:a", "4", os.path.join(ROOT, "ambience", name + ".ogg")], check=True); os.remove(tmp)

# ---------- AMBIENTES (loops sem emenda) ----------
L = 14
n = noise(L + 1.5); t = np.arange(len(n)) / SR
room = band(n, 25, 160) * 1.0 + band(noise(L + 1.5), 500, 900) * (0.05 + 0.10 * slow(L + 1.5, 0.25)) + band(noise(L + 1.5), 2000, 4000) * 0.01
amb("bedroom_room_tone", norm(make_loop(room), 0.35))
g = 0.25 + 0.75 * slow(L + 1.5, 0.35)
town = band(noise(L + 1.5), 90, 1100) * g + band(noise(L + 1.5), 2500, 6000) * 0.05 * g
amb("town_wind", norm(make_loop(town), 0.55))
g2 = 0.2 + 0.8 * slow(L + 1.5, 0.4)
leaves = np.zeros(len(g2))
for _ in range(int(2.2 * (L + 1.5))):
    s = rng.integers(0, len(leaves) - SR // 3); m = int(rng.uniform(0.04, 0.16) * SR)
    leaves[s:s + m] += band(rng.standard_normal(m), 2500, 7500) * env(m, 0.01, 0.05) * rng.uniform(0.2, 0.6)
garden = band(noise(L + 1.5), 120, 2200) * g2 * 1.2 + leaves * 0.35
amb("garden_wind", norm(make_loop(garden), 0.6))
Lr = 10; nn = Lr + 1.5
speech = sum(band(noise(nn), f, f * 1.6) * (0.2 + slow(nn, 5 + i)) for i, f in enumerate([450, 1300, 2400]))
speech = band(speech, 250, 3400) * (0.3 + slow(nn, 3.5))
amb("src_radio", norm(make_loop(speech), 0.5))
Lc = 8; c = np.zeros(int((Lc + 1.5) * SR))
for _ in range(int(14 * (Lc + 1.5))):
    s = rng.integers(0, len(c) - 2000); m = int(rng.uniform(0.002, 0.012) * SR); c[s:s + m] += rng.standard_normal(m) * rng.uniform(0.1, 1.0) * env(m, 0.0005, 0.003)
c = band(c, 900, 6500) + band(noise(Lc + 1.5), 40, 180) * 0.15
amb("src_crackle", norm(make_loop(c), 0.5))

# ---------- EFEITOS ----------
def tick(freq, dur=0.05, amt=0.6):
    m = int(dur * SR); tt = np.arange(m) / SR
    return (np.sin(2 * np.pi * freq * tt) * 0.5 + band(noise(dur), 1500, 5000) * amt) * env(m, 0.001, dur / 4)
sfx("ui_move", norm(tick(740, 0.045, 0.4), 0.35))
sfx("ui_select", norm(np.concatenate([tick(520, 0.06, 0.3), tick(660, 0.09, 0.2)]), 0.4))
sfx("ui_back", norm(tick(440, 0.07, 0.3), 0.35))
sfx("text_blip", norm(tick(620, 0.02, 0.1), 0.25))
# porta: rangido + trinco
m = int(0.9 * SR); tt = np.arange(m) / SR; f = 170 + 110 * (tt / 0.9) ** 1.5 + 6 * np.sin(2 * np.pi * 23 * tt)
creak = np.sin(2 * np.pi * np.cumsum(f) / SR) + 0.5 * np.sin(4 * np.pi * np.cumsum(f) / SR) + band(noise(0.9), 600, 2500) * 0.6
creak = creak * np.sin(np.pi * tt / 0.9) ** 0.7 * (0.5 + 0.5 * slow(0.9, 14))
click = band(noise(0.04), 1500, 6000) * env(int(0.04 * SR), 0.0005, 0.008); thud = band(noise(0.25), 40, 220) * env(int(0.25 * SR), 0.002, 0.06)
door = np.concatenate([click, np.zeros(int(0.05 * SR)), creak * 0.5, thud * 0.8])
sfx("door_open", norm(door, 0.7))
sfx("door_close", norm(np.concatenate([thud * 1.2, click * 0.4]), 0.7))
p = band(noise(0.5), 1800, 7000) * (0.3 + slow(0.5, 28)) * env(int(0.5 * SR), 0.01, 0.25)
sfx("paper", norm(p, 0.4))
sfx("cloth", norm(band(noise(0.6), 350, 2200) * np.sin(np.pi * np.arange(int(0.6 * SR)) / (0.6 * SR)) ** 1.5, 0.4))
sfx("water", norm(band(noise(1.0), 1200, 5500) * (0.3 + slow(1.0, 22)) * np.sin(np.pi * np.arange(int(1.0 * SR)) / SR) ** 0.6, 0.45))
m = int(0.6 * SR); tt = np.arange(m) / SR
sfx("wood_creak", norm(sum(np.sin(2 * np.pi * (95 - 25 * tt) * k * tt) / k for k in (1, 2, 3)) * env(m, 0.03, 0.2) + band(noise(0.6), 200, 900) * 0.3 * env(m, 0.02, 0.15), 0.35))
for i in range(3):
    d = int(0.13 * SR); sfx(f"step_wood_{i+1}", norm(band(noise(0.13), 90 + 30 * i, 800 + 150 * i) * env(d, 0.002, 0.03) + band(noise(0.13), 1500, 4000) * 0.15 * env(d, 0.0005, 0.006), 0.5))
    d = int(0.2 * SR); sfx(f"step_snow_{i+1}", norm(band(noise(0.2), 700, 3800 + 300 * i) * (0.4 + 0.6 * (rng.random(d) > 0.55)) * env(d, 0.004, 0.06), 0.5))
    d = int(0.15 * SR); sfx(f"step_dirt_{i+1}", norm(band(noise(0.15), 150, 1400 + 200 * i) * env(d, 0.004, 0.04), 0.45))
d = int(0.5 * SR); dig = band(noise(0.5), 150, 2500) * env(d, 0.01, 0.12) * (0.4 + 0.6 * slow(0.5, 30)) + band(noise(0.5), 40, 200) * env(d, 0.004, 0.05) * 0.8
sfx("dig", norm(dig, 0.55))
sfx("seed_drop", norm(np.concatenate([tick(1250, 0.03, 0.8), np.zeros(int(0.05 * SR)), tick(980, 0.02, 0.6) * 0.5]), 0.35))
d = int(6 * SR); tt = np.arange(d) / SR; car = band(noise(6), 80, 700) * np.exp(-((tt - 3) / 1.1) ** 2) + np.sin(2 * np.pi * np.cumsum(95 - 12 * np.tanh((tt - 3) / 0.8)) / SR) * 0.25 * np.exp(-((tt - 3) / 1.3) ** 2)
sfx("car_pass", norm(car, 0.35))
d = int(0.5 * SR); sfx("far_door", norm(band(noise(0.5), 45, 220) * env(d, 0.002, 0.08) + band(noise(0.5), 1200, 3000) * env(d, 0.0005, 0.01) * 0.2, 0.4))
d = int(0.12 * SR); sfx("twig", norm(band(noise(0.12), 2200, 8000) * env(d, 0.0003, 0.008) + np.concatenate([np.zeros(int(0.05 * SR)), band(noise(0.07), 2500, 7000) * env(int(0.07 * SR), 0.0003, 0.006)]), 0.4))
d = int(8 * SR); tt = np.arange(d) / SR; f0 = 293.66
note = sum(a * np.sin(2 * np.pi * f0 * k * (1 + 0.0004 * k * k) * tt) * np.exp(-tt / (4.0 / (1 + 0.6 * k))) for k, a in ((1, 1.0), (2, 0.45), (3, 0.2), (4, 0.1), (6, 0.04)))
note += 0.35 * np.sin(2 * np.pi * f0 / 2 * tt) * np.exp(-tt / 3.5)
note *= np.minimum(1, tt / 0.03); note += band(noise(8), 2000, 6000) * np.exp(-tt / 0.03) * 0.05
sfx("final_note", norm(note, 0.5))
d = int(0.25 * SR); tt = np.arange(d) / SR; fq = 500 + 1500 * np.exp(-tt * 14)
drip = np.sin(2 * np.pi * np.cumsum(fq) / SR) * np.exp(-tt / 0.045) * np.minimum(1, tt / 0.002) + band(noise(0.25), 2000, 6000) * np.exp(-tt / 0.01) * 0.1
sfx("drip", norm(drip, 0.45))
d = int(0.8 * SR); tt = np.arange(d) / SR; en = np.minimum(1, tt / 0.02) * np.exp(-tt / 0.35)
st = band(noise(0.8), 600, 7000) * en * (0.35 + 0.65 * (rng.random(d) > 0.55)) + band(noise(0.8), 100, 400) * en * 0.2
sfx("radio_static", norm(st, 0.5))
print("ok")
