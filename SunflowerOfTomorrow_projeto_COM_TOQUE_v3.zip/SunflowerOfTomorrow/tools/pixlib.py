"""Mini biblioteca de pixel art procedural (PIL + numpy) usada por gerar_cenarios.py.
Tudo em 1 pixel = 1 pixel do jogo (base 640x360), sem antialiasing."""
from PIL import Image, ImageDraw, ImageFont
import numpy as np, random, math, cv2

def new(w, h, fill=(0, 0, 0, 0)): return Image.new("RGBA", (w, h), fill)
def clamp(v): return max(0, min(255, int(v)))
def shade(c, f): return (clamp(c[0] * f), clamp(c[1] * f), clamp(c[2] * f)) + ((c[3],) if len(c) > 3 else ())
def mix(a, b, t): return tuple(clamp(a[i] * (1 - t) + b[i] * t) for i in range(3))
def jitter(c, rnd, v): d = rnd.uniform(-v, v); return (clamp(c[0] + d), clamp(c[1] + d), clamp(c[2] + d * 0.9))
def rect(d, x0, y0, x1, y1, col):
    if x1 > x0 and y1 > y0: d.rectangle([int(x0), int(y0), int(x1) - 1, int(y1) - 1], fill=col)
def vline(d, x, y0, y1, col): d.line([(int(x), int(y0)), (int(x), int(y1))], fill=col)

def noise_map(w, h, scale, rnd_seed, octaves=2):
    rng = np.random.default_rng(rnd_seed); out = np.zeros((h, w), np.float32); amp = 1.0; tot = 0
    for o in range(octaves):
        s = max(1, int(scale / (2 ** o)))
        small = rng.random((h // s + 2, w // s + 2)).astype(np.float32)
        big = cv2.resize(small, ((w // s + 2) * s, (h // s + 2) * s), interpolation=cv2.INTER_CUBIC)[:h, :w]
        out += big * amp; tot += amp; amp *= 0.5
    out /= tot; return (out - out.min()) / (out.max() - out.min() + 1e-6)

def paste(img, spr, x, y): img.alpha_composite(spr, (int(x), int(y)))

def sky(w, h, top, bot, seed, cloud_dark, cloud_light, block=4):
    """Céu em faixas com nuvens pesadas em blocos."""
    n = noise_map(w // block + 1, h // block + 1, 14, seed, 3)
    grad = np.linspace(0, 1, h // block + 1)[:, None]
    base = np.array(top, np.float32)[None, None] * (1 - grad[..., None]) + np.array(bot, np.float32)[None, None] * grad[..., None]
    t = np.clip((n - 0.35) / 0.5, 0, 1)
    t = np.round(t * 5) / 5
    cl = np.array(cloud_dark, np.float32) * (1 - t[..., None]) + np.array(cloud_light, np.float32) * t[..., None]
    mixv = np.clip(0.55 + 0.4 * (1 - grad), 0, 1)[..., None]
    arr = base * (1 - mixv * 0.65) + cl * (mixv * 0.65)
    img = Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8), "RGB").resize(((w // block + 1) * block, (h // block + 1) * block), Image.NEAREST)
    return img.crop((0, 0, w, h)).convert("RGBA")

def top_profile(x0, x1, top, rnd, rough=6, steps=6, flat=False):
    """altura do topo por coluna (prédio arruinado: degraus e buracos)."""
    prof = np.full(x1 - x0, float(top))
    if flat: return prof
    x = 0
    while x < len(prof):
        run = rnd.randint(6, max(8, (x1 - x0) // steps)); dy = rnd.randint(-rough, rough * 3) if rnd.random() < 0.7 else 0
        prof[x:x + run] += dy; x += run
    return np.clip(prof, top - rough, top + rough * 5)

def apply_profile(img, x0, prof):
    a = np.array(img); h = a.shape[0]
    for i, t in enumerate(prof):
        x = x0 + i
        if 0 <= x < a.shape[1]: a[:int(t), x, 3] = 0
    img.paste(Image.fromarray(a, "RGBA"), (0, 0))

def snow_cap(img, x0, prof, rnd, depth=4, ice=True, white=(224, 232, 242)):
    d = ImageDraw.Draw(img)
    for i, t in enumerate(prof):
        x = x0 + i; t = int(t)
        dep = depth + int(2 * math.sin(i * 0.37) + rnd.uniform(-1, 1.5))
        for k in range(-2, max(1, dep)):
            c = white if k < dep - 2 else mix(white, (150, 164, 184), 0.5)
            d.point((x, t + k), fill=c + (255,))
        if ice and rnd.random() < 0.07:
            L = rnd.randint(4, 12)
            for k in range(L):
                d.point((x, t + dep + k), fill=mix(white, (150, 175, 205), k / L) + (255,))
                if k < L // 2: d.point((x + 1, t + dep + k), fill=(190, 205, 225, 255))

def window(img, x, y, w=18, h=24, rnd=None, broken=False, frame=(26, 29, 36), glass=(24, 33, 48), sill=True):
    d = ImageDraw.Draw(img); rnd = rnd or random.Random(0)
    rect(d, x - 1, y - 1, x + w + 1, y + h + 1, frame)
    rect(d, x + 1, y + 1, x + w - 1, y + h - 1, glass)
    rect(d, x + w // 2, y + 1, x + w // 2 + 1, y + h - 1, frame)
    rect(d, x + 1, y + h // 2 - 2, x + w - 1, y + h // 2 - 1, frame)
    if broken:
        for _ in range(rnd.randint(2, 4)):
            px = x + rnd.randint(1, w - 5); py = y + rnd.randint(1, h - 6)
            d.polygon([(px, py), (px + rnd.randint(3, 6), py + rnd.randint(0, 3)), (px + rnd.randint(1, 4), py + rnd.randint(4, 8))], fill=(8, 10, 14))
        for _ in range(3):
            px = x + rnd.randint(2, w - 3); py = y + rnd.randint(2, h - 3)
            d.line([(px, py), (px + rnd.randint(-5, 5), py + rnd.randint(-6, 6))], fill=(105, 120, 142), width=1)
    else:
        d.line([(x + 2, y + 2), (x + 4, y + 2)], fill=(70, 88, 112))
    if sill:
        rect(d, x - 2, y + h + 1, x + w + 2, y + h + 3, (205, 214, 226)); rect(d, x - 2, y + h + 3, x + w + 2, y + h + 4, (120, 132, 152))

def bricks(img, x0, y0, x1, y1, base, rnd, bw=10, bh=5, var=12, mortar=None, grad=0.78):
    d = ImageDraw.Draw(img); mortar = mortar or shade(base, 0.5); rect(d, x0, y0, x1, y1, mortar)
    row = 0
    for y in range(y0, y1, bh):
        off = (bw // 2) if row % 2 else 0
        for x in range(x0 - off, x1, bw):
            f = 1.0 - (y - y0) / max(1, (y1 - y0)) * (1 - grad)
            c = shade(jitter(base, rnd, var), f)
            rect(d, max(x + 1, x0), y + 1, min(x + bw, x1), min(y + bh, y1), c)
        row += 1

def plaster(img, x0, y0, x1, y1, base, rnd, var=7):
    d = ImageDraw.Draw(img); rect(d, x0, y0, x1, y1, base)
    n = noise_map(x1 - x0, y1 - y0, 6, rnd.randint(0, 9999), 2)
    a = np.array(img); reg = a[y0:y1, x0:x1, :3].astype(np.float32)
    reg *= (0.88 + 0.24 * n)[..., None]; a[y0:y1, x0:x1, :3] = np.clip(reg, 0, 255).astype(np.uint8)
    img.paste(Image.fromarray(a, "RGBA"), (0, 0))
    for _ in range((x1 - x0) // 14):   # manchas e rachaduras
        px = rnd.randint(x0 + 2, x1 - 3); py = rnd.randint(y0 + 4, y1 - 12)
        pts = [(px, py)]
        for _ in range(rnd.randint(3, 6)): px += rnd.randint(-2, 2); py += rnd.randint(2, 5); pts.append((px, py))
        d.line(pts, fill=shade(base, 0.45), width=1)

def cobbles(img, x0, y0, x1, y1, rnd, stone=(86, 90, 99), snow_seed=1, snow_amt=0.5):
    d = ImageDraw.Draw(img); rect(d, x0, y0, x1, y1, shade(stone, 0.45))
    y = y0; row = 0
    while y < y1:
        rh = 7 + int((y - y0) / max(1, (y1 - y0)) * 5); off = rnd.randint(0, 9) if row % 2 else 0
        x = x0 - off
        while x < x1:
            sw = rnd.randint(11, 17)
            c = jitter(stone, rnd, 11)
            rect(d, max(x + 1, x0), y + 1, min(x + sw, x1), min(y + rh, y1), c)
            rect(d, max(x + 1, x0), y + 1, min(x + sw, x1), y + 2, shade(c, 1.18))
            x += sw
        y += rh; row += 1
    # neve em placas alongadas: mais perto da calçada e do fim da rua, pouco no meio
    w, h = x1 - x0, y1 - y0
    small = noise_map(w // 6 + 2, h // 3 + 2, 6, snow_seed, 3)
    n = cv2.resize(small, (w, h), interpolation=cv2.INTER_CUBIC)
    yy = np.linspace(0, 1, h)[:, None]
    bias = 0.34 * np.exp(-((yy - 0.02) / 0.10) ** 2) + 0.18 * np.exp(-((yy - 1.0) / 0.12) ** 2)
    mask = (n + bias) > (1 - snow_amt)
    a = np.array(img); reg = a[y0:y1, x0:x1]
    tone = (196, 206, 220); shadow = (132, 146, 168)
    inner = ndi_erode(mask)
    reg[mask, :3] = shadow; reg[inner, :3] = tone; reg[mask, 3] = 255
    # pontinhos de neve entre as pedras
    sp = (np.random.default_rng(snow_seed).random((h, w)) < 0.012) & ~mask
    reg[sp, :3] = (170, 182, 200)
    img.paste(Image.fromarray(a, "RGBA"), (0, 0))

def ndi_erode(mask):
    from scipy import ndimage as ndi
    return ndi.binary_erosion(mask, iterations=1)

def lamp(img, x, base_y, rnd, tilt=0, height=120):
    d = ImageDraw.Draw(img); col = (36, 40, 48)
    top_x = x + tilt
    d.line([(x, base_y), (top_x, base_y - height)], fill=col, width=3)
    d.line([(top_x, base_y - height), (top_x + 22, base_y - height - 6)], fill=col, width=2)
    rect(d, top_x + 19, base_y - height - 7, top_x + 30, base_y - height - 2, (60, 66, 76))
    rect(d, top_x + 19, base_y - height - 9, top_x + 30, base_y - height - 7, (224, 232, 242))
    for k in range(3): vline(d, top_x + 22 + k * 3, base_y - height - 2, base_y - height + rnd.randint(2, 7), (190, 208, 230))
    rect(d, x - 3, base_y - 4, x + 4, base_y, (50, 54, 62))

def bare_tree(img, x, base_y, h, rnd, depth=0, ang=-90, length=None, thick=3, snow=True):
    d = ImageDraw.Draw(img); length = length or h * 0.34
    if length < 3 or thick < 1: return
    rad = math.radians(ang); x2 = x + math.cos(rad) * length; y2 = base_y + math.sin(rad) * length
    col = (34, 31, 34)
    d.line([(x, base_y), (x2, y2)], fill=col, width=max(1, int(thick)))
    if snow and depth > 0: d.point((int(x2), int(y2) - 1), fill=(225, 233, 243, 255)); d.point((int(x), int(base_y) - 1), fill=(210, 220, 232, 255))
    n = 2 if depth < 3 else rnd.choice([1, 2])
    for i in range(n):
        bare_tree(img, x2, y2, h, rnd, depth + 1, ang + rnd.uniform(-38, 38), length * rnd.uniform(0.62, 0.78), thick - 0.8, snow)

def rubble(img, x, y, w, rnd, snow=True):
    d = ImageDraw.Draw(img)
    for _ in range(w // 4):
        px = x + rnd.randint(0, w); py = y - rnd.randint(0, w // 4); s = rnd.randint(3, 8)
        c = jitter((78, 80, 88), rnd, 14)
        d.polygon([(px, py), (px + s, py - s // 2), (px + s + 2, py + s // 2), (px + 1, py + s // 2 + 1)], fill=c)
        if snow: d.line([(px, py), (px + s, py - s // 2)], fill=(214, 223, 235), width=1)
    d.line([(x + 3, y), (x + w // 2, y - w // 3)], fill=(60, 44, 36), width=2)   # viga caída

def text_px(img, x, y, s, col, size=11, bold=True):
    f = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans%s.ttf" % ("-Bold" if bold else ""), size)
    t = Image.new("L", img.size, 0); d = ImageDraw.Draw(t); d.fontmode = "1"; d.text((x, y), s, font=f, fill=255)
    m = np.array(t) > 127; a = np.array(img); a[m] = col + (255,); img.paste(Image.fromarray(a, "RGBA"), (0, 0))

def vignette(img, strength=0.5):
    a = np.array(img).astype(np.float32); h, w = a.shape[:2]
    yy, xx = np.mgrid[0:h, 0:w]; r = np.sqrt(((xx - w / 2) / (w / 2)) ** 2 + ((yy - h / 2) / (h / 2)) ** 2)
    f = 1 - np.clip(r - 0.55, 0, 1) * strength; a[..., :3] *= f[..., None]
    return Image.fromarray(np.clip(a, 0, 255).astype(np.uint8), "RGBA")


# ------------------------------------------------------------------ remendos (casa)
def screws(d, pts, col=(66, 58, 52)):
    for (x, y) in pts:
        d.point((x, y), fill=col); d.point((x, y - 1), fill=(196, 186, 164))

def tape_strip(img, x0, y0, x1, y1, col=(150, 156, 166)):
    d = ImageDraw.Draw(img); rect(d, x0, y0, x1, y1, col)
    if x1 - x0 >= y1 - y0: d.line([(x0, y0), (x1 - 1, y0)], fill=shade(col, 1.25)); d.line([(x0, y1 - 1), (x1 - 1, y1 - 1)], fill=shade(col, 0.72))
    else: d.line([(x0, y0), (x0, y1 - 1)], fill=shade(col, 1.25)); d.line([(x1 - 1, y0), (x1 - 1, y1 - 1)], fill=shade(col, 0.72))

def patch_plywood(img, x, y, w, h, rnd, base=(158, 124, 84)):
    d = ImageDraw.Draw(img); rect(d, x, y, x + w, y + h, base)
    for k in range(max(1, h // 4)):
        yy = y + 2 + k * 4; d.line([(x + 1, yy), (x + w - 2, yy + rnd.randint(-1, 1))], fill=shade(base, 0.84 + rnd.random() * 0.12))
    rect(d, x, y + h - 1, x + w, y + h, shade(base, 0.55)); rect(d, x + w - 1, y, x + w, y + h, shade(base, 0.6)); rect(d, x, y, x + w, y + 1, shade(base, 1.2))
    screws(d, [(x + 3, y + 3), (x + w - 4, y + 3), (x + 3, y + h - 4), (x + w - 4, y + h - 4)])
    if w > 30 and rnd.random() < 0.7: d.line([(x + w // 3, y + 2), (x + w // 3 + rnd.randint(-3, 3), y + h - 3)], fill=shade(base, 0.62))

def patch_tin(img, x, y, w, h, rnd):
    d = ImageDraw.Draw(img)
    for i in range(w): vline(d, x + i, y, y + h - 1, (136, 140, 146) if (i // 3) % 2 == 0 else (104, 108, 114))
    for _ in range(max(2, w // 3)):
        rx = x + rnd.randint(0, w - 1); ry = y + rnd.randint(0, max(1, h - 9)); vline(d, rx, ry, ry + rnd.randint(3, 9), (138, 84, 54))
    rect(d, x, y, x + w, y + 1, (176, 180, 186)); rect(d, x, y + h - 1, x + w, y + h, (70, 72, 78))
    screws(d, [(x + 2, y + 3), (x + w - 3, y + 3), (x + 2, y + h - 4), (x + w - 3, y + h - 4)], (50, 50, 56))

def patch_tarp(img, x, y, w, h, rnd, col=(52, 86, 130)):
    d = ImageDraw.Draw(img); rect(d, x, y, x + w, y + h, col)
    for k in range(0, w + h, 9): d.line([(x + k, y), (x + k - h // 2, y + h - 1)], fill=shade(col, 1.2 if (k // 9) % 2 else 0.85))
    rect(d, x, y + h - 1, x + w, y + h, shade(col, 0.55))
    for (gx, gy) in ((x + 3, y + 3), (x + w - 4, y + 3), (x + 3, y + h - 4), (x + w - 4, y + h - 4)): d.ellipse([gx - 1, gy - 1, gx + 1, gy + 1], fill=(190, 196, 204))
    tape_strip(img, x, y, x + w, y + 3); tape_strip(img, x, y + h - 3, x + w, y + h)

def patch_cardboard(img, x, y, w, h, rnd, text=None):
    d = ImageDraw.Draw(img); base = (180, 144, 100); rect(d, x, y, x + w, y + h, base)
    for i in range(0, w, 3): vline(d, x + i, y, y + h - 1, shade(base, 0.9))
    rect(d, x, y + h - 1, x + w, y + h, shade(base, 0.6)); rect(d, x + w - 1, y, x + w, y + h, shade(base, 0.7))
    for (tx, ty) in ((x - 1, y - 1), (x + w - 6, y - 1), (x - 1, y + h - 5), (x + w - 6, y + h - 5)): tape_strip(img, tx, ty, tx + 7, ty + 5)
    if text: text_px(img, x + 3, y + h // 2 - 5, text, (70, 44, 34), 8, bold=False)

def patch_brick(img, x, y, w, h, rnd):
    d = ImageDraw.Draw(img); rect(d, x - 2, y - 2, x + w + 2, y + h + 2, (150, 148, 138))
    for _ in range((w + h) // 3):                                         # borda irregular de cimento
        bx = rnd.choice([x - 3, x + w + 1]) if rnd.random() < 0.5 else rnd.randint(x - 2, x + w); by = rnd.randint(y - 3, y + h + 1)
        rect(d, bx, by, bx + rnd.randint(2, 4), by + rnd.randint(2, 4), (146, 144, 134))
    row = 0
    for yy in range(y, y + h, 6):
        off = 6 if row % 2 else 0
        for xx in range(x - off, x + w, 12):
            xa = max(xx + 1, x); xb = min(xx + 11, x + w)
            if xb > xa: rect(d, xa, yy + 1, xb, min(yy + 5, y + h), jitter((166, 76, 54), rnd, 14))
        row += 1

def masked(img, painter, polygon):
    """pinta com painter(layer) e recorta pelo polígono (para bordas irregulares)."""
    layer = new(*img.size); painter(layer)
    m = Image.new("L", img.size, 0); ImageDraw.Draw(m).polygon(polygon, fill=255)
    out = Image.new("RGBA", img.size, (0, 0, 0, 0)); out.paste(layer, (0, 0), m); img.alpha_composite(out)

def plank_floor(img, x0, y0, x1, y1, rnd, base=(84, 64, 52), patches=True):
    d = ImageDraw.Draw(img); rect(d, x0, y0, x1, y1, base)
    for i, y in enumerate(range(y0, y1, 14)):
        off = (i * 53) % 90
        for x in range(x0 - off, x1, 90):
            c = jitter(base, rnd, 9); xa = max(x + 1, x0); xb = min(x + 90, x1)
            if patches and rnd.random() < 0.10: c = jitter((130, 100, 66), rnd, 8)         # tábua nova (remendo)
            if xb > xa:
                rect(d, xa, y + 1, xb, min(y + 14, y1), c)
                for _ in range(3):
                    gy = y + rnd.randint(3, 12); xe = min(x + rnd.randint(30, 80), x1 - 1)
                    if xe > xa + 4: d.line([(xa + 3, gy), (xe, gy)], fill=shade(c, 0.88))
                d.point((xa + 2, y + 4), fill=(46, 36, 30)); d.point((xa + 2, y + 10), fill=(46, 36, 30))
