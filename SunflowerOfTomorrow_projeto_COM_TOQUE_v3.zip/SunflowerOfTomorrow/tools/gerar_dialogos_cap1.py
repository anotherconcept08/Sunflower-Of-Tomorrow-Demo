"""Compila tools/roteiro_cap1/*.py (diálogos em mini-linguagem) para data/dialogue/chapter1_*.json
e gera docs/05_roteiro_capitulo_1.md. Uso: python3 tools/gerar_dialogos_cap1.py"""
import os, sys, json, importlib
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.join(HERE, "..")
sys.path.insert(0, HERE)
from roteiro_cap1.dsl import compile_dialogue

GROUPS = [("casa", "Casa e bairro"), ("centro", "Rua das Lojas e interiores"), ("praca", "Praça e área humanitária"), ("biblioteca", "Biblioteca e Olivier"), ("final", "Volta para casa e encerramento")]
OUT = os.path.join(ROOT, "data", "dialogue"); md = ["# Capítulo I — Um Lugar Para Escapar: roteiro dos diálogos", "",
    "> Gerado por `python3 tools/gerar_dialogos_cap1.py` a partir de `tools/roteiro_cap1/*.py`. O jogo lê `data/dialogue/chapter1_*.json`.",
    "> Convenções: *(narração)* = pensamento de Alen; `nX` = nó; “→” = salto; pausa = silêncio antes da fala.", ""]
seen = set(); total_nodes = 0; total = 0
for key, title in GROUPS:
    mod = importlib.import_module("roteiro_cap1." + key)
    res = {}
    for did, items in mod.D.items():
        assert did not in seen, "id duplicado: " + did
        seen.add(did)
        meta = dict(getattr(mod, "META", {}).get(did, {})); meta.setdefault("cena", "Capítulo I — " + title); meta.setdefault("titulo", did)
        res[did] = compile_dialogue(did, items, meta)
    json.dump(res, open(os.path.join(OUT, "chapter1_%s.json" % key), "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    md.append("## " + title); md.append("")
    for did, d in res.items():
        md.append("#### `%s`" % did)
        nodes = d["nodes"]; ids = list(nodes)
        for i, nid in enumerate(ids):
            n = nodes[nid]
            if "branch" in n:
                b = n["branch"]; md.append("- `%s` **SE** `%s`%s → `%s` · **SENÃO** → `%s`" % (nid, b["flag"], (" = `%s`" % b["equals"]) if "equals" in b else "", b["yes"], b["no"])); continue
            spk = n.get("speaker") or ""
            notes = []
            if n.get("wait"): notes.append("pausa %s s" % n["wait"])
            if n.get("sfx"): notes.append("som: " + n["sfx"])
            if n.get("set"): notes.append("grava " + ", ".join("`%s=%s`" % (k, json.dumps(v, ensure_ascii=False)) for k, v in n["set"].items()))
            note = (" *(" + "; ".join(notes) + ")*") if notes else ""
            if "choices" in n:
                md.append("- `%s` %s%s — *o jogador escolhe:*" % (nid, ("**%s:** " % spk if spk else "") + n.get("text", ""), note))
                for c in n["choices"]:
                    ex = []
                    if c.get("set"): ex.append("grava " + ", ".join("`%s`" % k for k in c["set"]))
                    if c.get("if"): ex.append("só se `%s`" % c["if"])
                    if c.get("ifnot"): ex.append("só se não `%s`" % c["ifnot"])
                    md.append("    - ▸ “%s” → `%s`%s" % (c["text"], c.get("next") or "fim", (" *(" + "; ".join(ex) + ")*") if ex else ""))
                continue
            nx = n.get("next", ""); arrow = "" if (i + 1 < len(ids) and nx == ids[i + 1]) else (" → `%s`" % nx if nx else " → *fim*")
            md.append("- `%s` %s%s%s%s" % (nid, ("**%s:** " % spk) if spk else "*(narração)* ", n.get("text", ""), note, arrow))
        md.append("")
        total += 1; total_nodes += len(nodes)
open(os.path.join(ROOT, "docs", "05_roteiro_capitulo_1.md"), "w", encoding="utf-8").write("\n".join(md))
print("%d diálogos, %d nós" % (total, total_nodes))
