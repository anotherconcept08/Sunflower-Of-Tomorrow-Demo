from .dsl import ask, opt, br

D = {}
META = {}

# =============================================================== RUA DAS LOJAS
D["c1_centro_sign_back"] = [
    "“PINHAL ALTO →”. Alguém acrescentou, embaixo, com tinta branca: “(casa)”.",
    "A placa não pediu opinião, mas concordo.",
]

D["c1_oficina_1"] = [
    "Oficina Santos. A porta de enrolar está meio aberta, como uma pálpebra que desistiu.",
    "Lá dentro, no escuro, um carro sem rodas apoiado em tijolos e um macaco hidráulico esquecido bem no meio.",
    "Quem sai com pressa leva o que é importante e esquece o que é pesado.",
]
D["c1_oficina_2"] = [
    "Um calendário preso na parede: “Paisagens da Suíça — 2007”.",
    "O mês de agosto mostra um lago azul. Daqui dá pra ver direitinho: o lago não tem nada a ver com a gente.",
]

D["c1_locadora_fachada"] = [
    "VÍDEO PONTO. “ALUGUE UM MUNDO”, diz o letreiro apagado. Na vitrine, caixas de jogos viradas de lado, todas com as capas descoloridas pela luz de uma época em que havia luz de sobra.",
    "Uma das caixas tem uma nave azul na capa. Não consigo ler o nome daqui.",
]
D["c1_locadora_porta"] = [
    "A porta da locadora está encostada. Tem um papel preso com fita no vidro, escrito à mão: “Fechado para balanço. Volto na segunda.”",
    "Não diz qual segunda. Empurro a porta mesmo assim. {w=0.4}Com cuidado, como quem entra em um lugar que ainda espera alguém.",
]

D["c1_ferrarias_1"] = [
    "A Rua das Ferrarias. Sacos de areia, uma barreira, um jipe verde com a lona coberta de neve e uma faixa de “ÁREA INTERDITADA” atravessada de lado a lado.",
    "Um soldado está sentado em um caixote ao lado do jipe, de capacete no joelho. Parece mais cansado do que a rua inteira.",
    "Cb. Menezes: Pode passar reto. A rua é aqui, mas o seu caminho não é.",
    ask("Alen", "", [opt("O que tem aí dentro?", go="o"), opt("Estou indo pra biblioteca.", go="b"), opt("O senhor está bem?", go="e", face="triste")]),
    "@o",
    "Cb. Menezes: Casas. Gente que não sai. {w=0.4}Uma padaria sem teto. E uma ordem pra eu ficar aqui até a ordem mudar.",
    "->z",
    "@b",
    "Cb. Menezes: Reto, até a praça. Passa pelo relógio e vira à esquerda. Não pega a avenida — o posto lá é do pessoal mais nervoso.",
    "->z",
    "@e",
    "Cb. Menezes: Seis horas em pé. Se eu sento, eu durmo. Se eu durmo, o sargento aparece. {w=0.5}",
    "Cb. Menezes: Mas obrigado por perguntar. Ninguém pergunta.",
    "@z",
    "Ele coloca o capacete de volta. A conversa acabou, mas ele ficou menos duro por um instante.{set=c1_menezes_met}",
]
D["c1_ferrarias_2"] = [
    "Cb. Menezes: Reto, praça, relógio, esquerda.",
    "Alen: Eu lembro.",
    "Cb. Menezes: Eu repito pra mim mesmo. Pra ver se ainda sei falar.",
]
D["c1_ferrarias_back"] = [
    "Cb. Menezes: Voltando? Tem comida na caixa?",
    "Alen: Tem.",
    "Cb. Menezes: Então a manhã valeu. {w=0.5}A minha ainda não.",
]

D["c1_televale_1"] = [
    "TELE VALE. Quatro televisores de tubo na vitrine, todos apagados. Na tela escura de cada um, um pedaço do meu reflexo, em quatro tamanhos.",
    "Um papel colado no vidro: “CONSERTAMOS. VOLTAMOS EM BREVE.”",
    "“Breve” foi riscado e escrito de novo, três vezes, em canetas diferentes.",
]
D["c1_televale_2"] = [
    "Pela fresta da porta, um calendário parado em setembro. Todos os calendários da cidade parecem ter combinado.",
]

D["c1_padaria_fachada"] = [
    "PÃO & PROSA. É a única chaminé da rua com fumaça. O cheiro chega antes de eu entender o que é: massa quente. {w=0.6}",
    "Fico parado na calçada, de olhos fechados, por mais tempo do que a decência permite.",
]
D["c1_padaria_porta"] = [
    "A porta está destrancada. O sino da entrada dá um tilintar rouco, como quem não é usado desde a última boa notícia.",
]
D["c1_padaria_lousa"] = [
    "Uma lousa na calçada: “HOJE: SÓ 1 PÃO.”",
    "Embaixo, em outra letra, mais miúda: “Por pessoa. Não adianta chorar, eu também choro.”",
]

D["c1_mercearia_1"] = [
    "MERCEARIA. Janelas tapadas com tábuas, porta de ferro fechada, um aviso: “SÓ COM CARTÃO.”",
    "Mas dá pra ver pela fresta o que sobrou: as marcas das prateleiras na parede. Dá pra saber até onde o arroz chegava.",
]
D["c1_mercearia_2"] = [
    "Embaixo da porta, um pedaço de papel dobrado com a letra de criança: “Seu João: eu devo uma bala. Quando abrir eu pago.”",
    "O Seu João não vai ler. Mas alguém ainda deve uma bala, e isso é uma forma de acreditar que a loja volta.",
]

D["c1_beco_1"] = [
    "O Beco do Sapateiro. Um corredor estreito entre duas paredes, com um varal de roupas duras de gelo e uma porta de madeira ao fundo.",
    "A porta está entreaberta. Não tem ninguém na janela. Não tem cheiro de fumaça. {w=0.5}",
    "Entro. {w=0.4}Sem fazer barulho, porque a casa parece ouvir.",
]

D["c1_moda_1"] = [
    "MODA ELEGANCE. Dois manequins de roupa de festa na vitrine, olhando para a rua com o orgulho dos que nunca foram convidados.",
    "Cada um ainda tem uma etiqueta de preço pendurada. Os preços ficaram onde o mundo era mais barato.",
]
D["c1_moda_2"] = [
    "Uma das manequins está sem o braço. Alguém levou, ou ela perdeu num acidente de moda.",
    "Não consigo decidir se eu rio ou se eu respeito.",
]

D["c1_cafe_1"] = [
    "CAFÉ DO LARGO. Cadeiras viradas sobre as mesas, correntes nas pernas das mesas de fora, um toldo azul com gelo caindo em pedaços.",
    "Na lousa: “VOLTAMOS QUANDO A FARINHA VOLTAR.”",
]
D["c1_cafe_2"] = [
    "Alguém riscou “farinha” e escreveu “esperança”. Depois riscou “esperança” e escreveu “farinha” de novo.",
    "Acho que foi a mesma pessoa. Acho que ela estava tentando ser honesta.",
]

D["c1_sebo_1"] = [
    "O LIVRO AZUL. Sebo, troca e doação. Na vitrine, livros inchados pela umidade, empilhados em ordem alfabética e com dignidade.",
    "Um cartaz: “DOE UM LIVRO. A BIBLIOTECA PRECISA → ” e uma seta apontando para o fim da rua.",
]
D["c1_sebo_2"] = [
    "No meio da vitrine: “Manual do Jardineiro Iniciante”. {w=0.6}",
    "Eu não vou comentar.",
    "{w=0.5}Mas gravo o título.",
]

D["c1_ruina_1"] = [
    "O prédio do fim da rua perdeu uma parte da frente. Dá pra ver o interior de dois andares, como uma casa de boneca aberta.",
    "Uma fita de “RISCO” atravessa a calçada. Passo do outro lado, longe, por educação.",
]
D["c1_ruina_2"] = [
    "No que sobrou da parede da entrada, alguém escreveu com giz: “MARIA: ESTAMOS NA BIBLIOTECA, BLOCO C. — MÃE.”",
    "Embaixo, outra letra: “Visto às 9h. Ela já foi.” {w=0.7}",
    "Embaixo desse, a primeira letra de novo: “Obrigada.”",
    "Eu não tenho o que acrescentar. Fico lendo até a mensagem virar mais um pedaço do chão.",
]

D["c1_onibus_1"] = [
    "Um ônibus da Linha 12, parado com as portas fechadas e a placa de “SUSPENSA” no para-brisa. Os pneus estão murchos e cobertos de neve, como se a gente tivesse dado um tempo pra eles.",
]
D["c1_onibus_2"] = [
    "No último banco, um guarda-chuva preto. Aberto. Pendurado no encosto, esperando uma chuva.",
    "Em Declan City, a chuva demorou. A neve não precisou de guarda-chuva.",
]

D["c1_banca_1"] = [
    "Seu Aurélio: Troca-se! Troca-se tudo, menos dinheiro! {w=0.4}",
    "A banca tem pilhas, meias de lã, um sapato direito, panelas, um rádio de carro, quatro livros sem capa e uma galinha de borracha.",
    ask("Alen", "", [opt("Eu não tenho nada pra trocar.", go="n"), opt("O que o senhor aceita?", go="a"), opt("A galinha é de borracha?", go="g", face="sarcastico")]),
    "@n",
    "Seu Aurélio: Todo mundo tem. {w=0.4}Eu aceito história.",
    "->h",
    "@a",
    "Seu Aurélio: Pilha, linha, remédio, sapato, boa notícia. {w=0.4}Boa notícia vale mais que remédio, mas é raríssima.",
    "->h",
    "@g",
    "Seu Aurélio: É. E tem mais valor do que a maioria das galinhas de verdade, hoje em dia.",
    "@h",
    "Seu Aurélio: Me conta uma coisa que aconteceu com você nesta semana. {w=0.4}Uma que não seja triste. Se for verdadeira, eu troco por uma bala de menta.",
    ask("Alen", "", [opt("Eu plantei uma semente de girassol. Em dezembro.", go="s", iff="planted"), opt("Achei uma lata de sementes no meio de um jardim abandonado.", go="s2"), opt("Não tenho nada de bom.", go="n2", face="triste")]),
    "@s",
    "Seu Aurélio: Girassol. Em dezembro. {w=0.6}",
    "Seu Aurélio: O senhor da terra deve estar rindo. Toma a bala. Essa é de primeira.{set=c1_candy}",
    "->z",
    "@s2",
    "Seu Aurélio: Isso é história, sim. Meio curta. Mas honesta.",
    "Seu Aurélio: Toma a bala.{set=c1_candy}",
    "->z",
    "@n2",
    "Seu Aurélio: Todo mundo tem. {w=0.5}Mas não precisa ser hoje. Passa na volta.",
    "@z",
]
D["c1_banca_2"] = [
    "Seu Aurélio: Se achar uma meia de lã com um furo no calcanhar, é da Dona Cândida. Ela nunca vem buscar, mas eu guardo.",
]
D["c1_banca_back"] = [
    "Seu Aurélio: Voltou! {w=0.3}E tá de caixa. Isso eu troco por duas balas.",
    "Alen: Não é pra troca.",
    "Seu Aurélio: Eu sei. Eu só queria falar em voz alta.",
]

# ------------------------------------------------ LOCADORA (interior: loja abandonada)
D["c1_loc_cartaz_space"] = [
    "Um cartaz: uma nave azul, estrelas e um robô vermelho enorme bloqueando a tela.",
    "“ANOTHER CONCEPT apresenta SPACE TRAVELERS.”",
    "“1 nave. 3 vidas. 0 piedade.”{w=0.4}",
    "Não sei o que é. Mas o robô tem cara de quem recebeu mal o convite.",
    "{set=c1_saw_space}",
]
D["c1_loc_cartaz_guitar"] = [
    "“GUITAR LEGENDS. Toque como se alguém estivesse ouvindo.”",
    "A guitarra do cartaz não tem o braço no tamanho certo. Mas a atitude é impecável.",
    "{set=c1_saw_guitar}",
]
D["c1_loc_neon"] = [
    "O letreiro de neon está apagado, mas as letras ainda guardam a forma. “VÍDEO PONTO”. Alguém desenhou um ponto grande depois do “O”, a canetinha, para ficar mais completo.",
]
D["c1_loc_balcao"] = [
    "A gaveta do caixa está aberta e vazia. Sobrou uma moeda de um centavo, o que diz muito sobre inflação.",
]
D["c1_loc_nota"] = [
    "Presa na caixa registradora com um clipe: “Fui buscar minha mãe em outra cidade. Quem quiser alugar, deixa o dinheiro na caixa e anota o título no caderno. Eu confio. — Valdo.”",
    "Ao lado, o caderno. As anotações vão até setembro. A última, de novembro, diz: “Pagamento adiantado, R$ 5. Dona Marta. (Nada alugado. Só pra ajudar.)”",
    "Fico um tempo sem saber o que fazer com as mãos. {w=0.6}Fecho o caderno com cuidado, pra não amassar a confiança.",
]
D["c1_loc_fitas"] = [
    "Prateleiras e mais prateleiras de fitas: “Os Caçadores de Domingo”, “Verão em Sintra 2”, “O Retorno do Retorno”, “Papagaio contra o Mundo”.",
    "Nunca vi nenhum desses. Todos têm um selo de “DEVOLVA ATÉ SEXTA”. Com a pressa que a vida tem, estão todos atrasados.",
]
D["c1_loc_tv"] = [
    "A TV do balcão está desligada. Dentro do aparelho, uma fita presa, com uma etiqueta: “FIM DE SEMANA 3”.",
    "Imagino o filme que ela estava passando quando a luz foi cortada. Prefiro que seja uma comédia.",
]
D["c1_loc_devolucao"] = [
    "A caixa de devolução ainda tem coisas: dois jogos, três fitas e um bilhete: “Desculpa. Estava arranhado quando eu peguei.”",
    "Um dos jogos se chama “Mundo de Tinta”. É da mesma empresa. Another Concept. O logotipo é um círculo com uma linha no meio, como um olho fechado.",
    "Não pego. Não é meu, mesmo que ninguém venha buscar. {w=0.5}Fica anotado: Another Concept. “Mundo de Tinta”.",
]
D["c1_loc_ficha"] = [
    "Um fichário de sócios, com uma ficha aberta: “Sócio 007. Pendências: devolver SPACE TRAVELERS (desde 1998). Multa acumulada: infinita.”",
    "Alguém escreveu com outra caneta: “Vale a multa.”",
]
D["c1_loc_saida"] = [
    "A porta da locadora. Do outro lado, a rua. Mas antes eu dou uma última olhada no cartaz da nave. {w=0.4}",
    "Saio.",
]

# ------------------------------------------------ PADARIA (interior: estabelecimento em funcionamento mínimo)
D["c1_pad_iris_1"] = [
    "Dona Íris: Fecha a porta, o calor escapa! {w=0.3}",
    "Uma mulher de avental branco e cabelo preso sova uma massa sobre a mesa com a firmeza de quem faz isso desde antes de ter motivo.",
    "Dona Íris: Se veio comprar, não tem. Se veio dar bom dia, tem de sobra.",
    ask("Alen", "", [opt("Bom dia. Cheira muito bem aqui.", go="b"), opt("Eu vou pra biblioteca. A senhora precisa de alguma coisa?", go="l"), opt("Eu não tenho dinheiro.", go="d", face="triste")]),
    "@b",
    "Dona Íris: Cheira porque eu tenho um forno, e o forno tem uma ideia fixa. {w=0.4}",
    "->r",
    "@l",
    "Dona Íris: Biblioteca? {w=0.5}Ora, pois então.",
    "->r",
    "@d",
    "Dona Íris: Eu também não, filho. A gente trabalha com outra moeda.",
    "@r",
    "Dona Íris: A Helena me mandou três sacos de farinha. Foi o que sobrou do comboio de terça. {w=0.4}Dá dez pães. Cinco vão pro abrigo, três pro posto, dois pra quem aparecer.",
    "Dona Íris: Você apareceu.",
    ask("Alen", "", [opt("Posso levar os do abrigo?", go="y"), opt("A senhora nem me conhece.", go="m", face="envergonhado")]),
    "@y",
    "Dona Íris: Pode, pode. Cinco, no saco de pano. Entrega pra Helena, e diz que é da Íris, que ela já sabe.",
    "->t",
    "@m",
    "Dona Íris: Conheço o jeito. O jeito de quem anda com pressa e com medo. {w=0.4}Isso eu conheço de longe.",
    "Dona Íris: Leva os do abrigo?",
    "Alen: Levo.",
    "@t",
    "Ela embrulha cinco pães quentes em um saco de pano e o saco quase me queima as mãos. Gosto disso. É um calor que não vem do fogão da sala nem da caneca.{set=c1_bread}",
    "Dona Íris: E esse aqui — {w=0.4}",
    "Ela separa um sexto pão e coloca na minha mão.",
    "Dona Íris: Quem carrega, prova. É a regra da casa. Não é presente: é salário.",
    "Alen: Eu... posso levar pra casa?",
    "Dona Íris: Pode levar pra onde quiser. Regra da casa é essa também.{set=c1_roll;c1_iris_met}",
]
D["c1_pad_iris_2"] = [
    "Dona Íris: Já entregou os pães?",
    "Alen: Estou indo.",
    "Dona Íris: Então vai, antes que eles esfriem e eu fique com raiva.",
]
D["c1_pad_iris_back"] = [
    "Dona Íris: Voltou pelo calor, né? Eu sei como é.",
    "Alen: Passei pra agradecer.",
    "Dona Íris: Não agradece. Se você agradece, eu me sinto obrigada a fazer mais pão. E aí falta farinha.",
]
D["c1_pad_forno"] = [
    "O forno de tijolos está aceso. É o lugar mais quente da rua. Percebo que fiquei parado mais tempo do que precisava.",
    "O fogo tem uma cor que a casa nunca viu: laranja de verdade.",
]
D["c1_pad_farinha"] = [
    "FARINHA. Três sacos, um deles já aberto. A Dona Íris disse que três sacos são “um começo”.",
    "Gosto da palavra. Começo. Ainda mais para um saco de farinha.",
]
D["c1_pad_gato"] = [
    "Um gato cinza dorme sobre o último saco de farinha, como se soubesse o valor. Provavelmente sabe.",
    "Dona Íris: Esse é o Miolo! {w=0.3}Dorme em cima do que é caro. Não toca, que ele cobra.",
]
D["c1_pad_lousa"] = [
    "A lousa da parede ainda tem os preços de antes: PÃO FRANCÊS, PÃO DOCE, BOLO DO DIA. Todos riscados com giz.",
    "No lugar de “BOLO DO DIA”, a Dona Íris escreveu: “SÓ HOJE: AMASSAR PRA SOBREVIVER.”",
]
D["c1_pad_balcao"] = [
    "No balcão, três pãezinhos dourados sobre um pano, com um cartão: “ENCOMENDADO — BIBLIOTECA.”",
    "Eu olho. Eu não toco. Eu sou educado até a fome.",
]
D["c1_pad_saida"] = [
    "O sino da porta toca de novo, desta vez como quem agradece.",
]

# ------------------------------------------------ CASA ABANDONADA (interior parcialmente abandonado)
D["c1_casa_entrada"] = [
    "Uma casa pequena, uma sala, uma cozinha e, atrás da divisória, um quarto. O ar é parado, mais frio do que na rua.",
    "Um lugar em que alguém morou até a pressa decidir o contrário.",
]
D["c1_casa_mesa"] = [
    "A mesa está posta para o jantar de um dia que não aconteceu. Quatro pratos, quatro garfos, uma jarra com um resto de gelo no fundo.",
    "Alguém saiu com cuidado, pra não quebrar nada. {w=0.5}E nada quebrou.",
]
D["c1_casa_bilhete"] = [
    "Um bilhete debaixo da jarra: “Fomos para a casa da tia Cleusa. Voltamos quando abrirem a estrada. Se alguém precisar de abrigo, a chave está debaixo do vaso. A casa é de vocês enquanto estivermos fora. Cuidem da planta. — Marta.”",
    "Releio duas vezes. {w=0.6}Cuidem da planta.",
]
D["c1_casa_vaso"] = [
    "Debaixo do vaso da porta, a chave. O vaso está vazio, a terra dura de gelo.",
    "A chave não tem ferrugem nem pó. Está limpa. {w=0.5}Alguém usa essa chave.",
    "{set=c1_key_used}",
]
D["c1_casa_canecas"] = [
    "Na prateleira, cinco canecas diferentes, cada uma com um nome pintado à mão: Pai, Mãe, Teo, Bia, Visita.",
    "A de “Visita” está de ponta-cabeça no escorredor. Alguém lavou. {w=0.5}Recentemente.",
]
D["c1_casa_foto"] = [
    "Uma foto na parede: um pai, uma mãe, um menino de uns dez anos e uma menina com um laço enorme. Todos olhando para o fotógrafo como se ele tivesse acabado de contar uma piada.",
    "Eu me pergunto qual foi a piada. Eu me pergunto se ainda tem graça.",
]
D["c1_casa_calendario"] = [
    "O calendário da parede está parado em setembro. Alguém riscou os dias até o 14. O 15 está circulado em vermelho.",
    "Sem explicação. A casa inteira fica no silêncio de quem sabe e não conta.",
]
D["c1_casa_fogao"] = [
    "O fogão está frio, com uma chaleira em cima e um pano de prato dobrado em três. A gente sempre sabe quem deixou a casa em ordem pra ela esperar bem.",
]
D["c1_casa_casaco"] = [
    "Um casaco de adulto, pendurado atrás da porta. No bolso, uma bala de menta e um bilhete de ônibus da linha 12.",
    "Não pego nada. Mas fica anotado que tem bala de menta num casaco. É importante saber onde moram as pequenas coisas.",
]
D["c1_casa_trem"] = [
    "Um trem de brinquedo parado no meio do tapete, virado para a porta. Esperando o apito de alguém.",
]
D["c1_casa_mochila"] = [
    "Uma mochila escolar, ainda com o caderno aberto. “Dever: escreva uma frase sobre o que você quer ser quando crescer.”",
    "Embaixo, na letra torta de um garoto: “Quando eu crescer eu quero ser” — e a frase para aí.",
    "Eu não termino a frase por ele.{w=0.5} Mas pensei em três finais antes de conseguir fechar o caderno.",
]
D["c1_casa_cama"] = [
    "A cama do quarto está desfeita de um jeito que não é de quem saiu correndo. É de quem dormiu ali. {w=0.5}Recentemente.",
    "Há uma marca de cabeça no travesseiro, e um cobertor dobrado no pé da cama com cuidado de quem não quer ser notado.",
    "{set=c1_saw_bed}",
]
D["c1_casa_janela"] = [
    "A janela do quarto está embaçada pelo frio. No vidro, desenhado com o dedo, alguém fez uma pequena nave espacial, com asas, uma cauda, e uma fileira de estrelas no alto.",
    "As bordas ainda estão nítidas. O desenho é novo.{set=c1_saw_ship}",
]
D["c1_casa_neve"] = [
    "Um buraco no teto do quarto. A neve entra e forma uma montanhazinha em cima do tapete.",
    "Dentro de casa, nevando. Na minha, é o telhado que eu remendo. Aqui, ninguém remendou. {w=0.4}Dá uma pontada esquisita.",
]
D["c1_casa_saida"] = [
    "Antes de sair, eu coloco o bilhete do jeito que estava. Alinho o vaso. Quem quer que use esta casa, que continue achando tudo como achou.",
]
