from .dsl import ask, opt, br

D = {}
META = {}

# =============================================================== CASA (manhã)
D["c1_wake"] = [
    "Amanhã chegou, que era o combinado.",
    "A muda do quarto continua viva. O caderno continua com uma linha só. O meu estômago também só tem uma linha, e ela diz “comida”.",
    "Do outro lado da parede, o rádio já está falando sozinho.{w=0.6}",
]

D["c1_mae_1"] = [
    "Mãe: Dormiu? {w=0.4}",
    ask("Alen", "", [opt("Mais ou menos.", go="a"), opt("O frio acordou a casa inteira.", go="b", face="sarcastico")], echo=True),
    "@a",
    "Mãe: Mais ou menos já é mais do que a maioria. {w=0.5}",
    "->c",
    "@b",
    "Mãe: Acordou. Mas a casa não reclamou, que eu ouvi.",
    "@c",
    "Mãe: Essa caneca é sua. Ainda está morna.",
    "Ela me estende a caneca com as duas mãos. Uma delas treme um pouco. Faço de conta que é por causa do frio.",
    "Mãe: E esse aqui — {w=0.5}",
    "Ela abre o outro punho. Dentro, um cartão dobrado em quatro, mole de tanto ser apertado.",
    "“CARTÃO DE RAÇÃO Nº 117 — FAMÍLIA HADER — 3 PESSOAS.” Carimbo da Prefeitura, azul, já meio apagado.",
    "Mãe: Biblioteca, no centro. Disseram que o balcão abriu de novo hoje.",
    "Alen: Eu sei onde é.",
    "Mãe: Sabe. Eu que fico repetindo, pra ouvir que alguém sabe. {w=0.6}",
    "Mãe: Traz o que tiver. Se tiver pão, traz pão. Se não tiver pão, arroz. Se não tiver arroz...",
    "Alen: Eu trago o que tiver, mãe.",
    ask("Alen", "", [opt("Eu volto antes de escurecer.", go="v"), opt("A senhora está bem?", go="e", face="triste"), opt("(Pegar o cartão em silêncio.)", say="Guardo o cartão no bolso de dentro da jaqueta. É o bolso onde cabem as coisas que não podem se perder.", narr=True, go="f")]),
    "@v",
    "Mãe: É bom. A rua fica estranha quando escurece. {w=0.5}",
    "->f",
    "@e",
    "Mãe: Estou ótima. {w=0.9}",
    "Mãe: Estou cansada, que é diferente. {w=0.6}",
    "->f",
    "@f",
    "Mãe: Ah. E Alen... não discute com ninguém hoje. Hoje todo mundo está com a paciência no fim.{set=c1_card;c1_mae_talked}",
]

D["c1_mae_again"] = [
    "Mãe: Já está com o cartão? {w=0.3}",
    "Alen: Estou.",
    "Mãe: Então vai logo. Antes que eu invente mais recomendação.",
]

D["c1_pai_1"] = [
    "Pai: Alen. {w=0.4}",
    "Ele não levanta os olhos do livro. Está aberto na mesma página desde ontem; eu sei porque a página tem uma dobra no canto que não estava aí.",
    "Pai: Vai pela Rua das Lojas. Não pela avenida. Os soldados fecharam a avenida e a estrada do Moinho esta noite.",
    "Estrada do Moinho. Fechada. {w=0.8}",
    ask("Alen", "", [opt("Fecharam por quê?", go="p"), opt("Eu não vou discutir com soldado.", go="d", face="sarcastico"), opt("(Não dizer nada.)", say="Penso em um jardim, uma lata, uma semente coberta de terra ontem à tarde. Não digo nada.", narr=True, go="x")]),
    "@p",
    "Pai: O rádio disse “por segurança”. É o que o rádio diz quando sabe e não pode dizer. {w=0.5}",
    "->x",
    "@d",
    "Pai: Você discute com o rádio.",
    "Alen: O rádio merece.",
    "Pai: {w=0.4}Merece. {w=0.4}Mesmo assim, se um soldado pedir pra voltar, volta.",
    "@x",
    "Pai: E leva isto.",
    "Ele tira o cachecol do próprio pescoço e me estende. Hoje é o único calor extra que ele tem.",
    ask("Alen", "", [opt("O senhor precisa mais.", go="n"), opt("Obrigado.", go="o")]),
    "@n",
    "Pai: Eu estou dentro de casa, com um cobertor e uma poltrona. Você vai pra fora do mundo. {w=0.5}",
    "Pai: Leva.",
    "->s",
    "@o",
    "Pai: Não agradece. Devolve inteiro.",
    "@s",
    "Pai: Mais uma coisa. Se a biblioteca ainda tiver “Contos de Outros Mundos”, dá uma olhada. {w=0.4}",
    "Pai: Estou devendo a mim mesmo o último conto há dois anos.",
    "Ele diz isso como se fosse uma piada. Rio como se fosse.{set=c1_pai_talked;c1_scarf;c1_book_asked}",
]

D["c1_pai_again"] = [
    "Pai: Cachecol?",
    "Alen: Estou com ele.",
    "Pai: Ótimo. {w=0.5}Então o resto da lista é com Deus e com a Dona Helena, que lá é quem manda.",
]

D["c1_radio_c1"] = [
    "O rádio de válvula chia, acha uma estação e perde de novo.",
    "“...a prefeitura de Declan City informa que o toque de recolher passa a valer às vinte horas em todos os setores...”",
    "“...repetimos: as vinte horas.”{w=0.5}",
    "Vinte horas. A luz da casa volta às vinte. Até nisso eles combinaram.",
]

D["c1_door_nocard"] = [
    "Sem o cartão eu vou até lá pra voltar de mãos vazias.",
    "A mãe está com ele. Ou estava.",
]

D["c1_door_parents"] = [
    "Eu não saio sem falar com os dois. Seria a primeira vez que eu saio e a casa fica me olhando pelas costas.",
]

D["c1_door_ready"] = [
    "A porta da frente. Do outro lado, a rua, a neve e um dia inteiro de coisas que dão errado por motivos que ninguém explica.",
    "Lista de hoje: um cartão, uma biblioteca, uma caixa.",
    ask("", "", [opt("Sair.", set="door_choice:leave", go="leave"), opt("Mais um minuto.", go="wait")], echo=False),
    "@leave",
    "Fecho a porta devagar, pra não acordar a casa. Ela já está acordada.{w=0.5}",
    "END",
    "@wait",
    "Tudo bem. Um minuto não custa nada. É o que a gente tem de sobra.",
]

# =============================================================== BAIRRO (Pinhal Alto) — o prólogo continua, mas a cidade mudou
D["c1_marcus_1"] = [
    "Marcus: {w=0.3}Olha só quem acordou antes do sol e depois do café, que não tem.",
    br("planted", "m_planted", "m_plain"),
    "@m_planted",
    "Marcus: Soube que você foi lá no Moinho ontem. {w=0.4}",
    "Marcus: Pois então. Ontem à noite chegou um caminhão, dois jipes e uma ordem. A estrada fechou.",
    "->m_go",
    "@m_plain",
    "Marcus: Ontem à noite chegou um caminhão, dois jipes e uma ordem. A estrada do Moinho fechou.",
    "@m_go",
    ask("Alen", "", [opt("Fechou até quando?", go="q1"), opt("Eu preciso passar lá. Eu tinha dito que voltava.", go="q2", face="triste"), opt("E eu com isso? Vou pra biblioteca.", go="q3", face="sarcastico")]),
    "@q1",
    "Marcus: Até a ordem mudar. Ninguém sabe quando a ordem muda; só sabem quando ela chega.",
    "->m_next",
    "@q2",
    "Marcus: Disse pra quem?",
    "Alen: Pra ninguém. {w=0.5}Pra terra.",
    "Marcus: {w=0.5}Então a terra espera. Ela é boa nisso. Melhor que a gente.",
    "->m_next",
    "@q3",
    "Marcus: Esse é o espírito. Teimoso e com destino.",
    "@m_next",
    "Marcus: Biblioteca. Certo. Vai pela esquerda da rua: dobra depois da casa onde você mora e segue reto, até a rua das lojas. Não corre, não discute, não olha torto.",
    "Marcus: E o remédio da sua mãe... {w=0.5}ainda nada. Mas se chegar no comboio, a lista fica lá. A Dona Helena anota tudo.",
    "Alen: Obrigado, Marcus.",
    "Marcus: Não agradece, joga uma moeda no chapéu do próximo azarado.{set=c1_marcus_met}",
]

D["c1_marcus_2"] = [
    "Marcus: Ainda aqui? Já era pra estar na fila.",
    "Alen: A fila anda.",
    "Marcus: A fila não anda, ela se muda de lugar. {w=0.4}Vai.",
]

D["c1_marcus_back"] = [
    "Marcus: {w=0.3}Voltou inteiro e com caixa. Tá bom demais pra ser uma segunda-feira.",
    ask("Alen", "", [opt("É só arroz e feijão.", go="a"), opt("Tinha fila. Muita gente.", go="b", face="triste")]),
    "@a",
    "Marcus: Arroz e feijão é uma boa notícia que ninguém comemora.",
    "->z",
    "@b",
    "Marcus: Sempre tem. {w=0.4}Dá pra ver quem tá bem pela cara de quem já foi.",
    "@z",
    "Marcus: Vai pra casa. Alimenta teu pessoal. {w=0.5}E amanhã a gente fala de estrada.",
]

D["c1_barricada_1"] = [
    "A estrada do Moinho. O que era cerca e sinalização é agora um muro de sacos de areia, uma barra listrada de vermelho e branco e ouriços de ferro pintados de cinza.",
    "Um soldado de capacete me observa, de pé, de braços cruzados, como quem decidiu a conversa antes de ela começar.",
    "Sd. Ferraz: Volta.",
    ask("Alen", "", [opt("Eu só queria passar.", go="p"), opt("Tem um jardim no fim dessa estrada.", go="j", face="triste"), opt("Tá.", go="t")]),
    "@p",
    "Sd. Ferraz: Todo mundo só queria passar. {w=0.4}",
    "->f",
    "@j",
    "Sd. Ferraz: Tem muita coisa no fim dessa estrada, garoto. {w=0.5}Nenhuma que eu possa te deixar ver.",
    "->f",
    "@t",
    "Sd. Ferraz: Bom garoto. {w=0.4}",
    "@f",
    "Sd. Ferraz: Ordem 114 do Comando Regional. Acesso proibido. Não me pediram o motivo; me pediram a barra.",
    "Ele diz isso sem raiva. Parece o resumo de uma noite inteira.",
    "Penso em uma semente coberta de terra. “Amanhã eu volto, pra ver.” Hoje é amanhã. A terra vai ter que esperar mais um pouco.{set=c1_barricada_seen}",
]

D["c1_barricada_2"] = [
    "Sd. Ferraz: Já falei.",
    "Alen: Eu sei. {w=0.4}Só vim olhar.",
    "Sd. Ferraz: Olhar não é proibido. {w=0.5}Por enquanto.",
]

D["c1_barricada_back"] = [
    "Sd. Ferraz: Ainda por aqui?",
    "Alen: Vim de volta da biblioteca. Estou indo pra casa.",
    "Sd. Ferraz: Então vai. {w=0.5}E... {w=0.4}pega a rua da frente. A de trás tem gelo.",
    "É a coisa mais gentil que ele disse o dia todo. Ele provavelmente nega depois.",
]

D["c1_sign_centro"] = [
    "Uma placa pintada à mão: “← CENTRO · Biblioteca 1,2 km”.",
    "Embaixo, em letra menor e outra tinta: “(a pé; não corra)”.",
]

D["c1_candida_1"] = [
    "Dona Cândida: A roupa nunca seca. Eu sei. {w=0.4}",
    "Dona Cândida: Mas pendurar faz bem. É como falar um bom dia pra casa.",
    ask("Alen", "", [opt("Tá fazendo frio demais.", go="a"), opt("A senhora precisa de ajuda?", go="b")]),
    "@a",
    "Dona Cândida: Frio demais pra quê, filho? Pra secar? Pra viver? {w=0.4}Pra viver ainda dá.",
    "->z",
    "@b",
    "Dona Cândida: Ah, não. Mas se passar uma vizinha, diz que a minha camisa azul está pendurada ali e que ela pode vir ver se é dela.",
    "Dona Cândida: O vento levou a dela pra cá. Ele não é muito bom em endereços.",
    "@z",
    "Ela prende o último pregador. A camisa azul vira um pedaço de gelo com mangas.",
]

D["c1_candida_back"] = [
    "Dona Cândida: Voltando com a caixa? {w=0.4}Ótimo. Quem carrega comida anda mais reto.",
    "Alen: É verdade?",
    "Dona Cândida: É. Reparei nos meus vizinhos. {w=0.5}E na minha camisa.",
]

D["c1_tobias_1"] = [
    "Seu Tobias mexe no botão de um rádio de pilha. A agulha vai do chiado para outro chiado e depois para a missa.",
    "Seu Tobias: Esse rádio pega três estações: o chiado, o outro chiado e a missa. {w=0.5}",
    "Seu Tobias: Hoje o chiado está muito bom. Quer ouvir?",
    ask("Alen", "", [opt("Quero.", go="s"), opt("Prefiro a missa.", go="m", face="sarcastico")]),
    "@s",
    "Ele aumenta o volume. É só chiado mesmo. Mas é um chiado cheio de conversa.",
    "->z",
    "@m",
    "Seu Tobias: A missa tem boa dicção e poucas surpresas. Respeito. {w=0.4}",
    "@z",
    "Seu Tobias: Se escutar uma voz de verdade dizendo o que tá acontecendo, vem me avisar. Tô há três semanas esperando uma voz de verdade.",
]

D["c1_tobias_2"] = [
    "Seu Tobias: Chiado. {w=0.4}Missa. {w=0.4}Chiado.",
    "Seu Tobias: Hoje é um dia de poucas novidades.",
]

D["c1_criancas_giz"] = [
    "Duas crianças desenham uma amarelinha na neve com um pedaço de carvão. O céu, no fim, é maior do que o resto todo.",
    "Menino: Não pisa na linha! Isso aqui é sério!",
    "Menina: Ele inventou as regras agora. A primeira regra é que ele ganha.",
    "Menino: A primeira regra é que não pode rir do chefe do jogo.",
    "Ela ri. Eu quase.",
]

D["c1_criancas_giz_2"] = [
    "Menino: Quer jogar?",
    "Alen: Não posso, tenho uma missão.",
    "Menino: Missão de quê?",
    "Alen: De caixa.",
    "Menino: {w=0.4}Missão de caixa é a mais chata.",
    "Menina: É a mais importante, bobo.",
    "Eu não sabia que alguém ia dizer isso hoje. Fico ouvindo a frase mais um pouco depois de sair andando.",
]

D["c1_criancas_giz_back"] = [
    "Menino: Ganhou a missão?",
    "Alen: Ganhei a caixa.",
    "Menina: Então ganhou tudo.",
    "Menino: Mentira. O céu da amarelinha é meu.",
]

D["c1_laundry_sign"] = [
    "Um bilhete preso no varal com pregador: “Quem achar uma meia verde com furo no calcanhar: é minha. Não devolve. Só me avisa que ela está bem.”",
    "Rio. Rio de verdade, curto, pelo nariz. {w=0.5}Faz bastante tempo.",
]
