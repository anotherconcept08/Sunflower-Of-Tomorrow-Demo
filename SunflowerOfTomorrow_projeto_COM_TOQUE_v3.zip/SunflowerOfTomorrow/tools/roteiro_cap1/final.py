from .dsl import ask, opt, br

D = {}
META = {}

D["c1_home_arrive"] = [
    "A casa me recebe com o mesmo cheiro de sempre: remédio velho, lenha, tempo.",
    "Mas hoje eu trago uma caixa. {w=0.6}A casa percebe.",
]

D["c1_unpack"] = [
    "Ponho a caixa em cima da mesa da cozinha e desfaço o barbante, nó por nó.",
    "Arroz. Feijão. Óleo. Leite em pó. Um saquinho de açúcar mascavo, que tem cheiro de infância.",
    "Tudo alinhado em cima da mesa, como um pequeno exército que chegou a tempo.",
    br("c1_peach", "pe", "pn"),
    "@pe",
    "E, no fundo, a lata de pêssego em calda da Dona Helena. O rótulo tem uma mancha de umidade em forma de continente.",
    "->pn",
    "@pn",
    br("c1_roll", "rl", "rn"),
    "@rl",
    "Do bolso da jaqueta, o pão da Dona Íris. Está frio agora, mas o cheiro ainda está inteiro, e é o cheiro que enche a cozinha primeiro.",
    "->rn",
    "@rn",
    "Dá três dias, talvez quatro, se a gente for firme. {w=0.5}É mais do que a casa tinha de manhã.{set=c1_unpacked}",
]

D["c1_mae_ret"] = [
    "Mãe: {w=0.4}Chegou. {w=0.6}",
    "Ela me olha de cima a baixo, como quem confere se eu voltei com todas as partes. Depois olha a mesa.",
    "Mãe: Arroz. {w=0.5}Feijão. {w=0.4}Açúcar mascavo? {w=0.4}Você foi na biblioteca ou numa feira de domingo?",
    "Alen: A Dona Helena disse que o sal acabou. {w=0.3}Que a senhora ia achar o gosto curioso.",
    "Mãe: Curioso é o que eu preciso. {w=0.6}",
    br("c1_peach", "pe", "pn"),
    "@pe",
    "Ela pega a lata de pêssego em calda e a segura contra a luz, como se o rótulo fosse uma carta.",
    "Mãe: Pêssego. {w=0.8}Eu não via pêssego desde antes de tudo isso.",
    "Alen: A Dona Helena guardou pra quando alguém merecesse.",
    "Mãe: E você merecia? {w=0.5}",
    "Alen: Eu só carreguei o saco de pão.",
    "Mãe: A gente nunca sabe quando uma coisa pequena é grande. {w=0.5}",
    "Ela diz a mesma frase que a Dona Helena. Acho que as duas aprenderam em lugares diferentes e chegaram à mesma conclusão.",
    "->pn",
    "@pn",
    br("c1_roll", "rl", "rn"),
    "@rl",
    "Eu tiro o pão frio do bolso e coloco na mão dela.",
    "Mãe: Pão. {w=0.8}De verdade. {w=0.5}Que cheiro...",
    "Ela parte um pedaço pequeno e põe na boca, de olhos fechados. {w=0.8}Um segundo que eu não esqueço.",
    "->rn",
    "@rn",
    br("c1_biscuit", "bs", "bn"),
    "@bs",
    "Eu tiro do bolso a metade da barra de cereal.",
    "Alen: Esta é pra senhora.",
    "Mãe: Quem te deu?",
    "Alen: Um garoto lá. {w=0.4}Olivier.",
    "Mãe: Olivier. {w=0.5}É um nome bonito.",
    "Alen: É só um garoto, mãe.",
    "Mãe: Eu não disse que era mais que isso. {w=0.6}",
    "Ela ri. É uma risada pequena, que vem da mesma gaveta que o pêssego.",
    "->bn",
    "@bn",
    "Mãe: Obrigada, filho. Por voltar. {w=0.6}Por voltar antes de escurecer.{set=c1_mae_ret_done}",
]

D["c1_pai_ret"] = [
    "Pai: Chegou inteiro. {w=0.5}Isso eu já considero metade da missão.",
    "Alen: A outra metade está na mesa.",
    "Pai: {w=0.6}Eu sei. Estou sentindo o cheiro.",
    br("c1_item", "bk", "nobk", equals="book"),
    "@bk",
    "Eu tiro o livro de dentro da jaqueta. Ele fica um tempo sem se mexer, como se o livro soubesse que estava voltando pra casa.",
    "Pai: {w=1.0}Você achou. {w=0.6}“Contos de Outros Mundos”. {w=0.5}Eu tinha certeza que tinham levado.",
    "Alen: Estava na prateleira. A ficha tem três nomes. O terceiro é o senhor.",
    "Pai: {w=0.7}Eu sei. Eu escrevi com a letra de domingo.",
    "Ele passa o polegar pela lombada, devagar, como quem confere uma cicatriz.",
    "Pai: Obrigado, Alen. {w=0.5}Eu estava devendo isso a mim mesmo.",
    "->tail",
    "@nobk",
    br("c1_item", "gt", "nl", equals="guitar"),
    "@gt",
    "Pai: E o livro? Dos contos?",
    ask("Alen", "", [opt("Estava lá. Mas eu levei outra coisa. Vou buscar.", go="b1", iff="c1_found_book"), opt("Não deu tempo de olhar.", go="b2")]),
    "@b1",
    "Pai: {w=0.6}Então busca. {w=0.4}Livro é mais paciente que gente.",
    "->tail",
    "@b2",
    "Pai: Tudo bem. {w=0.5}Ele espera.",
    "->tail",
    "@nl",
    "Pai: E o livro dos contos? {w=0.4}Não precisa ser hoje. Só pra eu saber que ele existe.",
    "Alen: Se ele existir, eu trago.",
    "Pai: É bom o suficiente.",
    "@tail",
    br("c1_roll", "rl", "z"),
    "@rl",
    "Pai: Isso é pão? {w=0.6}",
    "Alen: Da Dona Íris. {w=0.3}Uma regra da casa.",
    "Pai: Regra boa. {w=0.4}O cheiro entra antes da palavra.",
    "@z",
    "Pai: Alen. {w=0.5}Eu sei que ninguém te perguntou se você queria fazer isto. {w=0.5}Mesmo assim, você foi.",
    "Alen: Eu só fui lá.",
    "Pai: Pois é. {w=0.6}O mundo mede diferente do que a gente mede.{set=c1_pai_ret_done}",
]

D["c1_cozinha_nao"] = [
    "Antes do quarto, a caixa tem que chegar na cozinha. A casa inteira está esperando por ela.",
]
D["c1_bed_cedo"] = [
    "Não ainda. Eu volto pra casa pra ficar com a casa. O quarto espera.",
]
D["c1_bed_pronto"] = [
    "A casa está quieta do jeito que ela fica depois que todo mundo comeu. {w=0.6}Cheia, de um jeito silencioso.",
    "É a hora. {w=0.4}Subo para o quarto.",
]

D["c1_night_guitar"] = [
    "Oito da noite. A luz volta com um estalo, como sempre, e a casa inteira se endireita.",
    "O computador de tubo demora um minuto pra acordar. Eu coloco o CD na bandeja, que gira, tosse e aceita.",
    "“GUITAR LEGENDS — Another Concept.” A tela escurece, depois acende em vermelho e dourado. Uma música de guitarra, meio tosca, meio linda, sai do alto-falante pequeno.",
    "A guitarra de verdade está encostada na parede, ao meu lado. Parada há muito tempo. {w=0.6}Eu ainda não encosto.",
    "Na tela, as notas descem em colunas. Verde, vermelho, amarelo. Não tenho o adaptador, mas tenho os dedos, e os dedos lembram de coisas que a cabeça esqueceu.",
    "Toco três notas no ar. {w=0.5}Depois três no braço da cadeira. {w=0.5}Depois três na guitarra de verdade, sem amplificador, tão baixo que só eu ouço.",
    "Do outro lado da parede, o meu pai para de virar a página.",
    "Pai: {w=0.8}Continua. {w=0.5}Eu estava esquecendo como era.",
]
D["c1_night_book"] = [
    "Oito da noite. A luz volta com um estalo, e a casa se endireita.",
    "Deixo a porta do quarto aberta, porque o meu pai pediu sem pedir. Pego o livro dele e leio o primeiro conto em voz baixa, só pra mim. Mas a voz sai mais alta do que eu planejei.",
    "“Na terceira lua de Kepler, um menino desenhava mapas de lugares que ainda não existiam.",
    "— Pra quê? — perguntou o robô.",
    "— Pra que alguém tenha pra onde ir, quando precisar.”",
    "Pai: {w=0.8}Mais uma página.",
    "Eu leio mais uma. {w=0.4}E mais uma. {w=0.4}Depois a voz dele deixa de responder, e eu continuo lendo mais baixo, para o escuro.",
]
D["c1_night_none"] = [
    "Oito da noite. A luz volta com um estalo, e a casa se endireita.",
    "Eu não trouxe nada. Mas dentro da cabeça eu tenho uma nave azul, uma música de oito notas e um garoto de cachecol laranja dizendo “respira, é feio ver gente azul.”",
    "Cantarolo a musiquinha, bem baixo. Erro a quinta nota. Volto e acerto.",
    "Do outro lado da parede, alguém ri. {w=0.4}Baixinho, no escuro. Não sei se foi a minha mãe ou o meu pai.",
]
D["c1_night_window"] = [
    "Deito. A casa respira devagar. {w=0.6}Lá fora, a neve continua a cair sobre Declan City, do jeito silencioso que ela cai.",
    "De vez em quando, bem longe, algo bate duas vezes. Grave. A janela estremece e para.{sfx=boom_far}",
    "Nada mudou, na verdade. A estrada do Moinho continua fechada. A lista continua curta. O remédio continua sem data.",
    "Mas hoje eu descobri uma coisa pequena: existe um lugar onde alguém deixou a luz acesa e o mundo ligado. {w=0.8}E existe um garoto de cachecol laranja que ainda não terminou a fase.",
    "Levanto e desenho uma nave no vidro embaçado, com o dedo. Asas, uma cauda, uma fileira de estrelas no alto. {w=0.8}Ela dura uns dois minutos. {w=0.5}É o bastante.",
    "Amanhã a lista tem uma palavra a mais.",
    "{w=1.2}Biblioteca.",
]

D["c1_pai_final"] = [
    "Pai: Vai descansar. {w=0.5}Amanhã a gente vê o que o dia pede.",
]
D["c1_mae_final"] = [
    "Mãe: Boa noite, filho. {w=0.5}Hoje a casa está cheia. Dá pra sentir pelo cheiro.",
]
D["c1_door_back"] = [
    "Lá fora já escureceu, e a luz está pra voltar. A rua fica estranha quando escurece; a mãe tinha razão.",
    "Amanhã eu volto lá. Hoje a casa precisa de mim inteira.",
]
