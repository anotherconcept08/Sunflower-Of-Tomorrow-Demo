from .dsl import ask, opt, br

D = {}
META = {}

# =============================================================== PRAÇA DO RELÓGIO
D["c1_praca_sign"] = [
    "Uma placa de metal com uma seta: “← BIBLIOTECA · ABRIGO Nº 3”.",
    "Alguém pintou por baixo um coração torto, a tinta rosa. Tem gente com sobra de tinta rosa em Declan City, e eu respeito.",
]
D["c1_banco_1"] = [
    "BANCO POPULAR. Quatro colunas, quatro janelas quebradas e uma grade de ferro baixada até o chão.",
    "Na grade, um papel: “FECHADO POR TEMPO INDETERMINADO. NÃO INSISTA.”",
]
D["c1_banco_2"] = [
    "Embaixo do aviso, alguém deixou dois bilhetes. Um diz “MEU DINHEIRO ESTÁ AÍ DENTRO.” O outro, com outra letra: “O DE TODO MUNDO.”",
    "O terceiro bilhete, em tinta fraca: “Mas eu só queria meu dinheiro.” {w=0.5}",
    "Dá pra ler uma cidade inteira em três pedaços de papel.",
]
D["c1_correios_1"] = [
    "CORREIOS. A porta está fechada com um cadeado novo e uma corrente velha. No vidro, um aviso: “Correspondência para a fronteira leste: SUSPENSA.”",
    "Em frente, uma caixa vermelha de cartas. Está bem cheia.",
]
D["c1_mulher_cartas"] = [
    "Uma mulher de cachecol amarelo coloca um envelope na caixa vermelha com os dois dedos, como se fosse algo que respira.",
    "Mulher: Quarenta e duas cartas. {w=0.4}Nenhuma passa da fronteira.",
    "Mulher: Eu escrevo mesmo assim. É como falar sozinha com endereço.",
    ask("Alen", "", [opt("E alguém responde?", go="r"), opt("Posso levar alguma?", go="l"), opt("A senhora devia ficar menos tempo no frio.", go="f", face="envergonhado")]),
    "@r",
    "Mulher: Responder, não. Mas a caixa continua aqui. {w=0.5}Ela me faz companhia.",
    "->z",
    "@l",
    "Mulher: Leva se você for pra fronteira. {w=0.5}Não vai? Então fica pra mim mesmo.",
    "->z",
    "@f",
    "Mulher: Obrigada, querido. Eu devia. Eu também devia muita coisa.",
    "@z",
]
D["c1_mulher_cartas_2"] = [
    "Mulher: Quarenta e três.",
]
D["c1_correio_caixa"] = [
    "A caixa vermelha de cartas está cheia até a boca. Sobrou um canto de papel azul para fora, com um nome: “Para Joana, em mãos.”",
    "Não é pra mim, não é de ninguém aqui. Mas reparo na letra, tão bem desenhada que parece escrita com respeito.",
]

D["c1_desaparecidos_1"] = [
    "Uma parede de madeira coberta de papéis. “PROCURA-SE.” Fotos fracas, nomes, datas, ruas.",
    "Fotografias de gente ainda sorrindo, de gente que se parece com o meu vizinho, de crianças em fantasia de Carnaval.",
    "Não consigo olhar para todas ao mesmo tempo. Escolho uma de cada vez, como quem atravessa um rio pelas pedras.",
]
D["c1_desaparecidos_2"] = [
    "Um papel diz: “QUIM, 7 anos, boné azul, última vez na Rua das Flores. Responde por Quim.”",
    "Em cima, com outra letra e canetinha verde: “ENCONTRADO — ESTÁ COMIGO. OBRIGADA A TODOS.”",
    "O verde é a cor mais forte da parede inteira.",
]
D["c1_desaparecidos_3"] = [
    "No canto de baixo, alguém prendeu uma foto sem nome. Um grupo de pessoas num piquenique, todos com a mão levantada num aceno.",
    "No verso, com letra apertada: “Quem reconhecer alguém, por favor, diga o nome. Só o nome.”",
    "{w=0.6}Digo, baixinho, o nome de ninguém. {w=0.5}Por respeito.",
]

D["c1_sopa"] = [
    "Em cima do banco, uma panela grande com tampa, enrolada em uma toalha. Um papel preso por uma colher: “TOME UM POUCO. SE SOBRAR, DEVOLVE A PANELA.”",
    ask("Alen", "", [opt("Tomar um pouco.", go="t"), opt("Deixar para quem precisa mais.", go="d")]),
    "@t",
    "Sirvo um pouco na tampa. Sopa de nada com gosto de cebola. É a melhor coisa que comi esta semana, e eu não vou contar isso pra ninguém.",
    "Ponho a tampa no lugar. Deixo a colher como achei.",
    "->z",
    "@d",
    "Fico olhando a panela. Não tomo. A caixa de casa pesa mais do que o meu estômago.",
    "Deixo o recado intacto, que é a melhor maneira de respeitar um recado.",
    "@z",
]
D["c1_relogio_1"] = [
    "No pedestal, uma placa de bronze: “AOS QUE FICARAM.” O relógio da torre parou às quatro e dez.",
    "Quatro e dez de quando, de qual dia, ninguém me contou.",
]
D["c1_relogio_2"] = [
    "Vejo duas pessoas olhando do relógio parado para o relógio de pulso e voltando, como quem pede desculpas ao tempo.",
    "A hora oficial de Declan City, hoje, é a que cada um traz no punho.",
]
D["c1_fonte"] = [
    "A fonte congelou. Embaixo do gelo, moedas de todos os tamanhos, como desejos suspensos.",
    "Imagino o gelo derretendo e todos os desejos sendo atendidos de uma vez só. Daria um caos delicioso.",
]
D["c1_jornais"] = [
    "A banca de jornais está trancada, mas ainda tem uma edição pendurada no cordão da vitrine. “15 DE SETEMBRO. MANTENHAM A CALMA.”",
    "O jornal parou de ser publicado no mesmo dia em que o relógio. {w=0.5}Parece coisa combinada.",
]
D["c1_xadrez"] = [
    "Um senhor de chapéu joga xadrez sozinho num banco coberto de neve. Os dois lados do tabuleiro têm a mesma cara de preocupação.",
    "Seu Hermes: Joga? {w=0.4}",
    ask("Alen", "", [opt("Pouco.", go="p"), opt("Não posso, estou com pressa.", go="n"), opt("Quem está ganhando?", go="g", face="sarcastico")]),
    "@p",
    "Seu Hermes: Pouco é melhor que ninguém. Senta do lado preto. Os brancos estão ocupados.",
    "Alen: Ocupados com quê?",
    "Seu Hermes: Em ganhar.",
    "->z",
    "@n",
    "Seu Hermes: Todo mundo está. Vai. O tabuleiro espera. Ele sempre foi a coisa mais paciente da minha vida, depois da minha mulher.",
    "->z",
    "@g",
    "Seu Hermes: Eu. {w=0.4}E também eu. {w=0.4}Não é tão emocionante quanto parece.",
    "@z",
]
D["c1_xadrez_2"] = [
    "Seu Hermes: Cavalo pra frente. {w=0.4}Cavalo pra trás. Aprendi isso na guerra, mas não era xadrez.",
    "Ele ri sozinho. Eu não sei se devo rir.",
]

D["c1_posto_sinal"] = [
    "“AVENIDA CENTRAL — SÓ VEÍCULOS AUTORIZADOS.” Embaixo, em letras pequenas: “Pedestres: usar a Rua das Lojas.”",
    "Alguém riscou “autorizados” e escreveu “armados”. Uma segunda pessoa riscou “armados” e escreveu “cansados”. A terceira rabiscou tudo e desenhou um sol.",
]
D["c1_posto_lopes_1"] = [
    "Uma soldada de capacete de lado, fuzil ao ombro e um chá numa caneca de metal. Ela me vê e baixa um pouco o queixo.",
    "Sd. Lopes: Avenida fechada. Mas você já sabia.",
    ask("Alen", "", [opt("Sabia. Estou indo pra biblioteca.", go="b"), opt("O que tem na avenida?", go="a"), opt("A senhora está bebendo chá no meio disso tudo?", go="c", face="sarcastico")]),
    "@b",
    "Sd. Lopes: Pelo lado esquerdo da praça, depois da capela. {w=0.4}Cuidado com o gelo, tá escorregadio.",
    "->z",
    "@a",
    "Sd. Lopes: A avenida. {w=0.5}Mais avenida.",
    "Sd. Lopes: E uma parte da cidade que me pediram pra não olhar. Eu cumpro. {w=0.4}Mas eu olho.",
    "->z",
    "@c",
    "Sd. Lopes: É a única coisa quente que me deixam trazer. {w=0.5}Quer um gole?",
    "Alen: Não, obrigado. {w=0.3}Mas é gentil.",
    "Sd. Lopes: Aqui ninguém é gentil de graça. Anota aí.",
    "@z",
    "Sd. Lopes: Seu pai e sua mãe sabem que você está aqui? {w=0.5}",
    "Alen: Sabem. Estão em casa. {w=0.4}Doentes.",
    "Sd. Lopes: {w=0.6}Dá o número da ração pra Dona Helena. Ela mantém uma lista de remédios. Se vier no comboio de sexta, pela avenida, ela sabe antes de mim.",
    "Sd. Lopes: Não repete que eu disse isso.{set=c1_lopes_met;c1_med_hint}",
]
D["c1_posto_lopes_2"] = [
    "Sd. Lopes: Sexta. Avenida. Helena. Mais nada que eu possa dizer. {w=0.5}",
    "Sd. Lopes: Anda, antes que o meu sargento me veja conversando.",
]
D["c1_posto_lopes_back"] = [
    "Sd. Lopes: Voltando com caixa, né? {w=0.4}Dá pra ver. Você anda como o povo daqui: mais pesado do lado em que carrega.",
    "Alen: Eu tento disfarçar.",
    "Sd. Lopes: Não disfarça. Esse peso é o certo.",
]
D["c1_posto_jipe"] = [
    "Um jipe verde com a lona cheia de neve. Ainda tem as marcas dos pneus da noite passada, cada vez mais fundas, como se cada viagem tivesse sido mais difícil que a anterior.",
]
D["c1_posto_barreira"] = [
    "A barreira listrada de vermelho e branco é a única coisa colorida da avenida. Baixada. Silenciosa.",
    "Tem gelo pendurado no braço dela, como cabelo de gente velha.",
]

D["c1_hotel_1"] = [
    "HOTEL CENTRAL. O fogo pegou um andar e parou, como se tivesse mudado de ideia. As janelas pretas olham pra praça sem expressão.",
    "Um hotel que um dia teve quartos, hóspedes e uma vista. Hoje tem uma ótima vista da própria falta de hóspedes.",
]
D["c1_hotel_2"] = [
    "Na porta, um aviso colado com fita: “NÃO ENTRE. ISSO NÃO É UM ABRIGO. O ABRIGO É NA BIBLIOTECA.”",
    "Embaixo, em letra de criança: “E É MUITO MAIS QUENTE.”",
]

D["c1_capela_1"] = [
    "Uma capela pequena de torre torta. Pela porta entreaberta, dá pra ver um brilho de velas e uma mulher ajeitando um lenço no banco da frente.",
    "Não entro. É como entrar na sala de alguém: dá vontade de pedir licença, mesmo sem ninguém por perto.",
]
D["c1_capela_doacoes"] = [
    "Uma caixa de madeira com um recado: “DEIXE O QUE SOBRAR. LEVE O QUE FALTAR.”",
    "Dentro: um par de luvas de criança, tricotadas em cores que não combinam, uma lata de sardinha, um cobertor dobrado e um pé de sapato.",
    "Eu não tenho nada que sobre. {w=0.5}Mas fico com a frase.",
]

# =============================================================== ÁREA HUMANITÁRIA
D["c1_hum_cadastro"] = [
    "“CADASTRO NOVO. FILA B.” Uma fila comprida de gente em cobertores e casacos, mochilas, uma criança dormindo em pé.",
    "A tenda tem um balcão dobrável e uma voluntária de colete azul que repete, a cada três minutos, o mesmo “próximo, por favor”. Hoje ela está bem educada.",
]
D["c1_fila_1"] = [
    "Senhora: Estou aqui desde as cinco da manhã. {w=0.4}Não é pra reclamar! É só pra constar.",
    "Ela prende o casaco com a mão e olha pra frente, firme.",
    ask("Alen", "", [opt("A senhora quer sentar?", go="s"), opt("O que a senhora veio fazer?", go="v")]),
    "@s",
    "Senhora: Se eu sentar, perco o lugar. E se eu perder o lugar, perco a manhã. {w=0.5}Prefiro as costas doendo.",
    "->z",
    "@v",
    "Senhora: Cadastrar a minha casa, que não existe mais. Pra ter um papel que prove que ela existiu.",
    "@z",
]
D["c1_fila_2"] = [
    "Homem: Escuta, é aqui a fila do pão ou a fila de cadastro?",
    "Voluntária: É a do cadastro, senhor.",
    "Homem: E a do pão?",
    "Voluntária: Do outro lado. É a mais curta.",
    "Homem: Então por que eu estou aqui? {w=0.5}",
    "Voluntária: Porque o senhor entrou na fila errada com muita convicção.",
    "O homem fica um segundo parado, depois dá risada. A fila inteira dá um pouco de risada junto, daquelas que saem baixinho.",
]
D["c1_fila_velho"] = [
    "Velho: Cinco da manhã. Eu trouxe uma cadeira, mas deixei em casa. {w=0.4}Esqueci por quê.",
    "Ele sorri com os olhos, não com a boca. Alguém pôs um cobertor nos ombros dele, e ele não parece ter notado quem foi.",
]
D["c1_caminhao_1"] = [
    "Um caminhão de suprimentos, verde, com uma lona aberta. Dois soldados e dois voluntários passam caixas de mão em mão numa corrente, sem conversar, num ritmo que parece música.",
    "Cada caixa tem um número. A caixa 114 passa por mim e eu sinto um pouco de vergonha por querer uma delas.",
]
D["c1_caixas"] = [
    "Pilha de caixas de papelão carimbadas: ARROZ, FEIJÃO, ÓLEO, LEITE EM PÓ, SAL.",
    "Numa delas, alguém escreveu a mão: “NÃO CONGELAR.” A caixa está a três graus negativos, ao ar livre. Acho que é fé.",
]
D["c1_agua_1"] = [
    "Um tanque cinza com três torneiras e uma placa: “ÁGUA — 5 LITROS POR PESSOA.” Uma fila curta, com baldes e garrafas.",
    "Menino: Eu prefiro neve derretida. {w=0.4}Tem gosto de nuvem.",
    "Mulher: Tem gosto de chaminé, isso sim.",
    "Menino: Chaminé de nuvem.",
]
D["c1_agua_2"] = [
    "Uma voluntária enche, uma por uma, as garrafas de uma família. Cada garrafa recebe um pequeno “pronto” em voz baixa, como se fosse uma bênção.",
]
D["c1_avisos_1"] = [
    "Quadro de avisos do Abrigo Nº 3.",
    "“AULA IMPROVISADA: 14h, SALA B. Traga lápis. Se não tiver lápis, traga a vontade.”",
    "“PROCURA-SE: cobertor de lã (qualquer cor), para uma senhora de 83 anos que não quer ser chamada de senhora.”",
]
D["c1_avisos_2"] = [
    "“GRATIDÃO: a quem deixou os sapatos de criança na capela: serviram. — Lúcia (e a Bia, que agora tem sapato novo)”",
    "Fico um tempo ali, sem querer ir embora. A coisa que me segura é uma palavra: serviram.",
]
D["c1_avisos_3"] = [
    "“TOQUE DE RECOLHER: 20h. QUEM ESTIVER NA RUA APÓS ESSE HORÁRIO SERÁ ORIENTADO A VOLTAR PARA CASA, ABRIGO OU BASE MILITAR MAIS PRÓXIMA.”",
    "Alguém escreveu embaixo: “Orientado = escoltado.” E outro: “Mas educadamente.”",
]
D["c1_alto_falante"] = [
    "Alto-falante: ...atenção, moradores de Declan City. O comboio de suprimentos de sexta-feira segue previsto pela Avenida Central. Repetimos...{sfx=radio_static}",
    "Alto-falante: ...as atividades de distribuição continuam até às dezoito horas...{w=0.4}",
    "Ao longe, abafado, algo grave bate duas vezes. Ninguém olha. Todo mundo para um segundo e depois continua.{sfx=boom_far}",
]
D["c1_teatro_1"] = [
    "Uma barraquinha de papelão: “TEATRO DE MEIAS. HOJE: ‘O REI QUE PERDEU O SAPATO’. ENTRADA FRANCA. APLAUSOS OBRIGATÓRIOS.”",
    "Dentro, um menino com uma meia vermelha em cada mão faz a voz grossa de um rei e a voz fina de uma rainha, trocando de uma para a outra sem respirar.",
    "Menino: “Meu sapato! Meu reino por um sapato!” {w=0.5}“Majestade, o sapato está no seu pé.” {w=0.5}“Então por que eu não sinto?” {w=0.5}“Porque o senhor está de meia.”",
    ask("Alen", "", [opt("Aplaudir.", go="a"), opt("Ficar em silêncio, impressionado.", go="s", face="envergonhado")]),
    "@a",
    "Eu aplaudo. O menino faz uma reverência com a meia vermelha. O público é de um: eu. É um bom público.{set=c1_puppet}",
    "->z",
    "@s",
    "Menino: Aplauso é obrigatório. {w=0.4}Tá na placa.",
    "Eu aplaudo. Com atraso, mas aplaudo.{set=c1_puppet}",
    "@z",
]
D["c1_teatro_2"] = [
    "Menino: Hoje tem outra peça. “A Rainha Que Esqueceu o Nome”. É um drama.",
    "Alen: Termina bem?",
    "Menino: Ainda estou decidindo.",
]
D["c1_teatro_back"] = [
    "Menino: A peça mudou! A rainha lembrou o nome!",
    "Alen: Qual era?",
    "Menino: Não conta. {w=0.4}É o final.",
]
D["c1_hum_ruina"] = [
    "O prédio ao lado perdeu a parede da frente. Dá pra ver a sala de alguém: um sofá, um quadro torto, um papel de parede de flores.",
    "Não existe nada mais íntimo do que uma sala sem parede. Olho um pouco e viro o rosto, pra devolver a privacidade.",
]
D["c1_hum_lamp"] = [
    "O poste da esquina ainda tem lâmpada. Está apagada, mas alguém amarrou nele uma fita vermelha, com um laço.",
    "Acho que é uma promessa de luz. Gosto de promessas pequenas e amarradas.",
]

# ---- porta da biblioteca (entrada)
D["c1_porta_bib_1"] = [
    "Um rapaz de colete azul e prancheta guarda a porta grande da biblioteca. Quando me vê, abre um sorriso curto, de quem decidiu ser simpático hoje.",
    "Tiago: Cartão de ração?",
    "Alen: Tenho. {w=0.3}Nº 117. Hader.",
    "Tiago: Hader. {w=0.4}Três pessoas. {w=0.4}Pode entrar. {w=0.5}Balcão da Dona Helena, no corredor da esquerda. Limpa os pés no capacho; se ela vir neve no chão, o discurso é longo.",
    ask("Alen", "", [opt("Obrigado.", go="a"), opt("Ela é brava?", go="b", face="sarcastico")]),
    "@a",
    "Tiago: Por nada. Faz parte do cargo. {w=0.4}",
    "->z",
    "@b",
    "Tiago: Ela é exata. É diferente. {w=0.4}Quem é exato não precisa ser bravo.",
    "@z",
    "A porta tem uma fresta de luz amarela. Atrás dela, o cheiro: papel, lã molhada, sopa, poeira boa.{set=c1_tiago_door}",
]
D["c1_porta_bib_2"] = [
    "Tiago: Pode entrar, pode entrar! {w=0.3}Só não carrega neve nas botas.",
]
D["c1_porta_bib_back"] = [
    "Tiago: Voltando pra casa? {w=0.3}Boa viagem, meu amigo. Chega inteiro.",
    "Alen: Vou tentar.",
    "Tiago: A gente não pede mais que isso.",
]
