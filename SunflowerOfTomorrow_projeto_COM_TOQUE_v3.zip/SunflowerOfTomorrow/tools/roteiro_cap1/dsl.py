"""Mini-linguagem para escrever os diálogos do Capítulo I de forma compacta.
Cada diálogo é uma lista de itens:
  "texto"                    narração em 1ª pessoa de Alen (caixa sem nome)
  "Pai: texto"               fala de um personagem (o prefixo precisa estar em SPEAKERS)
  "... {w=0.8}{f=triste}"    modificadores: w = pausa antes (s), f = expressão de Alen, sfx = som, set = flags (a;b:valor)
  "@rotulo"                  marca o próximo nó          "->rotulo"  salta para um rótulo      "END"  encerra
  ask(quem, enunciado, [opt(...), ...])     escolha do jogador
  br(flag, sim, nao, equals=None)           desvio por flag, sem texto
"""
import re

SPEAKERS = {"Alen", "Pai", "Mãe", "Marcus", "Eleanor", "Olivier", "Garoto", "Helena", "Nina", "Tiago", "Sd. Ferraz", "Sd. Lopes", "Cb. Menezes",
            "Dona Íris", "Seu Aurélio", "Dona Cândida", "Seu Tobias", "Seu Anselmo", "Lúcia", "Dona Rute", "Pedro", "Lia", "Mulher", "Homem",
            "Velho", "Voluntária", "Voluntário", "Menino", "Menina", "Soldado", "Senhora", "Seu Valdo", "Dona Marta", "Rádio", "Seu Hermes", "Sd. Teixeira", "Alto-falante", "Dona Lourdes", "Seu Jorge"}


def opt(t, say=None, go=None, set=None, face=None, narr=False, iff=None, ifnot=None):
    return {"t": t, "say": say, "go": go, "set": set, "face": face, "narr": narr, "if": iff, "ifnot": ifnot}


def ask(who, prompt, opts, echo=True, face=None):
    return {"kind": "ask", "who": who, "prompt": prompt, "opts": opts, "echo": echo, "face": face}


def br(flag, yes, no, equals=None):
    return {"kind": "branch", "flag": flag, "yes": yes, "no": no, "equals": equals}


def _mods(s):
    m = {k: v for k, v in re.findall(r"\{(\w+)=([^}]*)\}", s)}
    # a tag de pausa/rosto vira um espaço (antes ela engolia o espaço e colava "frase.Outra frase")
    t = re.sub(r"\s*\{\w+=[^}]*\}\s*", " ", s)
    return re.sub(r" {2,}", " ", t).strip(), m


def _sets(txt):
    out = {}
    for part in txt.split(";"):
        part = part.strip()
        if not part: continue
        if ":" in part:
            k, v = part.split(":", 1)
            out[k.strip()] = int(v) if v.strip().lstrip("-").isdigit() else v.strip()
        else:
            out[part] = True
    return out


def compile_dialogue(did, items, meta=None):
    nodes = []        # nós lógicos, ainda com rótulos
    labels = {}
    pend = []
    for it in items:
        if isinstance(it, str):
            if it.startswith("@"): pend.append(it[1:]); continue
            if it.startswith("->"):
                assert nodes, did + ": goto sem nó anterior"; nodes[-1]["goto"] = it[2:]; continue
            if it == "END":
                nodes[-1]["goto"] = ""; continue
            text, m = _mods(it); speaker = ""
            if ": " in text:
                pre, rest = text.split(": ", 1)
                if pre in SPEAKERS: speaker, text = pre, rest
            if text == "" and "set" in m and nodes and not pend and nodes[-1]["kind"] == "line":   # linha só com {set=...}: gruda no nó anterior
                nodes[-1].setdefault("set", {}).update(_sets(m["set"])); continue
            n = {"kind": "line", "speaker": speaker, "text": text}
            if "w" in m: n["wait"] = float(m["w"])
            if "f" in m: n["face"] = m["f"]
            if "sfx" in m: n["sfx"] = m["sfx"]
            if "set" in m: n["set"] = _sets(m["set"])
        else:
            n = dict(it)
        for p in pend: labels[p] = len(nodes)
        pend = []
        nodes.append(n)
    for p_ in pend: labels[p_] = len(nodes)          # rótulo no fim = encerra o diálogo
    ids = ["n%d" % (i + 1) for i in range(len(nodes))]

    def target(lbl):
        if lbl == "": return ""
        assert lbl in labels, "%s: rótulo inexistente %s" % (did, lbl)
        return ids[labels[lbl]] if labels[lbl] < len(ids) else ""

    out = {}
    for i, n in enumerate(nodes):
        nid = ids[i]
        seq_next = ids[i + 1] if i + 1 < len(nodes) else ""
        if n["kind"] == "branch":
            b = {"flag": n["flag"], "yes": target(n["yes"]), "no": target(n["no"])}
            if n.get("equals") is not None: b["equals"] = n["equals"]
            out[nid] = {"branch": b}
        elif n["kind"] == "ask":
            node = {"speaker": n["who"], "text": n["prompt"], "choices": []}
            if n.get("face"): node["face"] = n["face"]
            if n["echo"] is False: node["echo"] = False
            for o in n["opts"]:
                c = {"text": o["t"], "next": target(o["go"]) if o["go"] is not None else seq_next}
                if o["say"] is not None: c["say"] = o["say"]
                if o["narr"]: c["narr"] = True
                if o["face"]: c["face"] = o["face"]
                if o["set"]: c["set"] = _sets(o["set"]) if isinstance(o["set"], str) else o["set"]
                if o["if"]: c["if"] = o["if"]
                if o["ifnot"]: c["ifnot"] = o["ifnot"]
                node["choices"].append(c)
            out[nid] = node
        else:
            node = {"speaker": n["speaker"], "text": n["text"]}
            if "wait" in n: node["wait"] = n["wait"]
            if "sfx" in n: node["sfx"] = n["sfx"]
            if "set" in n: node["set"] = n["set"]
            if "face" in n: node["face"] = n["face"]
            node["next"] = target(n["goto"]) if "goto" in n else seq_next
            out[nid] = node
    m = {"cena": "", "titulo": did, "onde": "—", "som": "—", "anim": "—", "cons": "Nenhuma.", "fim": "Último nó."}
    m.update(meta or {})
    return {"meta": m, "start": ids[0], "nodes": out}
