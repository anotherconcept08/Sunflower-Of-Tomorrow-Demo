from .dsl import ask, opt, br

D = {}
META = {}

# =============================================================== ENTRADA E RECEPÇÃO
D["c1_bib_entrada"] = [
    "Dentro, o ar muda. Menos vento, mais cheiro: papel, lã molhada, sopa, poeira boa.",
    "É uma biblioteca. Também é um refeitório, um dormitório e uma sala de espera. As estantes estão no mesmo lugar de sempre, mas as pessoas pararam de falar baixo, porque não dá.",
    "Em Declan City, ainda existe um lugar em que alguém quis manter as luzes acesas e os livros arrumados. {w=0.6}Eu respiro. Uma respiração inteira.",
]
D["c1_nina_1"] = [
    "Nina: Bem-vindo! {w=0.3}Isso aqui é mais ou menos um hotel, um refeitório e uma escola ao mesmo tempo. {w=0.4}A gente ainda está decidindo o que mais.",
    "Uma garota de gorro laranja e colete azul, com uma prancheta e um lápis preso na orelha, olha pra mim como se já tivesse me esperado a manhã inteira.",
    "Nina: Cartão na mão? {w=0.3}Ótimo. Corredor da esquerda, balcão da Dona Helena. Ela vai fazer cara de exata. Não é cara de brava.",
    ask("Alen", "", [opt("Tem regra aqui?", go="r"), opt("Posso explorar depois?", go="e"), opt("Obrigado.", go="o")]),
    "@r",
    "Nina: Tem cinco. A número um é cartão, a dois é silêncio, a três é criança com adulto, a quatro é que o fogão é da Dona Rute, e a cinco é que ninguém dorme na fila.",
    "Nina: A quatro é a mais importante. {w=0.4}Já perdi um bolo por causa dela.",
    "->z",
    "@e",
    "Nina: Pode, pode! {w=0.3}Só não mexe nos jogos do canto sem pedir. E se o garoto da televisão disser que você perdeu, não acredita: ele mente sobre pontos.",
    "->z",
    "@o",
    "Nina: De nada. {w=0.4}É o meu emprego, e eu gosto dele.",
    "@z",
    "Ela volta pra prancheta. Eu volto pra rotina de caminhar e não esbarrar em ninguém.{set=c1_nina_met}",
]
D["c1_nina_2"] = [
    "Nina: Corredor da esquerda, balcão da Helena. {w=0.3}Você consegue.",
]
D["c1_nina_back"] = [
    "Nina: Pegou a caixa? {w=0.3}Ótimo! Então agora você só precisa não derrubar.",
    "Alen: Eu vou tentar.",
    "Nina: É o que a gente faz o dia inteiro.",
]
D["c1_regras"] = [
    "“REGRAS DO ABRIGO.” Uma folha grande, escrita à mão, em cinco linhas:",
    "“1. Um cartão = uma caixa.  2. Silêncio (dentro do possível).  3. Crianças com adultos.  4. Fogão: só a Dona Rute.  5. Ninguém dorme na fila.”",
    "A regra 2 tem um “(dentro do possível)” escrito por cima, com outra caneta. O possível mudou de lugar.",
]
D["c1_cabides"] = [
    "Um cabideiro de madeira com casacos pendurados, sem dono visível. Cada casaco tem uma etiqueta com nome, ou um desenho: um sol, uma estrela, um peixe.",
    "O meu eu levo. Eu só quero ver se eu entendo a lógica dos desenhos.",
]
D["c1_capacho"] = [
    "No chão, um capacho escrito “SECAR OS PÉS”. Em volta, marcas de neve em forma de bota de todos os tamanhos.",
    "A neve no capacho é o único mapa honesto do que esse lugar recebeu hoje.",
]
D["c1_banco_entrada"] = [
    "Um senhor dorme sentado no banco, a cabeça caída sobre o peito e as mãos sobre o joelho, como quem espera um ônibus que não vem.",
    "Passo devagar. A gente aprende rápido a andar em silêncio perto de quem dormiu.",
]
D["c1_bib_exit_nofood"] = [
    "Ainda não peguei a caixa. Eu não volto pra casa de mãos vazias; seria dar a notícia ruim sem precisar.",
]
D["c1_porta_saida_wait"] = [
    "Eu ainda não olhei o fundo da biblioteca. Tem uma luz azul que mexe, lá no canto. Uma televisão, parece.",
    "Não custa dar uma volta antes de ir.",
]
D["c1_porta_saida_ok"] = [
    "Pego a caixa nos dois braços e ajeito o peso. A porta abre pra um dia mais baixo do que quando eu entrei.",
]

# =============================================================== DISTRIBUIÇÃO
D["c1_helena_1"] = [
    "Atrás do balcão, uma mulher de cardigã verde-petróleo, óculos presos a um cordão e cabelo em um coque que desafia a gravidade confere uma lista, a caneta presa entre os dedos.",
    "Helena: Cartão. {w=0.3}",
    "Entrego. Ela lê sem olhar pra mim. A caneta anda pela linha como se tivesse medo de pisar fora.",
    "Helena: Hader. Rua do Moinho, catorze. Três pessoas, quinzena. {w=0.5}",
    "Ela levanta os olhos por cima dos óculos.",
    "Helena: Hader. Você é filho do homem que devolve os livros no prazo?",
    ask("Alen", "", [opt("Sou. Ele lia mais do que falava.", go="s"), opt("Sou. Mas eu nunca olhei o prazo.", go="p", face="sarcastico"), opt("(Assentir.)", say="Assinto. Não sei por que a garganta travou.", narr=True, go="a", face="envergonhado")]),
    "@s",
    "Helena: Eu sei. {w=0.4}Os melhores leitores falam pouco.",
    "->c",
    "@p",
    "Helena: Ele olhava por você. {w=0.4}Quinze anos sem um atraso. Eu guardei a ficha dele. Devia estar em exposição.",
    "->c",
    "@a",
    "Helena: Eu sei. {w=0.4}A gente não precisa falar disso agora.",
    "@c",
    "Helena: Ele não anda bem, não é?",
    "Alen: Não.",
    "Helena: Eu soube quando o livro parou de voltar. {w=0.5}Não me importa o livro. Me importa a pessoa.",
    "Ela diz isso rápido, sem olhar. Como quem sabe que se parar, não consegue continuar.",
    "Helena: Vamos ao que importa. {w=0.4}Arroz, feijão, óleo, leite em pó. O sal acabou semana passada; hoje vai açúcar mascavo. Sua mãe vai achar o gosto curioso.",
    "Ela faz um sinal com a cabeça. Um rapaz de colete azul, que eu já vi na porta, aparece com uma caixa de papelão, amarrada com barbante.",
    br("c1_bread", "p1", "p0"),
    "@p1",
    "Helena: E isso? {w=0.4}",
    "Alen: Pães. Da Dona Íris. Ela disse que a senhora já sabe.",
    "Helena: {w=0.8}Aquela mulher vai me matar de afeto. {w=0.4}Cinco pães quentes. {w=0.5}Ela deve ter aberto o último saco de farinha só pra isso.",
    "Ela fica um segundo em silêncio, a mão no saco, sentindo o calor.",
    "Helena: Espera. {w=0.4}",
    "Ela se vira, abre uma gaveta de metal e tira uma lata com um rótulo desbotado: pêssego em calda.",
    "Helena: Isso é de uma doação de setembro. Estava guardada pra quando alguém merecesse. {w=0.6}Hoje alguém merece.",
    "Alen: Eu só carreguei o saco.",
    "Helena: A gente nunca sabe quando uma coisa pequena é grande. {w=0.4}Leva.{set=c1_peach}",
    "->p2",
    "@p0",
    "Ela confere os itens da caixa com um dedo, como quem reza, e passa o barbante duas vezes.",
    "@p2",
    "Helena: Assina aqui. E aqui. E aqui. {w=0.5}Eles gostam de assinatura.",
    "Assino três vezes. Na terceira, minha letra já parece outra pessoa.",
    "Ela carimba o cartão: um carimbo azul, “RETIRADO”, na data de hoje.",
    ask("Alen", "", [opt("A senhora mantém uma lista de remédios?", go="m"), opt("Obrigado, dona Helena.", go="o")]),
    "@m",
    "Helena: Mantenho. Nome, dosagem, quem precisa. {w=0.4}Você tem a receita?",
    "Alen: A minha mãe tem. E o meu pai.",
    "Helena: Dois. {w=0.5}Então são o 23 e o 24.",
    "Helena: O comboio de sexta pode trazer antibiótico. Pode trazer outra coisa. Eu não prometo. {w=0.6}Prometo anotar.",
    "Alen: Já é mais do que eu tinha.{set=c1_meds_listed}",
    "->z",
    "@o",
    "Helena: Não agradece. {w=0.4}A caixa é da cidade. Eu só fiscalizo.",
    "@z",
    "Helena: A sala de jogos fica depois das estantes. Não corre, não grita e não fala com o rapaz da televisão se ele estiver perdendo. Ele mente sobre os pontos.",
    "Alen: O rapaz da televisão?",
    "Helena: Você vai saber quando ver.{set=c1_food}",
    "Pego a caixa. É mais pesada do que eu pensei e mais leve do que eu precisava. {w=0.6}A mão da minha mãe já está nela, de algum jeito.",
]
D["c1_helena_2"] = [
    "Helena: O que mais?",
    "@hub",
    ask("Alen", "", [
        opt("Quem é o rapaz da televisão?", go="r"),
        opt("Como eu levo um livro emprestado?", go="l"),
        opt("O que tem no depósito?", go="d"),
        opt("Nada, obrigado.", go="n"),
    ]),
    "@r",
    "Helena: Chegou em novembro. Veio do norte. Come pouco, joga muito. Eu deixo.",
    "Helena: Ele cuida do console melhor que muito adulto cuida da própria casa. {w=0.4}Isso não é pouco.",
    "->hub",
    "@l",
    "Helena: Caderno de empréstimos, na mesa de leitura. Anota seu nome e o título. A biblioteca é de todo mundo; só pede pra devolver.",
    "Helena: E se perder, escreve uma carta explicando. Eu leio todas.",
    "->hub",
    "@d",
    "Helena: Remédio, fórmula pra bebê e o que eu não digo. {w=0.4}O Teixeira cuida da chave. A chave cuida dele.",
    "->hub",
    "@n",
    "Helena: Então vai, que a fila anda. {w=0.4}E Alen... {w=0.5}diz pro seu pai que a biblioteca guardou a ficha dele.",
]
D["c1_helena_ret"] = [
    "Helena: Ainda por aqui? {w=0.3}Não tem problema. Lugar quente é pra isso.",
    "Helena: Mas sua família está esperando, e uma caixa de comida esfria de um jeito diferente.",
]
D["c1_balcao_livro"] = [
    "O livro-caixa de Helena está aberto no balcão: colunas e colunas de nomes, em uma letra tão regular que parece impressa.",
    "Do lado, um papelzinho: “Hoje faltam: sal, açúcar, leite em pó (fórmula), lâmpadas, esperança. — Pedir à Prefeitura (de novo).”",
]
D["c1_balanca"] = [
    "Uma balança de mola, com o ponteiro tremendo em 3 kg, como quem faz um cálculo difícil.",
    "Alguém escreveu na base: “NÃO PRESSIONE O PRATO COM O DEDO. A BALANÇA SABE.”",
]
D["c1_tiago_caixas"] = [
    "Tiago: Cuidado, essa é a caixa de feijão. {w=0.4}Quem derruba feijão é obrigado a catar.",
    "Ele faz uma pilha de caixas com uma precisão incrível e um cuidado que parece quase carinho.",
    "Tiago: A gente chega às seis, saí às oito da noite. {w=0.4}Não é um trabalho. É um jeito de ficar de pé.",
]
D["c1_fila_dist"] = [
    "Uma mulher e um senhor na fila, esperando a vez. Ela segura um cartão. Ele segura outro. Os dois seguram com as duas mãos, como quem carrega um passarinho.",
    "Mulher: Dizem que hoje tem leite em pó.",
    "Velho: Dizem que tinha ontem também.",
    "Mulher: Pois então. A gente repete os boatos até eles virarem verdade.",
]

# =============================================================== DEPÓSITO
D["c1_deposito_porta"] = [
    "Uma porta de aço com grades, um cadeado enorme e um aviso vermelho: “ACESSO RESTRITO — SOMENTE PESSOAL AUTORIZADO.”",
    "Pela grade dá pra ver uma pilha de caixas militares e outra, menor, de caixas brancas com uma cruz azul. {w=0.5}Remédios, imagino.",
]
D["c1_teixeira_1"] = [
    "Um soldado de braços cruzados guarda a porta, olhando um ponto fixo em cima da minha cabeça.",
    "Sd. Teixeira: Acesso restrito.",
    ask("Alen", "", [opt("Eu só queria saber se tem remédio.", go="r"), opt("Eu não vou entrar.", go="n"), opt("(Ficar olhando as caixas.)", say="Olho as caixas brancas por um tempo mais longo do que a educação recomenda.", narr=True, go="o")]),
    "@r",
    "Sd. Teixeira: Quem cuida dos remédios é a Dona Helena. {w=0.4}Eu cuido da porta. A porta, por si só, não tem opinião.",
    "->z",
    "@n",
    "Sd. Teixeira: Ótimo. Então a gente se entende.",
    "->z",
    "@o",
    "Sd. Teixeira: Caixas brancas, caixas verdes. {w=0.4}Cada uma com um número. Só quem tem o número entra.",
    "@z",
]
D["c1_teixeira_2"] = [
    "Sd. Teixeira: Acesso restrito. {w=0.4}Mas pode olhar. Olhar não está no regulamento.",
]
D["c1_deposito_cartaz"] = [
    "Um cartaz colado ao lado da porta: “SEXTA: COMBOIO. TODOS AUTORIZADOS A ESPERAR.”",
    "A frase tem duas leituras e as duas são verdade.",
]

# =============================================================== ABRIGO
D["c1_lucia_1"] = [
    "Uma mulher sentada num colchão, com um bebê embrulhado em um pano de prato, balança o corpo de um jeito antigo, sem ritmo e com muito ritmo.",
    "Lúcia: Ela só dorme quando o aquecedor estala. {w=0.4}Eu já tentei cantar, contar, rezar. {w=0.4}Ela só confia no aquecedor.",
    ask("Alen", "", [opt("Ela é linda.", go="b"), opt("Ela tem quantos meses?", go="m"), opt("(Sorrir de longe.)", say="Eu sorrio sem fazer barulho. Parece a forma mais educada de dizer “oi” pra um bebê.", narr=True, go="z")]),
    "@b",
    "Lúcia: É. Também acho. {w=0.4}Mas ela ronca igual a minha avó.",
    "->z",
    "@m",
    "Lúcia: Quatro. {w=0.3}Nasceu em agosto. {w=0.4}Foi o último mês de gente nascendo sem medo.",
    "@z",
]
D["c1_lucia_2"] = [
    "Lúcia: Ela dormiu. {w=0.3}Shhh. {w=0.5}Fica assim. Cuidado com o pé.",
]
D["c1_anselmo"] = [
    "Um senhor dorme de boca aberta, embrulhado em um cobertor xadrez, com um livro no peito subindo e descendo.",
    "Ele ronca em ré menor. Tem uma melodia até, se a gente se esforçar.",
    "A etiqueta do cobertor diz “ANSELMO”. Embaixo, outra caligrafia: “(pra devolver depois que acordar)”.",
]
D["c1_criancas_cartas"] = [
    "Duas crianças jogam cartas em cima de um colchão, com uma pilha de botões como fichas.",
    "Pedro: Se você ganhar, eu devolvo o botão. {w=0.3}",
    "Lia: Ele não tem botão. {w=0.3}Ele perdeu tudo pra mim.",
    "Pedro: Eu tenho um de reserva.",
    "Lia: Esse é do meu casaco.",
    br("c1_candy", "cy", "cn"),
    "@cy",
    "Eu tenho a bala de menta no bolso. {w=0.5}",
    ask("Alen", "", [opt("Dar a bala pra Lia.", go="dl"), opt("Dividir entre os dois.", go="dd"), opt("Guardar.", go="gg")]),
    "@dl",
    "Lia olha a bala com a seriedade de quem recebe um diploma. Depois parte no meio com os dentes e dá a metade pro Pedro, sem dizer nada.",
    "Pedro: Isso não conta como devolver o botão.",
    "Lia: Conta como pagar a dívida.{set=c1_candy_given;c1_candy:0}",
    "->z",
    "@dd",
    "Corto a bala em dois pedaços com cuidado, usando os dentes e uma unha. As crianças olham como se eu fizesse mágica.",
    "Pedro: Uma bala só rende dois sorrisos!",
    "Lia: Rende uma conversa inteira.{set=c1_candy_given;c1_candy:0}",
    "->z",
    "@gg",
    "Guardo. Hoje a gente não precisa gastar tudo.",
    "->z",
    "@cn",
    "Pedro: Você joga?",
    "Alen: Eu só olho.",
    "Lia: Olhar também conta. {w=0.3}Mas não ganha.",
    "@z",
]
D["c1_rute_1"] = [
    "Dona Rute: Pra trás! O fogão é meu. {w=0.3}",
    "Uma mulher mais baixa que a chaleira que carrega, com um pano de prato no ombro e uma colher de pau, mexe uma panela de ferro em cima do aquecedor.",
    "Dona Rute: É chá de casca de laranja. Não pergunta de onde veio a laranja.",
    ask("Alen", "", [opt("De onde veio a laranja?", go="p", face="sarcastico"), opt("Posso provar?", go="t"), opt("Quem dá aula na Sala B?", go="s")]),
    "@p",
    "Dona Rute: Eu avisei.",
    "Ela me estende uma caneca mesmo assim. {w=0.4}O chá tem gosto de verão que foi guardado numa gaveta.",
    "->z",
    "@t",
    "Dona Rute: Se for rápido. A regra da casa é uma caneca por visita.",
    "Provo. É quente e doce em um jeito que eu não tinha reparado que estava com saudade.",
    "->z",
    "@s",
    "Dona Rute: Uma professora que chegou semana passada. Ela diz que dá aula pra quem tem vontade e pra quem não tem. {w=0.4}Eu vou nas duas.",
    "@z",
]
D["c1_rute_2"] = [
    "Dona Rute: Hoje é quinta. Quinta é dia de sopa de macarrão. {w=0.4}Quem não gosta aprende.",
]
D["c1_aquecedor"] = [
    "O aquecedor a lenha. A chaminé de lata passa por um buraco que alguém abriu na janela e vedou com um pano molhado.",
    "Dá pra ficar parado ali e sentir os dedos voltando a ser dedos.",
]
D["c1_desenhos"] = [
    "Desenhos de crianças presos na parede com fita. Casas, sóis, um cachorro azul, três bonecos de palito de mãos dadas.",
    "Em um deles, uma nave. {w=0.4}Em outro, uma nave. {w=0.4}No terceiro, uma nave com um robô enorme. Alguém tem um tema.",
]
D["c1_calendario_bib"] = [
    "Um calendário de DEZEMBRO 2008, com cada dia riscado em X. Alguém circulou o dia da sexta, o comboio.",
    "Alguém escreveu na margem: “Dia 19: a gente aguenta.” {w=0.4}O resto da margem está cheio de contas e anotações pequenas de gente que não perdeu a esperança de ser exata.",
]
D["c1_malas"] = [
    "Malas empilhadas ao lado de um colchão. Uma tem um nome e um endereço na etiqueta. O endereço não existe mais, mas a etiqueta insiste.",
]
D["c1_colchao"] = [
    "Um colchão arrumado com cuidado: lençol esticado, travesseiro afofado, um livro aberto de bruços. Sobre o livro, uma colher.",
    "Pessoas que perderam muita coisa se agarram a pequenas ordens.",
]
D["c1_lencol"] = [
    "Um lençol pendurado entre duas cordas separa dois colchões. Dos dois lados, ouço vozes baixas, um riso curto.",
    "É uma parede de pano. Mas é uma parede, e as pessoas respeitam.",
]

# =============================================================== ESTANTES
D["c1_book_contos"] = [
    "Na prateleira de ficção, entre uma capa azul e uma verde, uma lombada: “CONTOS DE OUTROS MUNDOS”.",
    "Abro. A primeira página tem um carimbo da biblioteca e, no cantinho, a ficha com três nomes de leitores. O terceiro é “Hader”.",
    "Viro até a última página. Alguém escreveu a lápis: “volto antes do verão”. A tinta está borrada. Não há nome.",
    "É a letra mais calma que eu li hoje.{set=c1_found_book}",
]
D["c1_book_dicionario"] = [
    "Um dicionário enorme, em cima de uma estante baixa, aberto numa página qualquer.",
    "A palavra no topo é “abrigo”. Três páginas depois, “acaso”. É a única coincidência que eu permito hoje.",
]
D["c1_book_atlas"] = [
    "Um atlas de capa dura, com todos os mapas ainda no lugar. Menos um. A página do norte foi arrancada, com cuidado, rente à costura.",
    "Não sei quem. Não sei por quê. Fecho o livro como quem fecha uma porta que alguém deixou entreaberta.",
]
D["c1_book_infantil"] = [
    "Na prateleira baixa, de criança, um livro de capa amarela: “O Urso que Esperava a Primavera”.",
    "Abro numa página. O urso olha a janela. A janela olha a neve. A neve não sabe de nada.",
    "Fecho. Não é pra mim, mas eu entendi o livro.",
]
D["c1_revista"] = [
    "Uma revista velha na estante de periódicos: “PIXEL CLUB nº 41 — Junho de 1998”. Na capa, uma nave azul.",
    "Abro na matéria: “Space Travelers: difícil, injusto e inesquecível. NOTA: 8,5.” Mais abaixo: “Another Concept lançou três jogos e nenhum sucesso. Existe um culto ao redor deles. Ainda não sabemos quantos membros.”",
    "No rodapé, em lápis, alguém acrescentou: “Dois.” {w=0.5}O lápis é de alguém que riu sozinho.",
    "{set=c1_read_mag}",
]
D["c1_guitar_box"] = [
    "Numa prateleira do alto, uma caixa chata e colorida: “GUITAR LEGENDS — PC CD-ROM — Another Concept.”",
    "A guitarra da capa tem o braço curto demais pra um humano. Mas o riso do guitarrista é perfeito.",
    "Na etiqueta da biblioteca: “Jogo de ritmo. Acompanha adaptador de guitarra (perdido).”",
    "Penso na guitarra encostada na parede do meu quarto. A que eu não toco faz tempo.{set=c1_guitar_seen}",
]
D["c1_fichario"] = [
    "Na ponta do balcão da recepção, uma caixa azul de fichas, com divisórias de A a Z. Abro na letra “H” por curiosidade. Dentro, uma ficha com um nome de família: o meu.",
    "“Hader. Empréstimos: 31. Atrasos: 0. Observação: ‘Devolve sempre com um marcador novo.’”",
    "Eu nunca soube dos marcadores. Fico um tempo lendo a observação.",
]
D["c1_mesa_leitura"] = [
    "Uma menina de uns dez anos lê um livro grosso com o dedo percorrendo as linhas, os lábios mexendo sem som.",
    "Ela me olha e levanta um dedo pra pedir silêncio, sério como um juiz. Eu concordo com a cabeça.",
]
D["c1_emprestimo"] = [
    "Sobre a mesa, o caderno de empréstimos, com uma caneta amarrada por um barbante. Na capa, a letra de Helena: “LEVE. DEVOLVA. NÃO PERCA. — H.”",
    "Eu viro as páginas. Nomes, datas, títulos. {w=0.6}A caneta me espera.",
    br("c1_item", "ja", "nada"),
    "@ja",
    "Meu nome já está numa linha. Posso trocar, se quiser.",
    "@nada",
    ask("", "O que levar para casa?", [
        opt("Levar GUITAR LEGENDS (jogo de ritmo, para o computador).", say="Escrevo “Hader” e “Guitar Legends” numa linha nova. A caneta faz um ruído de coisa decidida.", narr=True, set="c1_item:guitar", iff="c1_guitar_seen", go="fim"),
        opt("Levar CONTOS DE OUTROS MUNDOS (o livro do meu pai).", say="Escrevo “Hader” e “Contos de Outros Mundos”. Passo o dedo pela lombada e lembro da dobra no canto da página que não estava lá ontem.", narr=True, set="c1_item:book", iff="c1_found_book", go="fim"),
        opt("Não levar nada hoje.", say="Fecho o caderno. Hoje eu levo a caixa e as mãos cheias já bastam.", narr=True, set="c1_item:none", go="fim"),
        opt("Procurar mais um pouco antes de decidir.", say="Ainda não. Tem coisa pra olhar nas estantes.", narr=True, go="fim"),
    ], echo=True),
    "@fim",
]

# =============================================================== CANTO DE ENTRETENIMENTO
D["c1_tv_luz"] = [
    "No fundo da biblioteca, uma luz azul que mexe. Ela faz sombra nas estantes de um jeito que as sombras se movem à frente das coisas que estão paradas.",
    "Um som fraquinho de música de oito notas se repete, alegre e teimosa, como um ruído de passarinho eletrônico.",
]
D["c1_tv"] = [
    "Uma televisão de tubo sobre um carrinho de feira. Na tela, uma nave azul e minúscula dispara luzes contra robôs cinzentos e enormes.",
    "No canto da tela, uma palavra pisca: “SPACE TRAVELERS”. Em letras menores: “© ANOTHER CONCEPT”. {w=0.4}O resto é cheio de ruído e de escuridão boa.",
]
D["c1_console"] = [
    "Um console cinza de plástico gasto, com dois controles de fios longos e embolados. Alguém costurou um pedaço de fita no cabo de um deles, com todo o cuidado.",
    "Na fita, um nome: “DONA HELENA: ESTE É DA BIBLIOTECA. NÃO PUXE PELO FIO.”",
]
D["c1_cartuchos"] = [
    "Uma prateleira com cartuchos de jogos, em fila: “SPACE TRAVELERS”, “GUITAR LEGENDS”, “MUNDO DE TINTA”, “CORRIDA NOTURNA 3”.",
    "Todos têm o círculo com uma linha no meio, o logotipo da Another Concept. Parece um olho fechado.",
    "Embaixo, um bilhete: “JOGOS (CUIDEM DELES). — H.”",
]
D["c1_cartucho_space"] = [
    "O cartucho de Space Travelers está na prateleira, vazio. {w=0.4}O que está no console deve ser a cópia da biblioteca.",
    "Tem uma etiqueta: “NÃO EMPRESTAR: O CONSOLE É O ÚNICO NA CIDADE.”",
    "Quem leva o jogo leva a metade. A outra metade fica aqui.",
]
D["c1_poster_another"] = [
    "Um pôster: um círculo atravessado por uma linha, como um olho fechado, e estrelas ao redor. “ANOTHER CONCEPT.”",
    "Alguém escreveu a lápis embaixo: “Sonhos pequenos, bem feitos.”",
]
D["c1_pufe"] = [
    "Dois pufes velhos e um tapete de retalhos em tons de roxo. Tem uma marca em um dos pufes onde alguém passa horas por dia.",
    "No outro, uma manta dobrada com capricho. Parece de visita.",
]

D["c1_oliv_intro"] = [
    "O fundo da biblioteca tem uma luz azul que mexe. Uma televisão de tubo sobre um carrinho, um console cinza, fios por todo lado.",
    "Na frente, sentado de qualquer jeito num pufe, um garoto de cachecol laranja e cabelo castanho bagunçado. Controle nas duas mãos. Costas curvas. Uma perna balançando no ritmo de um jogo que eu não conheço.",
    "Na tela, uma nave azul minúscula desvia de robôs enormes.",
    "Garoto: Se você está esperando eu perder, vai ficar aí até amanhã. {w=0.6}",
    "Alen: Eu nem sei o que você está jogando.",
    "Garoto: Melhor ainda. Assim você não vai entender como eu consegui perder.",
    "Alen: Você acabou de dizer que não ia perder.",
    "Garoto: E você acabou de descobrir que não deve acreditar em tudo que ouve. {w=0.6}",
    "Ele não tira os olhos da tela. Mas o canto da boca se mexe um pouco. Um pixel só.",
    "Na tela, a nave explode em quatro pedaços e uma musiquinha de oito notas afunda, triste.{sfx=game_lose}",
    "Garoto: ...Isso não conta. Eu estava conversando.",
    "Alen: Então a culpa é minha.",
    "Garoto: É. Anota aí. {w=0.5}",
    "Ele larga o controle no colo. Pela primeira vez me olha de verdade, de cima a baixo, rápido, e acha uma conclusão que não conta.",
    "Garoto: Quantos anos? Doze?",
    "Alen: Dezesseis.{f=irritado}",
    "Garoto: Parece doze.",
    "Alen: E você?",
    "Garoto: Dezoito. {w=0.4}Não é muita diferença, mas hoje eu me sinto bem mais velho. É só uma sensação. Ignora.",
    "Garoto: Você vai ficar aí em pé me olhando perder ou tem nome?",
    "Alen: Alen.",
    "Olivier: Olivier. {w=0.4}Não aperta a mão, tô com o controle.{set=c1_oliv_met;c1_oliv_named}",
    "Ele não sorri, mas a perna para de balançar. Isso, nele, deve ser uma espécie de sorriso.",
]

D["c1_oliv_hub"] = [
    br("c1_played", "hub_pos", "hub_pre"),
    # ---------------- antes de jogar
    "@hub_pre",
    ask("Alen", "", [
        opt("Que jogo é esse?", go="g"),
        opt("Vi o cartaz dele numa locadora.", go="loc", iff="c1_saw_space", ifnot="c1_loc_talked"),
        opt("Vi uma nave desenhada num vidro, num beco.", go="nave", iff="c1_saw_ship", ifnot="c1_ship_told"),
        opt("Posso ver mais um pouco?", go="ver", ifnot="c1_watched"),
        opt("Posso tentar?", go="tentar"),
        opt("Eu preciso ir. Tenho uma caixa pra levar.", go="despedida", iff="c1_food", ifnot="c1_oliv_bye"),
        opt("(Voltar depois.)", go="sair"),
    ]),
    "@g",
    "Olivier: Space Travelers. {w=0.4}Uma nave, três vidas, uns oito tipos de robô que não gostam de visita. {w=0.4}Você atira, desvia, atira de novo. No fim tem um chefe que parece um fogão com raiva.",
    "Alen: Parece fácil.",
    "Olivier: É. {w=0.6}Parece.",
    "Alen: Quem fez?",
    "Olivier: Another Concept. Três jogos, nenhum sucesso. {w=0.4}Tem gente que diz que foi de propósito.",
    "Olivier: Esse eu achei aqui, no fundo da prateleira, com um bilhete dizendo “cuidem”. {w=0.4}Cuidei. Mais ou menos.",
    "->hub_pre",
    "@loc",
    "Olivier: Vídeo Ponto? {w=0.6}Você entrou lá? {w=0.5}Dentro?",
    "Alen: Entrei. Só tinha o cartaz e uma caixa de devolução.",
    "Olivier: ...Tá. {w=0.8}O cartaz ainda está inteiro?",
    "Alen: Está.",
    "Olivier: Bom. {w=0.5}Alguém devia ter levado aquele. {w=0.4}Mas bom.{set=c1_loc_talked}",
    "->hub_pre",
    "@nave",
    "Olivier: {w=0.9}Muita gente desenha nave.",
    "Alen: A mão estava bem treinada.",
    "Olivier: {w=0.8}É o desenho que a mão faz quando está entediada. {w=0.6}E quando não tem mais o que desenhar.",
    "Ele continua de olho na tela, mas a orelha esquerda ficou da cor do cachecol.",
    "Olivier: Você quer jogar ou não?{set=c1_ship_told}",
    "->hub_pre",
    "@ver",
    "Olivier: Pode. {w=0.3}Fica de pé, que o pufe é meu. E não toca no cabo; ele só funciona de ódio.",
    "Ele recomeça a fase. Eu nunca vi alguém jogar assim. Ele não mexe só os dedos: mexe o ombro, o pescoço, a boca em silêncio, como se cada tiro custasse alguma coisa.",
    "Os robôs vêm em fila. Ele atira, atira, desvia pra esquerda por um fio, atira de novo. {w=0.5}Em algum momento eu percebo que estou prendendo a respiração.",
    "Olivier: Respira. É feio ver gente azul.{set=c1_watched}",
    "->hub_pre",
    "@tentar",
    "Olivier: Hum. {w=0.5}Quer mesmo?",
    "Alen: Quero.",
    "Olivier: Regras. Três vidas, sem pausa, sem choro. Se quebrar o controle, assume a dívida.",
    "Alen: A dívida de quem?",
    "Olivier: Da biblioteca. Mas eu cobro pela biblioteca.",
    "Olivier: Setas movem. O botão que lá fora você chama de “interagir”, aqui é “atirar”. Segura que ele atira sozinho. {w=0.4}Segura.",
    "Ele estende o controle com as duas mãos, como se eu fosse receber um bebê. Eu recebo com as duas também.{set=c1_play_now}",
    "END",
    "@sair",
    "Olivier: Quando voltar eu ainda estou aqui. {w=0.4}Ou o jogo está. É a mesma coisa.",
    "END",
    # ---------------- depois de jogar
    "@hub_pos",
    ask("Alen", "", [
        opt("Quem criou esse jogo? A Another Concept?", go="ac", ifnot="c1_ac_talked"),
        opt("Você é de onde?", go="norte", ifnot="c1_north_talked"),
        opt("Eu tenho uma guitarra em casa.", go="gl", iff="c1_guitar_seen", ifnot="c1_gl_talked"),
        opt("Quero jogar de novo.", go="de_novo"),
        opt("Eu preciso ir. Tenho uma caixa pra levar.", go="despedida", iff="c1_food", ifnot="c1_oliv_bye"),
        opt("(Voltar depois.)", go="sair2"),
    ]),
    "@ac",
    "Olivier: Três jogos. Um de nave, um de guitarra, um de tinta. {w=0.4}Todos fizeram sucesso em exatamente quatro casas.",
    "Olivier: Dizem que foram dois caras num apartamento. Que o logotipo é um olho fechado porque eles dormiam pouco. {w=0.5}Eu acho que é porque eles queriam que a gente sonhasse sem precisar abrir.",
    "Alen: Isso é bonito.",
    "Olivier: É uma teoria. Não é uma verdade. {w=0.4}Mas é a minha.{set=c1_ac_talked}",
    "->hub_pos",
    "@norte",
    "Olivier: Do norte.",
    "Alen: Norte de onde?",
    "Olivier: {w=0.8}De lá.",
    "Ele diz “lá” do jeito que alguém diz um endereço que não existe mais. Mais nada. A tela continua piscando.",
    ask("Alen", "", [opt("Tá.", say="Tá. {w=0.4}Eu também tenho uma lista de coisas que eu não respondo.", go="n1"), opt("E sua família?", go="n2")]),
    "@n1",
    "Olivier: {w=0.8}Você não insiste.",
    "Alen: Não gosto quando fazem comigo.",
    "Olivier: {w=0.6}Hm. {w=0.5}Isso é raro. {w=0.4}Guarda esse jeito.",
    "Olivier: Cheguei faz três semanas. Durmo ali — {w=0.3}perto do aquecedor; eu não sou bobo. {w=0.4}O resto, um dia. Ou não.{set=c1_north_talked;c1_oliv_trust}",
    "->hub_pos",
    "@n2",
    "Olivier: Troca de assunto. {w=0.6}Você joga mal, aliás.",
    "Alen: Eu joguei uma vez.",
    "Olivier: Pior ainda.",
    "Ele ri. É uma risada curta, de quem estava treinando pra não rir. {w=0.4}Eu entendi o recado e deixei quieto.{set=c1_north_talked}",
    "->hub_pos",
    "@gl",
    "Olivier: Você toca?",
    "Alen: Tocava. {w=0.4}Ela está encostada no quarto faz tempo.",
    "Olivier: Então pega o Guitar Legends. É um jogo de ritmo; roda no computador. {w=0.4}Não é empréstimo oficial. Mas a Dona Helena anota tudo num caderno, e se você devolver, ela esquece que você levou.",
    "Alen: E o seu?",
    "Olivier: O meu é este. {w=0.4}O console é um só na cidade. {w=0.5}Quem leva o jogo leva a metade. A outra metade fica aqui.{set=c1_gl_talked}",
    "->hub_pos",
    "@de_novo",
    "Olivier: Quero ver se melhora. {w=0.4}Dedos, vai.",
    "Ele me passa o controle sem cerimônia desta vez.{set=c1_play_now}",
    "END",
    "@sair2",
    "Olivier: Quando voltar eu ainda estou aqui. {w=0.4}Ou o jogo está.",
    "END",
    # ---------------- despedida (levar a caixa pra casa)
    "@despedida",
    "Olivier: A caixa de ração. {w=0.6}Certo. {w=0.4}Quem está em casa?",
    "Alen: Meus pais. Estão doentes.",
    "Olivier: {w=0.8}Então vai. {w=0.4}Não faz cara de pena; eu não vou fazer a minha.",
    "Alen: Eu não estava fazendo.",
    "Olivier: Estava. Era pequena. {w=0.5}Eu gostei.",
    "Ele revira o bolso do casaco e tira uma barra de cereal embrulhada, amassada, velha.",
    "Olivier: Toma. Pro caminho.",
    "Alen: Não precisa.",
    "Olivier: Eu sei que não precisa. {w=0.6}É a metade que eu não ia comer.",
    "Parto a barra no meio e a metade dele continua intacta no embrulho. Ele nunca ia comer. {w=0.6}Ele guardou a barra inteira pra alguém.",
    "Alen: Obrigado.",
    "Olivier: Não agradece. É troca. {w=0.5}Você volta e termina a fase.",
    "Alen: Tá combinado.",
    "Olivier: Eu fico por aqui. {w=0.4}Quase sempre.",
    "Alen: Quase?",
    "Olivier: Depende de quanto o aquecedor estiver a fim.{set=c1_biscuit;c1_oliv_bye}",
]

D["c1_oliv_before_game"] = [
    "O console faz um clique. A tela pisca e a musiquinha de oito notas recomeça. {w=0.4}É uma música feita pra não deixar ninguém desistir.",
    "Olivier: {w=0.5}Quando eu falo “agora”, você aperta. Mas só depois.",
    "Alen: Isso não é uma instrução.",
    "Olivier: É a única que eu tenho.",
]

D["c1_oliv_after_win_clean"] = [
    "Olivier: {w=1.0}...Você nunca jogou isso, né?",
    "Alen: Nunca.",
    "Olivier: {w=0.6}Mentiroso. {w=0.5}Ninguém passa a fase um sem perder uma vida. Eu perdi doze.",
    "Alen: Eu tive sorte.",
    "Olivier: Sorte não desvia daquele atirador do canto. {w=0.5}...Tá. Foi sorte. Mas sorte com dedos.",
]
D["c1_oliv_after_win"] = [
    "Olivier: Passou. {w=0.5}Perdeu vida, mas passou. {w=0.4}É o jeito certo: com cicatriz.",
    "Alen: Parecia mais fácil de fora.",
    "Olivier: Tudo parece mais fácil de fora. {w=0.5}Anota. É a única lei do universo que eu tenho certeza.",
]
D["c1_oliv_after_lose"] = [
    "Olivier: Três vidas, e a terceira durou menos que a segunda. {w=0.5}",
    "Alen: Eu avisei que era péssimo.",
    "Olivier: Você não avisou nada. {w=0.4}Tudo bem. Eu perdi doze vezes no primeiro dia. Esse jogo é feito pra isso.",
    "Alen: Doze?",
    "Olivier: Quinze. {w=0.4}Fica entre nós.",
]
D["c1_oliv_after_quit"] = [
    "Olivier: Saiu no meio? {w=0.4}Sem pena. Mas o jogo não tem pausa. {w=0.5}Isso é uma lei.",
    "Alen: Tinha cara de que ia me derrotar.",
    "Olivier: Tem cara de que derrota todo mundo. {w=0.4}Isso é o charme.",
]
D["c1_oliv_boom"] = [
    "Longe, bem longe, algo bate duas vezes. Grave. O vidro da janela mais alta estremece num ruído que a gente aprende a não notar.{sfx=boom_far}",
    "Olivier ficou parado. Não é um susto grande. É um tipo de pausa: o corpo inteiro se calando por dentro.",
    "Os dedos dele no controle estão brancos nos nós. {w=0.8}",
    "Alen: ...Olivier?",
    "Olivier: {w=0.9}Tô aqui. {w=0.6}Só pensando no próximo movimento.",
    "Ele respira fundo e solta o ar devagar, como quem conta. Depois se vira de novo pra tela, rápido demais.",
    ask("Alen", "", [opt("Quer que eu fale de outra coisa?", go="o"), opt("(Ficar ao lado dele, em silêncio.)", say="Não pergunto. Fico ao lado dele, olhando a tela, até o barulho do jogo cobrir o resto.", narr=True, go="s")]),
    "@o",
    "Olivier: {w=0.6}Fala de qualquer coisa. De tijolo. De sopa. Do seu cachecol.",
    "Alen: Foi meu pai que me deu.",
    "Olivier: {w=0.6}É um bom cachecol.",
    "->z",
    "@s",
    "Ele não agradece. Mas, depois de um tempo, empurra o pufe uns dois dedos na minha direção.",
    "@z",
    "Depois de um tempo, a musiquinha recomeça e a gente volta a ser só dois garotos diante de uma tela azul.{set=c1_boom_done;c1_oliv_trust}",
]
