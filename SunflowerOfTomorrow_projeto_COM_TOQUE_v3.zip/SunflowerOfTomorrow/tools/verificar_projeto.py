"""Verificação estática do projeto (não substitui abrir na Godot). Uso: python3 tools/verificar_projeto.py"""
import re, os, json, glob, sys
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
os.chdir(ROOT)
errs, warns = [], []
gd = glob.glob("scripts/**/*.gd", recursive=True)
tscn = glob.glob("scenes/**/*.tscn", recursive=True)
OPTIONAL = {"res://assets/fonts/ui.ttf"}

# 1) indentação
for f in gd:
    for i, l in enumerate(open(f, encoding="utf-8"), 1):
        if "\t" in l: errs.append(f"{f}:{i}: tabulação (use 4 espaços)")
        s = len(l) - len(l.lstrip(" "))
        if l.strip() and s % 4: errs.append(f"{f}:{i}: indentação não múltipla de 4")

# 2) caminhos res://
texts = {f: open(f, encoding="utf-8").read() for f in gd + tscn + ["project.godot"]}
for f, t in texts.items():
    t_nocomment = "\n".join(l for l in t.splitlines() if not l.strip().startswith("#"))
    for p in set(re.findall(r'res://[^\s"\')\]]+', t_nocomment)):
        if "*" in p or "..." in p: continue
        p = p.rstrip(",.;")
        if p in OPTIONAL or p.endswith("/"): continue
        if "%d" in p or "%s" in p:                       # padrões montados em código: confere todas as variantes
            variants = [p.replace("%d", str(i)) for i in range(1, 6)] if "%d" in p else [p]
            ok = True
            for v in variants:
                if "%s" in v:
                    if not glob.glob(v.replace("res://", "").replace("%s", "*")): ok = False
                elif not os.path.exists(v.replace("res://", "")): ok = False
            if not ok: errs.append(f"{f}: variantes inexistentes para {p}")
            continue
        if not os.path.exists(p.replace("res://", "")): errs.append(f"{f}: caminho inexistente {p}")

# 3) diálogos
db = {}
for f in glob.glob("data/dialogue/*.json"):
    d = json.load(open(f, encoding="utf-8"))
    for k, v in d.items():
        if k in db: errs.append(f"id de diálogo duplicado: {k}")
        db[k] = v
for k, d in db.items():
    nodes = d["nodes"]
    if d["start"] not in nodes: errs.append(f"{k}: start inexistente")
    for nid, n in nodes.items():
        refs = []
        if "branch" in n: refs += [n["branch"]["yes"], n["branch"]["no"]]
        else:
            if "choices" in n: refs += [c.get("next", "") for c in n["choices"]]
            else: refs.append(n.get("next", ""))
        for r in refs:
            if r and r not in nodes: errs.append(f"{k}.{nid}: next/branch inexistente '{r}'")
    reach, todo = set(), [d["start"]]
    while todo:
        x = todo.pop()
        if x in reach or x not in nodes: continue
        reach.add(x); n = nodes[x]
        if "branch" in n: todo += [n["branch"]["yes"], n["branch"]["no"]]
        elif "choices" in n: todo += [c.get("next", "") for c in n["choices"]]
        else: todo.append(n.get("next", ""))
    for nid in nodes:
        if nid not in reach: warns.append(f"{k}.{nid}: nó inalcançável")
allsrc = "\n".join(texts[f] for f in gd)
used = set(re.findall(r'Dialogue\.play\(\s*(?:"([a-z_0-9]+)")', allsrc))
for m in re.findall(r'\[((?:"[a-z_0-9]+"(?:,\s*)?)+)\]', allsrc): used |= set(re.findall(r'"([a-z_0-9]+)"', m))
used |= set(re.findall(r'"(notice_board|notice_again)"', allsrc))
for u in used:
    if u not in db and re.fullmatch(r"[a-z]+(_[a-z0-9]+)+", u) and u in ("bed_1","photo_1","plant_1","door_ready","marcus_intro","eleanor_intro","plant_end","seed_find"): errs.append(f"diálogo usado e inexistente: {u}")
# ids passados a add_interactable
for ids in re.findall(r'add_interactable\([^)]*?\[([^\]]*)\]', allsrc):
    for i in re.findall(r'"([a-z_0-9]+)"', ids):
        if i not in db: errs.append(f"add_interactable usa diálogo inexistente: {i}")
for i in re.findall(r'Dialogue\.play\("([a-z_0-9]+)"\)', allsrc):
    if i not in db: errs.append(f"Dialogue.play usa id inexistente: {i}")
# 4) sons referenciados
am = texts["scripts/audio/audio_manager.gd"]
sfx_ids = set(re.findall(r'^\s+"([a-z_0-9]+)": "res://assets/audio/sfx', am, re.M))
amb_ids = set(re.findall(r'^\s+"([a-z_0-9]+)": "res://assets/audio/ambience', am, re.M))
grp = set(re.findall(r'^\s+"(step_[a-z]+)":', am, re.M))
for i in re.findall(r'play_sfx\("([a-z_0-9]+)"', allsrc) + [x for ids in re.findall(r'"sfx": "([a-z_0-9]+)"', json.dumps(db)) for x in [ids]]:
    if i not in sfx_ids: errs.append(f"sfx inexistente: {i}")
for i in re.findall(r'(?:play_ambience|make_positional)\([^"]*"([a-z_0-9]+)"', allsrc):
    if i not in amb_ids: errs.append(f"ambiente inexistente: {i}")
for i in re.findall(r'start_occasional\(\[([^\]]*)\]', allsrc):
    for x in re.findall(r'"([a-z_0-9]+)"', i):
        if x not in sfx_ids: errs.append(f"sfx ocasional inexistente: {x}")
for s in re.findall(r'surface = "([a-z]+)"', allsrc):
    if "step_" + s not in grp: errs.append(f"superfície sem passos: {s}")
# 5) padrões perigosos
for f in gd:
    for i, l in enumerate(open(f, encoding="utf-8"), 1):
        if re.search(r':=\s*[\w\.]+\.get\(', l) or re.search(r':=\s*_?\w+\[["\w]', l) and "Array" not in l and "range" not in l:
            warns.append(f"{f}:{i}: ':=' com valor Variant? -> {l.strip()[:70]}")
print(f"{len(gd)} scripts, {len(tscn)} cenas, {len(db)} diálogos, {len(sfx_ids)} sfx, {len(amb_ids)} ambientes")
for w in warns: print("AVISO:", w)
for e in errs: print("ERRO:", e)
print("RESULTADO:", "OK" if not errs else f"{len(errs)} erro(s)")
sys.exit(1 if errs else 0)
