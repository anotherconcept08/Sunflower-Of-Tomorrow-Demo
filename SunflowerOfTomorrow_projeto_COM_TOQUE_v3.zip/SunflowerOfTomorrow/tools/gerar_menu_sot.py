"""Prepara a arte do novo menu principal a partir da imagem de referência (tools/arte/menu_referencia.png, 1672x941).
Gera em assets/ui/menu/:
  sot_bg.png     – cenário limpo (sem logotipo, opções e frase; essas partes são desenhadas pelo jogo)
  sot_logo.png   – logotipo extraído, com transparência
  sot_depth.png  – mapa de profundidade (claro = perto) usado pelo shader de parallax
  sot_sky.png    – máscara do céu (onde as nuvens pintadas derivam)
Uso: python3 tools/gerar_menu_sot.py       (requer numpy, pillow e opencv)"""
import os, numpy as np, cv2
from PIL import Image, ImageDraw
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.join(HERE, "..")
OUT = os.path.join(ROOT, "assets", "ui", "menu") + os.sep
ref = cv2.imread(os.path.join(HERE, "arte", "menu_referencia.png")); H, W = ref.shape[:2]
gray = cv2.cvtColor(ref, cv2.COLOR_BGR2GRAY).astype(np.float32)


def stroke_mask(x0, y0, x1, y1, thr=10.0, blur=17, grow=5):
    """Pixels claros e finos (texto, molduras) dentro de um retângulo: diferença para o fundo desfocado."""
    m = np.zeros((H, W), np.uint8)
    bg = cv2.GaussianBlur(gray, (0, 0), blur / 3.0)
    d = gray - bg
    sel = (d > thr)
    sub = np.zeros_like(sel); sub[y0:y1, x0:x1] = sel[y0:y1, x0:x1]
    m[sub] = 255
    return cv2.dilate(m, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (grow, grow)))


# ---- máscaras do que está "embutido" na referência
mask = np.zeros((H, W), np.uint8)
logo_box = (38, 110, 712, 348)
bx0, by0, bx1, by1 = logo_box
rgb = cv2.cvtColor(ref, cv2.COLOR_BGR2RGB).astype(np.float32)
Rr, Gg, Bb = rgb[..., 0], rgb[..., 1], rgb[..., 2]
lg = np.zeros((H, W), bool)
lg[by0:by1, bx0:bx1] = (gray[by0:by1, bx0:bx1] > 62) | ((Gg > Rr + 6) & (Gg > Bb + 6) & (gray > 22))[by0:by1, bx0:bx1]   # letras, girassol e folhas
mask[lg] = 255
mask = cv2.dilate(mask, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (9, 9)))
cv2.circle(mask, (437, 221), 66, 255, -1)                                           # girassol do logotipo (centro escuro inclusive)
mask |= stroke_mask(bx0, 106, bx1, 126, thr=5.0)                                    # fio superior do painel
mask |= stroke_mask(bx0, 330, bx1, 350, thr=5.0)                                    # fio inferior do painel
mask |= stroke_mask(56, 366, 446, 640, thr=8.0)                                     # lista de opções, moldura e seta
mask |= stroke_mask(56, 366, 446, 640, thr=-3.0, blur=5, grow=3) & cv2.rectangle(np.zeros((H, W), np.uint8), (98, 368), (420, 416), 255, -1)  # miolo da moldura
mask |= stroke_mask(60, 688, 345, 825, thr=8.0)                                     # frase e autoria
mask = cv2.dilate(mask, np.ones((3, 3), np.uint8))

# ---- limpeza por inpaint (as áreas são finas: letras ~14 px; o fundo ali é escuro e liso)
clean = cv2.inpaint(ref, mask, 7, cv2.INPAINT_TELEA)
rng = np.random.default_rng(7)
grain = rng.normal(0, 1.6, (H, W, 1)).astype(np.float32)
mk = (cv2.GaussianBlur(mask.astype(np.float32) / 255.0, (0, 0), 3))[..., None]
clean = np.clip(clean.astype(np.float32) + grain * mk, 0, 255).astype(np.uint8)
# o painel do logotipo era levemente mais claro que o resto: nivela (só onde o fundo é quase preto)
panel = np.zeros((H, W), np.float32); panel[bx0 - 6 + 4:bx1 + 4, :0] = 0
panel[by0 + 2:by1 - 2, bx0 + 2:bx1 - 2] = 1.0
panel = cv2.GaussianBlur(panel, (0, 0), 10)
cl = clean.astype(np.float32); lum_c = cl.mean(axis=2)
dark = np.clip((38.0 - lum_c) / 22.0, 0, 1)
cl -= (4.6 * panel * dark)[..., None]
clean = np.clip(cl, 0, 255).astype(np.uint8)
cv2.imwrite(OUT + "sot_bg.png", clean)

# ---- logotipo com transparência (diferença entre a referência e o fundo limpo)
x0, y0, x1, y1 = 60, 146, 716, 322
a = ref[y0:y1, x0:x1].astype(np.float32); b = clean[y0:y1, x0:x1].astype(np.float32)
diff = np.abs(a - b).max(axis=2)
alpha = np.clip((diff - 14.0) / 46.0, 0, 1)
alpha = cv2.GaussianBlur(alpha, (0, 0), 0.6)
al3 = np.maximum(alpha, 1e-3)[..., None]
col = np.clip((a - (1 - al3) * b) / al3, 0, 255)
# o painel escuro da referência deixa um véu fraco: zera alpha muito baixo e dark-on-dark (não é letra)
lum = col.mean(axis=2)
alpha[(alpha < 0.35) & (lum < 70)] = 0
rgba = np.dstack([col[..., ::-1], alpha * 255]).astype(np.uint8)            # BGR -> RGB
ys, xs = np.where(alpha > 0.05)
pad = 4
box = (max(xs.min() - pad, 0), max(ys.min() - pad, 0), min(xs.max() + pad, rgba.shape[1]), min(ys.max() + pad, rgba.shape[0]))
logo = Image.fromarray(rgba, "RGBA").crop(box)
logo.save(OUT + "sot_logo.png"); print("logo", logo.size, "origem na referência", (x0 + box[0], y0 + box[1]))

# ---- mapa de profundidade (0 = longe, 1 = perto)
depth = np.zeros((H, W), np.float32)
yy = np.arange(H, dtype=np.float32)[:, None] * np.ones((1, W), np.float32)
depth = np.where(yy < 300, 0.0, 0.18 + 0.30 * np.clip((yy - 300) / 520.0, 0, 1)).astype(np.float32)      # céu longe; chão da cidade ganha profundidade
img = Image.new("L", (W, H), 0); d = ImageDraw.Draw(img)


def poly(pts, v):
    d.polygon(pts, fill=int(v * 255))


# estrutura da direita (poste, placa de racionamento, parede) e o parapeito de neve
poly([(1500, 0), (1672, 0), (1672, 941), (1500, 941)], 0.92)
poly([(1425, 0), (1455, 0), (1455, 760), (1425, 760)], 0.88)                 # poste fino
poly([(0, 868), (1672, 835), (1672, 941), (0, 941)], 0.85)                     # neve da frente
# Alen (silhueta aproximada) e mochila: o mais perto
poly([(1292, 500), (1300, 450), (1340, 425), (1390, 430), (1410, 480), (1405, 530), (1480, 565), (1510, 680), (1505, 760), (1440, 790), (1360, 800), (1250, 820), (1170, 820), (1180, 780), (1220, 720), (1240, 670), (1250, 620), (1300, 540)], 1.0)
# girassol, cerca quebrada e neve do canto esquerdo
poly([(430, 560), (520, 545), (610, 575), (615, 640), (570, 690), (540, 720), (545, 830), (480, 860), (430, 830), (440, 740), (420, 650)], 0.80)
poly([(330, 620), (400, 610), (420, 880), (340, 900)], 0.74)
poly([(0, 760), (700, 800), (700, 941), (0, 941)], 0.80)
dm = np.array(img, np.float32) / 255.0
depth = np.maximum(depth, dm)
depth = cv2.GaussianBlur(depth, (0, 0), 7)
Image.fromarray((np.clip(depth, 0, 1) * 255).astype(np.uint8), "L").resize((W // 2, H // 2), Image.LANCZOS).save(OUT + "sot_depth.png")

# ---- máscara do céu (nuvens pintadas que derivam)
sky = np.zeros((H, W), np.float32)
sky[0:260, 440:1500] = 1.0
sky[170:300, 940:1060] = 0.0                                                    # torre alta no horizonte
sky = cv2.GaussianBlur(sky, (0, 0), 24)
ramp = np.clip((250 - yy) / 120.0, 0, 1)                                         # some perto do horizonte (e do sol)
sky = sky * ramp
Image.fromarray((np.clip(sky, 0, 1) * 255).astype(np.uint8), "L").resize((W // 4, H // 4), Image.LANCZOS).save(OUT + "sot_sky.png")
print("ok")
