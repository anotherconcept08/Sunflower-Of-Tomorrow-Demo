"""Lê data/dialogue/*.json e gera docs/01_visao_e_roteiro.md (Partes A e B). Uso: python3 tools/gerar_roteiro.py"""
import json, os, glob
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
os.chdir(ROOT)

INTRO = open("tools/_intro_roteiro.md", encoding="utf-8").read() if os.path.exists("tools/_intro_roteiro.md") else ""

def fmt_set(s): return ", ".join(f"`{k}={json.dumps(v, ensure_ascii=False)}`" for k, v in s.items())

def render(did, d, out):
    m = d.get("meta", {})
    out.append(f"#### `{did}` — {m.get('titulo', did)}")
    out.append(f"- **Condição para iniciar:** {m.get('onde','—')}")
    out.append(f"- **Sons:** {m.get('som','—')}")
    out.append(f"- **Animação / expressão:** {m.get('anim','—')}")
    out.append(f"- **Consequência narrativa:** {m.get('cons','Nenhuma.')}")
    out.append(f"- **Condição para encerrar:** {m.get('fim','Último nó.')}")
    out.append("")
    ids = list(d["nodes"].keys())
    for i, nid in enumerate(ids):
        n = d["nodes"][nid]
        nxt_inline = ids[i + 1] if i + 1 < len(ids) else None
        if "branch" in n:
            b = n["branch"]; cond = f"`{b['flag']}` = `{b['equals']}`" if "equals" in b else f"`{b['flag']}`"
            out.append(f"- `{nid}` **SE** {cond} → `{b['yes']}` · **SENÃO** → `{b['no']}`")
            continue
        notes = []
        if n.get("wait"): notes.append(f"pausa {n['wait']} s")
        if n.get("sfx"): notes.append(f"som: {n['sfx']}")
        if n.get("set"): notes.append("grava " + fmt_set(n["set"]))
        note = f" *({'; '.join(notes)})*" if notes else ""
        spk = n.get("speaker") or "—"
        if "choices" in n:
            head = f"`{nid}` **{spk}**" + (f": {n['text']}" if n.get("text") else "") + note + " — *o jogador escolhe:*"
            out.append("- " + head)
            for c in n["choices"]:
                extra = []
                if c.get("set"): extra.append("grava " + fmt_set(c["set"]))
                if c.get("narr"): extra.append("narração")
                cond = f" [só se `{c['if']}`]" if c.get("if") else ""
                out.append(f"    - ▸ “{c['text']}”{cond} → `{c.get('next') or 'fim'}`" + (f" *({'; '.join(extra)})*" if extra else ""))
            continue
        nx = n.get("next", "")
        arrow = "" if nx == nxt_inline else (f" → `{nx}`" if nx else " → *fim*")
        txt = n.get("text", "")
        who = f"**{spk}:** " if spk != "—" else "*(narração)* "
        out.append(f"- `{nid}` {who}{txt}{note}{arrow}")
    out.append("")

dialogs = {}
for f in ["prologue_bedroom.json", "prologue_house.json", "prologue_town.json", "prologue_garden.json"]:
    dialogs.update(json.load(open("data/dialogue/" + f, encoding="utf-8")))
order = ["Cena 2 — Acordar (quarto)", "Cena 2b — A casa (sala, cozinha e entrada desabada)", "Cena 3 — A porta (entrada da casa)", "Cena 4 — A cidade durante o inverno", "Cena 5 — O jardim abandonado", "Cena 6 — A semente"]
out = [INTRO, "", "# PARTE B — Roteiro completo dos diálogos", "",
       "> Texto gerado a partir de `data/dialogue/*.json` (a fonte de verdade que o jogo lê). Para mudar uma fala, edite o JSON e rode `python3 tools/gerar_roteiro.py` para atualizar este documento.",
       "> Convenções: **—** / *(narração)* = pensamento de Alen em primeira pessoa, sem nome na caixa. `nX` = id do nó. “→ nX” indica salto; sem seta, segue para a linha seguinte. “pausa” = caixa vazia (silêncio) antes da fala.", ""]
for cena in order:
    out.append(f"## {cena}\n")
    for did, d in dialogs.items():
        if d["meta"].get("cena") == cena: render(did, d, out)
open("docs/01_visao_e_roteiro.md", "w", encoding="utf-8").write("\n".join(out))
print("docs/01_visao_e_roteiro.md gerado:", sum(len(x) for x in out), "caracteres")
