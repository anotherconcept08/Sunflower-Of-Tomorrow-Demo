"""Cria um loop sem emenda a partir de qualquer música (crossfade de potência constante fim -> início).
Uso: python3 tools/refazer_loop_menu.py minha_musica.mp3 assets/audio/music/menu_theme.ogg [segundos_de_crossfade=6]
Requer ffmpeg e numpy. O arquivo gerado começa pelo crossfade (cauda -> início) e termina no ponto
imediatamente anterior ao início da cauda, então o salto fim->início é igual a qualquer par de amostras vizinhas."""
import subprocess, sys, numpy as np
src, dst = sys.argv[1], sys.argv[2]
xf = float(sys.argv[3]) if len(sys.argv) > 3 else 6.0
SR = 48000
raw = subprocess.run(["ffmpeg", "-v", "error", "-i", src, "-vn", "-f", "f32le", "-ac", "2", "-ar", str(SR), "-"], capture_output=True, check=True).stdout
a = np.frombuffer(raw, dtype=np.float32).reshape(-1, 2).copy()
N, X = len(a), int(xf * SR)
assert N > 4 * X, "música curta demais para esse crossfade"
t = np.linspace(0, 1, X, dtype=np.float32)[:, None]
out = np.concatenate([a[N - X:] * np.cos(t * np.pi / 2) + a[:X] * np.sin(t * np.pi / 2), a[X:N - X]], axis=0)
print("salto na emenda: %.5f (normal entre amostras vizinhas: %.5f)" % (np.abs(out[0] - out[-1]).max(), np.abs(a[N - X] - a[N - X - 1]).max()))
p = subprocess.Popen(["ffmpeg", "-v", "error", "-y", "-f", "f32le", "-ar", str(SR), "-ac", "2", "-i", "-", "-c:a", "libvorbis", "-q:a", "5", dst], stdin=subprocess.PIPE)
p.communicate(out.tobytes())
print("ok:", dst, "(%.1f s)" % (len(out) / SR))
