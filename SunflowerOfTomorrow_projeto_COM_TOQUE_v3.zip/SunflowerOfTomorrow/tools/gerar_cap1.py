"""Gera os cenários do Capítulo I — Declan City (PNG, 1 px = 1 px do jogo), no mesmo estilo do prólogo.
Uso: python3 tools/gerar_cap1.py [bairro|centro|praca|humanitaria|biblioteca|locadora|padaria|casa|minigame|all]
Reaproveita o céu e o fundo distante da cidade do prólogo (town_sky.png / town_far.png).
As posições de portas, objetos e colisões estão repetidas nos scripts scripts/world/ch1_*.gd: mexa com cuidado."""
import sys, os, random, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pixlib import *
from gerar_cenarios import building, pine, araucaria

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
OUT = os.path.join(ROOT, "assets", "environments") + os.sep
MG = os.path.join(ROOT, "assets", "minigame") + os.sep
os.makedirs(OUT, exist_ok=True); os.makedirs(MG, exist_ok=True); os.makedirs("/tmp/an", exist_ok=True)
SNOW = (214, 223, 235); SNOW_D = (150, 164, 184)
H = 360


# ====================================================================== utilitários
def glow(img, cx, cy, r, col, k=0.5):
    """Mancha de luz aditiva (lâmpada, janela, TV)."""
    a = np.array(img).astype(np.float32); h, w = a.shape[:2]
    x0, x1 = max(0, int(cx - r)), min(w, int(cx + r)); y0, y1 = max(0, int(cy - r)), min(h, int(cy + r))
    if x1 <= x0 or y1 <= y0: return
    yy, xx = np.mgrid[y0:y1, x0:x1]; d = np.sqrt((xx - cx) ** 2 + (yy - cy) ** 2) / r
    f = np.clip(1 - d, 0, 1) ** 2 * k
    for c in range(3): a[y0:y1, x0:x1, c] += f * col[c]
    a[..., :3] = np.clip(a[..., :3], 0, 255); img.paste(Image.fromarray(a.astype(np.uint8), "RGBA"), (0, 0))


def shadeband(img, x0, y0, x1, y1, f):
    """Escurece uma faixa (sombra/penumbra)."""
    a = np.array(img).astype(np.float32); a[y0:y1, x0:x1, :3] *= f; img.paste(Image.fromarray(np.clip(a, 0, 255).astype(np.uint8), "RGBA"), (0, 0))


def street(W, seed, fog=0.16):
    rnd = random.Random(seed); img = new(W, H); d = ImageDraw.Draw(img)
    cobbles(img, 0, 226, W, H, rnd, snow_seed=seed + 7, snow_amt=0.30)
    rect(d, 0, 226, W, 246, (150, 160, 176))
    for sx in range(0, W, 38): vline(d, sx, 226, 246, (112, 122, 138))
    rect(d, 0, 246, W, 249, (66, 72, 84)); rect(d, 0, 226, W, 228, (222, 230, 241))
    nz = noise_map(W, 20, 30, seed, 2); aa = np.array(img); reg = aa[226:246, :, :3].astype(np.float32)
    reg *= (0.9 + 0.25 * nz)[..., None]; aa[226:246, :, :3] = np.clip(reg, 0, 255).astype(np.uint8)
    return Image.fromarray(aa, "RGBA"), rnd


def finish_outdoor(img, name, fog=0.18):
    a = np.array(img).astype(np.float32); f = np.clip(1 - np.abs(np.arange(H)[:, None] - 232) / 34.0, 0, 1) * fog
    a[..., :3] = a[..., :3] * (1 - f[..., None]) + np.array((176, 188, 204), np.float32) * f[..., None]
    Image.fromarray(np.clip(a, 0, 255).astype(np.uint8), "RGBA").save(OUT + name + ".png")
    W = img.width; prev = new(W, H); prev.alpha_composite(Image.open(OUT + "town_sky.png").convert("RGBA"), (0, 0))
    prev.alpha_composite(Image.open(OUT + "town_far.png").convert("RGBA"), (300, 22)); prev.alpha_composite(Image.open(OUT + name + ".png"))
    prev.convert("RGB").save("/tmp/an/prev_%s.png" % name); print(name, "ok", (W, H))


def sign(img, x, y, w, text, col=(86, 66, 52), ink=(232, 220, 186), size=9, post=True):
    d = ImageDraw.Draw(img)
    if post: rect(d, x + w // 2 - 2, y + 18, x + w // 2 + 3, y + 62, (72, 56, 44))
    rect(d, x, y, x + w, y + 18, col); rect(d, x, y, x + w, y + 2, SNOW); rect(d, x, y + 16, x + w, y + 18, shade(col, 0.6))
    text_px(img, x + 5, y + 3, text, ink, size)


def paper(img, x, y, w, h, rnd, ink=(60, 50, 44), tint=None):
    d = ImageDraw.Draw(img); c = tint or jitter((214, 206, 182), rnd, 14); rect(d, x, y, x + w, y + h, c)
    d.point((x + w // 2, y), fill=(150, 40, 40))
    for k in range(2, h - 1, 3): d.line([(x + 2, y + k), (x + w - 3 - rnd.randint(0, 3), y + k)], fill=ink)


def sandbags(img, x, y, w, rows, rnd):
    """Barricada de sacos de areia: fileiras que se afunilam (y = base da fileira de baixo)."""
    d = ImageDraw.Draw(img)
    for r in range(rows):
        yy = y - r * 9; off = (r % 2) * 7; x0 = x + r * 5
        for bx in range(x0 - off, x + w - r * 5, 14):
            c = jitter((150, 132, 98), rnd, 12)
            d.rounded_rectangle([bx + 1, yy - 8, bx + 14, yy], radius=3, fill=c)
            d.line([(bx + 3, yy - 7), (bx + 11, yy - 7)], fill=shade(c, 1.2)); d.line([(bx + 2, yy - 1), (bx + 13, yy - 1)], fill=shade(c, 0.7))
            if r == rows - 1: d.line([(bx + 2, yy - 9), (bx + 13, yy - 9)], fill=SNOW)


def barrier_arm(img, x, y, w):
    d = ImageDraw.Draw(img); rect(d, x - 5, y - 26, x + 1, y, (60, 62, 66)); rect(d, x - 5, y - 26, x + 1, y - 24, SNOW)
    for k in range(0, w, 12):
        rect(d, x + k, y - 24, x + min(k + 6, w), y - 19, (196, 60, 52)); rect(d, x + k + 6, y - 24, x + min(k + 12, w), y - 19, (222, 226, 230))
    rect(d, x, y - 25, x + w, y - 24, SNOW)


def jeep(img, x, y, rnd, flip=False, w=70):
    """Veículo militar (oliva). x = esquerda, y = chão."""
    layer = new(*img.size); d = ImageDraw.Draw(layer)
    body = (74, 84, 58); dk = shade(body, 0.6)
    rect(d, x + 2, y - 22, x + w, y - 8, body); rect(d, x + 2, y - 10, x + w, y - 8, dk)
    rect(d, x + 14, y - 38, x + w - 16, y - 22, shade(body, 0.92)); rect(d, x + 18, y - 35, x + w - 20, y - 24, (34, 44, 58)); d.line([(x + 18, y - 35), (x + w - 20, y - 35)], fill=(98, 112, 130))
    rect(d, x + 12, y - 38, x + w - 14, y - 36, SNOW)
    rect(d, x + 4, y - 23, x + w - 2, y - 22, shade(body, 1.2))
    text_px(layer, x + 24, y - 22, "EX-114", (200, 200, 180), 7)
    for wx in (x + 14, x + w - 16):
        d.ellipse([wx - 7, y - 14, wx + 7, y], fill=(24, 24, 26)); d.ellipse([wx - 3, y - 10, wx + 3, y - 4], fill=(82, 86, 92))
    d.line([(x + w, y - 16), (x + w + 3, y - 16)], fill=(236, 210, 130), width=2)
    if flip: layer = layer.transpose(Image.FLIP_LEFT_RIGHT); layer = layer.crop((0, 0, *layer.size)); 
    img.alpha_composite(layer)


def crates(img, x, y, nx, ny, rnd, text=None, col=(128, 96, 62)):
    d = ImageDraw.Draw(img)
    for j in range(ny):
        for i in range(nx):
            cx = x + i * 22; cy = y - j * 17
            c = jitter(col, rnd, 10); rect(d, cx, cy - 16, cx + 21, cy, c)
            rect(d, cx, cy - 16, cx + 21, cy - 15, shade(c, 1.25)); rect(d, cx, cy - 1, cx + 21, cy, shade(c, 0.6))
            d.line([(cx + 1, cy - 14), (cx + 20, cy - 2)], fill=shade(c, 0.78)); d.line([(cx + 20, cy - 14), (cx + 1, cy - 2)], fill=shade(c, 0.78))
            rect(d, cx + 7, cy - 11, cx + 15, cy - 6, (212, 204, 176)); 
            if text and j == 0: text_px(img, cx + 7, cy - 12, text[i % len(text)], (70, 52, 40), 6)
    for i in range(nx): rect(d, x + i * 22, y - ny * 17 - 1, x + i * 22 + 21, y - ny * 17, SNOW)


def tent(img, x, y, w, h, col=(150, 152, 138), rnd=None):
    d = ImageDraw.Draw(img)
    d.polygon([(x, y), (x + w // 2, y - h), (x + w, y)], fill=col); d.polygon([(x + 4, y), (x + w // 2, y - h + 5), (x + w - 4, y)], fill=shade(col, 0.82))
    d.polygon([(x + w // 2 - 12, y), (x + w // 2, y - h // 2), (x + w // 2 + 12, y)], fill=(30, 28, 30))
    d.line([(x, y), (x + w // 2, y - h), (x + w, y)], fill=SNOW, width=2)
    d.line([(x + w // 2, y - h), (x + w // 2, y - h - 8)], fill=(70, 56, 44), width=2)


def bench(img, x, y, w=64):
    d = ImageDraw.Draw(img); rect(d, x, y - 2, x + w, y + 3, (74, 58, 48)); rect(d, x, y + 8, x + w, y + 14, (90, 70, 54)); rect(d, x + 3, y + 14, x + 8, y + 26, (58, 44, 37)); rect(d, x + w - 8, y + 14, x + w - 3, y + 26, (58, 44, 37))
    rect(d, x, y - 2, x + w, y - 1, SNOW)


def lamp_post(img, x, rnd, tilt=0, h=124): lamp(img, x, 232, rnd, tilt=tilt, height=h)


def side_street(img, x0, x1, rnd, top=64):
    """Rua lateral que se afasta para o fundo (perspectiva simples, névoa)."""
    d = ImageDraw.Draw(img); w = x1 - x0
    rect(d, x0, top, x1, 228, (92, 104, 122))
    for yy in range(top, 228):
        t = (yy - top) / (228 - top); c = mix((128, 142, 160), (84, 94, 110), t); d.line([(x0, yy), (x1, yy)], fill=c + (255,))
    # paredes laterais em perspectiva
    d.polygon([(x0, top - 6), (x0 + w * 0.28, top + 40), (x0 + w * 0.28, 204), (x0, 228)], fill=(70, 62, 62))
    d.polygon([(x1, top - 6), (x1 - w * 0.28, top + 40), (x1 - w * 0.28, 204), (x1, 228)], fill=(66, 60, 62))
    for k in range(4):
        yy = 100 + k * 26; d.line([(x0 + 2, yy + 6), (x0 + w * 0.26, yy + 22)], fill=(40, 36, 40)); d.line([(x1 - 2, yy + 6), (x1 - w * 0.26, yy + 22)], fill=(40, 36, 40))
    d.polygon([(x0 + w * 0.28, 204), (x1 - w * 0.28, 204), (x1 - w * 0.34, 150), (x0 + w * 0.34, 150)], fill=(150, 164, 182))
    rect(d, x0 + w * 0.36, 118, x0 + w * 0.5, 160, (96, 108, 126)); rect(d, x0 + w * 0.52, 130, x0 + w * 0.64, 160, (104, 116, 134))
    d.line([(x0 + w * 0.5, 228), (x0 + w * 0.5, 160)], fill=(214, 223, 235), width=1)
    rect(d, x0 - 2, 228, x1 + 2, 232, (66, 72, 84))


# ---- objetos de vitrine ---------------------------------------------------------
def display(img, x0, y0, x1, y1, kind, rnd, crack=False):
    d = ImageDraw.Draw(img); rect(d, x0 - 2, y0 - 2, x1 + 2, y1 + 2, (30, 28, 32)); rect(d, x0, y0, x1, y1, (28, 36, 48))
    d.polygon([(x0 + 2, y1 - 2), (x0 + 16, y0 + 2), (x0 + 24, y0 + 2), (x0 + 10, y1 - 2)], fill=(44, 56, 74))
    if kind == "tv":
        for i, sx in enumerate(range(x0 + 6, x1 - 22, 28)):
            for j, sy in enumerate((y0 + 6, y0 + 22)):
                if sy + 14 > y1: continue
                rect(d, sx, sy, sx + 22, sy + 14, (170, 166, 150)); rect(d, sx + 2, sy + 2, sx + 18, sy + 11, (16, 20, 24)); d.point((sx + 20, sy + 12), fill=(190, 60, 50))
    elif kind == "mannequin":
        for sx in range(x0 + 12, x1 - 8, 26):
            rect(d, sx + 6, y0 + 4, sx + 11, y0 + 10, (176, 170, 160)); rect(d, sx + 2, y0 + 10, sx + 15, y0 + 28, (86, 70, 86)); rect(d, sx + 7, y0 + 28, sx + 10, y1 - 4, (120, 116, 110))
            rect(d, sx + 2, y0 + 10, sx + 15, y0 + 12, (110, 92, 110))
        rect(d, x0, y1 - 3, x1, y1, (46, 40, 36))
    elif kind == "books":
        for r in range(2):
            yy = y0 + 4 + r * 18; rect(d, x0 + 2, yy + 14, x1 - 2, yy + 16, (80, 62, 48))
            sx = x0 + 4
            while sx < x1 - 8:
                bw = rnd.randint(3, 6); bh = rnd.randint(9, 14); c = jitter(rnd.choice([(70, 90, 130), (130, 70, 70), (90, 110, 80), (140, 120, 80), (100, 80, 120)]), rnd, 12)
                rect(d, sx, yy + 14 - bh, sx + bw, yy + 14, shade(c, 0.7)); rect(d, sx, yy + 14 - bh, sx + 1, yy + 14, c); sx += bw + 1
        rect(d, x0 + 4, y1 - 8, x0 + 30, y1 - 2, (60, 80, 120))
    elif kind == "loaves":
        rect(d, x0 + 2, y1 - 10, x1 - 2, y1 - 8, (90, 66, 46))
        for sx in (x0 + 8, x0 + 32):
            d.ellipse([sx, y1 - 18, sx + 14, y1 - 9], fill=(164, 114, 62)); d.line([(sx + 3, y1 - 14), (sx + 10, y1 - 14)], fill=(210, 160, 96))
    elif kind == "clothes":
        for sx in range(x0 + 6, x1 - 16, 22): rect(d, sx, y0 + 6, sx + 14, y0 + 24, jitter(rnd.choice([(96, 60, 60), (60, 80, 100), (110, 100, 70)]), rnd, 10)); rect(d, sx + 6, y0 + 3, sx + 8, y0 + 6, (140, 140, 140))
    elif kind == "games":
        for r in range(2):
            for sx in range(x0 + 4, x1 - 14, 18):
                c = rnd.choice([(40, 56, 110), (120, 40, 40), (40, 100, 80), (110, 90, 40)]); rect(d, sx, y0 + 4 + r * 18, sx + 13, y0 + 18 + r * 18, c); rect(d, sx + 2, y0 + 6 + r * 18, sx + 11, y0 + 12 + r * 18, shade(c, 1.5))
    if crack:
        d.line([(x0 + 6, y0 + 2), (x0 + 22, y1 - 4)], fill=(118, 134, 156)); d.line([(x0 + 14, y0 + 12), (x0 + 30, y0 + 6)], fill=(118, 134, 156)); d.line([(x0 + 22, y1 - 4), (x0 + 36, y1 - 12)], fill=(118, 134, 156))
    rect(d, x0 - 3, y1 + 2, x1 + 3, y1 + 4, SNOW)


def awning(img, x0, x1, y, c1=(150, 58, 52), c2=(214, 208, 196)):
    d = ImageDraw.Draw(img)
    for i, sx in enumerate(range(x0, x1, 10)):
        d.polygon([(sx, y), (sx + 10, y), (sx + 12, y + 14), (sx - 2, y + 14)], fill=c1 if i % 2 == 0 else c2)
    rect(d, x0 - 2, y - 2, x1 + 2, y + 1, SNOW)
    for sx in range(x0, x1, 10): d.line([(sx - 1, y + 14), (sx + 11, y + 14)], fill=shade(c1, 0.6))


def shutter(img, x0, y0, x1, y1):
    d = ImageDraw.Draw(img); rect(d, x0, y0, x1, y1, (84, 90, 100))
    for yy in range(y0, y1, 3): d.line([(x0, yy), (x1, yy)], fill=(106, 114, 126)); d.line([(x0, yy + 1), (x1, yy + 1)], fill=(64, 70, 80))
    rect(d, x0, y1 - 3, x1, y1, (50, 54, 62))


def shop(img, rnd, x, w, T, col, text, kind="brick", door=None, wins=True, chim=None, sign_h=148, broken=0.35):
    """Fachada padrão: andar de cima com janelas, letreiro em y=148, térreo livre para vitrine/porta."""
    windows = [(x + 16 + k * 36, T + 14, 0) for k in range(max(1, (w - 24) // 36))] if wins else []
    building(img, x, w, T, rnd, kind, col, windows=windows, door=door, chimney=chim, shop=(x + 8, sign_h, w - 16), shop_text=text, broken=broken)


def tape(img, x0, y0, x1, y1):
    d = ImageDraw.Draw(img)
    for i, sx in enumerate(range(x0, x1, 8)):
        d.polygon([(sx, y0), (sx + 4, y0), (sx + 2, y1), (sx - 2, y1)], fill=(222, 190, 60) if i % 2 == 0 else (30, 30, 34))


def poster_rows(img, x0, x1, y0, y1, rnd):
    for _ in range((x1 - x0) // 10):
        paper(img, rnd.randint(x0, x1 - 12), rnd.randint(y0, y1 - 16), rnd.randint(8, 12), rnd.randint(11, 16), rnd)


# ====================================================================== BAIRRO (camada extra sobre town_main.png)
def bairro():
    """Overlay transparente 2240x360 usado SÓ no capítulo I: placa para o Centro, varal e a barricada da Estrada do Moinho."""
    W = 2240; rnd = random.Random(31); img = new(W, H); d = ImageDraw.Draw(img)
    # placa indicando o Centro (extremo esquerdo da rua)
    sign(img, 26, 190, 112, "← CENTRO", col=(52, 70, 96), ink=(226, 232, 240), size=9)
    text_px(img, 30, 209, "Biblioteca 1,2 km", (176, 190, 210), 7, bold=False)
    # varal entre o poste e a casa de Alen (roupas congeladas)
    d.line([(318, 196), (356, 206)], fill=(190, 190, 186), width=1)
    for k, c in enumerate([(120, 66, 66), (176, 172, 160), (66, 86, 110)]):
        x0 = 322 + k * 11; rect(d, x0, 198 + k * 3, x0 + 8, 210 + k * 3, c); rect(d, x0, 198 + k * 3, x0 + 8, 200 + k * 3, SNOW)
    # barricada na Estrada do Moinho: começa na cerca (x~2060) e fecha a estrada toda
    sandbags(img, 2050, 266, 150, 3, rnd); sandbags(img, 2050, 322, 150, 3, rnd)
    rect(d, 2072, 272, 2092, 318, (28, 28, 30)); 
    barrier_arm(img, 2062, 296, 128)
    for cx in (2108, 2140, 2172):  # ouriços tchecos
        d.line([(cx - 9, 300), (cx + 9, 270)], fill=(66, 70, 74), width=3); d.line([(cx - 9, 270), (cx + 9, 300)], fill=(66, 70, 74), width=3); d.line([(cx, 266), (cx, 304)], fill=(66, 70, 74), width=3)
        d.line([(cx - 9, 270), (cx + 9, 270)], fill=SNOW)
    sign(img, 2046, 190, 112, "INTERDITADA", col=(150, 44, 40), ink=(246, 232, 226), size=9, post=False)
    text_px(img, 2052, 209, "Ordem 114 · Com. Regional", (240, 214, 206), 6, bold=False)
    rect(d, 2096, 208, 2100, 262, (60, 60, 64))
    img.save(OUT + "bairro_overlay.png"); print("bairro overlay ok")


# ====================================================================== CENTRO — Rua das Lojas (W 2240)
def centro():
    W = 2240; img, rnd = street(W, 41); d = ImageDraw.Draw(img)
    # 1. oficina (garagem com porta de enrolar meio aberta)
    shop(img, rnd, -10, 140, 104, (92, 72, 62), "OFICINA SANTOS", door=None, chim=None)
    d = ImageDraw.Draw(img); rect(d, 22, 172, 110, 228, (22, 22, 26)); shutter(img, 22, 172, 110, 192)
    rect(d, 40, 204, 92, 226, (60, 66, 76)); rect(d, 48, 196, 84, 206, (74, 82, 94)); d.ellipse([44, 220, 56, 230], fill=(20, 20, 22)); d.ellipse([76, 220, 88, 230], fill=(20, 20, 22))
    d.line([(112, 228), (112, 190)], fill=(48, 48, 52), width=2)
    for k in range(3): d.ellipse([118 + k * 3, 216 - k * 8, 134 + k * 3, 228 - k * 8], fill=(26, 26, 28)); d.ellipse([123 + k * 3, 220 - k * 8, 129 + k * 3, 224 - k * 8], fill=(90, 94, 100))
    rubble(img, 142, 228, 30, rnd)
    # 2. locadora VÍDEO PONTO (entrada acessível)
    shop(img, rnd, 176, 170, 108, (84, 78, 98), "VÍDEO PONTO", kind="plaster", door=(250, 176))
    display(img, 188, 174, 244, 214, "games", rnd, crack=True); display(img, 282, 174, 336, 214, "games", rnd)
    paper(img, 296, 150 - 36, 12, 16, rnd, tint=(200, 70, 60)); text_px(img, 192, 124, "ALUGUE UM MUNDO", (148, 140, 120), 7, bold=False)
    # 3. rua lateral bloqueada: Rua das Ferrarias
    side_street(img, 352, 442, rnd); d = ImageDraw.Draw(img)
    sandbags(img, 352, 244, 92, 3, rnd); sandbags(img, 354, 272, 90, 2, rnd)
    barrier_arm(img, 360, 262, 70); jeep(img, 372, 228, rnd, w=64)
    tape(img, 352, 152, 442, 158); sign(img, 352, 120, 90, "RUA DAS FERRARIAS", col=(150, 44, 40), ink=(246, 232, 226), size=7, post=False)
    # 4. Tele Vale (eletrônicos)
    shop(img, rnd, 452, 160, 100, (94, 76, 72), "TELE VALE", door=(552, 176))
    display(img, 466, 172, 540, 214, "tv", rnd, crack=True); paper(img, 520, 190, 14, 12, rnd)
    lamp_post(img, 632, rnd, tilt=3)
    # 5. padaria PÃO & PROSA (entrada acessível; chaminé em uso)
    shop(img, rnd, 660, 190, 100, (130, 100, 78), "PÃO & PROSA", kind="plaster", door=(742, 176), chim=(812, 90))
    awning(img, 668, 736, 164); display(img, 770, 174, 840, 214, "loaves", rnd); glow(img, 806, 196, 44, (255, 190, 90), 0.22)
    d = ImageDraw.Draw(img); rect(d, 704, 232, 724, 238, (60, 46, 38))
    # chalkboard
    rect(d, 678, 196, 716, 224, (36, 44, 40)); rect(d, 677, 195, 717, 197, (110, 82, 56)); text_px(img, 681, 198, "HOJE:", (210, 210, 200), 6, bold=False); text_px(img, 681, 207, "SÓ 1 PÃO", (210, 210, 200), 6, bold=False)
    # 6. banco / rubble
    bench(img, 868, 236, 56); rubble(img, 936, 228, 36, rnd)
    # 7. mercearia São Jorge (fechada, tábuas)
    shop(img, rnd, 980, 170, 106, (98, 72, 58), "MERCEARIA", door=(1052, 176))
    d = ImageDraw.Draw(img)
    for k in range(5): rect(d, 996, 176 + k * 8, 1040, 180 + k * 8, jitter((82, 62, 46), rnd, 10))
    shutter(img, 1086, 172, 1140, 224); paper(img, 1060, 186, 14, 18, rnd)
    # 8. beco do Sapateiro (entrada da casa vazia)
    d = ImageDraw.Draw(img); x0, x1 = 1156, 1226
    rect(d, x0, 70, x1, 228, (40, 38, 44)); 
    for yy in range(70, 228, 2): d.line([(x0, yy), (x1, yy)], fill=mix((60, 62, 72), (22, 22, 28), (yy - 70) / 160) + (255,))
    rect(d, x0 + 10, 160, x0 + 30, 228, (70, 52, 40)); rect(d, x0 + 12, 162, x0 + 28, 190, (30, 36, 46)); d.point((x0 + 26, 196), fill=(190, 160, 90))   # porta do fundo
    d.line([(x0, 120), (x1, 140)], fill=(176, 176, 172), width=1)
    for k, c in enumerate([(130, 70, 70), (200, 196, 186)]): rect(d, x0 + 20 + k * 16, 126 + k * 3, x0 + 28 + k * 16, 140 + k * 3, c)
    rect(d, x0 + 36, 196, x0 + 66, 228, (74, 56, 44)); d.line([(x0 + 36, 196), (x0 + 66, 228)], fill=(48, 36, 30)); d.line([(x0 + 66, 196), (x0 + 36, 228)], fill=(48, 36, 30)); rect(d, x0 + 36, 195, x0 + 66, 197, SNOW)
    rect(d, x0 - 2, 70, x0, 228, (52, 40, 40)); rect(d, x1, 70, x1 + 2, 228, (52, 40, 40))
    text_px(img, x0 + 4, 86, "BECO DO", (180, 170, 140), 7); text_px(img, x0 + 4, 95, "SAPATEIRO", (180, 170, 140), 7)
    # 9. loja de roupas MODA ELEGANCE
    shop(img, rnd, 1240, 160, 100, (122, 112, 122), "MODA ELEGANCE", kind="plaster", door=(1330, 176))
    display(img, 1254, 174, 1318, 214, "mannequin", rnd, crack=True)
    # 10. Café do Largo
    shop(img, rnd, 1420, 170, 104, (84, 62, 56), "CAFÉ DO LARGO", door=(1496, 176))
    d = ImageDraw.Draw(img); awning(img, 1428, 1488, 164, (60, 76, 96), (190, 190, 180))
    for k in range(3): rect(d, 1508 + k * 8, 216 - k * 12, 1520 + k * 8, 220 - k * 12, (92, 70, 54)); rect(d, 1510 + k * 8, 220 - k * 12, 1511 + k * 8, 230 - k * 12, (60, 46, 38))
    rect(d, 1428, 190, 1470, 228, (30, 32, 38))
    for k, t in enumerate(("VOLTAMOS", "QUANDO A", "FARINHA", "VOLTAR")): text_px(img, 1432, 192 + k * 8, t, (214, 214, 204), 6, bold=False)
    lamp_post(img, 1618, rnd, tilt=-3)
    # 11. sebo O LIVRO AZUL
    shop(img, rnd, 1650, 170, 98, (66, 80, 108), "O LIVRO AZUL", kind="plaster", door=(1726, 176))
    display(img, 1664, 174, 1718, 214, "books", rnd, crack=False); paper(img, 1692, 188, 20, 22, rnd)
    text_px(img, 1664, 124, "SEBO · TROCA · DOAÇÃO", (170, 180, 200), 6, bold=False)
    # 12. edifício parcialmente destruído (fachada com buraco, lajes expostas)
    building(img, 1850, 130, 112, rnd, "brick", (92, 68, 62), [(1866, 126, 0), (1944, 126, 0)], broken=0.9)
    d = ImageDraw.Draw(img)
    rect(d, 1882, 150, 1940, 226, (26, 24, 28))                                                         # interior exposto
    rect(d, 1882, 150, 1940, 154, (150, 144, 134)); rect(d, 1878, 188, 1944, 193, (120, 114, 106)); rect(d, 1878, 188, 1944, 189, SNOW)
    rect(d, 1886, 158, 1896, 186, (86, 70, 66)); rect(d, 1924, 196, 1938, 226, (66, 50, 44)); d.line([(1908, 154), (1912, 176)], fill=(70, 70, 76), width=2)
    a_ = np.array(img); a_[112:152, 1900:1940, 3] = 0; img = Image.fromarray(a_, "RGBA"); d = ImageDraw.Draw(img)   # topo arrancado
    d.line([(1900, 152), (1918, 140), (1940, 152)], fill=SNOW, width=1)
    rubble(img, 1846, 232, 96, rnd); rubble(img, 1900, 234, 60, rnd); tape(img, 1846, 226, 1984, 232)
    paper(img, 1858, 168, 18, 22, rnd, tint=(198, 70, 60)); text_px(img, 1856, 142, "RISCO", (246, 232, 226), 7); 
    # 13. ponto de ônibus + ônibus parado
    layer = new(W, H); ld = ImageDraw.Draw(layer)
    rect(ld, 2010, 160, 2150, 224, (150, 70, 44)); rect(ld, 2010, 160, 2150, 168, (190, 100, 60)); rect(ld, 2010, 200, 2150, 208, (214, 206, 190)); rect(ld, 2010, 212, 2150, 224, (70, 40, 30))
    for wx in range(2018, 2140, 24): rect(ld, wx, 172, wx + 18, 196, (30, 38, 52)); rect(ld, wx, 172, wx + 18, 174, (80, 96, 118))
    for wx in (2030, 2120): ld.ellipse([wx - 11, 214, wx + 11, 236], fill=(22, 22, 24)); ld.ellipse([wx - 5, 220, wx + 5, 230], fill=(70, 72, 78))
    rect(ld, 2008, 156, 2152, 160, SNOW); text_px(layer, 2018, 164, "LINHA 12 — SUSPENSA", (240, 236, 220), 7)
    img.alpha_composite(layer)
    # 14. fim da rua (lado do bairro): poste e placa
    lamp_post(img, 2176, rnd, tilt=2); d = ImageDraw.Draw(img); sign(img, 2186, 190, 52, "PINHAL ALTO →", col=(52, 70, 96), ink=(226, 232, 240), size=6, post=True)
    # banca de trocas (toldo azul) — fica à frente do ônibus
    rect(d, 1760, 214, 1766, 246, (70, 56, 44)); rect(d, 1824, 214, 1830, 246, (70, 56, 44)); d.polygon([(1752, 208), (1838, 208), (1830, 222), (1760, 222)], fill=(52, 86, 130)); rect(d, 1752, 206, 1838, 209, SNOW)
    rect(d, 1764, 238, 1826, 250, (96, 74, 54)); rect(d, 1764, 238, 1826, 240, (130, 102, 76))
    for k, c in enumerate([(176, 150, 60), (180, 60, 56), (80, 100, 130), (150, 150, 150)]): rect(d, 1770 + k * 14, 230, 1778 + k * 14, 238, c)
    text_px(img, 1766, 222, "TROCA-SE", (240, 232, 210), 6)
    finish_outdoor(img, "centro_main")


# ====================================================================== PRAÇA DO RELÓGIO (W 2000)
def praca():
    W = 2000; img, rnd = street(W, 52); d = ImageDraw.Draw(img)
    lamp_post(img, 40, rnd, tilt=1); sign(img, 52, 190, 118, "← BIBLIOTECA", col=(52, 70, 96), ink=(226, 232, 240), size=9)
    # banco (fechado)
    building(img, 190, 200, 70, rnd, "plaster", (118, 116, 122), [(214, 96, 0), (250, 96, 0), (286, 96, 0), (322, 96, 0), (358, 96, 0)], broken=0.5, shop=(204, 148, 172), shop_text="BANCO POPULAR", flat=True)
    d = ImageDraw.Draw(img)
    for cx in (210, 250, 290, 330, 370): rect(d, cx, 170, cx + 8, 228, (156, 154, 160)); rect(d, cx, 170, cx + 2, 228, (190, 188, 194)); rect(d, cx - 2, 166, cx + 10, 171, (176, 174, 180))
    shutter(img, 232, 176, 348, 226); paper(img, 262, 182, 40, 28, rnd); text_px(img, 266, 184, "FECHADO", (150, 40, 40), 7); text_px(img, 266, 194, "TEMPO", (60, 50, 44), 6, bold=False); text_px(img, 266, 202, "INDETERMINADO", (60, 50, 44), 6, bold=False)
    lamp_post(img, 410, rnd, tilt=-2)
    # correios
    building(img, 440, 150, 110, rnd, "brick", (112, 56, 50), [(462, 124, 0), (500, 124, 0), (538, 124, 0)], door=(498, 176), shop=(450, 148, 130), shop_text="CORREIOS", broken=0.3)
    d = ImageDraw.Draw(img); rect(d, 560, 190, 576, 228, (150, 44, 40)); rect(d, 558, 186, 578, 194, (176, 56, 50)); rect(d, 562, 200, 572, 202, (20, 20, 20)); rect(d, 558, 186, 578, 187, SNOW)
    # mural dos desaparecidos
    rect(d, 610, 178, 614, 228, (60, 46, 38)); rect(d, 704, 178, 708, 228, (60, 46, 38)); rect(d, 596, 136, 722, 200, (84, 64, 50)); rect(d, 596, 136, 722, 138, SNOW)
    poster_rows(img, 600, 718, 140, 198, rnd); text_px(img, 612, 126, "PROCURA-SE", (222, 210, 170), 8)
    # árvore seca + banco de praça
    bare_tree(img, 800, 232, 160, rnd); bench(img, 822, 236, 60)
    rect(d, 862, 226, 872, 236, (150, 150, 150)); rect(d, 864, 222, 870, 226, (180, 90, 60))                  # panela de sopa no banco
    # monumento com relógio
    rect(d, 1000, 196, 1060, 230, (130, 134, 142)); rect(d, 990, 224, 1070, 232, (112, 116, 124)); rect(d, 1012, 100, 1048, 198, (136, 140, 148)); rect(d, 1012, 100, 1016, 198, (170, 174, 182))
    d.ellipse([1010, 84, 1050, 124], fill=(70, 72, 80)); d.ellipse([1014, 88, 1046, 120], fill=(206, 204, 190)); d.line([(1030, 104), (1030, 92)], fill=(40, 40, 44), width=2); d.line([(1030, 104), (1038, 108)], fill=(40, 40, 44), width=2)
    for k in range(12):
        ang = k * math.pi / 6; d.point((1030 + int(math.sin(ang) * 14), 104 - int(math.cos(ang) * 14)), fill=(60, 60, 64))
    d.polygon([(1008, 84), (1030, 62), (1052, 84)], fill=(110, 114, 122)); d.line([(1008, 84), (1030, 62), (1052, 84)], fill=SNOW, width=2)
    rect(d, 1012, 196, 1048, 198, SNOW); text_px(img, 1004, 206, "AOS QUE FICARAM", (200, 204, 212), 5, bold=False)
    # fonte congelada
    d.ellipse([1150, 214, 1230, 238], fill=(98, 104, 114)); d.ellipse([1156, 216, 1224, 232], fill=(168, 196, 214)); rect(d, 1186, 190, 1194, 222, (124, 128, 138)); d.polygon([(1172, 200), (1190, 182), (1208, 200)], fill=(180, 210, 228))
    for k in range(6): d.line([(1176 + k * 6, 214), (1178 + k * 6, 224)], fill=(220, 238, 248))
    # banca de jornais
    rect(d, 1290, 196, 1344, 230, (66, 90, 80)); rect(d, 1286, 188, 1348, 198, (80, 108, 96)); rect(d, 1286, 186, 1348, 189, SNOW); rect(d, 1300, 204, 1334, 222, (30, 36, 40)); text_px(img, 1292, 190, "JORNAIS", (230, 226, 210), 6)
    paper(img, 1306, 208, 10, 12, rnd); paper(img, 1320, 208, 10, 12, rnd)
    bare_tree(img, 1380, 232, 150, rnd); bench(img, 1400, 236, 60)
    # posto de controle na Avenida Central
    side_street(img, 1500, 1620, rnd, top=60); d = ImageDraw.Draw(img)
    sandbags(img, 1488, 246, 144, 3, rnd); sandbags(img, 1494, 276, 136, 2, rnd); barrier_arm(img, 1520, 264, 84)
    rect(d, 1632, 150, 1672, 232, (90, 96, 72)); rect(d, 1630, 146, 1674, 154, (110, 118, 88)); rect(d, 1630, 144, 1674, 147, SNOW); rect(d, 1642, 164, 1662, 186, (30, 40, 52))   # guarita
    jeep(img, 1560, 234, rnd, w=74); tape(img, 1500, 150, 1620, 156)
    sign(img, 1498, 112, 124, "AVENIDA CENTRAL", col=(150, 44, 40), ink=(246, 232, 226), size=8, post=False); text_px(img, 1504, 130, "SÓ VEÍCULOS AUTORIZADOS", (246, 232, 226), 5, bold=False)
    # hotel danificado
    building(img, 1700, 150, 76, rnd, "brick", (104, 74, 66), [(1720, 90, 0), (1756, 90, 0), (1792, 90, 0), (1720, 134, 0), (1756, 134, 0), (1792, 134, 0)], door=(1768, 176), shop=(1710, 148, 130), shop_text="HOTEL CENTRAL", broken=0.9)
    d = ImageDraw.Draw(img); rubble(img, 1840, 228, 40, rnd)
    for (cx, cy) in ((1726, 100), (1812, 100)):                                                                  # marcas de fuligem
        d.polygon([(cx, cy), (cx + 22, cy - 8), (cx + 26, cy + 26), (cx + 4, cy + 28)], fill=(26, 24, 26))
    # capela
    building(img, 1880, 100, 120, rnd, "plaster", (150, 142, 126), [(1912, 140, 0)], door=(1918, 176), broken=0.2)
    d = ImageDraw.Draw(img); rect(d, 1914, 70, 1946, 122, (138, 130, 116)); d.polygon([(1910, 72), (1930, 40), (1950, 72)], fill=(96, 70, 62)); d.line([(1910, 72), (1930, 40), (1950, 72)], fill=SNOW, width=2)
    d.line([(1930, 40), (1930, 26)], fill=(40, 36, 40), width=2); d.line([(1924, 32), (1936, 32)], fill=(40, 36, 40), width=2)
    glow(img, 1930, 205, 36, (255, 190, 90), 0.4);
    rect(d, 1956, 214, 1980, 232, (96, 74, 54)); rect(d, 1956, 214, 1980, 216, (130, 102, 76)); text_px(img, 1952, 200, "DOAÇÕES", (232, 220, 186), 6)
    finish_outdoor(img, "praca_main")


# ====================================================================== ÁREA HUMANITÁRIA + BIBLIOTECA (fachada) (W 1900)
def humanitaria():
    W = 1900; img, rnd = street(W, 63); d = ImageDraw.Draw(img)
    # fachada da biblioteca (x 0..420)
    layer = new(W, H); ld = ImageDraw.Draw(layer); bricks(layer, 0, 40, 424, 228, (128, 118, 106), rnd, bw=14, bh=7, var=8, mortar=(86, 80, 72))
    rect(ld, 0, 40, 424, 60, (150, 142, 130)); rect(ld, 0, 40, 424, 42, SNOW); rect(ld, 0, 58, 424, 61, (86, 80, 72))
    for cx in (60, 140, 284, 364):
        rect(ld, cx, 62, cx + 14, 224, (170, 162, 150)); rect(ld, cx, 62, cx + 3, 224, (196, 190, 178)); rect(ld, cx - 3, 62, cx + 17, 68, (186, 178, 166)); rect(ld, cx - 3, 218, cx + 17, 226, (150, 142, 130))
    img.alpha_composite(layer); d = ImageDraw.Draw(img)
    rect(d, 150, 100, 276, 136, (62, 54, 48)); rect(d, 150, 100, 276, 102, SNOW); text_px(img, 163, 106, "BIBLIOTECA", (232, 220, 186), 11); text_px(img, 168, 120, "MUNICIPAL", (232, 220, 186), 9)
    # portão grande
    rect(d, 178, 160, 252, 228, (28, 26, 28)); rect(d, 182, 164, 248, 228, (74, 54, 40)); vline(d, 215, 164, 228, (36, 26, 20)); d.arc([182, 150, 248, 190], 180, 360, fill=(28, 26, 28), width=4)
    rect(d, 184, 168, 212, 190, (52, 60, 72)); rect(d, 218, 168, 246, 190, (52, 60, 72)); glow(img, 215, 214, 54, (255, 196, 110), 0.45)
    for sy in range(160, 228, 16): rect(d, 170, sy + 12, 260, sy + 16, (160, 152, 140))
    for wx in (20, 96, 318, 384):
        window(img, wx, 100, 22, 40, rnd, broken=False, sill=True); rect(d, wx, 100, wx + 22, 140, (212, 160, 84)); rect(d, wx + 10, 100, wx + 12, 140, (60, 50, 40)); rect(d, wx, 118, wx + 22, 120, (60, 50, 40))
        glow(img, wx + 11, 122, 36, (255, 190, 100), 0.35)
    for wx in (20, 96, 318, 384):                                                                              # fita em X nas janelas
        d.line([(wx, 100), (wx + 22, 140)], fill=(206, 200, 184), width=1); d.line([(wx + 22, 100), (wx, 140)], fill=(206, 200, 184), width=1)
    # faixa do centro de ajuda (sem símbolos reais)
    rect(d, 168, 74, 262, 94, (34, 62, 90)); rect(d, 168, 74, 262, 76, SNOW); text_px(img, 174, 77, "ABRIGO · ALIMENTOS", (236, 236, 230), 7)
    # escada + sacos de areia protegendo a entrada
    rect(d, 164, 226, 266, 233, (150, 144, 134)); rect(d, 164, 226, 266, 228, SNOW)
    sandbags(img, 20, 246, 120, 3, rnd); sandbags(img, 296, 246, 120, 3, rnd)
    # tendas e fila de cadastro
    tent(img, 440, 232, 96, 62, (146, 150, 136), rnd); text_px(img, 462, 164, "CADASTRO", (226, 232, 240), 7)
    for px in range(556, 760, 34): rect(d, px, 244, px + 3, 270, (66, 58, 50)); 
    d.line([(556, 250), (726, 250)], fill=(150, 44, 40), width=2); d.line([(556, 262), (726, 262)], fill=(150, 44, 40), width=2)
    sign(img, 540, 180, 90, "FILA B", col=(34, 62, 90), ink=(236, 236, 230), size=9); text_px(img, 546, 198, "CADASTRO NOVO", (190, 206, 226), 6, bold=False)
    # caminhão de suprimentos + caixas
    layer = new(W, H); ld = ImageDraw.Draw(layer)
    rect(ld, 800, 150, 930, 226, (88, 98, 70)); rect(ld, 800, 150, 930, 156, (118, 130, 94)); rect(ld, 930, 176, 978, 226, (80, 90, 64)); rect(ld, 936, 182, 972, 204, (34, 44, 58)); rect(ld, 930, 170, 978, 176, (100, 112, 80))
    rect(ld, 796, 146, 934, 150, SNOW); rect(ld, 930, 168, 978, 171, SNOW); rect(ld, 800, 214, 978, 226, (56, 62, 46))
    for wx in (830, 900, 954): ld.ellipse([wx - 12, 212, wx + 12, 236], fill=(22, 22, 24)); ld.ellipse([wx - 5, 219, wx + 5, 229], fill=(78, 82, 88))
    rect(ld, 806, 160, 924, 212, (0, 0, 0, 0)); rect(ld, 800, 156, 930, 214, (60, 66, 52))
    for k in range(5): rect(ld, 806 + k * 24, 160, 826 + k * 24, 212, (136, 100, 64) if k % 2 == 0 else (120, 90, 58))
    rect(ld, 796, 156, 806, 214, (88, 98, 70)); text_px(layer, 930, 192, "114", (200, 200, 180), 6)
    img.alpha_composite(layer); crates(img, 990, 244, 3, 2, rnd, ["ARROZ", "FEIJÃO", "ÓLEO"]); crates(img, 1060, 244, 2, 3, rnd, ["LEITE", "SAL"])
    # água
    d = ImageDraw.Draw(img); rect(d, 1190, 176, 1244, 232, (86, 100, 118)); rect(d, 1190, 176, 1244, 182, (108, 124, 144)); rect(d, 1186, 172, 1248, 176, SNOW); rect(d, 1244, 214, 1262, 220, (60, 64, 70))
    rect(d, 1262, 214, 1266, 232, (60, 64, 70)); sign(img, 1156, 128, 116, "ÁGUA · 5L/PESSOA", col=(34, 62, 90), ink=(236, 236, 230), size=8)
    for k in range(3): rect(d, 1280 + k * 12, 220, 1290 + k * 12, 236, (170, 150, 60) if k != 1 else (60, 100, 150)); 
    # quadro de avisos e alto-falante
    rect(d, 1370, 180, 1374, 232, (60, 46, 38)); rect(d, 1470, 180, 1474, 232, (60, 46, 38)); rect(d, 1358, 128, 1486, 190, (84, 66, 52)); rect(d, 1358, 128, 1486, 130, SNOW)
    poster_rows(img, 1362, 1482, 134, 188, rnd); text_px(img, 1368, 116, "AVISOS · ABRIGO Nº 3", (222, 210, 170), 7)
    rect(d, 1520, 90, 1525, 232, (58, 60, 66)); d.polygon([(1525, 96), (1548, 88), (1548, 112), (1525, 108)], fill=(86, 90, 98)); rect(d, 1523, 92, 1527, 96, SNOW)
    # ruína com "teatro de meias"
    building(img, 1580, 150, 130, rnd, "brick", (96, 70, 62), [(1598, 144, 0), (1636, 144, 0)], broken=0.9)
    a = np.array(img); a[130:228, 1655:1730, 3] = 0; img = Image.fromarray(a, "RGBA"); d = ImageDraw.Draw(img)
    rubble(img, 1650, 230, 90, rnd); tape(img, 1580, 226, 1730, 232)
    rect(d, 1752, 196, 1800, 232, (110, 84, 62)); rect(d, 1748, 188, 1804, 198, (176, 60, 52)); rect(d, 1748, 186, 1804, 189, SNOW); rect(d, 1758, 204, 1794, 226, (30, 28, 34)); text_px(img, 1754, 190, "TEATRO", (246, 236, 214), 7)
    rect(d, 1768, 206, 1774, 214, (200, 70, 70)); rect(d, 1780, 208, 1786, 216, (230, 200, 80))
    lamp_post(img, 1856, rnd, tilt=-2); sign(img, 1790, 120, 100, "PRAÇA →", col=(52, 70, 96), ink=(226, 232, 240), size=9, post=True)
    finish_outdoor(img, "humanitaria_main")


# ====================================================================== INTERIORES (mesmo recorte da casa: parede y 56-168, piso y 168-300)
DARK_BG = (9, 13, 21, 255)


def room_base(W, walls, floors, rnd):
    """walls: [(x0, x1, cor)]; floors: [(x0, x1, cor)]. Fundo escuro opaco fora do cômodo (como house.png)."""
    img = new(W, H, DARK_BG)
    for (x0, x1, col) in walls:
        plaster(img, x0, 56, x1, 168, col, rnd)
        d = ImageDraw.Draw(img); rect(d, x0, 138, x1, 168, shade(col, 0.72)); rect(d, x0, 138, x1, 140, shade(col, 1.18)); rect(d, x0, 164, x1, 168, shade(col, 0.45))
        for xx in range(x0, x1, 22): vline(d, xx, 141, 164, shade(col, 0.64))
    for (x0, x1, col) in floors: plank_floor(img, x0, 168, x1, 300, rnd, col, patches=True)
    shadeband(img, 0, 56, W, 72, 0.78)
    return img


def tall_window(img, x, y, w, h, rnd, snow=True):
    d = ImageDraw.Draw(img); rect(d, x - 3, y - 3, x + w + 3, y + h + 3, (40, 34, 32)); rect(d, x, y, x + w, y + h, (150, 172, 198))
    for k in range(h):
        c = mix((190, 208, 228), (120, 142, 170), k / h); d.line([(x, y + k), (x + w - 1, y + k)], fill=c + (255,))
    rect(d, x + w // 2 - 1, y, x + w // 2 + 1, y + h, (40, 34, 32)); rect(d, x, y + h // 2, x + w, y + h // 2 + 2, (40, 34, 32))
    d.line([(x, y), (x + w, y + h)], fill=(214, 208, 190), width=1); d.line([(x + w, y), (x, y + h)], fill=(214, 208, 190), width=1)
    rect(d, x - 4, y + h + 3, x + w + 4, y + h + 5, SNOW_D)
    lay = new(*img.size); ld = ImageDraw.Draw(lay)
    ld.polygon([(x + 4, y + h), (x + w - 4, y + h), (x + w + 60, 298), (x - 30, 298)], fill=(190, 208, 232, 26)); img.alpha_composite(lay)


def door_light(img, x, w=52, text=None):
    d = ImageDraw.Draw(img); rect(d, x - 5, 84, x + w + 5, 168, (52, 40, 34)); rect(d, x, 90, x + w, 168, (176, 196, 216))
    for k in range(78): d.line([(x, 90 + k), (x + w - 1, 90 + k)], fill=mix((210, 224, 238), (150, 170, 196), k / 78) + (255,))
    rect(d, x + w // 2 - 1, 90, x + w // 2 + 1, 168, (52, 40, 34)); rect(d, x, 150, x + w, 168, SNOW)
    glow(img, x + w // 2, 200, 70, (170, 190, 220), 0.30)
    if text: text_px(img, x - 6, 72, text, (232, 220, 186), 7)


def book_rows(img, x0, x1, y0, y1, rnd, fill=0.85, pal=None):
    d = ImageDraw.Draw(img); pal = pal or [(70, 90, 130), (130, 70, 70), (90, 110, 80), (150, 126, 80), (104, 80, 124), (60, 100, 110), (150, 100, 60)]
    for yy in range(y0, y1, 22):
        rect(d, x0, yy + 20, x1, yy + 22, (62, 46, 36)); sx = x0 + 2
        while sx < x1 - 6:
            if rnd.random() > fill: sx += rnd.randint(4, 10); continue
            bw = rnd.randint(3, 6); bh = rnd.randint(12, 19); c = jitter(rnd.choice(pal), rnd, 14)
            rect(d, sx, yy + 20 - bh, sx + bw, yy + 20, shade(c, 0.7)); rect(d, sx, yy + 20 - bh, sx + 1, yy + 20, c); rect(d, sx + 1, yy + 20 - bh + 3, sx + bw - 1, yy + 20 - bh + 4, shade(c, 1.3)); sx += bw + 1


def bookcase(img, x0, x1, y0, y1, rnd, fill=0.85, wood=(74, 54, 42)):
    d = ImageDraw.Draw(img); rect(d, x0, y0, x1, y1, shade(wood, 0.55)); book_rows(img, x0 + 3, x1 - 3, y0 + 2, y1 - 2, rnd, fill)
    rect(d, x0, y0, x0 + 3, y1, wood); rect(d, x1 - 3, y0, x1, y1, wood); rect(d, x0, y0, x1, y0 + 3, shade(wood, 1.25)); rect(d, x0, y1 - 2, x1, y1, shade(wood, 0.7))


def mattress(img, x, y, w, h, col, rnd, pillow=True):
    d = ImageDraw.Draw(img); rect(d, x, y + 3, x + w, y + h, shade(col, 0.55)); rect(d, x, y, x + w, y + h - 3, col)
    for k in range(x + 6, x + w - 3, 8): d.line([(k, y + 1), (k, y + h - 4)], fill=shade(col, 0.82))
    rect(d, x, y, x + w, y + 1, shade(col, 1.3))
    if pillow: rect(d, x + 3, y + 2, x + 16, y + h - 5, (214, 206, 190)); rect(d, x + 3, y + 2, x + 16, y + 3, (236, 230, 216))
    bl = jitter(rnd.choice([(96, 60, 60), (70, 90, 110), (110, 100, 70), (80, 100, 80)]), rnd, 8)
    d.polygon([(x + 18, y + 2), (x + w, y + 3), (x + w, y + h - 2), (x + 18, y + h - 3)], fill=bl)
    for k in range(x + 22, x + w, 8): d.line([(k, y + 3), (k, y + h - 3)], fill=shade(bl, 0.8))
    rect(d, x + 18, y + 2, x + w, y + 4, shade(bl, 1.3))


def stove(img, x, y_base):
    d = ImageDraw.Draw(img); rect(d, x, y_base - 30, x + 34, y_base, (46, 48, 54)); rect(d, x, y_base - 30, x + 34, y_base - 28, (84, 88, 96)); rect(d, x + 4, y_base - 22, x + 20, y_base - 8, (20, 20, 22)); rect(d, x + 6, y_base - 14, x + 18, y_base - 9, (230, 130, 50))
    rect(d, x + 14, y_base - 90, x + 20, y_base - 30, (58, 60, 66)); rect(d, x + 14, y_base - 90, x + 16, y_base - 30, (86, 90, 98)); glow(img, x + 12, y_base - 12, 50, (255, 150, 60), 0.35)
    rect(d, x + 22, y_base - 38, x + 32, y_base - 30, (130, 134, 140)); rect(d, x + 31, y_base - 36, x + 35, y_base - 34, (130, 134, 140))   # chaleira


def cartridge(img, x, y, kind):
    d = ImageDraw.Draw(img)
    pal = {"space": ((24, 30, 64), (92, 130, 220), "ST"), "guitar": ((120, 40, 24), (240, 160, 60), "GL"), "tinta": ((40, 90, 80), (150, 220, 190), "MT"), "corrida": ((90, 90, 96), (230, 230, 120), "CN")}
    bg, fg, tx = pal[kind]
    rect(d, x, y, x + 20, y + 26, bg); rect(d, x, y, x + 20, y + 1, shade(bg, 1.5)); rect(d, x + 2, y + 3, x + 18, y + 17, shade(bg, 0.6))
    if kind == "space":
        d.polygon([(x + 10, y + 5), (x + 14, y + 14), (x + 6, y + 14)], fill=fg); rect(d, x + 4, y + 8, x + 5, y + 9, (240, 240, 255)); rect(d, x + 15, y + 6, x + 16, y + 7, (240, 240, 255))
    elif kind == "guitar":
        d.line([(x + 4, y + 15), (x + 15, y + 5)], fill=fg, width=2); d.ellipse([x + 3, y + 12, x + 8, y + 17], fill=fg)
    elif kind == "tinta":
        d.ellipse([x + 5, y + 6, x + 14, y + 14], fill=fg); rect(d, x + 8, y + 4, x + 11, y + 7, (200, 80, 80))
    else:
        d.line([(x + 3, y + 14), (x + 17, y + 14)], fill=fg, width=1); d.polygon([(x + 5, y + 12), (x + 15, y + 12), (x + 13, y + 8), (x + 7, y + 8)], fill=fg)
    rect(d, x + 3, y + 19, x + 17, y + 24, (220, 214, 196)); text_px(img, x + 4, y + 18, tx, (40, 36, 36), 6)


def poster_big(img, x, y, w, h, kind, rnd):
    d = ImageDraw.Draw(img)
    pal = {"another": ((20, 24, 44), (230, 170, 70)), "space": ((10, 14, 40), (110, 160, 240)), "guitar": ((90, 30, 20), (250, 190, 80)), "band": ((24, 22, 28), (200, 70, 70))}
    bg, fg = pal[kind]; rect(d, x - 1, y - 1, x + w + 1, y + h + 1, (30, 26, 26)); rect(d, x, y, x + w, y + h, bg)
    for _ in range(18): d.point((x + rnd.randint(1, w - 2), y + rnd.randint(1, h - 2)), fill=(230, 230, 255))
    if kind == "another":
        d.ellipse([x + w // 2 - 9, y + 8, x + w // 2 + 9, y + 26], outline=fg); d.line([(x + w // 2 - 9, y + 17), (x + w // 2 + 9, y + 17)], fill=fg)
        text_px(img, x + 4, y + h - 18, "ANOTHER", fg, 7); text_px(img, x + 4, y + h - 10, "CONCEPT", fg, 7)
    elif kind == "space":
        d.polygon([(x + w // 2, y + 8), (x + w // 2 + 8, y + 30), (x + w // 2 - 8, y + 30)], fill=fg); text_px(img, x + 3, y + h - 20, "SPACE", fg, 8); text_px(img, x + 3, y + h - 11, "TRAVELERS", fg, 6)
    elif kind == "guitar":
        d.line([(x + 6, y + 34), (x + w - 8, y + 8)], fill=fg, width=3); d.ellipse([x + 4, y + 28, x + 16, y + 40], fill=fg); text_px(img, x + 3, y + h - 20, "GUITAR", fg, 8); text_px(img, x + 3, y + h - 11, "LEGENDS", fg, 7)
    else: text_px(img, x + 3, y + 6, "HOLLOW", fg, 7); text_px(img, x + 3, y + 15, "CITY", fg, 7)


def save_room(img, name, props=()):
    img.convert("RGBA").save(OUT + name + ".png"); img.convert("RGB").save("/tmp/an/prev_%s.png" % name); print(name, "ok", img.size)


def prop(name, w, h, painter):
    im = new(w, h); painter(im, ImageDraw.Draw(im)); im.save(OUT + name + ".png"); print(" prop", name, (w, h))


def wood_counter(w, h, top=(150, 112, 78), front=(96, 70, 52), items=None, rnd=None):
    def p(im, d):
        rect(d, 0, 0, w, 10, top); rect(d, 0, 0, w, 2, shade(top, 1.25)); rect(d, 0, 9, w, 11, shade(top, 0.6))
        rect(d, 0, 11, w, h, front)
        for x in range(8, w - 4, 22): rect(d, x, 15, x + 18, h - 5, shade(front, 0.82)); rect(d, x, 15, x + 18, 16, shade(front, 1.2)); rect(d, x + 17, 15, x + 18, h - 5, shade(front, 0.55))
        rect(d, 0, h - 3, w, h, shade(front, 0.45)); rect(d, 0, 0, 2, h, shade(front, 0.7))
        if items: items(im, d)
    return p


# ---------------------------------------------------------------------- BIBLIOTECA (W 2440)
def biblioteca():
    W = 2440; rnd = random.Random(77)
    walls = [(80, 480, (132, 126, 112)), (480, 1010, (112, 118, 110)), (1010, 1190, (104, 108, 112)), (1190, 1770, (110, 114, 112)), (1770, 2130, (78, 60, 48)), (2130, 2380, (84, 90, 112))]
    floors = [(80, 480, (96, 84, 74)), (480, 1010, (88, 72, 60)), (1010, 1190, (80, 68, 60)), (1190, 1770, (92, 76, 62)), (1770, 2130, (82, 62, 48)), (2130, 2380, (70, 70, 84))]
    img = room_base(W, walls, floors, rnd); d = ImageDraw.Draw(img)
    # ---- entrada / recepção
    door_light(img, 108, 52, text="BIBLIOTECA MUNICIPAL")
    rect(d, 96, 262, 176, 286, (150, 156, 164)); rect(d, 96, 262, 176, 264, (200, 206, 214)); text_px(img, 112, 270, "SECAR OS PÉS", (90, 94, 100), 6, bold=False)       # capacho com pegadas de neve
    for k in range(5): d.ellipse([112 + k * 12, 268 + (k % 2) * 6, 116 + k * 12, 274 + (k % 2) * 6], fill=(120, 126, 136))
    rect(d, 196, 124, 200, 168, (60, 46, 38)); rect(d, 190, 118, 214, 124, (60, 46, 38))
    for k, c in enumerate([(90, 70, 70), (70, 80, 100), (110, 100, 80)]): rect(d, 194 + k * 8, 126 + k * 4, 202 + k * 8, 148 + k * 4, c)   # cabides com casacos
    rect(d, 232, 84, 330, 134, (74, 56, 44)); rect(d, 234, 86, 328, 132, (206, 198, 174)); text_px(img, 240, 88, "REGRAS DO ABRIGO", (50, 44, 40), 7)
    for k, t in enumerate(["1 cartão = 1 caixa", "Silêncio (dentro do possível)", "Crianças com adultos", "Fogão: só a Dona Rute", "Ninguém dorme na fila"]): text_px(img, 240, 98 + k * 7, t, (70, 60, 54), 5, bold=False)
    tall_window(img, 352, 84, 38, 50, rnd)
    bench(img, 404, 250, 60)
    # ---- distribuição (parede do fundo com prateleiras de caixas)
    rect(d, 520, 70, 900, 78, (74, 56, 44)); text_px(img, 560, 56, "DISTRIBUIÇÃO — UM CARTÃO, UMA CAIXA", (232, 220, 186), 8)
    for sx in range(520, 900, 76):
        rect(d, sx, 84, sx + 4, 168, (74, 56, 44)); rect(d, sx, 118, sx + 76, 121, (74, 56, 44))
        for sy, n in ((90, 3), (124, 2)):
            for k in range(n): cx = sx + 6 + k * 22; c = jitter((136, 100, 66), rnd, 10); rect(d, cx, sy + 0, cx + 20, sy + 26, c); rect(d, cx, sy, cx + 20, sy + 1, shade(c, 1.3)); rect(d, cx + 5, sy + 8, cx + 15, sy + 16, (212, 204, 176))
    rect(d, 900, 84, 904, 168, (74, 56, 44))
    for k in range(3): d.line([(512 + k * 2, 252 + k * 16), (912 + k * 2, 252 + k * 16)], fill=(222, 190, 60), width=1) if False else None
    rect(d, 500, 256, 940, 258, (222, 190, 60)); text_px(img, 560, 262, "AGUARDE AQUI", (222, 190, 60), 6, bold=False)
    # ---- depósito restrito
    rect(d, 1036, 78, 1166, 168, (62, 66, 74)); rect(d, 1036, 78, 1166, 82, (92, 98, 108))
    for yy in range(86, 166, 6): d.line([(1040, yy), (1162, yy)], fill=(84, 90, 100))
    for xx in range(1040, 1164, 8): d.line([(xx, 86), (xx, 166)], fill=(48, 52, 58))
    rect(d, 1066, 100, 1136, 168, (80, 86, 94)); rect(d, 1066, 100, 1136, 104, (112, 120, 130)); vline(d, 1101, 104, 168, (50, 54, 60)); rect(d, 1096, 130, 1106, 140, (180, 150, 70)); rect(d, 1098, 126, 1104, 130, (150, 150, 150))
    rect(d, 1060, 66, 1142, 80, (150, 44, 40)); text_px(img, 1064, 67, "ACESSO RESTRITO", (246, 232, 226), 6); text_px(img, 1070, 90, "DEPÓSITO", (200, 206, 214), 6)
    glow(img, 1100, 76, 40, (255, 210, 130), 0.30)
    # ---- abrigo
    rect(d, 1220, 84, 1224, 138, (60, 46, 38)); 
    for k, (px, py, c) in enumerate([(1236, 92, (212, 160, 84)), (1262, 98, (110, 150, 200)), (1288, 90, (190, 100, 100)), (1312, 100, (140, 190, 130))]):
        rect(d, px, py, px + 18, py + 22, (230, 226, 210)); rect(d, px + 2, py + 2, px + 16, py + 20, c); d.line([(px + 4, py + 16), (px + 14, py + 6)], fill=shade(c, 0.5))
    text_px(img, 1232, 78, "DESENHOS DAS CRIANÇAS", (222, 210, 170), 6, bold=False)
    rect(d, 1560, 84, 1640, 134, (214, 206, 182)); text_px(img, 1566, 86, "DEZEMBRO 2008", (150, 40, 40), 7)
    for r in range(4):
        for c in range(7):
            x0 = 1564 + c * 11; y0 = 97 + r * 8; rect(d, x0, y0, x0 + 8, y0 + 6, (240, 236, 220))
            if (r * 7 + c) < 12: d.line([(x0, y0), (x0 + 8, y0 + 6)], fill=(150, 40, 40)); d.line([(x0 + 8, y0), (x0, y0 + 6)], fill=(150, 40, 40))
    tall_window(img, 1400, 84, 38, 50, rnd)
    mattress(img, 1204, 180, 118, 30, (82, 108, 140), rnd); mattress(img, 1342, 180, 118, 30, (120, 96, 70), rnd); mattress(img, 1480, 180, 112, 30, (90, 120, 100), rnd)
    mattress(img, 1300, 262, 118, 30, (96, 84, 120), rnd); mattress(img, 1500, 262, 118, 30, (130, 90, 80), rnd)
    d.line([(1330, 70), (1330, 214)], fill=(190, 190, 184), width=1)
    lay = new(W, H); ld = ImageDraw.Draw(lay)
    ld.polygon([(1332, 74), (1470, 80), (1470, 214), (1332, 216)], fill=(222, 218, 206, 70)); ld.line([(1332, 74), (1470, 80)], fill=(235, 232, 220, 180))     # lençol-divisória
    img.alpha_composite(lay); d = ImageDraw.Draw(img)
    for sx, sy in ((1218, 214), (1236, 220)): rect(d, sx, sy, sx + 18, sy + 12, (96, 78, 56)); rect(d, sx, sy, sx + 18, sy + 2, (130, 108, 80)); rect(d, sx + 7, sy + 4, sx + 11, sy + 6, (180, 160, 90))   # malas
    stove(img, 1676, 168)
    # ---- estantes
    for i, x0 in enumerate(range(1780, 2120, 68)): bookcase(img, x0, min(x0 + 66, 2124), 76, 168, rnd, fill=0.9 if i != 1 else 0.55)
    rect(d, 1790, 66, 1870, 76, (232, 220, 186)); text_px(img, 1796, 66, "FICÇÃO · AVENTURA", (60, 44, 36), 6, bold=False)
    rect(d, 1930, 66, 2000, 76, (232, 220, 186)); text_px(img, 1936, 66, "INFANTIL", (60, 44, 36), 6, bold=False)
    rect(d, 2040, 66, 2120, 76, (232, 220, 186)); text_px(img, 2046, 66, "REVISTAS · JOGOS", (60, 44, 36), 6, bold=False)
    glow(img, 1920, 210, 90, (255, 200, 120), 0.20)
    # ---- entretenimento
    rect(d, 2160, 218, 2370, 292, (70, 56, 84)); rect(d, 2166, 224, 2364, 286, (86, 70, 102))
    for k in range(6): d.line([(2166 + k * 34, 224), (2166 + k * 34, 286)], fill=(104, 86, 120))
    rect(d, 2150, 96, 2284, 152, (60, 46, 38)); rect(d, 2154, 100, 2280, 148, (36, 32, 36))
    for i, kind in enumerate(["space", "guitar", "tinta", "corrida"]): cartridge(img, 2160 + i * 30, 104, kind); 
    for i, kind in enumerate(["tinta", "corrida", "space"]): cartridge(img, 2168 + i * 30, 128 - 0, kind) if False else None
    rect(d, 2150, 150, 2284, 154, (90, 68, 52)); text_px(img, 2156, 86, "JOGOS (CUIDEM DELES)", (232, 220, 186), 6, bold=False)
    poster_big(img, 2302, 84, 54, 70, "another", rnd); poster_big(img, 2134, 70, 0, 0, "band", rnd) if False else None
    tall_window(img, 2200, 160, 0, 0, rnd) if False else None
    d.ellipse([2176, 246, 2210, 272], fill=(180, 80, 60)); d.ellipse([2182, 248, 2204, 258], fill=(204, 108, 84))                                   # pufe
    d.ellipse([2222, 280, 2256, 300], fill=(60, 90, 120)); 
    rect(d, 2262, 270, 2284, 282, (140, 142, 150)); rect(d, 2262, 270, 2284, 272, (176, 178, 186)); rect(d, 2268, 276, 2272, 278, (60, 200, 80))                         # console
    d.line([(2284, 278), (2300, 262), (2308, 238)], fill=(30, 30, 34), width=1)
    glow(img, 2330, 200, 80, (110, 150, 230), 0.22)
    # luminárias penduradas (lâmpadas nuas)
    for lx, ly in ((330, 70), (700, 70), (1100, 60), (1500, 70), (1700, 70), (1900, 70), (2250, 70)):
        d.line([(lx, 56), (lx, ly + 8)], fill=(30, 28, 28)); rect(d, lx - 2, ly + 8, lx + 3, ly + 14, (250, 226, 150)); glow(img, lx, ly + 14, 90, (255, 214, 140), 0.32)
    shadeband(img, 0, 286, W, 300, 0.78)
    save_room(img, "biblioteca")
    # --- props com ordenação por profundidade
    def dist_items(im, dd):
        rect(dd, 20, -8, 62, 0, (136, 100, 66)); rect(dd, 20, -8, 62, -7, (176, 140, 100)); rect(dd, 28, -4, 54, -1, (212, 204, 176))
        rect(dd, 150, -4, 190, 0, (214, 206, 182)); rect(dd, 150, -4, 190, -3, (240, 236, 220)); rect(dd, 300, -10, 322, 0, (60, 60, 66)); rect(dd, 306, -14, 316, -10, (180, 40, 40))
    def cdist(im, dd):
        wood_counter(380, 52, items=None)(im, dd)
        rect(dd, 20, 0, 62, 3, (0, 0, 0, 0))
    # os itens ficam no tampo (y 0..10): desenhados dentro do próprio sprite com 12 px de folga acima
    def pdist(im, dd):
        rect(dd, 0, 12, 380, 22, (150, 112, 78)); rect(dd, 0, 12, 380, 14, (190, 150, 108)); rect(dd, 0, 21, 380, 23, (92, 64, 46)); rect(dd, 0, 23, 380, 64, (96, 70, 52))
        for x in range(8, 372, 28): rect(dd, x, 28, x + 22, 59, shade((96, 70, 52), 0.82)); rect(dd, x, 28, x + 22, 29, shade((96, 70, 52), 1.2)); rect(dd, x + 21, 28, x + 22, 59, shade((96, 70, 52), 0.55))
        rect(dd, 0, 61, 380, 64, shade((96, 70, 52), 0.45)); rect(dd, 0, 12, 2, 64, shade((96, 70, 52), 0.7))
        rect(dd, 24, 6, 46, 12, (136, 100, 66)); rect(dd, 24, 6, 46, 7, (176, 140, 100)); rect(dd, 28, 8, 42, 11, (212, 204, 176))             # caixas de ração prontas
        rect(dd, 52, 6, 74, 12, (136, 100, 66)); rect(dd, 52, 6, 74, 7, (176, 140, 100))
        rect(dd, 150, 8, 192, 12, (214, 206, 182)); rect(dd, 150, 8, 192, 9, (240, 236, 220)); rect(dd, 156, 9, 186, 10, (120, 110, 100))         # livro-caixa
        rect(dd, 300, 4, 326, 12, (66, 68, 74)); rect(dd, 306, 0, 320, 4, (186, 42, 42)); rect(dd, 310, 5, 316, 11, (230, 226, 214))                 # balança
        rect(dd, 250, 8, 262, 12, (60, 60, 66)); rect(dd, 252, 4, 260, 8, (150, 40, 40))                                                        # carimbo
        rect(dd, 340, 6, 352, 12, (200, 200, 190)); rect(dd, 342, 2, 350, 6, (200, 200, 190))                                                   # caneca
    prop("bib_balcao", 380, 64, pdist)
    def prec(im, dd):
        rect(dd, 0, 10, 130, 18, (150, 112, 78)); rect(dd, 0, 10, 130, 12, (190, 150, 108)); rect(dd, 0, 17, 130, 19, (92, 64, 46)); rect(dd, 0, 19, 130, 52, (96, 70, 52))
        for x in range(8, 120, 28): rect(dd, x, 24, x + 22, 47, shade((96, 70, 52), 0.82))
        rect(dd, 0, 49, 130, 52, shade((96, 70, 52), 0.45)); rect(dd, 10, 4, 34, 10, (214, 206, 182)); rect(dd, 90, 0, 98, 10, (120, 120, 126)); rect(dd, 88, -2, 100, 2, (246, 220, 140)) if False else None
        rect(dd, 94, 2, 108, 10, (200, 200, 190)); rect(dd, 60, 6, 78, 10, (70, 90, 130))
    prop("bib_recepcao", 130, 52, prec)
    def ptable(im, dd):
        rect(dd, 0, 8, 124, 18, (140, 104, 72)); rect(dd, 0, 8, 124, 10, (180, 142, 102)); rect(dd, 4, 18, 9, 34, (80, 58, 44)); rect(dd, 115, 18, 120, 34, (80, 58, 44)); rect(dd, 0, 17, 124, 19, (86, 60, 44))
        rect(dd, 14, 3, 34, 8, (70, 90, 130)); rect(dd, 14, 3, 34, 4, (120, 150, 200)); rect(dd, 38, 4, 58, 8, (130, 70, 70)); rect(dd, 80, -6, 84, 8, (60, 60, 64)); rect(dd, 74, -10, 90, -5, (240, 214, 130))
        rect(dd, 96, 4, 114, 8, (214, 206, 182))
    prop("bib_mesa", 124, 36, ptable)
    def ptv(im, dd):
        rect(dd, 0, 36, 62, 40, (60, 52, 46)); rect(dd, 4, 40, 8, 66, (60, 52, 46)); rect(dd, 54, 40, 58, 66, (60, 52, 46)); rect(dd, 2, 54, 60, 57, (84, 72, 62))
        rect(dd, 4, 2, 58, 36, (150, 146, 134)); rect(dd, 4, 2, 58, 4, (186, 182, 170)); rect(dd, 8, 6, 46, 32, (0, 0, 0, 0)); rect(dd, 49, 8, 55, 12, (90, 90, 86)); rect(dd, 49, 16, 55, 20, (60, 60, 56))
        dd.line([(24, 2), (14, -8)], fill=(60, 60, 64), width=1); dd.line([(38, 2), (48, -10)], fill=(60, 60, 64), width=1)
    prop("bib_tv", 62, 66, ptv)
    for nm, fn in (("bib_tv_screen", None),): pass


# ---------------------------------------------------------------------- LOCADORA (W 800) — interior de loja abandonada
def locadora():
    W = 800; rnd = random.Random(88)
    img = room_base(W, [(80, 720, (88, 82, 98))], [(80, 720, (74, 62, 58))], rnd); d = ImageDraw.Draw(img)
    door_light(img, 108, 48, text="VÍDEO PONTO")
    # neon apagado
    rect(d, 206, 70, 330, 100, (30, 28, 34)); text_px(img, 214, 74, "VÍDEO PONTO", (70, 40, 60), 11); d.line([(206, 104), (330, 104)], fill=(60, 36, 52), width=2)
    # prateleiras de fitas e jogos
    for i, x0 in enumerate(range(380, 632, 64)):
        rect(d, x0, 76, x0 + 60, 168, (60, 48, 42)); rect(d, x0 + 3, 80, x0 + 57, 165, (30, 28, 32))
        for yy in (84, 108, 132, 156 - 4):
            rect(d, x0 + 3, yy + 18, x0 + 57, yy + 20, (74, 60, 50)); sx = x0 + 5
            while sx < x0 + 54:
                if rnd.random() < 0.18: sx += 5; continue
                c = rnd.choice([(40, 40, 46), (34, 34, 40), (70, 30, 30), (40, 56, 90), (96, 80, 40)]); rect(d, sx, yy + 2, sx + 4, yy + 18, c); rect(d, sx + 1, yy + 6, sx + 3, yy + 12, (200, 196, 180)); sx += 5
    poster_big(img, 232, 84, 40, 54, "space", rnd); poster_big(img, 282, 90, 40, 50, "guitar", rnd); poster_big(img, 176, 92, 36, 46, "band", rnd)
    # TV velha e caixa de devolução
    rect(d, 330, 124, 366, 160, (120, 118, 110)); rect(d, 334, 128, 360, 154, (14, 18, 22))
    rect(d, 186, 256, 226, 284, (90, 70, 52)); rect(d, 186, 256, 226, 259, (130, 104, 76)); text_px(img, 190, 264, "DEVOLUÇÃO", (222, 210, 170), 6, bold=False)
    # expositor no meio da loja (bloco) com capas
    rect(d, 450, 214, 540, 248, (66, 52, 44)); rect(d, 450, 214, 540, 217, (100, 80, 64))
    for k in range(8): rect(d, 454 + k * 11, 200, 462 + k * 11, 214, rnd.choice([(40, 56, 110), (120, 40, 40), (40, 100, 80), (110, 90, 40)]))
    # poeira e luz da janela
    tall_window(img, 640, 84, 36, 50, rnd)
    glow(img, 140, 210, 70, (170, 190, 220), 0.25); shadeband(img, 80, 286, 720, 300, 0.8)
    save_room(img, "locadora")
    def pc(im, dd):
        rect(dd, 0, 12, 120, 20, (126, 96, 70)); rect(dd, 0, 12, 120, 14, (170, 138, 104)); rect(dd, 0, 20, 120, 56, (84, 62, 48)); rect(dd, 0, 53, 120, 56, (50, 38, 30))
        rect(dd, 10, 2, 40, 12, (196, 190, 170)); rect(dd, 10, 2, 40, 3, (226, 220, 200)); rect(dd, 14, 4, 36, 8, (40, 40, 44))   # caixa registradora aberta
        rect(dd, 70, 6, 94, 12, (214, 206, 182)); rect(dd, 98, 4, 110, 12, (70, 90, 130))
    prop("loc_balcao", 120, 56, pc)


# ---------------------------------------------------------------------- PADARIA (W 800) — estabelecimento em funcionamento mínimo
def padaria():
    W = 800; rnd = random.Random(99)
    img = room_base(W, [(80, 720, (142, 118, 92))], [(80, 720, (112, 88, 64))], rnd); d = ImageDraw.Draw(img)
    door_light(img, 108, 48, text="PÃO & PROSA")
    # forno de tijolos com fogo
    rect(d, 520, 70, 650, 168, (110, 70, 56)); bricks(img, 520, 70, 650, 168, (126, 76, 58), rnd, bw=12, bh=6, var=10)
    rect(d, 548, 110, 622, 160, (22, 18, 18)); rect(d, 546, 106, 624, 112, (150, 140, 128)); rect(d, 556, 140, 614, 158, (230, 110, 40)); rect(d, 566, 130, 604, 150, (250, 170, 60)); rect(d, 576, 124, 594, 140, (255, 220, 120))
    glow(img, 585, 140, 120, (255, 150, 50), 0.55); rect(d, 570, 40, 600, 70, (110, 70, 56))
    # prateleiras vazias atrás do balcão e quadro de preços apagado
    for x0 in (210, 300): rect(d, x0, 90, x0 + 80, 94, (96, 70, 52)); rect(d, x0, 120, x0 + 80, 124, (96, 70, 52)); rect(d, x0 + 6, 82, x0 + 20, 90, (230, 226, 214)); 
    rect(d, 400, 84, 480, 140, (34, 42, 38)); rect(d, 398, 82, 482, 85, (110, 82, 56)); text_px(img, 406, 88, "PÃO FRANCÊS", (130, 130, 124), 6, bold=False); text_px(img, 406, 100, "PÃO DOCE", (110, 110, 106), 6, bold=False)
    for k in range(4): d.line([(406, 90 + k * 12 + 8), (470, 90 + k * 12 + 8)], fill=(70, 74, 72))
    text_px(img, 406, 122, "SÓ HOJE:", (222, 214, 190), 6, bold=False)
    # sacos de farinha e mesa de trabalho
    for k in range(3): rect(d, 664 + (k % 2) * 8, 232 - k * 22, 700 + (k % 2) * 8, 252 - k * 22, (216, 208, 188)); rect(d, 664 + (k % 2) * 8, 232 - k * 22, 700 + (k % 2) * 8, 234 - k * 22, (240, 234, 216)); text_px(img, 670 + (k % 2) * 8, 236 - k * 22, "FARINHA", (150, 60, 50), 5)
    d.ellipse([668, 196, 692, 212], fill=(120, 124, 134)); d.polygon([(670, 198), (673, 190), (677, 198)], fill=(120, 124, 134)); d.polygon([(683, 198), (687, 190), (690, 198)], fill=(120, 124, 134)); d.line([(672, 204), (680, 204)], fill=(86, 90, 98))   # Miolo
    rect(d, 440, 220, 540, 252, (150, 118, 84)); rect(d, 440, 220, 540, 224, (190, 156, 116)); rect(d, 446, 252, 452, 270, (84, 62, 46)); rect(d, 528, 252, 534, 270, (84, 62, 46)); d.ellipse([460, 208, 500, 222], fill=(226, 214, 188)); d.ellipse([506, 212, 528, 222], fill=(214, 202, 176))
    tall_window(img, 340, 150, 0, 0, rnd) if False else None
    glow(img, 150, 210, 60, (170, 190, 220), 0.22); shadeband(img, 80, 286, 720, 300, 0.85)
    save_room(img, "padaria")
    def pc(im, dd):
        rect(dd, 0, 12, 230, 20, (170, 126, 86)); rect(dd, 0, 12, 230, 14, (210, 168, 124)); rect(dd, 0, 20, 230, 56, (110, 80, 58)); rect(dd, 0, 53, 230, 56, (60, 44, 34))
        for x in range(8, 222, 30): rect(dd, x, 26, x + 24, 49, shade((110, 80, 58), 0.82))
        rect(dd, 14, 4, 90, 12, (226, 218, 196)); dd.ellipse([20, 0, 40, 10], fill=(176, 120, 64)); dd.ellipse([46, 0, 66, 10], fill=(168, 112, 60)); dd.ellipse([72, 2, 86, 10], fill=(170, 118, 66))   # os últimos pãezinhos
        rect(dd, 150, 2, 176, 12, (60, 60, 66)); rect(dd, 190, 4, 214, 12, (230, 226, 214))
    prop("pad_balcao", 230, 56, pc)


# ---------------------------------------------------------------------- CASA ABANDONADA (W 900) — sala/cozinha + quarto de criança
def casa():
    W = 900; rnd = random.Random(55)
    img = room_base(W, [(80, 520, (96, 112, 100)), (520, 820, (116, 100, 108))], [(80, 520, (86, 66, 52)), (520, 820, (92, 74, 64))], rnd); d = ImageDraw.Draw(img)
    door_light(img, 108, 48)
    rect(d, 514, 56, 526, 168, (74, 60, 52)); rect(d, 514, 168, 526, 200, (60, 48, 42)); rect(d, 514, 262, 526, 300, (60, 48, 42))   # parede divisória (vão de porta no meio)
    # cozinha/sala: mesa posta, fogão frio, fotos
    rect(d, 330, 90, 440, 134, (214, 206, 180)); rect(d, 330, 90, 440, 92, (240, 232, 210))
    for k in range(5): rect(d, 336 + k * 20, 100, 346 + k * 20, 126, [(120, 80, 70), (80, 100, 130), (110, 120, 80), (150, 120, 70), (90, 80, 120)][k]); rect(d, 336 + k * 20, 100, 346 + k * 20, 102, (232, 226, 210))
    rect(d, 240, 120, 300, 168, (120, 116, 110)); rect(d, 240, 120, 300, 124, (160, 156, 148)); rect(d, 250, 134, 288, 160, (36, 34, 36)); rect(d, 254, 100, 260, 120, (74, 72, 76))
    rect(d, 150, 90, 190, 136, (214, 200, 160)); rect(d, 154, 94, 186, 132, (96, 118, 150)); d.polygon([(154, 132), (186, 132), (170, 110)], fill=(80, 100, 70))      # quadro (paisagem)
    rect(d, 450, 96, 500, 134, (60, 50, 44)); rect(d, 452, 98, 498, 132, (200, 190, 168)); d.rectangle([460, 104, 490, 126], outline=(120, 110, 100)); d.ellipse([470, 108, 480, 118], fill=(150, 110, 90))   # foto de família
    rect(d, 206, 128, 218, 168, (90, 70, 56)); rect(d, 200, 124, 224, 130, (90, 70, 56)); rect(d, 204, 130, 220, 160, (96, 60, 60))
    rect(d, 166, 150, 184, 168, (150, 90, 66)); rect(d, 164, 148, 186, 152, (176, 108, 80)); d.line([(175, 148), (172, 134), (178, 128)], fill=(90, 80, 60), width=1)   # vaso seco                                            # cabide com casaco esquecido
    # quarto: cama, guarda-roupa, buraco no teto com neve
    rect(d, 560, 100, 640, 168, (110, 84, 62)); rect(d, 564, 104, 636, 164, (96, 72, 54)); vline(d, 600, 104, 164, (70, 52, 40)); rect(d, 596, 130, 599, 136, (190, 160, 90)); rect(d, 601, 130, 604, 136, (190, 160, 90))
    mattress(img, 668, 200, 120, 34, (86, 110, 150), rnd); rect(d, 668, 192, 672, 236, (120, 90, 64)); rect(d, 786, 196, 790, 236, (120, 90, 64))
    d.polygon([(690, 56), (740, 56), (750, 84), (700, 90)], fill=(10, 14, 22)); d.polygon([(690, 56), (740, 56), (736, 70), (696, 74)], fill=(180, 196, 218))
    d.polygon([(668, 270), (738, 270), (726, 288), (680, 288)], fill=(214, 223, 235)); d.polygon([(676, 270), (726, 270), (718, 280), (684, 280)], fill=(236, 242, 250))   # neve que entrou
    rect(d, 584, 270, 640, 284, (160, 60, 50)); rect(d, 584, 270, 640, 273, (200, 90, 70)); rect(d, 596, 266, 604, 270, (230, 200, 80)); rect(d, 612, 264, 622, 270, (70, 110, 170))      # trem de brinquedo
    rect(d, 560, 244, 580, 266, (60, 90, 130)); rect(d, 560, 244, 580, 247, (90, 124, 168))                                                                                          # mochila escolar
    rect(d, 760, 100, 800, 136, (214, 206, 180)); rect(d, 764, 104, 796, 132, (130, 156, 120))
    text_px(img, 768, 108, "SET", (150, 40, 40), 7); text_px(img, 766, 118, "2008", (60, 50, 44), 7)                                                                                 # calendário parado
    tall_window(img, 650, 84, 36, 50, rnd)
    for seg in (((668, 118), (668, 104), (662, 112)), ((668, 104), (674, 112), (668, 118))): pass
    d.line([(668, 120), (668, 100)], fill=(240, 246, 252), width=1); d.line([(668, 104), (661, 114)], fill=(240, 246, 252), width=1); d.line([(668, 104), (675, 114)], fill=(240, 246, 252), width=1); d.line([(664, 116), (672, 116)], fill=(240, 246, 252), width=1)   # nave desenhada no vidro
    glow(img, 140, 210, 60, (170, 190, 220), 0.25); shadeband(img, 80, 286, 820, 300, 0.82)
    save_room(img, "casa_vazia")
    def pmesa(im, dd):
        rect(dd, 0, 6, 120, 16, (150, 114, 82)); rect(dd, 0, 6, 120, 8, (190, 156, 120)); rect(dd, 6, 16, 11, 34, (96, 70, 54)); rect(dd, 109, 16, 114, 34, (96, 70, 54))
        for k in range(4): dd.ellipse([8 + k * 28, 2, 28 + k * 28, 10], fill=(226, 222, 210)); dd.ellipse([13 + k * 28, 3, 23 + k * 28, 8], fill=(204, 200, 190))
        rect(dd, 52, 0, 58, 6, (200, 196, 120)); rect(dd, 94, 0, 108, 6, (176, 140, 90))
    prop("casa_mesa", 120, 36, pmesa)


# ====================================================================== MINIJOGO: sprites em pixel art (Space Travelers)
def mini_sprites():
    def bmp(rows, pal):
        h = len(rows); w = max(len(r) for r in rows); im = new(w, h)
        for y, r in enumerate(rows):
            for x, ch in enumerate(r):
                if ch in pal: im.putpixel((x, y), pal[ch] + (255,))
        return im
    P = {"w": (236, 240, 252), "b": (96, 150, 240), "d": (40, 70, 150), "r": (230, 70, 60), "o": (255, 170, 60), "y": (255, 232, 120), "g": (120, 130, 150), "k": (54, 60, 78), "e": (90, 220, 130), "p": (190, 90, 220), "c": (110, 220, 230)}
    ship = ["......w......", ".....www.....", ".....wbw.....", "....wbbbw....", "...wbbcbbw...", "..dwbbbbbwd..", ".ddwbbbbbwdd.", "dd.wbdddbw.dd", "d..wb.o.bw..d", "...w..o..w...", ".......y....."]
    drone = ["..kggk..", ".kgrrgk.", "kggrrggk", "kgggggk.", ".kg..gk.", "k......k"]
    shooter = ["...kk...", "..kggk..", ".kgppgk.", "kgpppgk.", "kggppggk", ".kgkkgk.", "..k..k.."]
    sentinel = ["..kkkkkk..", ".kggggggk.", "kgg.rr.ggk", "kgg.rr.ggk", "kggggggggk", "kgkggggkgk", ".kg.kk.gk.", "..k....k.."]
    boss = ["......kkkkkkkk......", "....kkggggggggkk....", "...kggggggggggggk...", "..kgg.rrgggg.rrgg k.".replace(" ", ""), "..kgg.rrgggg.rrggk..", ".kgggggggrrgggggggk.", ".kggkkgggrrgggkkggk.", "kgggkggggggggggkgggk", "kggk.kgggggggk.kgggk", "kgk...kkkkkkk...kgk.", "kk..............kk.."]
    sprites = {"st_ship": bmp(ship, P), "st_drone": bmp(drone, P), "st_shooter": bmp(shooter, P), "st_sentinel": bmp(sentinel, P), "st_boss": bmp(boss, P),
               "st_shot": bmp(["y", "y", "o"], P), "st_ebullet": bmp([".r.", "rpr", ".r."], P), "st_heart": bmp([".rr.rr.", "rrrrrrr", "rrrrrrr", ".rrrrr.", "..rrr..", "...r..."], P)}
    for k, im in sprites.items(): im.save(MG + k + ".png")
    sheet = new(200, 40, (10, 14, 40, 255)); x = 4
    for k, im in sprites.items(): sheet.alpha_composite(im, (x, 4)); x += im.width + 6
    sheet.resize((800, 160), Image.NEAREST).convert("RGB").save("/tmp/an/prev_minigame.png"); print("minigame ok")


if __name__ == "__main__":
    what = sys.argv[1] if len(sys.argv) > 1 else "all"
    table = {"bairro": bairro, "centro": centro, "praca": praca, "humanitaria": humanitaria, "biblioteca": biblioteca, "locadora": locadora, "padaria": padaria, "casa": casa, "minigame": mini_sprites}
    for k, fn in table.items():
        if what in ("all", k): fn()
