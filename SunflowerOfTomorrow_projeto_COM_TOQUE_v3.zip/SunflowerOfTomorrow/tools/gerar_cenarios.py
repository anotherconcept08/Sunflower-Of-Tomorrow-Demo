"""Gera os cenários do prólogo (PNG, 1 px = 1 px do jogo) no estilo de uma cidade arruinada sob neve.
Uso: python3 tools/gerar_cenarios.py [town|garden|house|all]   (requer numpy, scipy, opencv, pillow)
As posições de portas, janelas, objetos e colisões seguem os scripts em scripts/world/: mexa com cuidado."""
import sys, os, random, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pixlib import *
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "assets", "environments") + os.sep
os.makedirs(OUT, exist_ok=True)

def building(img, x, w, top, rnd, kind="brick", col=(92, 70, 62), windows=(), door=None, base_y=228, broken=0.35, boarded=0.12, chimney=None, shop=None, flat=False, shop_text="ARMAZÉM DIAS"):
    layer = new(*img.size); d = ImageDraw.Draw(layer)
    if kind == "brick": bricks(layer, x, top - 8, x + w, base_y, col, rnd)
    else: plaster(layer, x, top - 8, x + w, base_y, col, rnd)
    rect(d, x, base_y - 5, x + w, base_y, shade(col, 0.45))            # soco
    for fy in range(top + 36, base_y - 30, 46):                          # frisos entre andares
        rect(d, x - 1, fy, x + w + 1, fy + 2, mix(col, (200, 208, 220), 0.35)); rect(d, x - 1, fy + 2, x + w + 1, fy + 3, shade(col, 0.5))
    if chimney:
        cx, ct = chimney; rect(d, cx, ct, cx + 13, top + 4, shade(col, 0.7)); rect(d, cx - 1, ct - 2, cx + 14, ct + 1, (218, 226, 238))
    for (wx, wy, lit) in windows:
        if rnd.random() < boarded and not lit:
            rect(d, wx - 1, wy - 1, wx + 19, wy + 25, (22, 24, 30))
            for k in range(4): rect(d, wx - 2, wy + 1 + k * 6, wx + 20, wy + 4 + k * 6, jitter((82, 62, 46), rnd, 10))
        else:
            window(layer, wx, wy, 18, 24, rnd, broken=(rnd.random() < broken and not lit))
    if door:
        dx, dy = door; rect(d, dx - 2, dy - 2, dx + 26, base_y, (24, 22, 26)); rect(d, dx, dy, dx + 24, base_y, (66, 46, 36))
        rect(d, dx + 3, dy + 3, dx + 21, dy + 15, (30, 38, 52)); vline(d, dx + 12, dy, base_y, (40, 28, 22)); d.point((dx + 19, dy + 30), fill=(170, 150, 90))
        rect(d, dx - 4, base_y - 3, dx + 28, base_y, (214, 223, 235))
    if shop:
        sx, sy, sw = shop; rect(d, sx, sy, sx + sw, sy + 18, (52, 40, 32)); rect(d, sx, sy + 18, sx + sw, sy + 20, (214, 223, 235))
        text_px(layer, sx + 12, sy + 2, shop_text, (222, 205, 160), 11)
    prof = top_profile(x, x + w, top, rnd, rough=6, steps=5, flat=flat)
    apply_profile(layer, x, prof)
    snow_cap(layer, x, prof, rnd, depth=4)
    # sombra ambiente no pé e no lado direito
    a = np.array(layer).astype(np.float32); m = a[..., 3] > 0
    gh = np.clip((np.arange(a.shape[0])[:, None] - (base_y - 50)) / 50.0, 0, 1) * 0.35
    a[..., :3] *= (1 - gh[..., None]); layer = Image.fromarray(np.clip(a, 0, 255).astype(np.uint8), "RGBA")
    img.alpha_composite(layer)

def pine(img, x, base_y, h, rnd):
    d = ImageDraw.Draw(img); rect(d, x - 2, base_y - 14, x + 3, base_y, (40, 30, 26))
    for j in range(5):
        y = base_y - 14 - j * (h // 5); w = int((h // 5 + 18) * (1 - j * 0.14)) + 8
        d.polygon([(x - w, y), (x, y - h // 4), (x + w, y)], fill=(26, 44, 36))
        d.polygon([(x - w + 3, y - 2), (x, y - h // 4 + 3), (x + w - 3, y - 2)], fill=(34, 56, 44))
        d.line([(x - w, y), (x - w // 2, y - h // 8)], fill=(218, 228, 240), width=2); d.line([(x + w, y), (x + w // 2, y - h // 8)], fill=(218, 228, 240), width=2)
        d.line([(x - w // 2, y - 1), (x + w // 2, y - 1)], fill=(190, 204, 222), width=1)

def araucaria(img, x, base_y, rnd):
    d = ImageDraw.Draw(img); rect(d, x - 5, 96, x + 6, base_y, (44, 36, 34)); rect(d, x - 5, 96, x - 3, base_y, (66, 54, 48))
    for i in range(6):                                                    # galhos em candelabro
        yy = 104 + i * 18; L = 34 + i * 6
        for sgn in (-1, 1):
            d.line([(x, yy), (x + sgn * L, yy - 20)], fill=(36, 30, 30), width=3)
            for k in range(7):
                px = x + sgn * (L - 3 + rnd.randint(-8, 8)); py = yy - 20 - rnd.randint(0, 6)
                d.ellipse([px - 6, py - 4, px + 6, py + 4], fill=jitter((30, 54, 42), rnd, 8))
            d.line([(x + sgn * (L - 14), yy - 24), (x + sgn * (L + 8), yy - 24)], fill=(214, 224, 238), width=2)
    for k in range(10): d.ellipse([x - 40 + k * 8, 78 + rnd.randint(-3, 3), x - 28 + k * 8, 90], fill=jitter((32, 58, 44), rnd, 8))
    d.line([(x - 44, 78), (x + 44, 78)], fill=(214, 224, 238), width=2)

def town():
    W, H = 2240, 360; rnd = random.Random(11)
    sky(W, 232, (20, 27, 38), (104, 116, 132), 5, (44, 53, 66), (150, 160, 174)).save(OUT + "town_sky.png")
    # --- camada distante (parallax): torres arruinadas
    far = new(1400, 210); fd = ImageDraw.Draw(far)
    x = 0
    while x < 1400:
        w = rnd.randint(46, 96); h = rnd.randint(70, 190); col = jitter((52, 62, 77), rnd, 6)
        rect(fd, x, 210 - h, x + w, 210, col)
        prof = top_profile(x, x + w, 210 - h, rnd, rough=8, steps=4)
        apply_profile(far, x, prof)
        for wy in range(210 - h + 14, 200, 22):
            for wx in range(x + 8, x + w - 8, 16):
                if rnd.random() < 0.55: rect(fd, wx, wy, wx + 7, wy + 10, shade(col, 0.6))
        snow_cap(far, x, prof, rnd, depth=2, ice=False, white=(180, 192, 208)); x += w + rnd.randint(-8, 10)
    a = np.array(far).astype(np.float32); fog = np.clip((np.arange(210)[:, None] - 120) / 90.0, 0, 1)
    fogc = np.array((112, 124, 140), np.float32); a[..., :3] = a[..., :3] * (1 - fog[..., None] * 0.7) + fogc * fog[..., None] * 0.7
    Image.fromarray(np.clip(a, 0, 255).astype(np.uint8), "RGBA").save(OUT + "town_far.png")
    # --- camada principal
    img = new(W, H); d = ImageDraw.Draw(img)
    cobbles(img, 0, 226, W, H, rnd, snow_seed=21, snow_amt=0.30)
    rect(d, 0, 226, W, 246, (150, 160, 176))                                # calçada
    for sx in range(0, W, 38): vline(d, sx, 226, 246, (112, 122, 138))
    rect(d, 0, 246, W, 249, (66, 72, 84)); rect(d, 0, 226, W, 228, (222, 230, 241))
    nz = noise_map(W, 20, 30, 5, 2); aa = np.array(img); reg = aa[226:246, :, :3].astype(np.float32); reg *= (0.9 + 0.25 * nz)[..., None]; aa[226:246, :, :3] = np.clip(reg, 0, 255).astype(np.uint8); img = Image.fromarray(aa, "RGBA")
    building(img, -10, 104, 24, rnd, "brick", (96, 72, 64), [(10, 52, 0), (48, 52, 0), (10, 100, 0), (48, 100, 0), (10, 148, 0), (48, 148, 0), (10, 190, 0)], broken=0.6)
    building(img, 100, 200, 66, rnd, "brick", (88, 66, 62), [(122, 84, 0), (160, 84, 0), (198, 84, 0), (236, 84, 0), (272, 84, 0), (122, 128, 0), (160, 128, 0), (236, 128, 0), (272, 128, 0), (128, 184, 0), (246, 184, 0)], door=(178, 176), broken=0.4)
    rubble(img, 300, 228, 40, rnd)
    building(img, 340, 140, 100, rnd, "plaster", (98, 98, 106), [(356, 124, 0), (390, 124, 0), (356, 168, 0), (390, 168, 1)], door=(444, 176), chimney=(440, 112), broken=0.35)
    # mural de avisos
    d = ImageDraw.Draw(img); rect(d, 560, 188, 564, 228, (60, 46, 38)); rect(d, 600, 188, 604, 228, (60, 46, 38)); rect(d, 554, 176, 610, 212, (86, 66, 52)); rect(d, 554, 176, 610, 178, (214, 223, 235))
    for (px, py, pw, ph, pc) in [(560, 182, 14, 12, (205, 198, 176)), (580, 181, 12, 17, (216, 206, 150)), (596, 183, 10, 12, (176, 190, 204)), (562, 198, 12, 9, (190, 160, 150))]:
        rect(d, px, py, px + pw, py + ph, pc); d.point((px + pw // 2, py + 1), fill=(150, 40, 40))
    lamp(img, 628, 232, rnd, tilt=4, height=128)
    building(img, 690, 240, 112, rnd, "brick", (84, 70, 70), [(716, 178, 1), (760, 178, 1), (716, 126, 0), (760, 126, 0), (850, 126, 0), (890, 126, 0), (850, 178, 0)], door=(806, 176), shop=(740, 148, 140), broken=0.3)
    rubble(img, 936, 228, 56, rnd)
    lamp(img, 1004, 232, rnd, tilt=-26, height=110)                          # poste caído de lado
    d = ImageDraw.Draw(img)                                                  # banco + garrafa + livro
    rect(d, 1040, 232, 1120, 237, (74, 58, 48)); rect(d, 1040, 242, 1120, 248, (90, 70, 54)); rect(d, 1044, 248, 1049, 260, (58, 44, 37)); rect(d, 1111, 248, 1116, 260, (58, 44, 37)); rect(d, 1040, 232, 1120, 233, (214, 223, 235))
    rect(d, 1088, 230, 1094, 242, (138, 148, 159)); rect(d, 1088, 228, 1094, 230, (196, 70, 60)); rect(d, 1066, 238, 1082, 242, (107, 63, 58))
    araucaria(img, 1260, 232, rnd)
    for k in range(3): rect(d, 1278 + k * 8, 298 + (k % 2) * 3, 1283 + k * 8, 301 + (k % 2) * 3, (92, 61, 42))
    bare_tree(img, 1190, 232, 150, rnd)
    building(img, 1380, 140, 112, rnd, "plaster", (104, 98, 100), [(1400, 150, 0), (1440, 150, 0), (1480, 150, 0), (1400, 190, 0), (1480, 190, 0)], door=(1432, 176), chimney=(1444, 106), broken=0.5, shop=(1390, 126, 120), shop_text="FARMÁCIA")
    d = ImageDraw.Draw(img); rect(d, 1438, 190, 1451, 205, (232, 230, 218)); [d.line([(1440, 193 + k * 3), (1449, 193 + k * 3)], fill=(176, 50, 50)) for k in range(4)]; tape_strip(img, 1437, 189, 1452, 191); tape_strip(img, 1437, 204, 1452, 206); rect(d, 1436, 214, 1442, 220, (60, 44, 36))
    rubble(img, 1524, 228, 34, rnd)
    building(img, 1560, 160, 92, rnd, "brick", (92, 68, 64), [(1590, 160, 1), (1650, 160, 0), (1590, 116, 0), (1650, 116, 0), (1690, 116, 0)], door=(1618, 176), chimney=(1686, 90), broken=0.35)
    lamp(img, 1744, 232, rnd, tilt=2, height=124)
    d = ImageDraw.Draw(img)
    for fx in range(1780, W, 46):
        rect(d, fx, 212, fx + 5, 244, (72, 56, 44)); rect(d, fx - 1, 210, fx + 6, 212, (214, 223, 235))
    d.line([(1780, 222), (W, 222)], fill=(72, 56, 44), width=2); d.line([(1780, 234), (W, 234)], fill=(72, 56, 44), width=2)
    rect(d, 1854, 196, 1859, 250, (72, 56, 44)); rect(d, 1796, 186, 1916, 204, (86, 66, 52)); rect(d, 1796, 186, 1916, 188, (214, 223, 235))
    text_px(img, 1802, 188, "ESTRADA DO MOINHO", (232, 220, 186), 9)
    for px, ph in ((1930, 130), (2010, 150), (2090, 120), (2176, 148)): pine(img, px, 234, ph, rnd)
    bare_tree(img, 1980, 232, 120, rnd)
    # névoa baixa
    a = np.array(img).astype(np.float32); fog = np.clip(1 - np.abs(np.arange(H)[:, None] - 232) / 34.0, 0, 1) * 0.18
    a[..., :3] = a[..., :3] * (1 - fog[..., None]) + np.array((176, 188, 204), np.float32) * fog[..., None]
    Image.fromarray(np.clip(a, 0, 255).astype(np.uint8), "RGBA").save(OUT + "town_main.png")
    prev = Image.open(OUT + "town_sky.png").convert("RGBA"); prev2 = new(W, H); prev2.alpha_composite(prev, (0, 0))
    prev2.alpha_composite(Image.open(OUT + "town_far.png"), (300, 22)); prev2.alpha_composite(Image.open(OUT + "town_main.png"))
    prev2.convert("RGB").resize((W // 2, H // 2), Image.LANCZOS).save("/tmp/an/prev_town.png")
    print("town ok")

def dirt_ground(img, x0, y0, x1, y1, rnd, seed, snow_amt=0.26):
    w, h = x1 - x0, y1 - y0
    n = noise_map(w, h, 10, seed, 3); a = np.array(img)
    base = np.array((98, 86, 70), np.float32); dark = np.array((62, 54, 46), np.float32)
    reg = base[None, None] * (0.75 + 0.5 * n[..., None]) * 1.0
    reg = np.where((n < 0.30)[..., None], dark[None, None] * (0.8 + 0.4 * n[..., None]), reg)
    a[y0:y1, x0:x1, :3] = np.clip(reg, 0, 255).astype(np.uint8); a[y0:y1, x0:x1, 3] = 255
    img.paste(Image.fromarray(a, "RGBA"), (0, 0)); d = ImageDraw.Draw(img)
    for _ in range(w // 3):                                               # capim seco
        px = rnd.randint(x0, x1 - 1); py = rnd.randint(y0 + 10, y1 - 1); L = rnd.randint(2, 6)
        c = jitter((128, 112, 78), rnd, 20); d.line([(px, py), (px + rnd.randint(-2, 2), py - L)], fill=c)
    small = noise_map(w // 6 + 2, h // 3 + 2, 6, seed + 3, 3); sn = cv2.resize(small, (w, h), interpolation=cv2.INTER_CUBIC)
    yy = np.linspace(0, 1, h)[:, None]; bias = 0.25 * np.exp(-((yy - 0.0) / 0.12) ** 2)
    mask = (sn + bias) > (1 - snow_amt); a = np.array(img); reg2 = a[y0:y1, x0:x1]
    inner = ndi_erode(mask); reg2[mask, :3] = (128, 140, 160); reg2[inner, :3] = (200, 210, 224)
    img.paste(Image.fromarray(a, "RGBA"), (0, 0))

def dry_sunflower(img, x, base_y, h, rnd, bent=1):
    d = ImageDraw.Draw(img); tx = x + bent * rnd.randint(4, 9)
    d.line([(x, base_y), (x + bent * 2, base_y - h * 0.6), (tx, base_y - h)], fill=(96, 82, 52), width=2)
    for k in range(2):
        ly = base_y - h * (0.3 + 0.25 * k); sgn = -1 if k == 0 else 1
        d.polygon([(x + 1, ly), (x + sgn * 11, ly + 4), (x + sgn * 8, ly + 9)], fill=jitter((108, 92, 56), rnd, 12))
    d.ellipse([tx - 5, base_y - h - 4, tx + 5, base_y - h + 6], fill=(34, 26, 20)); d.ellipse([tx - 2, base_y - h - 1, tx + 2, base_y - h + 3], fill=(56, 42, 30))
    d.point((tx - 5, base_y - h - 5), fill=(210, 220, 232))

def garden():
    W, H = 1440, 360; rnd = random.Random(31)
    sky(W, 232, (46, 56, 68), (150, 162, 176), 8, (62, 72, 86), (176, 186, 198)).save(OUT + "garden_sky.png")
    far = new(1100, 200); fd = ImageDraw.Draw(far)
    pts = [(0, 200)]
    for x in range(0, 1101, 20): pts.append((x, 150 - 36 * (0.5 + 0.3 * math.sin(x * 0.012) + 0.2 * math.sin(x * 0.045 + 1.3))))
    pts.append((1100, 200)); fd.polygon(pts, fill=(98, 110, 126, 255))
    for _ in range(26): bare_tree(far, rnd.randint(0, 1100), 196, rnd.randint(70, 130), rnd, snow=False)
    a = np.array(far).astype(np.float32); fog = np.clip((np.arange(200)[:, None] - 100) / 100.0, 0, 1)
    a[..., :3] = a[..., :3] * (1 - fog[..., None] * 0.55) + np.array((150, 162, 176), np.float32) * fog[..., None] * 0.55
    Image.fromarray(np.clip(a, 0, 255).astype(np.uint8), "RGBA").save(OUT + "garden_far.png")
    img = new(W, H); dirt_ground(img, 0, 214, W, H, rnd, 41); d = ImageDraw.Draw(img)
    bare_tree(img, 620, 214, 170, rnd); bare_tree(img, 905, 214, 150, rnd); bare_tree(img, 1395, 220, 190, rnd); bare_tree(img, 130, 214, 140, rnd)
    for fx in range(0, W, 44):                                             # cerca com o portão caído
        if 214 < fx < 284: continue
        rect(d, fx, 206, fx + 5, 240, jitter((80, 64, 50), rnd, 8)); rect(d, fx - 1, 204, fx + 6, 206, (214, 223, 235))
    for yy in (216, 228):
        d.line([(0, yy), (214, yy)], fill=(84, 66, 52), width=2); d.line([(284, yy), (W, yy)], fill=(84, 66, 52), width=2)
        d.line([(0, yy - 1), (214, yy - 1)], fill=(214, 223, 235)); d.line([(284, yy - 1), (W, yy - 1)], fill=(214, 223, 235))
    d.polygon([(214, 206), (223, 206), (264, 246), (255, 246)], fill=(92, 74, 56)); d.polygon([(240, 206), (284, 206), (284, 242), (268, 242)], fill=(84, 68, 54))
    d.line([(214, 226), (262, 226)], fill=(60, 48, 40), width=1)
    for i in range(8): dry_sunflower(img, 340 + i * 18, 292, rnd.randint(52, 82), rnd, bent=rnd.choice([-1, 1]))
    rect(d, 360, 306, 510, 332, (52, 44, 38)); d.rectangle([358, 304, 511, 333], outline=(112, 108, 104), width=2)
    for i in range(12): d.line([(364 + i * 12, 318), (366 + i * 12, 310 - rnd.randint(0, 5))], fill=(120, 106, 70))
    rect(d, 740, 270, 830, 300, (52, 44, 38)); d.rectangle([738, 268, 831, 301], outline=(112, 108, 104), width=2)
    for i in range(9): d.line([(748 + i * 9, 296), (750 + i * 9, 280 - (i % 3) * 4)], fill=(128, 112, 74))
    rect(d, 526, 238, 594, 244, (84, 66, 52)); rect(d, 526, 248, 594, 255, (96, 76, 58)); rect(d, 530, 255, 535, 266, (62, 48, 40)); rect(d, 585, 255, 590, 266, (62, 48, 40)); rect(d, 526, 236, 594, 238, (214, 223, 235))
    d.point((570, 240), fill=(40, 30, 24)); d.line([(566, 240), (568, 242)], fill=(40, 30, 24)); d.line([(571, 239), (571, 243)], fill=(40, 30, 24))
    rect(d, 814, 288, 832, 300, (118, 96, 72)); d.line([(832, 292), (842, 284)], fill=(118, 96, 72), width=2); rect(d, 814, 286, 832, 288, (200, 212, 226))
    layer = new(W, H)                                                      # galpão
    plaster(layer, 960, 116, 1130, 232, (92, 76, 64), rnd, 8); ld = ImageDraw.Draw(layer)
    for i in range(10): vline(ld, 970 + i * 17, 116, 232, (62, 50, 42))
    ld.polygon([(950, 118), (1045, 90), (1140, 118)], fill=(52, 44, 40)); ld.line([(950, 118), (1045, 90), (1140, 118)], fill=(214, 223, 235), width=3)
    rect(ld, 1020, 172, 1064, 232, (16, 13, 14)); rect(ld, 1018, 170, 1066, 173, (74, 58, 46))
    window(layer, 1084, 170, 30, 26, rnd, broken=True)
    img.alpha_composite(layer); d = ImageDraw.Draw(img)
    rect(d, 1030, 262, 1048, 272, (140, 122, 88)); rect(d, 1030, 262, 1048, 264, (176, 158, 116)); d.point((1038, 268), fill=(86, 70, 52))
    rect(d, 1256, 262, 1344, 314, (132, 128, 120)); d.rectangle([1254, 260, 1345, 315], outline=(96, 94, 92), width=2)
    for i in range(7): d.ellipse([1250 + i * 15, 258 if i % 2 == 0 else 312, 1258 + i * 15, 266 if i % 2 == 0 else 320], fill=jitter((100, 98, 96), rnd, 12))
    for _ in range(22): d.point((rnd.randint(1260, 1340), rnd.randint(266, 310)), fill=(176, 184, 196))
    a = np.array(img).astype(np.float32); fog = np.clip(1 - np.abs(np.arange(H)[:, None] - 224) / 30.0, 0, 1) * 0.16
    a[..., :3] = a[..., :3] * (1 - fog[..., None]) + np.array((176, 188, 204), np.float32) * fog[..., None]
    Image.fromarray(np.clip(a, 0, 255).astype(np.uint8), "RGBA").save(OUT + "garden_main.png")
    p = new(W, H); p.alpha_composite(Image.open(OUT + "garden_sky.png").convert("RGBA")); p.alpha_composite(Image.open(OUT + "garden_far.png"), (300, 30)); p.alpha_composite(Image.open(OUT + "garden_main.png"))
    p.convert("RGB").resize((W // 2, H // 2), Image.LANCZOS).save("/tmp/an/prev_garden.png"); print("garden ok")

def draw_bedroom(img, rnd):
    d = ImageDraw.Draw(img)
    rect(d, 96, 46, 544, 52, (28, 34, 46))
    # parede com papel listrado, mancha de umidade, rachadura e rodapé
    for x in range(96, 544, 12): rect(d, x, 52, x + 12, 168, (64, 77, 96) if (x // 12) % 2 == 0 else (58, 70, 88))
    a = np.array(img).astype(np.float32); nz = noise_map(448, 116, 7, 3, 3); a[52:168, 96:544, :3] *= (0.86 + 0.28 * nz)[..., None]
    gr = np.clip(1 - (np.arange(116)[:, None] / 40.0), 0, 1) * 0.4; a[52:168, 96:544, :3] *= (1 - gr)[..., None]
    img = Image.fromarray(np.clip(a, 0, 255).astype(np.uint8), "RGBA"); d = ImageDraw.Draw(img)
    for r in range(18): d.ellipse([100 + r * 2, 54 + r, 160 - r * 2, 92 - r], outline=(50, 62, 80, 255)) if r % 3 == 0 else None
    d.line([(470, 52), (474, 70), (468, 84), (476, 104), (471, 120)], fill=(38, 46, 60), width=1)
    rect(d, 96, 124, 544, 168, (48, 58, 74)); rect(d, 96, 122, 544, 125, (68, 78, 98))
    for x in range(110, 540, 30): rect(d, x, 130, x + 1, 162, (40, 48, 62)); rect(d, x + 1, 130, x + 2, 162, (62, 74, 92))
    rect(d, 96, 164, 544, 168, (30, 36, 46))
    # piso de tábuas
    rect(d, 96, 168, 544, 308, (84, 64, 52))
    for i, y in enumerate(range(168, 308, 14)):
        off = (i * 53) % 90
        for x in range(96 - off, 544, 90):
            c = jitter((88, 67, 54), rnd, 9); rect(d, max(x + 1, 96), y + 1, min(x + 90, 544), min(y + 14, 308), c)
            for _ in range(3):
                gy = y + rnd.randint(3, 12); xa = max(x + 4, 97); xb = min(x + rnd.randint(30, 80), 543)
                if xb > xa: d.line([(xa, gy), (xb, gy)], fill=shade(c, 0.88))
            d.point((max(x + 3, 97), y + 4), fill=(46, 36, 30)); d.point((max(x + 3, 97), y + 10), fill=(46, 36, 30))
    # tapete
    rect(d, 284, 236, 436, 290, (58, 88, 92)); d.rectangle([284, 236, 435, 289], outline=(124, 98, 70), width=3)
    for x in range(292, 430, 10): rect(d, x, 244, x + 4, 282, (66, 98, 102))
    for x in range(284, 436, 6): d.line([(x, 290), (x, 293)], fill=(150, 124, 92)); d.line([(x, 233), (x, 236)], fill=(150, 124, 92))
    # janela
    rect(d, 296, 66, 384, 146, (30, 34, 44)); rect(d, 296, 66, 384, 68, (60, 66, 80))
    pane = np.zeros((70, 76, 3), np.uint8); gy = np.linspace(0, 1, 70)[:, None]
    pane[:] = (np.array((120, 138, 162)) * (1 - gy[..., None]) + np.array((196, 208, 222)) * gy[..., None]).astype(np.uint8)
    img.paste(Image.fromarray(pane, "RGB"), (300, 70)); d = ImageDraw.Draw(img)
    for bx, bw, bh in ((304, 16, 14), (324, 10, 22), (340, 18, 12), (362, 12, 18)): rect(d, bx, 140 - bh, bx + bw, 140, (74, 84, 100))
    for (fx, fy) in ((300, 70), (368, 70), (300, 128), (368, 128)):
        for _ in range(26): d.point((fx + rnd.randint(0, 8), fy + rnd.randint(0, 12)), fill=(226, 234, 244))
    for _ in range(9):
        cx = rnd.randint(304, 374)
        if abs(cx - 338) > 3: d.line([(cx, 100 + rnd.randint(0, 14)), (cx, 118 + rnd.randint(0, 20))], fill=(214, 224, 236), width=1)
    rect(d, 337, 70, 340, 140, (30, 34, 44)); rect(d, 300, 102, 376, 105, (30, 34, 44)); d.line([(366, 74), (372, 90), (369, 98)], fill=(236, 240, 248))
    rect(d, 292, 144, 388, 150, (110, 120, 138)); rect(d, 292, 150, 388, 152, (50, 56, 70))
    # pôsteres de bandas FICTÍCIAS (arte original), prateleira de CDs, relógio parado e calendário de 2008
    def poster(x, y, w, h, bg, fg, lines, tilt=0):
        rect(d, x, y, x + w, y + h, bg); rect(d, x, y + h - 1, x + w, y + h, shade(bg, 0.55)); rect(d, x + w - 1, y, x + w, y + h, shade(bg, 0.65))
        d.ellipse([x + w // 2 - 9, y + 5, x + w // 2 + 9, y + 23], fill=fg)
        d.line([(x + 3, y + 28), (x + w - 3, y + 28 + tilt)], fill=fg, width=1)
        for k, t in enumerate(lines): text_px(img, x + 3, y + 31 + k * 9, t, (236, 232, 220), 8)
        for (tx, ty) in ((x - 2, y - 1), (x + w - 5, y - 1)): tape_strip(img, tx, ty, tx + 7, ty + 4)
    poster(120, 58, 42, 58, (30, 30, 40), (176, 54, 54), ["HOLLOW", "CITY"])
    poster(168, 66, 34, 48, (44, 62, 92), (214, 190, 120), ["PAPER", "STATIC"], 3)
    poster(232, 62, 40, 56, (46, 70, 60), (200, 120, 70), ["LATE", "BUS"], -2)
    poster(398, 58, 34, 46, (110, 70, 44), (28, 24, 24), ["SEM", "VOLTA"], 2)
    rect(d, 116, 140, 222, 144, (60, 46, 38)); rect(d, 116, 144, 222, 146, (36, 28, 22))
    cdc = [(176, 54, 54), (214, 190, 120), (60, 110, 160), (230, 230, 220), (90, 150, 100), (200, 120, 70), (40, 40, 50)]
    x = 119
    while x < 218:
        rect(d, x, 124 + rnd.randint(0, 3), x + 2, 140, cdc[rnd.randint(0, 6)]); x += 3
    d.ellipse([450, 80, 476, 106], fill=(36, 40, 50)); d.ellipse([452, 82, 474, 104], fill=(196, 200, 208))
    d.line([(463, 93), (463, 85)], fill=(30, 30, 34), width=2); d.line([(463, 93), (469, 96)], fill=(30, 30, 34), width=2)
    rect(d, 490, 78, 516, 112, (206, 200, 180)); rect(d, 490, 78, 516, 87, (150, 56, 52)); text_px(img, 492, 78, "2008", (236, 232, 220), 8)
    for r_ in range(4):
        for c_ in range(5): d.point((493 + c_ * 4, 92 + r_ * 5), fill=(70, 66, 60))
    d.line([(493, 91), (508, 107)], fill=(176, 48, 48)); d.line([(493, 107), (508, 91)], fill=(176, 48, 48))
    # cama: estrutura, lençol, cobertor xadrez desarrumado, travesseiro
    rect(d, 112, 164, 230, 264, (40, 31, 27)); rect(d, 112, 160, 230, 172, (52, 40, 34)); rect(d, 116, 172, 226, 260, (124, 132, 146))
    d.polygon([(116, 204), (200, 196), (228, 232), (222, 262), (116, 262)], fill=(44, 50, 64))
    for x in range(116, 228, 9): d.line([(x, 198), (x - 4, 262)], fill=(68, 78, 98))
    for y in range(200, 262, 9): d.line([(116, y), (228, y + 4)], fill=(32, 38, 50))
    d.polygon([(200, 196), (228, 232), (206, 224)], fill=(62, 72, 92)); d.polygon([(222, 262), (232, 276), (196, 270), (200, 262)], fill=(40, 46, 58))
    d.line([(130, 232), (180, 244)], fill=(30, 36, 48)); d.line([(150, 214), (196, 226)], fill=(30, 36, 48))
    d.ellipse([120, 176, 152, 204], fill=(190, 196, 206)); d.ellipse([124, 182, 148, 202], fill=(166, 172, 184)); d.arc([126, 184, 146, 200], 20, 200, fill=(140, 146, 160))
    # criado-mudo com abajur e retrato
    rect(d, 234, 168, 264, 198, (76, 58, 46)); rect(d, 234, 168, 264, 171, (100, 78, 62)); rect(d, 238, 178, 260, 190, (62, 48, 40)); d.point((249, 184), fill=(180, 160, 100))
    d.polygon([(236, 168), (246, 168), (244, 154), (238, 154)], fill=(150, 140, 112)); rect(d, 240, 168, 242, 170, (60, 50, 44))
    rect(d, 248, 152, 262, 168, (122, 92, 63)); rect(d, 250, 154, 260, 166, (185, 154, 107)); d.line([(255, 154), (255, 166)], fill=(222, 214, 196))
    # guitarra elétrica encostada na parede
    d.line([(277, 170), (277, 92)], fill=(150, 112, 74), width=4); d.line([(278, 92), (278, 170)], fill=(60, 44, 32))
    rect(d, 273, 84, 283, 94, (34, 30, 36)); [d.point((274 + k * 3, 86), fill=(190, 190, 196)) for k in range(3)]
    d.polygon([(264, 160), (290, 160), (293, 170), (288, 174), (266, 174), (262, 168)], fill=(30, 30, 38)); d.polygon([(270, 150), (284, 150), (290, 162), (264, 162)], fill=(36, 34, 44))
    rect(d, 272, 154, 282, 168, (204, 198, 184)); rect(d, 266, 168, 289, 170, (176, 54, 54)); [d.point((274 + k * 2, 160), fill=(90, 90, 96)) for k in range(4)]
    # aparador sob a janela
    rect(d, 306, 168, 374, 184, (68, 54, 46)); rect(d, 306, 168, 374, 171, (92, 74, 62)); rect(d, 308, 184, 312, 192, (50, 40, 34)); rect(d, 368, 184, 372, 192, (50, 40, 34))
    for x in (324, 342, 360): rect(d, x, 174, x + 12, 182, (56, 44, 38)); d.point((x + 6, 178), fill=(170, 150, 100))
    # escrivaninha de madeira marcada: monitor de tubo, teclado, mouse, mini system, CDs, fones, apostilas
    rect(d, 398, 168, 520, 202, (92, 72, 58)); rect(d, 398, 168, 520, 180, (108, 86, 70)); rect(d, 398, 198, 520, 202, (56, 44, 37))
    for _ in range(6): px = rnd.randint(402, 516); d.point((px, rnd.randint(170, 178)), fill=(70, 54, 44))
    rect(d, 402, 130, 454, 176, (150, 146, 134)); rect(d, 402, 130, 454, 132, (190, 186, 172)); rect(d, 452, 130, 454, 176, (110, 106, 96))
    rect(d, 407, 136, 447, 166, (20, 26, 32)); d.polygon([(409, 138), (428, 138), (412, 156), (409, 156)], fill=(44, 56, 68)); rect(d, 407, 168, 447, 170, (122, 118, 108)); d.ellipse([440, 172, 444, 175], fill=(44, 70, 44))
    rect(d, 410, 176, 446, 180, (130, 126, 116)); rect(d, 406, 184, 450, 194, (172, 168, 152)); rect(d, 406, 184, 450, 185, (206, 202, 186))
    for ky in (187, 190): [rect(d, 408 + kx * 4, ky, 411 + kx * 4, ky + 2, (122, 118, 106)) for kx in range(10)]
    rect(d, 456, 188, 462, 194, (172, 168, 152)); d.line([(459, 188), (459, 180), (452, 176)], fill=(60, 60, 66))
    d.arc([450, 146, 464, 168], 200, 340, fill=(30, 30, 36), width=2); rect(d, 448, 160, 452, 168, (30, 30, 36)); rect(d, 462, 160, 466, 168, (30, 30, 36))
    rect(d, 470, 154, 494, 176, (88, 92, 100)); rect(d, 470, 154, 494, 156, (122, 126, 134)); d.ellipse([474, 160, 484, 170], fill=(52, 56, 62)); d.ellipse([477, 163, 481, 167], fill=(120, 124, 130)); rect(d, 486, 160, 492, 163, (44, 90, 50))
    rect(d, 496, 150, 510, 176, (72, 74, 82)); d.ellipse([499, 156, 507, 164], fill=(40, 42, 48)); d.ellipse([500, 166, 506, 172], fill=(40, 42, 48))
    for k, cc in enumerate(((176, 54, 54), (60, 110, 160), (214, 190, 120))): rect(d, 470 + k * 3, 184 + k * 2, 486 + k * 3, 190 + k * 2, cc); rect(d, 470 + k * 3, 184 + k * 2, 486 + k * 3, 185 + k * 2, (236, 236, 228))
    rect(d, 500, 182, 518, 192, (176, 64, 56)); rect(d, 500, 182, 518, 184, (212, 100, 90)); rect(d, 502, 192, 518, 197, (60, 96, 132)); rect(d, 502, 192, 518, 194, (92, 130, 168))
    # cadeira (o casaco é desenhado por código) e itens soltos
    rect(d, 258, 246, 288, 262, (74, 58, 46)); rect(d, 258, 262, 288, 280, (90, 70, 56)); rect(d, 260, 280, 264, 288, (56, 44, 38)); rect(d, 282, 280, 286, 288, (56, 44, 38))
    d.polygon([(258, 248), (288, 248), (292, 266), (262, 270)], fill=(62, 66, 78)); d.line([(262, 252), (270, 268)], fill=(46, 50, 60)); d.line([(278, 250), (286, 266)], fill=(46, 50, 60))
    rect(d, 296, 272, 316, 290, (44, 70, 78)); rect(d, 299, 280, 313, 289, (34, 56, 64)); rect(d, 300, 268, 312, 273, (30, 50, 58)); rect(d, 318, 282, 338, 289, (60, 110, 150)); rect(d, 320, 278, 340, 283, (176, 54, 54)); rect(d, 316, 275, 334, 279, (214, 190, 120))
    rect(d, 150, 270, 162, 276, (124, 62, 62)); rect(d, 166, 272, 178, 278, (124, 62, 62))      # chinelos
    rect(d, 240, 292, 250, 296, (56, 60, 70))                                                    # meia
    # parede direita com VÃO de porta (a porta agora liga o quarto ao resto da casa)
    rect(d, 96, 52, 112, 308, (46, 56, 72)); rect(d, 528, 52, 544, 190, (50, 60, 76)); rect(d, 528, 266, 544, 308, (46, 56, 72))
    rect(d, 529, 190, 544, 266, (84, 64, 52))
    for y in range(194, 266, 14): d.line([(529, y), (544, y)], fill=(70, 53, 43))
    rect(d, 526, 185, 546, 190, (28, 22, 18)); rect(d, 526, 190, 530, 266, (36, 28, 22)); rect(d, 544, 190, 547, 266, (36, 28, 22))
    rect(d, 530, 192, 533, 262, (92, 66, 48)); d.ellipse([530, 226, 532, 229], fill=(176, 150, 92))
    # ---- remendos do quarto
    patch_tarp(img, 466, 52, 60, 24, rnd)
    patch_cardboard(img, 301, 104, 36, 36, rnd); tape_strip(img, 360, 76, 382, 79); tape_strip(img, 356, 96, 380, 99)
    patch_plywood(img, 452, 282, 52, 22, rnd, (170, 134, 92)); patch_tin(img, 112, 140, 16, 24, rnd)
    for (px, py, pc) in ((150, 214, (140, 96, 80)), (178, 238, (84, 112, 100))):               # remendos de pano no cobertor
        rect(d, px, py, px + 14, py + 12, pc)
        for sx in range(px, px + 14, 3): d.point((sx, py), fill=(210, 200, 180)); d.point((sx, py + 11), fill=(210, 200, 180))
    return img

def draw_rooms(img, rnd):
    """Sala/cozinha (x 544-1004), pilar quebrado e entrada desabada (x 1030-1320)."""
    d = ImageDraw.Draw(img)
    rect(d, 544, 46, 1320, 52, (28, 34, 46))
    for x in range(544, 1004, 14): rect(d, x, 52, x + 14, 168, (76, 90, 76) if (x // 14) % 2 == 0 else (70, 83, 70))
    a = np.array(img).astype(np.float32); nz = noise_map(460, 116, 7, 9, 3); a[52:168, 544:1004, :3] *= (0.84 + 0.30 * nz)[..., None]
    gr = np.clip(1 - np.arange(116)[:, None] / 40.0, 0, 1) * 0.4; a[52:168, 544:1004, :3] *= (1 - gr)[..., None]
    img.paste(Image.fromarray(np.clip(a, 0, 255).astype(np.uint8), "RGBA"), (0, 0)); d = ImageDraw.Draw(img)
    rect(d, 544, 124, 1004, 168, (58, 68, 58)); rect(d, 544, 122, 1004, 125, (100, 112, 98))
    for x in range(560, 1004, 30): rect(d, x, 130, x + 1, 162, (46, 54, 46)); rect(d, x + 1, 130, x + 2, 162, (66, 78, 66))
    rect(d, 544, 164, 1004, 168, (32, 38, 32))
    plank_floor(img, 544, 168, 1320, 308, rnd, (86, 66, 54)); d = ImageDraw.Draw(img)
    patch_plywood(img, 596, 228, 56, 44, rnd, (168, 132, 90)); patch_plywood(img, 868, 246, 52, 36, rnd, (150, 118, 80)); patch_plywood(img, 940, 214, 40, 28, rnd, (176, 140, 98))
    pal = [(96, 72, 62), (66, 82, 96), (112, 102, 74), (80, 64, 88), (120, 84, 66), (70, 92, 78)]
    # ---- fogão a lenha com chapa de proteção
    sx, sy = 590, 118
    patch_tin(img, 578, 58, 76, 110, rnd); d = ImageDraw.Draw(img)
    rect(d, sx + 22, 52, sx + 30, sy + 10, (38, 40, 46)); rect(d, sx + 20, 62, sx + 32, 66, (60, 62, 68)); tape_strip(img, sx + 21, 82, sx + 31, 86)
    rect(d, sx - 2, sy + 8, sx + 56, sy + 12, (74, 76, 84)); rect(d, sx, sy + 12, sx + 54, sy + 52, (44, 46, 52)); rect(d, sx, sy + 12, sx + 54, sy + 14, (66, 68, 76)); rect(d, sx + 50, sy + 12, sx + 54, sy + 52, (34, 36, 40))
    rect(d, sx + 8, sy + 22, sx + 40, sy + 44, (30, 32, 38)); rect(d, sx + 11, sy + 25, sx + 37, sy + 41, (26, 18, 14)); vline(d, sx + 24, sy + 25, sy + 41, (44, 46, 52))
    for k in range(4): rect(d, sx + 10 + k * 7, sy + 46, sx + 14 + k * 7, sy + 47, (26, 28, 32))
    rect(d, sx + 4, sy + 52, sx + 10, sy + 56, (34, 36, 40)); rect(d, sx + 44, sy + 52, sx + 50, sy + 56, (34, 36, 40))
    rect(d, sx + 30, sy - 2, sx + 46, sy + 8, (92, 96, 104)); rect(d, sx + 30, sy - 2, sx + 46, sy, (130, 134, 142)); d.line([(sx + 46, sy + 2), (sx + 52, sy - 2)], fill=(92, 96, 104), width=2)
    for r_ in range(3):                                                    # pilha de lenha
        for c_ in range(4 - r_):
            cx, cy = 558 + c_ * 11 + r_ * 5, 162 - r_ * 10
            d.ellipse([cx - 5, cy - 5, cx + 5, cy + 5], fill=(122, 92, 62)); d.ellipse([cx - 3, cy - 3, cx + 3, cy + 3], fill=(150, 118, 82)); d.point((cx, cy), fill=(92, 66, 44))
    # ---- bancada, prateleira e pia
    patch_plywood(img, 732, 56, 40, 30, rnd, (166, 130, 90)); patch_cardboard(img, 668, 58, 46, 26, rnd, "CUIDADO"); d = ImageDraw.Draw(img)
    rect(d, 664, 92, 790, 96, (66, 50, 40)); rect(d, 664, 96, 790, 98, (40, 30, 24))
    for x in range(670, 786, 11):
        if rnd.random() < 0.38:
            c = rnd.choice([(150, 184, 172), (176, 150, 110), (120, 150, 180), (190, 190, 176)]); rect(d, x, 80, x + 8, 92, c); rect(d, x, 78, x + 8, 80, (90, 90, 96))
    rect(d, 664, 142, 790, 168, (96, 78, 62)); rect(d, 662, 138, 792, 144, (132, 114, 94)); rect(d, 662, 138, 792, 139, (166, 148, 126))
    for k, x in enumerate(range(666, 788, 21)):
        c = [(96, 78, 62), (150, 118, 80), (84, 100, 110), (110, 86, 66), (142, 112, 76), (96, 78, 62)][k % 6]
        rect(d, x, 146, x + 19, 167, c); d.rectangle([x, 146, x + 18, 166], outline=shade(c, 0.62)); d.point((x + 15, 156), fill=(190, 170, 110))
    rect(d, 692, 132, 726, 139, (150, 156, 164)); rect(d, 694, 134, 724, 138, (102, 108, 118)); rect(d, 716, 108, 719, 133, (158, 162, 170)); rect(d, 716, 108, 725, 111, (158, 162, 170))
    tape_strip(img, 716, 116, 720, 121); tape_strip(img, 716, 124, 720, 129); d = ImageDraw.Draw(img)
    # ---- janela da cozinha: colcha de retalhos pregada + tábuas em X
    rect(d, 806, 66, 880, 148, (30, 24, 20))
    for gy in range(0, 78, 13):
        for gx in range(0, 68, 13):
            c = rnd.choice(pal); rect(d, 810 + gx, 70 + gy, 810 + gx + 13, 70 + gy + 13, jitter(c, rnd, 8)); d.rectangle([810 + gx, 70 + gy, 810 + gx + 12, 70 + gy + 12], outline=shade(c, 0.7))
            d.point((810 + gx + 3, 70 + gy + 3), fill=(206, 196, 176)); d.point((810 + gx + 9, 70 + gy + 9), fill=(206, 196, 176))
    d.line([(808, 72), (878, 144)], fill=(110, 84, 58), width=4); d.line([(878, 72), (808, 144)], fill=(98, 74, 52), width=4)
    for (px, py) in ((810, 72), (876, 72), (810, 144), (876, 144), (843, 108)): d.point((px, py), fill=(40, 36, 34)); d.point((px, py - 1), fill=(200, 190, 170))
    d.line([(810, 70), (878, 70)], fill=(220, 232, 246)); vline(d, 809, 70, 146, (200, 214, 232)); rect(d, 800, 146, 886, 152, (90, 76, 62))
    # ---- geladeira (vira armário) com o bilhete
    rect(d, 888, 94, 936, 168, (176, 172, 156)); rect(d, 888, 94, 936, 97, (206, 202, 186)); rect(d, 932, 94, 936, 168, (140, 136, 122))
    d.line([(888, 128), (936, 128)], fill=(120, 116, 104)); rect(d, 926, 104, 929, 120, (104, 100, 92)); rect(d, 926, 134, 929, 154, (104, 100, 92)); tape_strip(img, 923, 111, 931, 115); d = ImageDraw.Draw(img)
    for _ in range(5): px = rnd.randint(892, 920); py = rnd.randint(100, 164); rect(d, px, py, px + 3, py + 2, (150, 146, 132))
    rect(d, 900, 108, 916, 126, (232, 230, 218)); d.ellipse([905, 106, 909, 110], fill=(176, 50, 50))
    for k in range(4): d.line([(902, 113 + k * 3), (913, 113 + k * 3)], fill=(110, 110, 120))
    # ---- porta do fundo, fechada e travada com tábua pregada
    rect(d, 942, 80, 988, 168, (28, 22, 18)); rect(d, 945, 84, 985, 168, (92, 66, 50)); rect(d, 950, 90, 980, 120, (82, 58, 44)); rect(d, 950, 128, 980, 160, (82, 58, 44))
    patch_plywood(img, 954, 96, 22, 18, rnd, (170, 134, 92)); d = ImageDraw.Draw(img)
    d.ellipse([978, 138, 982, 142], fill=(176, 150, 92)); rect(d, 940, 118, 990, 127, (112, 86, 58)); screws(d, [(944, 122), (986, 122), (966, 122)]); rect(d, 940, 118, 990, 119, (146, 116, 80))
    # ---- remendos de parede (sala)
    patch_tarp(img, 936, 52, 64, 24, rnd); patch_brick(img, 900, 56, 26, 22, rnd); patch_plywood(img, 548, 94, 26, 30, rnd, (160, 124, 86)); tape_strip(img, 786, 70, 806, 73); tape_strip(img, 880, 100, 886, 130); d = ImageDraw.Draw(img)
    # ---- tapete de retalhos, mesa mancando e cadeiras
    rect(d, 690, 232, 846, 292, (92, 70, 60))
    for gy in range(236, 290, 13):
        for gx in range(694, 844, 13): rect(d, gx, gy, gx + 12, gy + 12, jitter(rnd.choice(pal), rnd, 10))
    d.rectangle([690, 232, 845, 291], outline=(60, 46, 40), width=2)
    rect(d, 684, 220, 702, 246, (96, 74, 58)); rect(d, 682, 212, 686, 246, (74, 56, 44)); rect(d, 686, 246, 690, 262, (58, 44, 36)); rect(d, 698, 246, 702, 262, (58, 44, 36))
    rect(d, 704, 214, 786, 238, (118, 94, 72)); rect(d, 704, 214, 786, 216, (150, 122, 96)); rect(d, 704, 238, 786, 246, (86, 66, 50))
    rect(d, 706, 246, 711, 264, (62, 48, 38)); rect(d, 779, 246, 784, 262, (62, 48, 38)); rect(d, 777, 262, 790, 267, (52, 92, 118)); rect(d, 777, 262, 790, 263, (96, 140, 168))
    rect(d, 712, 220, 734, 232, (214, 210, 194)); vline(d, 723, 220, 232, (150, 146, 134)); rect(d, 744, 220, 752, 230, (138, 143, 153)); rect(d, 764, 218, 772, 230, (96, 100, 108))
    for k in range(3): d.line([(766 + k * 2, 218), (765 + k * 3, 211)], fill=[(176, 60, 60), (60, 100, 170), (200, 170, 70)][k])
    rect(d, 788, 220, 806, 246, (96, 74, 58)); rect(d, 804, 212, 808, 246, (74, 56, 44)); d.line([(804, 228), (790, 238)], fill=(160, 160, 166)); rect(d, 788, 246, 792, 262, (58, 44, 36)); rect(d, 802, 246, 806, 262, (58, 44, 36))
    def bucket(x, y):
        d.polygon([(x - 7, y - 12), (x + 7, y - 12), (x + 5, y), (x - 5, y)], fill=(104, 110, 120)); rect(d, x - 7, y - 13, x + 8, y - 11, (150, 156, 166)); rect(d, x - 6, y - 11, x + 7, y - 9, (52, 64, 86))
    bucket(736, 184); bucket(856, 186); d = ImageDraw.Draw(img)
    d.line([(934, 154), (900, 162), (850, 160), (810, 164), (790, 160)], fill=(26, 26, 30), width=2)                    # extensão de fios
    for (tx, ty) in ((900, 161), (850, 159), (810, 163)): rect(d, tx - 2, ty - 2, tx + 3, ty + 2, (150, 156, 166))
    # ---- pilar quebrado
    def pillar(L): bricks(L, 1002, 52, 1032, 180, (92, 68, 60), rnd)
    masked(img, pillar, [(1004, 52), (1030, 52), (1030, 96), (1023, 108), (1030, 122), (1021, 140), (1030, 160), (1030, 178), (1004, 178)]); d = ImageDraw.Draw(img)
    for (rx, ry, ln) in ((1024, 106, 9), (1022, 140, 10), (1026, 124, 7)): d.line([(rx, ry), (rx + ln, ry + 2)], fill=(122, 76, 50), width=1)
    # ---- ENTRADA DESABADA: paisagem de fora no lugar da parede
    ext = Image.new("RGBA", img.size, (0, 0, 0, 0)); ed = ImageDraw.Draw(ext)
    for yy in range(52, 168):
        t = (yy - 52) / 116.0; c = mix((116, 132, 152), (198, 208, 220), t); ed.line([(1030, yy), (1250, yy)], fill=c)
    for bx in range(1032, 1250, 22):
        bw = rnd.randint(14, 26); bh = rnd.randint(30, 66); rect(ed, bx, 152 - bh, bx + bw, 152, jitter((92, 104, 120), rnd, 6))
        for wy in range(152 - bh + 6, 148, 11):
            for wx in range(bx + 3, bx + bw - 3, 7): rect(ed, wx, wy, wx + 3, wy + 5, (66, 76, 92))
    rect(ed, 1030, 150, 1250, 168, (214, 223, 235)); img.alpha_composite(ext); d = ImageDraw.Draw(img)
    def wall_r(L): plaster(L, 1228, 52, 1322, 170, (124, 126, 136), rnd, 5)
    masked(img, wall_r, [(1250, 52), (1320, 52), (1320, 168), (1236, 168), (1244, 150), (1237, 132), (1250, 116), (1242, 92), (1250, 72)]); d = ImageDraw.Draw(img)
    patch_tin(img, 1274, 70, 30, 42, rnd); tape_strip(img, 1281, 112, 1284, 142); d = ImageDraw.Draw(img)
    d.line([(1030, 56), (1132, 98)], fill=(66, 46, 34), width=7); d.line([(1250, 54), (1186, 112)], fill=(58, 40, 30), width=7)                       # vigas caídas
    d.line([(1030, 52), (1132, 94)], fill=(112, 82, 56), width=1); d.line([(1250, 52), (1186, 108)], fill=(104, 76, 52), width=1)
    d.line([(1130, 98), (1146, 126)], fill=(130, 82, 54)); d.line([(1186, 112), (1178, 134)], fill=(130, 82, 54))
    # neve que entrou, entulho e o buraco no chão
    snow_c = (214, 223, 235); sh = (170, 184, 204)
    d.polygon([(1034, 168), (1250, 168), (1260, 176), (1230, 182), (1180, 178), (1120, 184), (1070, 178), (1040, 180)], fill=snow_c)
    d.ellipse([1100, 204, 1210, 226], fill=sh); d.ellipse([1106, 202, 1204, 220], fill=snow_c)
    rubble(img, 1090, 208, 62, rnd); rubble(img, 1196, 196, 36, rnd); d = ImageDraw.Draw(img)
    hole = [(1106, 270), (1130, 262), (1160, 267), (1192, 262), (1197, 290), (1181, 304), (1130, 300), (1108, 296)]
    d.polygon(hole, fill=(12, 14, 18))
    for jx in (1128, 1156, 1180): d.line([(jx, 266), (jx, 302)], fill=(74, 56, 40), width=3)
    for _ in range(14): px = rnd.randint(1112, 1190); py = rnd.randint(278, 300); d.point((px, py), fill=(190, 202, 218))
    for (a1, b1) in zip(hole, hole[1:] + hole[:1]): d.line([a1, b1], fill=(150, 116, 76), width=1)
    for (px, py) in ((1104, 268), (1160, 262), (1195, 276)): d.polygon([(px, py), (px + 7, py - 5), (px + 5, py + 2)], fill=(150, 116, 76))
    # escada que sobe para o nada (degraus iluminados, vão escuro embaixo, topo partido)
    zig = []
    for k in range(11):
        x = 1034 + int(k * 5.6); y = 168 - k * 7; zig += [(x, y), (x + 6, y)]
    body = [(1034, 172)] + zig + [(zig[-1][0], zig[-1][1] + 13), (1040, 172)]
    d.polygon(body, fill=(64, 48, 36))
    d.polygon([(1040, 172), (zig[-1][0], zig[-1][1] + 13), (zig[-1][0] - 8, zig[-1][1] + 20), (1048, 172)], fill=(26, 20, 16))
    for k in range(11):
        x = 1034 + int(k * 5.6); y = 168 - k * 7
        rect(d, x, y, x + 6, y + 2, (178, 148, 110)); rect(d, x, y + 2, x + 6, y + 3, (110, 84, 60)); vline(d, x + 6, y + 2, y + 9, (34, 26, 20))
    for px in (1046, 1068, 1088): d.line([(px, 164 - int((px - 1034) * 1.25)), (px, 144 - int((px - 1034) * 1.25))], fill=(120, 92, 66), width=2)
    d.line([(1046, 144 - 15), (1090, 144 - 70)], fill=(120, 92, 66), width=2)
    d.line([(zig[-1][0] + 6, zig[-1][1]), (zig[-1][0] + 18, zig[-1][1] - 8)], fill=(150, 116, 76), width=2); d.line([(zig[-1][0] + 4, zig[-1][1] + 4), (zig[-1][0] + 16, zig[-1][1] + 8)], fill=(150, 116, 76))
    # porta da frente, remendada e aparafusada
    rect(d, 1300, 52, 1320, 190, (50, 60, 76)); rect(d, 1300, 266, 1320, 308, (46, 56, 72)); rect(d, 1296, 185, 1320, 190, (28, 22, 18)); rect(d, 1296, 190, 1302, 268, (28, 22, 18))
    rect(d, 1302, 192, 1318, 266, (90, 64, 46)); patch_plywood(img, 1304, 198, 12, 26, rnd, (170, 134, 92)); patch_tin(img, 1304, 236, 12, 24, rnd); d = ImageDraw.Draw(img)
    rect(d, 1305, 226, 1315, 232, (150, 150, 156)); d.ellipse([1308, 228, 1311, 231], fill=(60, 60, 66)); rect(d, 1302, 266, 1320, 270, (210, 220, 236))
    # materiais de remendo encostados na parede: tábuas, lona e caixa de ferramentas
    for k in range(6): d.line([(1240 + k * 8, 238), (1250 + k * 8, 178)], fill=jitter((160, 126, 86), rnd, 10), width=5)
    rect(d, 1262, 218, 1286, 238, (54, 88, 130)); d.ellipse([1262, 214, 1286, 224], fill=(74, 108, 150)); d.ellipse([1266, 216, 1282, 222], fill=(46, 76, 116))
    rect(d, 1248, 252, 1270, 262, (160, 58, 48)); rect(d, 1248, 252, 1270, 254, (196, 90, 76)); d.arc([1253, 246, 1265, 256], 180, 360, fill=(90, 90, 96)); rect(d, 1256, 258, 1262, 260, (200, 200, 206))
    return img

def draw_sala(img, rnd):
    """Sala (x 544-924): poltrona do pai, sofá da mãe, rádio, TV coberta, mesinha de remédios, janela com neve."""
    d = ImageDraw.Draw(img); X0, X1 = 544, 924
    rect(d, X0, 46, X1, 52, (28, 34, 46))
    for x in range(X0, X1, 10): rect(d, x, 52, x + 10, 168, (122, 106, 84) if (x // 10) % 2 == 0 else (114, 99, 78))
    a = np.array(img).astype(np.float32); nz = noise_map(X1 - X0, 116, 7, 21, 3); a[52:168, X0:X1, :3] *= (0.80 + 0.32 * nz)[..., None]
    gr = np.clip(1 - np.arange(116)[:, None] / 40.0, 0, 1) * 0.35; a[52:168, X0:X1, :3] *= (1 - gr)[..., None]
    img.paste(Image.fromarray(np.clip(a, 0, 255).astype(np.uint8), "RGBA"), (0, 0)); d = ImageDraw.Draw(img)
    for r in range(10): d.ellipse([850 + r * 3, 52 + r, 924 - r * 3, 92 - r * 2], outline=(106, 92, 72, 255)) if r % 3 == 0 else None
    rect(d, X0, 126, X1, 168, (76, 58, 46)); rect(d, X0, 124, X1, 127, (126, 100, 78))
    for x in range(X0 + 14, X1, 26): rect(d, x, 132, x + 1, 164, (58, 44, 36)); rect(d, x + 1, 132, x + 2, 164, (92, 72, 58))
    rect(d, X0, 164, X1, 168, (40, 30, 24))
    plank_floor(img, X0, 168, X1, 308, rnd, (92, 70, 56)); d = ImageDraw.Draw(img)
    patch_plywood(img, 884, 262, 36, 30, rnd, (166, 130, 90)); d = ImageDraw.Draw(img)
    # tapete gasto sob a mesinha de centro
    rect(d, 672, 222, 860, 300, (98, 56, 50)); d.rectangle([672, 222, 859, 299], outline=(150, 118, 78), width=3)
    for gy in range(232, 296, 12):
        for gx in range(684, 850, 20): d.polygon([(gx, gy + 6), (gx + 8, gy), (gx + 16, gy + 6), (gx + 8, gy + 12)], outline=(134, 84, 66))
    for k in range(672, 860, 6): d.line([(k, 300), (k, 303)], fill=(150, 118, 78)); d.line([(k, 219), (k, 222)], fill=(150, 118, 78))
    # prateleira de parede quase vazia, retratos de família
    rect(d, 612, 94, 722, 98, (66, 50, 40)); rect(d, 612, 98, 722, 100, (40, 30, 24))
    rect(d, 622, 82, 630, 94, (150, 184, 172)); rect(d, 622, 80, 630, 82, (90, 90, 96)); rect(d, 660, 84, 668, 94, (200, 196, 180)); d.polygon([(662, 84), (666, 84), (664, 79)], fill=(230, 170, 70)); rect(d, 700, 86, 712, 94, (150, 110, 76))
    rect(d, 664, 62, 686, 86, (96, 72, 54)); rect(d, 666, 64, 684, 84, (170, 150, 118)); d.ellipse([670, 68, 680, 78], fill=(120, 100, 80)); rect(d, 694, 66, 712, 84, (96, 72, 54)); rect(d, 696, 68, 710, 82, (150, 160, 170))
    # TV coberta com toalha de renda e vaso; tabela de racionamento na parede
    rect(d, 550, 54, 598, 88, (226, 222, 204)); rect(d, 550, 54, 598, 60, (150, 56, 52)); [text_px(img, 553, 61 + k * 8, t, (50, 44, 40), 8, bold=False) for k, t in enumerate(("LUZ 4h", "ÁGUA 2", "REMED. ½"))]; d = ImageDraw.Draw(img)
    d.line([(553, 82), (595, 82)], fill=(176, 50, 50)); tape_strip(img, 548, 52, 556, 56); tape_strip(img, 592, 52, 600, 56); d = ImageDraw.Draw(img)
    rect(d, 548, 142, 606, 168, (84, 64, 50)); rect(d, 546, 140, 608, 144, (112, 90, 72)); rect(d, 552, 150, 576, 166, (70, 52, 40)); rect(d, 578, 150, 602, 166, (70, 52, 40)); d.point((564, 158), fill=(170, 150, 100)); d.point((590, 158), fill=(170, 150, 100))
    rect(d, 554, 112, 600, 140, (58, 60, 64)); rect(d, 559, 117, 595, 135, (22, 26, 30)); d.polygon([(561, 119), (576, 119), (563, 131), (561, 131)], fill=(44, 54, 64))
    d.polygon([(552, 110), (602, 110), (603, 122), (551, 122)], fill=(214, 206, 186))
    for k in range(10): d.point((556 + k * 4, 114), fill=(184, 176, 156)); d.point((558 + k * 4, 118), fill=(184, 176, 156))
    for k in range(11): d.polygon([(552 + k * 5, 122), (556 + k * 5, 122), (554 + k * 5, 126)], fill=(214, 206, 186))
    rect(d, 568, 100, 584, 110, (120, 76, 56)); d.ellipse([566, 90, 586, 102], fill=(78, 112, 70)); d.line([(576, 100), (570, 92)], fill=(60, 90, 56)); d.line([(576, 100), (584, 94)], fill=(60, 90, 56))
    # rádio de válvula no aparador
    rect(d, 614, 146, 646, 168, (86, 66, 52)); rect(d, 612, 144, 648, 148, (112, 90, 72)); rect(d, 620, 124, 642, 146, (134, 94, 58)); rect(d, 620, 124, 642, 126, (170, 126, 82)); rect(d, 640, 124, 642, 146, (100, 70, 44))
    for k in range(5): rect(d, 622, 129 + k * 3, 630, 130 + k * 3, (44, 30, 22))
    rect(d, 632, 129, 639, 137, (60, 44, 30)); rect(d, 633, 130, 638, 136, (206, 150, 64)); d.point((634, 141), fill=(210, 190, 120)); d.point((638, 141), fill=(210, 190, 120)); d.line([(640, 124), (647, 106)], fill=(150, 150, 156))
    # poltrona (pai): tecido gasto com remendos e paninho de crochê
    rect(d, 658, 124, 722, 172, (112, 88, 58)); rect(d, 658, 124, 722, 127, (146, 118, 82)); rect(d, 660, 128, 720, 170, (122, 96, 64))
    rect(d, 656, 150, 668, 192, (98, 76, 50)); rect(d, 712, 150, 724, 192, (98, 76, 50)); rect(d, 656, 150, 668, 153, (130, 104, 72)); rect(d, 712, 150, 724, 153, (130, 104, 72))
    rect(d, 668, 168, 712, 192, (128, 100, 68)); rect(d, 668, 168, 712, 170, (156, 128, 92)); rect(d, 660, 190, 666, 198, (60, 44, 34)); rect(d, 714, 190, 720, 198, (60, 44, 34))
    rect(d, 680, 130, 700, 138, (214, 206, 186)); [d.point((682 + k * 3, 134), fill=(180, 172, 152)) for k in range(7)]
    for (x, y, w, h, c) in ((664, 136, 14, 12, (150, 90, 66)), (704, 160, 12, 12, (74, 92, 110)), (672, 174, 12, 10, (90, 110, 84))):
        rect(d, x, y, x + w, y + h, c); [d.point((x + k * 3, y), fill=(214, 204, 184)) for k in range(w // 3 + 1)]; [d.point((x + k * 3, y + h - 1), fill=(214, 204, 184)) for k in range(w // 3 + 1)]
    # mesinha com remédios (frascos, caixa quase vazia, copo) e lenços usados no chão
    rect(d, 728, 158, 762, 164, (118, 94, 72)); rect(d, 728, 164, 762, 167, (84, 64, 50)); rect(d, 732, 167, 736, 190, (64, 48, 38)); rect(d, 754, 167, 758, 190, (64, 48, 38))
    for x in (730, 736, 742): rect(d, x, 148, x + 5, 158, (176, 112, 40)); rect(d, x, 146, x + 5, 148, (230, 230, 224))
    rect(d, 746, 150, 756, 158, (226, 230, 236)); rect(d, 746, 150, 756, 152, (60, 110, 170)); d.line([(751, 152), (751, 157)], fill=(176, 50, 50)); d.line([(749, 154), (753, 154)], fill=(176, 50, 50))
    rect(d, 757, 148, 762, 158, (190, 214, 232)); rect(d, 758, 152, 761, 157, (150, 190, 220))
    for (tx, ty) in ((778, 200), (766, 205), (792, 212)): d.ellipse([tx, ty, tx + 5, ty + 4], fill=(236, 236, 230))
    # abajur de pé (a luz amarelada é animada em código)
    rect(d, 770, 90, 773, 188, (60, 50, 44)); rect(d, 764, 186, 780, 190, (50, 42, 36)); d.polygon([(758, 92), (786, 92), (780, 68), (764, 68)], fill=(214, 178, 110)); rect(d, 758, 92, 786, 94, (176, 140, 80))
    # janela com neve e a cidade em silêncio, cortinas de renda
    rect(d, 818, 62, 904, 126, (34, 28, 24))
    for yy in range(65, 122): d.line([(821, yy), (900, yy)], fill=mix((150, 164, 182), (214, 222, 232), (yy - 65) / 57.0))
    for (bx, bw, bh) in ((823, 18, 22), (845, 26, 30), (874, 18, 20)):
        rect(d, bx, 122 - bh, bx + bw, 122, (104, 112, 126)); rect(d, bx, 122 - bh, bx + bw, 124 - bh, (236, 240, 246))
        for k in range(bw // 8): rect(d, bx + 3 + k * 8, 122 - bh + 8, bx + 7 + k * 8, 122 - bh + 13, (52, 60, 74))
    rect(d, 821, 112, 901, 122, (222, 230, 240)); rect(d, 859, 65, 862, 122, (34, 28, 24)); rect(d, 821, 92, 901, 95, (34, 28, 24))
    rect(d, 814, 60, 834, 126, (206, 198, 176)); rect(d, 888, 60, 908, 126, (206, 198, 176))
    for k in range(5): vline(d, 816 + k * 4, 62, 124, (184, 176, 152)); vline(d, 890 + k * 4, 62, 124, (184, 176, 152))
    rect(d, 812, 58, 910, 62, (96, 72, 54)); rect(d, 810, 126, 912, 132, (112, 90, 72))
    # sofá remendado (mãe) com manta de tricô
    rect(d, 788, 128, 900, 170, (104, 80, 66)); rect(d, 788, 128, 900, 131, (138, 110, 90))
    for k in range(4): d.ellipse([796 + k * 26, 140, 804 + k * 26, 148], fill=(86, 64, 52))
    rect(d, 786, 150, 798, 192, (92, 70, 58)); rect(d, 890, 150, 902, 192, (92, 70, 58)); rect(d, 798, 166, 890, 192, (122, 96, 80)); rect(d, 798, 166, 890, 168, (150, 122, 102)); d.line([(844, 168), (844, 192)], fill=(86, 64, 52))
    for (x, y, w, h, c) in ((800, 134, 18, 14, (78, 98, 82)), (872, 172, 14, 12, (74, 90, 112)), (820, 174, 16, 10, (150, 90, 66))):
        rect(d, x, y, x + w, y + h, c); [d.point((x + k * 3, y), fill=(214, 204, 184)) for k in range(w // 3 + 1)]; [d.point((x + k * 3, y + h - 1), fill=(214, 204, 184)) for k in range(w // 3 + 1)]
    d.polygon([(786, 146), (808, 146), (812, 182), (786, 186)], fill=(176, 110, 60))
    for k in range(6): d.line([(786, 150 + k * 6), (810, 152 + k * 6)], fill=(226, 206, 170))
    rect(d, 790, 192, 796, 198, (60, 44, 34)); rect(d, 892, 192, 898, 198, (60, 44, 34))
    # mesinha de centro com o jornal de 2008, caneca e vela em pote
    rect(d, 694, 226, 774, 238, (122, 98, 74)); rect(d, 694, 226, 774, 228, (150, 124, 96)); rect(d, 694, 238, 774, 246, (86, 66, 50)); rect(d, 698, 246, 702, 258, (64, 48, 38)); rect(d, 766, 246, 770, 258, (64, 48, 38))
    rect(d, 704, 227, 742, 236, (222, 220, 208)); rect(d, 704, 228, 742, 230, (30, 30, 36))
    for k in range(5): rect(d, 706 + k * 7, 232, 710 + k * 7, 235, (110, 110, 116))
    rect(d, 750, 224, 758, 233, (230, 226, 216)); d.arc([756, 226, 762, 232], -90, 90, fill=(230, 226, 216)); rect(d, 764, 226, 770, 234, (150, 184, 172)); d.polygon([(766, 226), (768, 226), (767, 221)], fill=(240, 190, 80))
    # passagem para a cozinha, com um cobertor pendurado para segurar o calor
    rect(d, 912, 52, 924, 168, (74, 56, 44)); rect(d, 912, 52, 914, 168, (104, 80, 62)); d.polygon([(898, 62), (924, 62), (924, 168), (914, 168), (906, 122)], fill=(88, 100, 120))
    for k in range(5): d.line([(900 + k * 5, 66), (910 + k * 3, 160)], fill=(70, 80, 100))
    return img

KX = 380

def house():
    W, H = 1780, 360; rnd = random.Random(7)
    img = new(W, H, (11, 16, 25, 255)); img = draw_bedroom(img, rnd)
    tmp = new(1400, 360, (11, 16, 25, 255)); tmp = draw_rooms(tmp, random.Random(13))
    img.paste(tmp.crop((544, 0, 1400, 360)), (544 + KX, 0))               # cozinha e desabamento deslocados para a direita
    img = draw_sala(img, random.Random(17))
    a = np.array(img).astype(np.float32)
    xs = np.clip((np.arange(W) - 1320) / 140.0, 0, 1)[None, :, None]       # quente (sala/cozinha) -> frio (desabamento)
    mult = np.array((1.06, 1.0, 0.92)) * (1 - xs) + np.array((0.95, 1.0, 1.08)) * xs
    a[52:308, 544:1700, :3] *= mult[:, 544:1700, :]
    img = vignette(Image.fromarray(np.clip(a, 0, 255).astype(np.uint8), "RGBA"), 0.45)
    img.save(OUT + "house.png"); img.convert("RGB").save("/tmp/an/prev_house.png"); print("house ok", img.size)

if __name__ == "__main__":
    which = sys.argv[1] if len(sys.argv) > 1 else "all"
    if which in ("town", "all"): town()
    if which in ("garden", "all"): garden()
    if which in ("house", "bedroom", "all"): house()
