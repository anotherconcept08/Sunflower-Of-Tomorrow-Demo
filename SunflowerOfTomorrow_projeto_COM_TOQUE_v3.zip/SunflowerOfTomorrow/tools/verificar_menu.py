"""Verificação estática do menu principal, das configurações e da pausa (complementa verificar_projeto.py e verificar_cap1.py).
Confere: caminhos de res:// em preload/load e cenas, uniforms do shader x parâmetros enviados pelo script, membros de autoloads
usados no código (GameSettings, GameState, AudioManager, SceneRouter, Dialogue) e a API dos componentes novos.
NÃO substitui abrir o projeto na Godot. Uso: python3 tools/verificar_menu.py"""
import re, os, glob, sys
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."); os.chdir(ROOT)
errs, warns = [], []
gd = sorted(glob.glob("scripts/**/*.gd", recursive=True))
src = {f: open(f, encoding="utf-8").read() for f in gd}

# 1) caminhos res:// literais
OPTIONAL = {"assets/fonts/ui.ttf"}                      # fonte opcional: o código só usa se o arquivo existir
for f, t in list(src.items()) + [(f, open(f, encoding="utf-8").read()) for f in glob.glob("scenes/**/*.tscn", recursive=True)]:
    t = "\n".join(l for l in t.split("\n") if not l.strip().startswith("#"))
    for p in re.findall(r'res://([A-Za-z0-9_./\-]+\.[A-Za-z0-9]+)', t):
        if not os.path.exists(p) and p not in OPTIONAL and not p.endswith("..."): errs.append(f"{f}: caminho inexistente res://{p}")

# 2) shader: uniforms x set_shader_parameter
sh = open("assets/ui/menu/menu_parallax.gdshader", encoding="utf-8").read()
uniforms = set(re.findall(r'uniform\s+\w+\s+(\w+)', sh))
for n in re.findall(r'set_shader_parameter\("(\w+)"', src["scripts/main_menu/menu_background.gd"]):
    if n not in uniforms: errs.append(f"shader: parâmetro '{n}' não existe no shader (uniforms: {sorted(uniforms)})")
for u in ("depth_tex", "sky_tex"):
    if f'"{u}"' not in src["scripts/main_menu/menu_background.gd"]: errs.append(f"shader: uniform {u} nunca é enviado")

# 3) membros de autoloads
proj = open("project.godot", encoding="utf-8").read()
auto = dict(re.findall(r'^(\w+)="\*?res://([^"]+)"', proj, re.M))
members = {}
for name, path in auto.items():
    t = src.get(path, "")
    m = set(re.findall(r'^(?:static\s+)?func\s+(\w+)\(', t, re.M)) | set(re.findall(r'^(?:var|const)\s+(\w+)', t, re.M)) | set(re.findall(r'^signal\s+(\w+)', t, re.M))
    m |= set(re.findall(r'^enum\s+\w*\s*\{([^}]*)\}', t, re.M))
    members[name] = m
def strip(t): return re.sub(r'#.*', '', re.sub(r'"(?:[^"\\\n]|\\.)*"', '""', t))
for f, t in src.items():
    t = strip(t)
    for name in members:
        for mem in re.findall(r'(?<![\w.])' + name + r'\.(\w+)', t):
            if mem not in members[name]:
                errs.append(f"{f}: {name}.{mem} não existe no autoload")

# 4) API dos componentes novos: o que é chamado em MenuList / painéis existe
def api(f): return set(re.findall(r'^func\s+(\w+)\(', src[f], re.M)) | set(re.findall(r'^signal\s+(\w+)', src[f], re.M))
ml = api("scripts/ui/menu_list.gd")
for f in ("scripts/main_menu/main_menu.gd", "scripts/ui/pause_menu.gd"):
    for m in re.findall(r'(?<![\w.])_list\.(\w+)', strip(src[f])):
        if m not in ml and m not in ("position", "size", "chosen"): errs.append(f"{f}: MenuList não tem '{m}'")
for panel, f in (("settings", "scripts/main_menu/settings_panel.gd"), ("credits", "scripts/main_menu/credits_panel.gd")):
    if "signal closed" not in src[f]: errs.append(f"{f}: falta o sinal closed")
if "signal picked" not in src["scripts/main_menu/confirm_panel.gd"]: errs.append("confirm_panel: falta picked")
# opções de menu x tratamento
for f, ids in (("scripts/main_menu/main_menu.gd", ["continue", "new", "settings", "credits", "quit"]), ("scripts/ui/pause_menu.gd", ["continue", "settings", "menu", "quit"])):
    for i in ids:
        if f'"{i}"' not in src[f]: errs.append(f"{f}: opção '{i}' sem tratamento")
# 5) configurações: toda opção tem setter, chave salva e controle no painel
gs = src["scripts/core/game_settings.gd"]
for var in ("window_mode", "resolution", "vsync", "fps_limit", "pixel_integer", "fx_snow", "fx_lights", "master_volume", "music_volume", "sfx_volume"):
    if not re.search(r'^var\s+' + var + r'\b', gs, re.M): errs.append(f"GameSettings: falta var {var}")
    if f"self.{var}" not in gs and f'"{var}"' not in gs and var not in re.findall(r'cfg\.set_value\([^)]*\b(' + var + r')\b', gs):
        pass
for key in ("mode", "width", "height", "vsync", "fps", "pixel_integer", "snow", "lights", "master", "music", "sfx"):
    if f'set_value("' not in gs or not re.search(r'set_value\("\w+", "' + key + '"', gs): errs.append(f"GameSettings: chave '{key}' não é salva")
    if not re.search(r'get_value\("\w+", "' + key + '"', gs): errs.append(f"GameSettings: chave '{key}' não é carregada")
sp = src["scripts/main_menu/settings_panel.gd"]
for call in ("set_window_mode", "set_resolution", "set_vsync", "set_fps_limit", "set_pixel_integer", "set_fx_snow", "set_fx_lights", "reset_defaults", "apply_audio"):
    if f"GameSettings.{call}" not in sp: errs.append(f"settings_panel não chama GameSettings.{call}")
for opt in ("30", "60", "120", "144", "240"):
    if opt not in re.search(r'FPS_OPTIONS[^=]*=\s*\[([^\]]*)\]', gs).group(1): errs.append(f"FPS {opt} ausente")
# 6) pausa: pausa de verdade e dirty
pm = src["scripts/ui/pause_menu.gd"]
for need in ("get_tree().paused = true", "get_tree().paused = false", "GameState.dirty", "PROCESS_MODE_ALWAYS", "SceneRouter.go"):
    if need not in pm: errs.append(f"pause_menu: falta '{need}'")
# 7) balanceamento simples
for f in ("scripts/main_menu/main_menu.gd", "scripts/main_menu/menu_background.gd", "scripts/main_menu/settings_panel.gd", "scripts/ui/menu_list.gd", "scripts/ui/pause_menu.gd", "scripts/core/game_settings.gd", "scripts/main_menu/credits_panel.gd", "scripts/main_menu/confirm_panel.gd"):
    t = re.sub(r'"(?:[^"\\\n]|\\.)*"', '""', src[f]); t = re.sub(r'#.*', '', t)
    for a, b in ("()", "[]", "{}"):
        if t.count(a) != t.count(b): errs.append(f"{f}: delimitadores {a}{b} desbalanceados")
    if "\t" in src[f]: errs.append(f"{f}: contém TAB")
print(f"autoloads verificados: {sorted(auto)}")
for w in warns: print("AVISO:", w)
for e in errs: print("ERRO:", e)
print("RESULTADO:", "OK" if not errs else f"{len(errs)} erro(s)")
sys.exit(1 if errs else 0)
