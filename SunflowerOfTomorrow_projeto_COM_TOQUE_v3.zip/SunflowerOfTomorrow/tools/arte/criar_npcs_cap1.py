"""Capítulo I — personagens novos (Olivier, Helena, voluntários, soldados, moradores).
Segue o mesmo método de criar_npcs.py / criar_pais.py: variações de cor e escala dos sprites do Alen
(assets/characters/alen/). São PLACEHOLDERS de boa qualidade até haver arte própria.
Uso: python3 tools/arte/criar_npcs_cap1.py     (requer numpy e pillow)
Gera: assets/characters/*.png  e  assets/ui/portraits/<nome>_normal.png"""
from PIL import Image, ImageDraw
import numpy as np, os

HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.join(HERE, "..", "..")
A = os.path.join(ROOT, "assets", "characters", "alen") + os.sep
OUT = os.path.join(ROOT, "assets", "characters") + os.sep
POR = os.path.join(ROOT, "assets", "ui", "portraits") + os.sep


def H(h):
    h = h.lstrip("#"); return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def ramp(cols, t):
    t = np.clip(t, 0, 1) * (len(cols) - 1); i = np.minimum(t.astype(int), len(cols) - 2); f = (t - i)[..., None]
    c = np.array(cols, np.float32); return c[i] * (1 - f) + c[i + 1] * f


def recolor(path, style, head_frac=0.40):
    img = np.array(Image.open(path).convert("RGBA")); rgb = img[..., :3].astype(np.float32); al = img[..., 3]
    h, w = al.shape
    mx = rgb.max(axis=2); mn = rgb.min(axis=2); V = mx / 255.0; S = np.where(mx > 0, (mx - mn) / np.maximum(mx, 1), 0)
    L = 0.3 * rgb[..., 0] + 0.59 * rgb[..., 1] + 0.11 * rgb[..., 2]
    R, G, B = rgb[..., 0], rgb[..., 1], rgb[..., 2]
    skin = (R > G) & (G >= B - 4) & ((R - B) > 22) & (S > 0.12) & (V > 0.42)
    light = (V > 0.40) & (S < 0.20) & ~skin
    pants = (B > R + 10) & (V > 0.22) & ~skin
    dark = ~(skin | light | pants)
    rows = np.arange(h)[:, None] * np.ones((1, w))
    hair = dark & (rows < h * head_frac); feet = dark & (rows > h * 0.88); jacket = dark & ~hair & ~feet
    t = np.clip((L - 6) / 90.0, 0, 1); out = rgb.copy()
    out[hair] = ramp(style["hair"], t)[hair]
    out[jacket] = ramp(style["jacket"], t)[jacket]
    out[pants] = ramp(style["pants"], np.clip((L - 20) / 110.0, 0, 1))[pants]
    out[feet] = ramp(style["shoes"], np.clip((L - 6) / 90.0, 0, 0.5))[feet]
    out[light] = ramp(style["shoes"], np.clip((L - 60) / 150.0, 0, 1))[light]
    out[skin] = np.clip(rgb[skin] * np.array(style.get("skin", (1, 1, 1))), 0, 255)
    if "scarf" in style:
        sk = np.where(skin[:int(h * 0.5)].any(axis=1))[0]
        if len(sk):
            r0 = sk.max() + 1; band = jacket.copy(); band[:r0, :] = False; band[r0 + 2:, :] = False
            out[band] = ramp(style["scarf"], t)[band]
    if "coat_extend" in style:
        pr = np.where(pants.any(axis=1))[0]
        if len(pr):
            r0, r1 = pr.min(), pr.max(); cut = r0 + int((r1 - r0) * style["coat_extend"])
            m = pants.copy(); m[cut:, :] = False; out[m] = ramp(style["jacket"], np.clip((L - 20) / 110.0, 0, 1))[m]
    return np.dstack([np.clip(out, 0, 255), al]).astype(np.uint8)


def scale(a, f):
    im = Image.fromarray(a, "RGBA") if isinstance(a, np.ndarray) else a
    return im.resize((max(1, round(im.width * f)), max(1, round(im.height * f))), Image.NEAREST)


def style(hair, jacket, pants, shoes, skin=(1, 1, 1), **kw):
    d = dict(hair=[H(c) for c in hair], jacket=[H(c) for c in jacket], pants=[H(c) for c in pants],
             shoes=[H(c) for c in shoes], skin=skin)
    for k, v in kw.items():
        d[k] = [H(c) for c in v] if isinstance(v, (list, tuple)) else v
    return d


NEUTRAL_PANTS = ("#16191f", "#2f353f", "#4a525e"); NEUTRAL_SHOES = ("#1c1b20", "#3a3840", "#5a5862")
OLIVE_PANTS = ("#1a1f15", "#363f2b", "#556048")

S = {
    # Olivier: jaqueta cinza-azulada gasta, cachecol laranja desbotado, cabelo castanho-claro bagunçado
    "olivier": style(("#2c2219", "#6e5238", "#a98a62"), ("#161c24", "#3a4756", "#6c7e92"), NEUTRAL_PANTS, NEUTRAL_SHOES,
                     skin=(1.02, 0.96, 0.92), scarf=("#4a2210", "#b5622c", "#e39a56")),
    # Helena: cardigã verde-petróleo, cabelo grisalho preso
    "helena": style(("#3a3431", "#857a72", "#c4bbb2"), ("#14292b", "#376565", "#74a09b"), ("#231f22", "#453d43", "#665a62"),
                    ("#2a2024", "#4b3a40", "#6d5a62"), skin=(1.03, 0.97, 0.94), scarf=("#3f3150", "#7d6a96", "#b4a2cc")),
    # voluntários: colete azul-claro sobre agasalho
    "nina": style(("#341810", "#8a4026", "#cf7a4a"), ("#14283a", "#2f6090", "#68a8d8"), NEUTRAL_PANTS, NEUTRAL_SHOES, skin=(1.04, 0.98, 0.95)),
    "tiago": style(("#16130f", "#3a342c", "#62594b"), ("#14283a", "#2f6090", "#68a8d8"), ("#1f2230", "#3a4256", "#586480"), NEUTRAL_SHOES, skin=(0.93, 0.85, 0.78)),
    # soldados: capacete e farda em tons de oliva (sem insígnias reais)
    "ferraz": style(("#23271c", "#555c42", "#8a9170"), ("#1d2417", "#46543a", "#7a8a5e"), OLIVE_PANTS, ("#14120f", "#2a2622", "#4a443e"), skin=(1.0, 0.92, 0.86)),
    "menezes": style(("#272a20", "#5e6548", "#979e7a"), ("#202618", "#4e5c3e", "#82926a"), OLIVE_PANTS, ("#14120f", "#2a2622", "#4a443e"), skin=(0.95, 0.86, 0.80)),
    "lopes": style(("#2a1d14", "#5a4130", "#8c6a50"), ("#1d2417", "#46543a", "#7a8a5e"), OLIVE_PANTS, ("#14120f", "#2a2622", "#4a443e"), skin=(1.03, 0.95, 0.90)),
    # moradores
    "mulher": style(("#3a2420", "#7a4a40", "#a97467"), ("#2a1626", "#68405e", "#a47498"), ("#211c22", "#463d46", "#665a66"), NEUTRAL_SHOES, skin=(1.03, 0.96, 0.93), scarf=("#4a3a14", "#a8842e", "#dcb860")),
    "velho": style(("#40424a", "#8d909a", "#cfd2da"), ("#1b1e24", "#3c424e", "#6c7686"), ("#1f2127", "#3c4048", "#5c626c"), NEUTRAL_SHOES, skin=(1.0, 0.92, 0.88)),
    "crianca_a": style(("#1c130d", "#4a3524", "#7d5c40"), ("#3a1212", "#a02a2a", "#e06060"), ("#1f2230", "#3a4256", "#586480"), ("#2a1a14", "#5a3a2a", "#8a5c44"), skin=(1.05, 0.98, 0.95)),
    "crianca_b": style(("#2a1c10", "#7a5a22", "#c4962e"), ("#3a3010", "#b09020", "#f0d050"), ("#2a2218", "#4a3e2c", "#6a5a42"), ("#1c1b20", "#3a3840", "#5a5862"), skin=(0.96, 0.88, 0.82)),
    "iris": style(("#2d2a2a", "#6b6565", "#aaa4a4"), ("#3a3226", "#cfc9bb", "#f2eee2"), ("#2b2018", "#58402c", "#7e6040"), ("#2a2024", "#4b3a40", "#6d5a62"), skin=(1.05, 0.98, 0.94), scarf=("#4a1c1c", "#9a3838", "#d06a6a")),
    "aurelio": style(("#1c1a16", "#4a463c", "#7a7464"), ("#1a2e2c", "#4a7a70", "#8cb8a8"), ("#2a2016", "#54402a", "#7c5e40"), NEUTRAL_SHOES, skin=(0.92, 0.82, 0.74), coat_extend=0.5),
    "candida": style(("#3d3a3c", "#8a8488", "#c6c0c4"), ("#3a1c1c", "#8a4040", "#c88070"), ("#271f20", "#4a3c3e", "#6a585c"), NEUTRAL_SHOES, skin=(1.04, 0.97, 0.94), coat_extend=0.45),
    "civil_a": style(("#16130f", "#3a342c", "#62594b"), ("#2a2218", "#6b5a3e", "#a08c64"), ("#1f2230", "#3a4256", "#586480"), NEUTRAL_SHOES, skin=(0.95, 0.87, 0.80)),
    "civil_b": style(("#3a2a1c", "#7a5a3a", "#b08c60"), ("#1c2430", "#44566e", "#7c92b0"), NEUTRAL_PANTS, NEUTRAL_SHOES, skin=(1.03, 0.96, 0.92), scarf=("#2a3a1c", "#566e3a", "#8caa62")),
    "civil_c": style(("#1a1214", "#4a363c", "#7c606a"), ("#241a2e", "#54406e", "#8a70a8"), ("#211c22", "#463d46", "#665a66"), NEUTRAL_SHOES, skin=(1.0, 0.9, 0.84)),
    "lucia": style(("#201510", "#523626", "#86604a"), ("#1c2a22", "#44684e", "#7aa488"), ("#211c22", "#463d46", "#665a66"), NEUTRAL_SHOES, skin=(1.0, 0.92, 0.88)),
    "anselmo": style(("#3a3c44", "#868a94", "#c8ccd4"), ("#2a2a2e", "#5a5a62", "#8e8e98"), ("#1f2127", "#3c4048", "#5c626c"), NEUTRAL_SHOES, skin=(1.0, 0.91, 0.86)),
}


def blanket(arr, top_row, base, line):
    im = Image.fromarray(arr, "RGBA"); d = ImageDraw.Draw(im); w, h = im.size
    d.polygon([(0, top_row + 2), (w * 0.3, top_row), (w * 0.7, top_row + 1), (w, top_row + 3), (w, h), (0, h)], fill=base + (255,))
    for x in range(-h, w, 5): d.line([(x, h), (x + (h - top_row), top_row)], fill=line + (255,))
    for y in range(top_row + 3, h, 5): d.line([(0, y), (w, y)], fill=line + (255,))
    return np.array(im)


def rifle(img):
    """fuzil a tiracolo: duas linhas escuras diagonais sobre o tronco (suficiente na escala do jogo)."""
    d = ImageDraw.Draw(img); w, h = img.size
    d.line([(int(w * 0.18), int(h * 0.50)), (int(w * 0.82), int(h * 0.74))], fill=(20, 20, 18, 255), width=2)
    d.line([(int(w * 0.70), int(h * 0.70)), (int(w * 0.92), int(h * 0.80))], fill=(48, 44, 38, 255), width=1)
    return img


sprites = {}
def put(name, arr, f=1.0, post=None):
    im = scale(arr, f)
    if post: im = post(im)
    sprites[name] = im


def crouch(key, head=0.45, strip=True):
    a = recolor(A + "dano.png", S[key], head_frac=head)
    if strip: a[:, int(a.shape[1] * 0.88):, 3] = 0       # remove os "riscos de dano" à direita
    return a


front = lambda key: recolor(A + "parado.png", S[key])
side = lambda key: recolor(A + "andando_lado.png", S[key])

put("olivier_front", front("olivier"), 1.13)
put("olivier_side", side("olivier"), 1.13)
put("olivier_sentado", crouch("olivier"), 1.10)
put("helena", front("helena"), 1.05)
put("nina", front("nina"), 1.04)
put("tiago", front("tiago"), 1.10)
put("ferraz", front("ferraz"), 1.14, rifle)
put("ferraz_side", side("ferraz"), 1.14, rifle)
put("menezes_sentado", crouch("menezes"), 1.12)
put("lopes", front("lopes"), 1.08, rifle)
put("mulher", front("mulher"), 1.02)
put("velho", front("velho"), 1.0)
put("crianca_a", front("crianca_a"), 0.70)
put("crianca_b", front("crianca_b"), 0.66)
put("iris", front("iris"), 1.02)
put("aurelio", front("aurelio"), 1.06)
put("candida", front("candida"), 1.0)
put("civil_a", front("civil_a"), 1.08)
put("civil_a_side", side("civil_a"), 1.08)
put("civil_b", front("civil_b"), 1.04)
put("civil_c", front("civil_c"), 1.0)
put("tobias_sentado", crouch("velho"), 1.05)
# Lúcia sentada com o bebê embrulhado (mancha clara no colo)
lu = crouch("lucia", head=0.42)
lu_im = Image.fromarray(lu, "RGBA"); d = ImageDraw.Draw(lu_im); w, h = lu_im.size
d.rectangle([w // 2 - 4, h - 16, w // 2 + 3, h - 8], fill=(222, 218, 206, 255)); d.point((w // 2 - 1, h - 13), fill=(190, 150, 130, 255))
sprites["lucia_sentada"] = scale(lu_im, 1.0)
# Seu Anselmo dormindo sob um cobertor xadrez
an = crouch("anselmo", head=0.40); an = blanket(an, int(an.shape[0] * 0.55), (96, 70, 60), (126, 94, 82))
sprites["anselmo_dormindo"] = scale(an, 1.08)

for k, im in sprites.items():
    im.save(OUT + k + ".png"); print(k, im.size)

# retratos-busto (parte de cima do sprite frontal, ampliada 2x), mesmo formato dos já existentes (60x52)
def portrait(name, spr, frac=0.52):
    w, h = spr.size; bust = spr.crop((0, 0, w, int(h * frac)))
    c = Image.new("RGBA", (30, 26), (18, 21, 27, 255)); c.alpha_composite(bust, ((30 - bust.width) // 2, 26 - bust.height))
    c.resize((60, 52), Image.NEAREST).convert("RGB").save(POR + name + "_normal.png")

for n, key in (("olivier", "olivier_front"), ("helena", "helena"), ("nina", "nina"), ("tiago", "tiago"), ("ferraz", "ferraz"),
               ("lopes", "lopes"), ("iris", "iris"), ("aurelio", "aurelio")):
    portrait(n, sprites[key])
portrait("menezes", sprites["ferraz_side"])
print("retratos ok")

# prévia
names = ["olivier_front", "olivier_sentado", "helena", "nina", "tiago", "ferraz", "lopes", "menezes_sentado", "mulher", "velho",
         "crianca_a", "crianca_b", "iris", "aurelio", "candida", "civil_a", "civil_b", "civil_c", "lucia_sentada", "anselmo_dormindo", "tobias_sentado"]
Wp = sum(sprites[n].width + 8 for n in names) + 8; prev = Image.new("RGBA", (Wp, 64), (96, 104, 118, 255)); x = 4
al = Image.open(A + "parado.png").convert("RGBA"); prev.alpha_composite(al, (x, 60 - al.height)); x += al.width + 8
for n in names:
    prev.alpha_composite(sprites[n], (x, 60 - sprites[n].height)); x += sprites[n].width + 8
os.makedirs("/tmp/an", exist_ok=True)
prev.resize((prev.width * 3, prev.height * 3), Image.NEAREST).convert("RGB").save("/tmp/an/prev_npcs_cap1.png")
