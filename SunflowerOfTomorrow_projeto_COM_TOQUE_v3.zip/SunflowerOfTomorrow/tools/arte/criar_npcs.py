from PIL import Image
import numpy as np, cv2
IN="/home/claude/sot/assets/characters/alen/"; OUT="/home/claude/sot/assets/characters/"
def ramp(cols,t):
    t=np.clip(t,0,1)*(len(cols)-1); i=np.minimum(t.astype(int),len(cols)-2); f=(t-i)[...,None]
    c=np.array(cols,np.float32); return c[i]*(1-f)+c[i+1]*f
def H(h): h=h.lstrip("#"); return tuple(int(h[i:i+2],16) for i in (0,2,4))
def recolor(path,style,head_frac=0.40,crop=None):
    img=np.array(Image.open(path).convert("RGBA")); rgb=img[...,:3].astype(np.float32); al=img[...,3]
    h,w=al.shape
    mx=rgb.max(axis=2); mn=rgb.min(axis=2); V=mx/255.0; S=np.where(mx>0,(mx-mn)/np.maximum(mx,1),0)
    L=0.3*rgb[...,0]+0.59*rgb[...,1]+0.11*rgb[...,2]
    R,G,B=rgb[...,0],rgb[...,1],rgb[...,2]
    skin=(R>G)&(G>=B-4)&((R-B)>22)&(S>0.12)&(V>0.42)
    light=(V>0.40)&(S<0.20)&~skin
    pants=(B>R+10)&(V>0.22)&~skin
    dark=~(skin|light|pants)
    rows=np.arange(h)[:,None]*np.ones((1,w))
    hair=dark&(rows<h*head_frac); feet=dark&(rows>h*0.88); jacket=dark&~hair&~feet
    t=np.clip((L-6)/90.0,0,1)
    out=rgb.copy()
    out[hair]=ramp(style["hair"],t)[hair]
    out[jacket]=ramp(style["jacket"],t)[jacket]
    out[pants]=ramp(style["pants"],np.clip((L-20)/110.0,0,1))[pants]
    out[feet]=ramp(style["shoes"],np.clip((L-6)/90.0,0,0.5))[feet]
    out[light]=ramp(style["shoes"],np.clip((L-60)/150.0,0,1))[light]
    out[skin]=np.clip(rgb[skin]*np.array(style.get("skin",(1,1,1))),0,255)
    # peças extras (cachecol/gola): faixa de pixels do jacket logo abaixo do queixo
    if "scarf" in style:
        sk=np.where(skin[:int(h*0.5)].any(axis=1))[0]
        if len(sk):
            r0=sk.max()+1
            band=jacket.copy(); band[:r0,:]=False; band[r0+2:,:]=False
            out[band]=ramp(style["scarf"],t)[band]
    if "coat_extend" in style:       # casaco longo: pinta o topo da calça com a cor do casaco
        pr=np.where(pants.any(axis=1))[0]
        if len(pr):
            r0,r1=pr.min(),pr.max(); cut=r0+int((r1-r0)*style["coat_extend"])
            m=pants.copy(); m[cut:,:]=False
            out[m]=ramp(style["jacket"],np.clip((L-20)/110.0,0,1))[m]
    res=np.dstack([np.clip(out,0,255),al]).astype(np.uint8)
    return res
MARCUS=dict(hair=[H("#202226"),H("#43464d"),H("#6a6d75")],            # gorro cinza-azulado
            jacket=[H("#21180f"),H("#5b4330"),H("#8a6a48")],            # jaqueta de trabalho marrom
            pants=[H("#16191f"),H("#2f353f"),H("#4a525e")],
            shoes=[H("#1c1b20"),H("#3a3840"),H("#5a5862")],
            skin=(1.0,0.93,0.86), scarf=[H("#2a2a2e"),H("#4a4f58"),H("#6c727e")])
ELEANOR=dict(hair=[H("#4b4d57"),H("#9a9ca6"),H("#d6d8df")],            # cabelo grisalho
             jacket=[H("#2b1e29"),H("#6d5560"),H("#9a7d89")],           # casaco ameixa
             pants=[H("#241b22"),H("#4a3a44"),H("#6a5764")],
             shoes=[H("#2a2024"),H("#4b3a40"),H("#6d5a62")],
             skin=(1.04,0.98,0.95), scarf=[H("#5a3f12"),H("#b78a3a"),H("#e0b866")], coat_extend=0.55)
def scale(a,f):
    im=Image.fromarray(a,"RGBA"); w,h=im.size; return im.resize((max(1,round(w*f)),max(1,round(h*f))),Image.NEAREST)
sets={}
m_front=recolor(IN+"parado.png",MARCUS); m_side=recolor(IN+"andando_lado.png",MARCUS)
e_front=recolor(IN+"parado.png",ELEANOR); e_crouch=recolor(IN+"dano.png",ELEANOR,head_frac=0.45)
# Eleanor: remove os "riscos de dano" à direita da cabeça (pixels isolados à direita)
alpha=e_crouch[...,3]; 
cols=np.where(alpha.any(axis=0))[0]; e_crouch[:, int(e_crouch.shape[1]*0.88):,3]=0
sprites={"marcus_front":scale(m_front,1.10),"marcus_side":scale(m_side,1.10),"eleanor_front":scale(e_front,0.94),"eleanor_crouch":scale(e_crouch,1.0)}
for k,im in sprites.items(): im.save(OUT+k+".png"); print(k,im.size)
# prévia ao lado do Alen
names=[("alen",Image.open(IN+"parado.png")),("alen lado",Image.open(IN+"andando_lado.png"))]+[(k,v) for k,v in sprites.items()]
W=sum(i.width+12 for _,i in names)+8; prev=Image.new("RGBA",(W,62),(120,126,138,255)); x=6
for _,i in names: prev.alpha_composite(i.convert("RGBA"),(x,58-i.height)); x+=i.width+12
prev.resize((prev.width*5,prev.height*5),Image.NEAREST).convert("RGB").save("prev_npcs.png")

# retratos-busto dos NPCs (parte de cima do sprite frontal, ampliada 2x, sobre fundo escuro)
for name,spr in (("marcus",sprites["marcus_front"]),("eleanor",sprites["eleanor_front"])):
    w,h=spr.size; bust=spr.crop((0,0,w,int(h*0.52)))
    canvas=Image.new("RGBA",(30,26),(18,21,27,255)); canvas.alpha_composite(bust,((30-bust.width)//2,26-bust.height))
    canvas=canvas.resize((60,52),Image.NEAREST); canvas.convert("RGB").save("/home/claude/sot/assets/ui/portraits/%s_normal.png"%name)
tiles=[Image.open("/home/claude/sot/assets/ui/portraits/%s_normal.png"%n) for n in ("marcus","eleanor")]
prev2=Image.new("RGB",(140,60),(40,40,44)); prev2.paste(tiles[0],(4,4)); prev2.paste(tiles[1],(74,4)); prev2.resize((420,180),Image.NEAREST).save("prev_busts.png")
