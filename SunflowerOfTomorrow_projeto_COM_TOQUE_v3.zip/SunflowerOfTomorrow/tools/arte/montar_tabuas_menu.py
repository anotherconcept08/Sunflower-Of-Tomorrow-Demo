from PIL import Image, ImageDraw, ImageFont
import numpy as np, cv2, os, json
from scipy import ndimage as ndi
SRC="/mnt/user-data/uploads/1792193778487_image.png"
OUT="/home/claude/sot/assets/ui/menu/"; os.makedirs(OUT,exist_ok=True)
im=Image.open(SRC).convert("RGB"); A=np.array(im)
FONT=ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf",13)
LABELS=["CONTINUAR","NOVO JOGO","CARREGAR JOGO","CONFIGURAÇÕES","SAIR"]
PW=152; PH=35
# --- base: tábua EXIT (x436..585, y364..398) com as pontas limpas
bx0,by0,bx1,by1=436,364,585,398
P4=A[by0:by1+1,bx0:bx1+1]          # 150x35
def stitch(width):
    left=P4[:, :44]; right=P4[:, -44:]
    mid_src=P4[:,14:32]                     # trecho limpo da esquerda
    need=width-88; tiles=[]; flip=False
    while sum(t.shape[1] for t in tiles)<need:
        tiles.append(mid_src[:, ::-1] if flip else mid_src); flip=not flip
    mid=np.concatenate(tiles,axis=1)[:, :need]
    return np.concatenate([left,mid,right],axis=1)
def tint(rgb,mult,add=0): return np.clip(rgb.astype(np.float32)*np.array(mult)+add,0,255).astype(np.uint8)
def text_img(label,color,outline=(14,16,22)):
    w=PW; h=PH
    t=Image.new("L",(w,h),0); d=ImageDraw.Draw(t); d.fontmode="1"
    bb=d.textbbox((0,0),label,font=FONT); tw,th=bb[2]-bb[0],bb[3]-bb[1]
    pos=((w-tw)//2-bb[0],(h-th)//2-bb[1]-1)
    d.text(pos,label,font=FONT,fill=255)
    m=np.array(t)>127
    o=ndi.binary_dilation(m,structure=np.ones((3,3)))&~m
    img=np.zeros((h,w,4),np.uint8); img[o]=(*outline,255); img[m]=(*color,255)
    return Image.fromarray(img,"RGBA")
def corner_alpha(w,h):
    a=np.full((h,w),255,np.uint8)
    for (x,y) in [(0,0),(w-1,0),(0,h-1),(w-1,h-1),(1,0),(0,1),(w-2,0),(w-1,1),(1,h-1),(0,h-2),(w-2,h-1),(w-1,h-2)]: a[y,x]=0
    return a
states={"normal":((1,1,1),0,(246,248,252)),"focus":((1.12,1.06,0.93),8,(255,218,110)),"disabled":((0.62,0.64,0.68),-6,(120,128,140))}
meta={}
for i,label in enumerate(LABELS,1):
    base=stitch(PW)
    if i%2==0: base=base[:, ::-1]
    for st,(mult,add,col) in states.items():
        rgb=tint(base,mult,add)
        rgba=np.dstack([rgb,corner_alpha(PW,PH)])
        plank=Image.fromarray(rgba,"RGBA")
        plank.alpha_composite(text_img(label,col))
        if i==1:      # tábua de cima ganha a neve da original (faixa sem texto)
            band=A[229:246,429:596].copy()            # 167x17
            canvas=Image.new("RGBA",(167,PH+14),(0,0,0,0))
            canvas.alpha_composite(plank,(7,14))
            bimg=Image.fromarray(tint(band,mult,add),"RGB").convert("RGBA")
            canvas.alpha_composite(bimg,(0,0))
            plank=canvas
        plank.save(OUT+f"plank_{i}_{st}.png")
    meta[i]=plank.size
print(meta)
# prévia empilhada
col=[Image.open(OUT+f"plank_{i}_normal.png") for i in range(1,6)]
foc=[Image.open(OUT+f"plank_{i}_focus.png") for i in range(1,6)]
dis=[Image.open(OUT+f"plank_{i}_disabled.png") for i in range(1,6)]
H=sum(c.height+4 for c in col); prev=Image.new("RGB",(167*3+20,H),(150,160,175)); y=0
for n,f,d in zip(col,foc,dis):
    for j,im2 in enumerate((n,f,d)): prev.paste(im2,(j*177,y),im2)
    y+=n.height+4
prev.resize((prev.width*2,prev.height*2),Image.NEAREST).save("prev_planks.png")
