from PIL import Image
import numpy as np, cv2
from scipy import ndimage as ndi
OUT="/home/claude/sot/assets/characters/alen/"
sheet=Image.open("/mnt/user-data/uploads/1792193784191_image_1.png").convert("RGB")
a=np.array(sheet).astype(np.int32)
bg=np.array([17,18,23])
Y0,Y1=478,664
segs={"parado":(26,110),"andando_lado":(144,235),"andando_cima":(274,362),"correndo":(400,509),"interagindo":(548,666),"conversando":(696,773),"dano":(818,928),"morto":(944,1068)}
TARGET_H=46.0   # altura em pixels do "Parado" no jogo (base 640x360)
def lum(p): return 0.3*p[...,0]+0.59*p[...,1]+0.11*p[...,2]
def mask_for(x0,x1,name):
    sub=a[Y0:Y1,x0-6:x1+6]
    diff=np.abs(sub-bg).sum(axis=2)
    fg=diff>16
    if name=="conversando":
        fg[:36,:]=False        # remove o balão de fala
    fg=ndi.binary_closing(fg,iterations=2)
    lab,n=ndi.label(fg)
    if n==0: return None,None
    sizes=ndi.sum(fg,lab,range(1,n+1)); keep=1+int(np.argmax(sizes))
    m=lab==keep
    L=lum(sub)
    # linha dos pés: último ponto claro (tênis)
    rows=np.where((L>62)&m)[0]
    yf=rows.max() if len(rows) else m.nonzero()[0].max()
    cut=np.zeros_like(m)
    shoes=ndi.binary_dilation((L>48)&m,iterations=1)
    for y in range(m.shape[0]):
        if y>yf-2:
            cut[y]=shoes[y]
        else:
            cut[y]=m[y]
    cut=ndi.binary_fill_holes(cut)
    return sub,cut
res={}
for name,(x0,x1) in segs.items():
    sub,m=mask_for(x0,x1,name)
    ys,xs=np.where(m)
    y0,y1,xc0,xc1=ys.min(),ys.max()+1,xs.min(),xs.max()+1
    rgba=np.dstack([sub,(m*255)]).astype(np.uint8)[y0:y1,xc0:xc1]
    res[name]=rgba
    print(name, rgba.shape)
f=res["parado"].shape[0]/TARGET_H
print("fator de redução", round(f,3))
def down(rgba,f):
    h,w=rgba.shape[:2]; nh,nw=max(1,round(h/f)),max(1,round(w/f))
    rgbf=rgba[...,:3].astype(np.float32); al=(rgba[...,3:]/255.0).astype(np.float32)
    pm=rgbf*al
    pm=cv2.resize(pm,(nw,nh),interpolation=cv2.INTER_AREA); al2=cv2.resize(al,(nw,nh),interpolation=cv2.INTER_AREA)
    if al2.ndim==2: al2=al2[...,None]
    col=np.where(al2>0.02,pm/np.maximum(al2,1e-3),0)
    hard=(al2>0.5)
    out=np.dstack([np.clip(col,0,255),hard*255]).astype(np.uint8)
    return out
for name,rgba in res.items():
    Image.fromarray(rgba,"RGBA").save(OUT+f"_hires_{name}.png")
    d=down(rgba,f)
    Image.fromarray(d,"RGBA").save(OUT+f"{name}.png")
    print(name,"->",d.shape[1],"x",d.shape[0])
# prévia sobre neve cinza, 4x
names=list(segs.keys())
W=sum(Image.open(OUT+f"{n}.png").width for n in names)+10*len(names)+10
prev=Image.new("RGBA",(W,70),(120,126,138,255)); x=5
for n in names:
    im=Image.open(OUT+f"{n}.png"); prev.alpha_composite(im,(x,64-im.height)); x+=im.width+10
prev=prev.resize((prev.width*4,prev.height*4),Image.NEAREST); prev.convert("RGB").save("prev_sprites.png")
