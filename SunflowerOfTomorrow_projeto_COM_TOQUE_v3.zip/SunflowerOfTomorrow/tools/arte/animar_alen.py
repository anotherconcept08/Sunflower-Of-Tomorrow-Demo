"""Gera assets/characters/alen/alen_sheet.png: ciclos de animação do Alen derivados dos sprites da ficha.
A ficha tem UM quadro por pose; aqui cada pose é separada em corpo superior e pernas, e as pernas são
alternadas (espelhadas, juntadas ou levantadas) para formar ciclos de 4 quadros, mais "respiração" no idle.
Folha: 4 colunas x 8 linhas de 40x54 px, pés na linha 51, centro em x=20.
Linhas: 0 idle_down, 1 idle_side, 2 idle_up, 3 walk_down, 4 walk_side, 5 walk_up, 6 run_side, 7 run_down"""
from PIL import Image
import numpy as np, os
HERE = os.path.dirname(os.path.abspath(__file__)); IN = os.path.join(HERE, "..", "..", "assets", "characters", "alen") + os.sep
CW, CH, BASE = 40, 54, 51
def load(n): return np.array(Image.open(IN + n + ".png").convert("RGBA"))
def hip_row(a):
    rgb = a[..., :3].astype(int); vis = a[..., 3] > 0
    pants = (rgb[..., 2] > rgb[..., 0] + 10) & vis
    rows = np.where(pants.sum(axis=1) >= 2)[0]
    return int(rows.min()) if len(rows) else int(a.shape[0] * 0.62)
def paste(canvas, arr, x, y):
    h, w = arr.shape[:2]
    for j in range(h):
        for i in range(w):
            if arr[j, i, 3] > 0 and 0 <= y + j < canvas.shape[0] and 0 <= x + i < canvas.shape[1]: canvas[y + j, x + i] = arr[j, i]
def mirror(low): return low[:, ::-1].copy()
def squeeze(low, f):
    h, w = low.shape[:2]; nw = max(4, int(round(w * f)))
    return np.array(Image.fromarray(low, "RGBA").resize((nw, h), Image.NEAREST))
def lift(low, side, px):
    out = low.copy(); mid = low.shape[1] // 2; sl = slice(0, mid) if side == "L" else slice(mid, None)
    part = low[:, sl]; new = np.zeros_like(part); new[:-px] = part[px:]; out[:, sl] = new; return out
def frame(spr, bob=0, low=None, up_dx=0, up_dy=0, low_dx=0):
    h, w = spr.shape[:2]; hip = hip_row(spr); upper = spr[:hip]; lower = spr[hip:]
    if low: lower = low(lower)
    if bob > 0:                                   # corpo sobe: as pernas "esticam" (repete a linha do quadril)
        lower = np.concatenate([np.repeat(lower[:1], bob, axis=0), lower]); bob = 0
    canvas = np.zeros((CH, CW, 4), np.uint8); lh, lw = lower.shape[:2]
    yl = BASE - lh + 1; paste(canvas, lower, (CW - lw) // 2 + low_dx, yl)
    paste(canvas, upper, (CW - w) // 2 + up_dx, yl - upper.shape[0] - bob + up_dy); return canvas
P = {n: load(n) for n in ("parado", "andando_lado", "andando_cima", "correndo")}
def cycle4(spr, bob_pass=1, sq=0.55, lean=0):
    return [frame(spr, 0, None, lean), frame(spr, bob_pass, lambda l: squeeze(l, sq), lean), frame(spr, 0, mirror, lean), frame(spr, bob_pass, lambda l: squeeze(l, sq), lean)]
rows = []
d = P["parado"]
rows.append([frame(d), frame(d, 0, None, 0, 1)])                                   # idle_down (respira)
s = P["andando_lado"]; sp = lambda **k: frame(s, 0, lambda l: squeeze(l, 0.55), **k)
rows.append([sp(), sp(up_dy=1)])                                                   # idle_side
u = P["andando_cima"]; up_ = lambda **k: frame(u, 0, lambda l: squeeze(l, 0.55), **k)
rows.append([up_(), up_(up_dy=1)])                                                 # idle_up
rows.append([frame(d, 1, lambda l: lift(l, "L", 2), 1), frame(d), frame(d, 1, lambda l: lift(l, "R", 2), -1), frame(d)])   # walk_down
rows.append(cycle4(s))                                                             # walk_side
rows.append(cycle4(u))                                                             # walk_up
rows.append(cycle4(P["correndo"], bob_pass=2, sq=0.5, lean=0))                     # run_side
rows.append([frame(d, 2, lambda l: lift(l, "L", 3), 1), frame(d, 0), frame(d, 2, lambda l: lift(l, "R", 3), -1), frame(d, 0)])   # run_down
sheet = np.zeros((CH * len(rows), CW * 4, 4), np.uint8)
for r, fr in enumerate(rows):
    for c, f in enumerate(fr): sheet[r * CH:(r + 1) * CH, c * CW:(c + 1) * CW] = f
Image.fromarray(sheet, "RGBA").save(IN + "alen_sheet.png")
prev = Image.new("RGBA", (sheet.shape[1], sheet.shape[0]), (120, 126, 138, 255)); prev.alpha_composite(Image.fromarray(sheet, "RGBA"))
prev.resize((prev.width * 3, prev.height * 3), Image.NEAREST).convert("RGB").save("/tmp/an/prev_sheet.png"); print("sheet", sheet.shape)
