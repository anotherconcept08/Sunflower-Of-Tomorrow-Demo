from PIL import Image
import numpy as np, json
from scipy import ndimage as ndi
SRC="/mnt/user-data/uploads/1792193778487_image.png"
OUT="/home/claude/sot/assets/ui/menu/"
im=Image.open(SRC).convert("RGB"); A=np.array(im).copy()
def lum(p): return 0.3*p[...,0]+0.59*p[...,1]+0.11*p[...,2]
# ---- extensão do poste (abaixo da 4ª tábua) com máscara só do poste
x0,x1=499,526
seg=A[399:433,x0:x1].astype(np.float32); L=lum(seg)
post=(L<150)
post=ndi.binary_opening(post,iterations=1); lab,n=ndi.label(post)
if n: 
    sizes=ndi.sum(post,lab,range(1,n+1)); post=lab==(1+int(np.argmax(sizes)))
post=ndi.binary_fill_holes(post)
print("poste px:",post.sum(), "cols", np.where(post.any(axis=0))[0].min()+x0, np.where(post.any(axis=0))[0].max()+x0)
SHIFT=40
# copia o poste (linhas 399..432) deslocado: preenche a lacuna 433..(432+SHIFT) repetindo o trecho médio
body=A[404:420,x0:x1]; bodym=post[5:21,:]
rows_needed=SHIFT
y=433
while y<433+SHIFT:
    h=min(16,433+SHIFT-y)
    reg=A[y:y+h,x0:x1]; m=bodym[:h]
    reg[m]=body[:h][m]; y+=h
# pé do poste: copia as últimas linhas originais (421..432) para o novo fim
foot=A[421:433,x0:x1].copy(); fm=post[22:34,:]
A[433+SHIFT-12+0:433+SHIFT,x0:x1][fm]=foot[fm]
bg=Image.fromarray(A)
CROP=15
bg=bg.crop((CROP,0,1024-CROP,559)); bg.save(OUT+"menu_bg.png"); print(bg.size)
# ---- prévia com as tábuas no lugar
pos={1:(429,229),2:(436,283),3:(436,323),4:(436,364),5:(436,404)}
prev=bg.copy().convert("RGBA")
for k,(x,y) in pos.items():
    pl=Image.open(OUT+f"plank_{k}_normal.png"); prev.alpha_composite(pl,(x-CROP,y))
prev.convert("RGB").save("prev_menu_full.png")
prev.crop((380,200,640,500)).convert("RGB").resize((520,600),Image.LANCZOS).save("prev_menu_sign.png")
json.dump({str(k):[v[0]-CROP,v[1]] for k,v in pos.items()},open("plank_pos.json","w"))
