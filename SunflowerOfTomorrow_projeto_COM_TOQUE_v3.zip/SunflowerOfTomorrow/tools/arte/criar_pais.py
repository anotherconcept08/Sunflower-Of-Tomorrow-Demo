"""Pai (poltrona) e mãe (sofá) de Alen: variações dos sprites da ficha, sentados, doentes e cansados.
Placeholders de boa qualidade até haver arte própria. Gera assets/characters/pai_sentado.png, mae_sentada.png
e os retratos assets/ui/portraits/pai_normal.png, mae_normal.png."""
from PIL import Image, ImageDraw
import numpy as np, os
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.join(HERE, "..", "..")
A = os.path.join(ROOT, "assets", "characters", "alen") + os.sep; OUT = os.path.join(ROOT, "assets", "characters") + os.sep
def H(h): h = h.lstrip("#"); return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))
def ramp(cols, t):
    t = np.clip(t, 0, 1) * (len(cols) - 1); i = np.minimum(t.astype(int), len(cols) - 2); f = (t - i)[..., None]; c = np.array(cols, np.float32); return c[i] * (1 - f) + c[i + 1] * f
def recolor(path, style, head_frac, rows=None):
    img = np.array(Image.open(path).convert("RGBA"))
    if rows: img = img[:rows]
    rgb = img[..., :3].astype(np.float32); al = img[..., 3]; h, w = al.shape
    mx = rgb.max(axis=2); mn = rgb.min(axis=2); V = mx / 255.0; S = np.where(mx > 0, (mx - mn) / np.maximum(mx, 1), 0)
    L = 0.3 * rgb[..., 0] + 0.59 * rgb[..., 1] + 0.11 * rgb[..., 2]; R, G, B = rgb[..., 0], rgb[..., 1], rgb[..., 2]
    skin = (R > G) & (G >= B - 4) & ((R - B) > 22) & (S > 0.12) & (V > 0.42); light = (V > 0.40) & (S < 0.20) & ~skin; pants = (B > R + 10) & (V > 0.22) & ~skin
    dark = ~(skin | light | pants); rr = np.arange(h)[:, None] * np.ones((1, w)); hair = dark & (rr < h * head_frac); jacket = dark & ~hair
    t = np.clip((L - 6) / 90.0, 0, 1); out = rgb.copy()
    out[hair] = ramp(style["hair"], t)[hair]; out[jacket] = ramp(style["jacket"], t)[jacket]
    out[pants] = ramp(style["jacket"], np.clip((L - 20) / 110.0, 0, 1))[pants]; out[light] = ramp(style["jacket"], np.clip((L - 60) / 150.0, 0, 1))[light]
    out[skin] = np.clip(rgb[skin] * np.array(style["skin"]), 0, 255)
    return np.dstack([np.clip(out, 0, 255), al]).astype(np.uint8)
def blanket(arr, top_row, base, line, fringe=True):
    im = Image.fromarray(arr, "RGBA"); d = ImageDraw.Draw(im); w, h = im.size
    d.polygon([(0, top_row + 2), (w * 0.3, top_row), (w * 0.7, top_row + 1), (w, top_row + 3), (w, h), (0, h)], fill=base + (255,))
    for x in range(-h, w, 5): d.line([(x, h), (x + (h - top_row), top_row)], fill=line + (255,))
    for y in range(top_row + 3, h, 5): d.line([(0, y), (w, y)], fill=line + (255,))
    d.line([(0, top_row + 2), (w * 0.3, top_row), (w * 0.7, top_row + 1), (w, top_row + 3)], fill=tuple(min(255, c + 40) for c in base) + (255,))
    if fringe: [d.point((x, h - 1), fill=(210, 196, 170, 255)) for x in range(0, w, 2)]
    return np.array(im)
def scale(a, f): im = Image.fromarray(a, "RGBA"); return im.resize((max(1, round(im.width * f)), max(1, round(im.height * f))), Image.NEAREST)
# --- pai: pose encolhida do sprite "dano", suéter verde-acinzentado, cabelo grisalho, cobertor xadrez sobre as pernas
pai = recolor(A + "dano.png", dict(hair=[H("#2e2a28"), H("#6b655d"), H("#a8a299")], jacket=[H("#1f2a24"), H("#47604f"), H("#7a9484")], skin=(0.97, 0.93, 0.90)), 0.45)
pai[:, int(pai.shape[1] * 0.88):, 3] = 0
pai = blanket(pai, int(pai.shape[0] * 0.70), (84, 62, 56), (112, 84, 74))
# --- mãe: tronco do sprite "parado", cardigã mostarda, cabelo castanho, caneca nas mãos e manta de tricô no colo
mae = recolor(A + "parado.png", dict(hair=[H("#24170f"), H("#583a26"), H("#8c6444")], jacket=[H("#3a2c14"), H("#8a6a32"), H("#c29c4c")], skin=(1.04, 0.98, 0.96)), 0.40, rows=38)
mae = blanket(mae, mae.shape[0] - 8, (74, 94, 116), (104, 126, 150), fringe=False)
mim = Image.fromarray(mae, "RGBA"); md = ImageDraw.Draw(mim); w, h = mim.size
md.rectangle([w // 2 - 3, h - 15, w // 2 + 2, h - 10], fill=(214, 210, 200, 255)); md.point((w // 2 + 3, h - 13), fill=(214, 210, 200, 255)); md.point((w // 2 - 1, h - 17), fill=(220, 224, 230, 150)); md.point((w // 2 + 1, h - 19), fill=(220, 224, 230, 110))
mae = np.array(mim)
sp = {"pai_sentado": scale(pai, 1.12), "mae_sentada": scale(mae, 1.06)}
for k, im in sp.items(): im.save(OUT + k + ".png"); print(k, im.size)
for name, key in (("pai", "pai_sentado"), ("mae", "mae_sentada")):
    spr = sp[key]; w, h = spr.size; bust = spr.crop((0, 0, w, int(h * 0.6)))
    c = Image.new("RGBA", (30, 26), (18, 21, 27, 255)); c.alpha_composite(bust, ((30 - bust.width) // 2, 26 - bust.height)); c = c.resize((60, 52), Image.NEAREST)
    c.convert("RGB").save(os.path.join(ROOT, "assets", "ui", "portraits", name + "_normal.png"))
prev = Image.new("RGBA", (120, 56), (120, 126, 138, 255)); prev.alpha_composite(sp["pai_sentado"], (10, 56 - sp["pai_sentado"].height - 2)); prev.alpha_composite(sp["mae_sentada"], (62, 56 - sp["mae_sentada"].height - 2))
prev.resize((480, 224), Image.NEAREST).convert("RGB").save("/tmp/an/prev_pais.png")
