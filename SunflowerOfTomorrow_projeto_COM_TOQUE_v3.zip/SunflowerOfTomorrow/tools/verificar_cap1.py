"""Verificação estática do Capítulo I (complementa tools/verificar_projeto.py; NÃO substitui abrir o projeto na Godot).
Confere: ids de diálogo usados x existentes, flags lidas x gravadas, imagens/sons referenciados, chamadas a funções
inexistentes nas fases novas, colisão de nomes entre classes pai/filha e balanceamento de parênteses.
Uso: python3 tools/verificar_cap1.py"""
import re, os, json, glob, sys
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
os.chdir(ROOT)
errs, warns = [], []

gd = sorted(glob.glob("scripts/**/*.gd", recursive=True))
src = {f: open(f, encoding="utf-8").read() for f in gd}
allsrc = "\n".join(src.values())
db = {}
for f in glob.glob("data/dialogue/*.json"):
    db.update(json.load(open(f, encoding="utf-8")))
c1 = {k: v for k, v in db.items() if k.startswith("c1_")}

# ---------- 1) literais c1_* / st_* nos scripts: cada um precisa ser diálogo, flag gravada ou chave de interação
lits = set(re.findall(r'"((?:c1|st)_[a-z0-9_%]+)"', allsrc))
keys = set(re.findall(r'(?:look2?|add_interactable)\(\s*Vector2\([^)]*\),\s*"([a-z_0-9]+)"', allsrc))
set_json, read_json = set(), set()
for k, d in db.items():
    for n in d["nodes"].values():
        for kk in (n.get("set") or {}): set_json.add(kk)
        for c in n.get("choices", []):
            for kk in (c.get("set") or {}): set_json.add(kk)
            for kk in ("if", "ifnot"):
                if kk in c: read_json.add(c[kk])
        if "branch" in n: read_json.add(n["branch"]["flag"])
set_gd = set(re.findall(r'set_flag\(\s*"([a-z_0-9]+)"', allsrc)) | set(re.findall(r'bump\(\s*"([a-z_0-9]+)"', allsrc))
read_gd = set(re.findall(r'get_flag\(\s*"([a-z_0-9]+)"', allsrc))
# padrões montados por formato: c1_%s_talked etc. -> expande para pai/mae
expanded = set()
for l in lits:
    if "%s" in l:
        for w in ("pai", "mae"): expanded.add(l.replace("%s", w))
dialogue_used = set()
for l in lits | expanded:
    if l in c1: dialogue_used.add(l)
    elif l in set_json | set_gd | keys: pass
    elif "%s" in l: pass
    elif l.startswith("c1v_") or l.startswith("st_"): pass
    else:
        if l not in read_gd | read_json: errs.append(f"literal desconhecido nos scripts: {l}")
# ids de diálogo escritos sem prefixo c1_ nos scripts do capítulo (ex.: "house_door", "radio_again") também contam
for f, t in src.items():
    for i in re.findall(r'Dialogue\.play\(\s*"([a-z_0-9]+)"\s*\)', t):
        if i not in db: errs.append(f"{f}: Dialogue.play usa id inexistente {i}")
        dialogue_used.add(i)
# ids em listas look/look2/add_interactable
for m in re.findall(r'(?:look2?|add_interactable)\(\s*Vector2\([^)]*\),\s*"[a-z_0-9]+",\s*(\[[^\]]*\])(?:,\s*(\[[^\]]*\]))?', allsrc):
    for part in m:
        for i in re.findall(r'"([a-z_0-9]+)"', part):
            if i not in db: errs.append(f"interação aponta para diálogo inexistente: {i}")
            dialogue_used.add(i)
# 2) flags lidas sem ninguém gravar
PROLOGUE_FLAGS = {"planted", "prologue_done", "intro_done", "has_coat", "marcus_met", "door_choice", "radio_seen", "radio_low", "overheard", "has_pinhao",
                  "eleanor_ok", "has_seed", "plant_watered", "parents_met", "pai_talked", "mae_talked", "ch1_started", "ch1_done"}
written = set_json | set_gd | PROLOGUE_FLAGS
for fl in sorted((read_json | read_gd)):
    if fl.startswith(("c1_", "st_")) and fl not in written:
        errs.append(f"flag lida mas nunca gravada: {fl}")
# 3) diálogos do capítulo sem uso
for k in sorted(c1):
    if k not in dialogue_used:
        warns.append(f"diálogo sem uso nos scripts: {k}")
# 4) imagens/personagens referenciados em código
for f, t in src.items():
    for n in re.findall(r'\bnpc\(\s*"([a-z_0-9]+)"', t):
        if not os.path.exists(f"assets/characters/{n}.png"): errs.append(f"{f}: sprite inexistente assets/characters/{n}.png")
    for n in re.findall(r'ENV\s*\+\s*"([A-Za-z_0-9]+\.png)"', t):
        if not os.path.exists(f"assets/environments/{n}"): errs.append(f"{f}: imagem inexistente assets/environments/{n}")
for k, d in db.items():
    pass
for pr in set(re.findall(r'"([a-z]+)":\s*"[a-z]+"', re.search(r'const PORTRAITS := \{(.*?)\n\}', src["scripts/dialogue/dialogue_manager.gd"], re.S).group(1))):
    pass
port = re.search(r'const PORTRAITS := \{(.*?)\n\}', src["scripts/dialogue/dialogue_manager.gd"], re.S).group(1)
for who, fn in re.findall(r'"([^"]+)":\s*"([a-z]+)"', port):
    if not os.path.exists(f"assets/ui/portraits/{fn}_normal.png"): errs.append(f"retrato inexistente para {who}: {fn}_normal.png")
speakers = set()
for k, d in c1.items():
    for n in d["nodes"].values():
        if n.get("speaker"): speakers.add(n["speaker"])
pitch = re.search(r'const SPEAKER_PITCH := \{(.*?)\n\}', src["scripts/dialogue/dialogue_manager.gd"], re.S).group(1)
for s_ in sorted(speakers):
    if f'"{s_}"' not in pitch: warns.append(f"personagem sem voz (pitch) definida: {s_}")
for f in glob.glob("assets/minigame/*.png"): pass
for n in re.findall(r'preload\("res://(assets/minigame/[a-z_]+\.png)"\)', src["scripts/minigame/space_travelers.gd"]):
    if not os.path.exists(n): errs.append(f"minijogo: falta {n}")
# 5) funções chamadas sem definição (fases novas) — heurística
BUILTIN = set("""print push_warning push_error str int float bool mini maxi clampf clamp absf abs sin cos atan2 fmod floorf roundf lerpf randf randi randf_range randi_range
min max range len load preload await assert Vector2 Vector3 Rect2 Color Callable PackedVector2Array Array Dictionary String super is_instance_valid
create_tween get_tree get_viewport get_viewport_rect queue_redraw queue_free add_child remove_child get_children set_process draw_rect draw_circle draw_string draw_texture_rect draw_line draw_arc
draw_colored_polygon draw_set_transform add_to_group set_anchors_preset set_anchors_and_offsets_preset sqrt pow snappedf signi sign is_empty has append filter size pick_random erase
emit connect call bind get set is_valid duplicate normalized length distance_to get_size get_height get_width new reset_smoothing make_current get_center get_axis
is_action_pressed is_action_just_pressed get_ticks_msec begins_with split join find replace to_upper to_lower get_flag set_flag bump
true false null self""".split())
chain = {"scripts/world/ch1_level.gd": ["scripts/world/level_base.gd"]}
for f in gd:
    if not (f.startswith("scripts/world/ch1_") or f in ("scripts/minigame/space_travelers.gd", "scripts/ui/chapter_card.gd")): continue
    base = ["scripts/world/level_base.gd", "scripts/world/ch1_level.gd"] if f.startswith("scripts/world/ch1_") and f != "scripts/world/ch1_level.gd" else (["scripts/world/level_base.gd"] if f.endswith("ch1_level.gd") else [])
    defined = set(re.findall(r'^\s*func\s+([a-z_0-9]+)\(', src[f], re.M))
    for b in base: defined |= set(re.findall(r'^\s*func\s+([a-z_0-9]+)\(', src[b], re.M))
    body = re.sub(r'#.*', '', src[f])
    body = re.sub(r'"[^"\n]*"', '""', body)
    for name in set(re.findall(r'(?<![\w.])([a-z_][a-z0-9_]*)\(', body)):
        if name in defined or name in BUILTIN or name.startswith("_on_") or name == "func": continue
        warns.append(f"{f}: chamada a '{name}()' não definida nem conhecida (confira)")
# 6) equilíbrio de delimitadores e colisões de nome pai/filha
for f in gd:
    t = re.sub(r'"(?:[^"\\\n]|\\.)*"', '""', src[f]); t = re.sub(r'#.*', '', t)
    for a, b in ("()", "[]", "{}"):
        if t.count(a) != t.count(b): errs.append(f"{f}: delimitadores {a}{b} desbalanceados ({t.count(a)} x {t.count(b)})")
lvl = {"level_base": src["scripts/world/level_base.gd"], "ch1_level": src["scripts/world/ch1_level.gd"]}
def members(t): return set(re.findall(r'^(?:var|const)\s+([A-Za-z_0-9]+)', t, re.M)) | set(re.findall(r'^func\s+([a-z_0-9]+)\(', t, re.M))
parent = members(lvl["level_base"]) | members(lvl["ch1_level"])
for f in gd:
    if f.startswith("scripts/world/ch1_") and f != "scripts/world/ch1_level.gd" or f == "scripts/world/town.gd":
        own = set(re.findall(r'^(?:var|const)\s+([A-Za-z_0-9]+)', src[f], re.M))
        clash = own & parent
        for c in clash: errs.append(f"{f}: '{c}' já existe na classe pai (conflito)")
        for fn in set(re.findall(r'^func\s+([a-z_0-9]+)\(', src[f], re.M)) & (members(lvl["ch1_level"])):
            if fn not in ("_process",): errs.append(f"{f}: redefine '{fn}' do ch1_level (sobrescrita sem super?)")
# cenas novas apontam para script existente
for f in glob.glob("scenes/ch1/*.tscn"):
    m = re.search(r'path="res://([^"]+)"', open(f, encoding="utf-8").read())
    if not m or not os.path.exists(m.group(1)): errs.append(f"{f}: script inexistente")
for sid, path in re.findall(r'"([a-z_]+)":\s*"res://(scenes/ch1/[a-z_]+\.tscn)"', src["scripts/save_system/game_state.gd"]):
    if not os.path.exists(path): errs.append(f"GameState.SCENES: {sid} -> {path} não existe")
# go_to_level / enter para fases que existem
scenes = set(re.findall(r'^\s+"([a-z_]+)":\s*"res://scenes/', src["scripts/save_system/game_state.gd"], re.M))
for f, t in src.items():
    for tgt in re.findall(r'(?:go_to_level|enter|add_edge_exit)\((?:"(?:left|right)",\s*)?"([a-z_]+)"', t):
        if tgt not in scenes: errs.append(f"{f}: destino de fase inexistente: {tgt}")
tot_nodes = sum(len(d["nodes"]) for d in c1.values())
print(f"Capítulo I: {len(c1)} diálogos, {tot_nodes} nós, {len(keys)} pontos de interação, {len(scenes)} fases no GameState")
for w in warns: print("AVISO:", w)
for e in errs: print("ERRO:", e)
print("RESULTADO:", "OK" if not errs else f"{len(errs)} erro(s)")
sys.exit(1 if errs else 0)
