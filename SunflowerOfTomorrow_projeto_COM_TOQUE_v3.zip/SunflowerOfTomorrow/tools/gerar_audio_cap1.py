"""Sons PLACEHOLDER do Capítulo I (síntese simples). Substitua os arquivos em assets/audio/ mantendo os nomes.
Uso: python3 tools/gerar_audio_cap1.py   (requer numpy e ffmpeg)"""
import numpy as np, wave, os, subprocess, tempfile
SR = 44100
rng = np.random.default_rng(21)
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "assets", "audio")

def noise(sec): return rng.standard_normal(int(sec * SR)).astype(np.float64)
def band(x, lo=None, hi=None, order=4):
    X = np.fft.rfft(x); f = np.fft.rfftfreq(len(x), 1 / SR); H = np.ones_like(f)
    if hi: H = H / np.sqrt(1 + (f / hi) ** (2 * order))
    if lo: H = H / np.sqrt(1 + (lo / np.maximum(f, 1e-3)) ** (2 * order))
    return np.fft.irfft(X * H, len(x))
def norm(x, peak=0.8): return x / (np.max(np.abs(x)) + 1e-9) * peak
def env(n, attack, decay, power=1.0):
    t = np.arange(n) / SR; a = np.minimum(1, t / max(attack, 1e-4)); return a * np.exp(-t / decay) ** power
def slow(sec, hz):
    m = band(noise(sec), None, hz, 2); return (m - m.min()) / (m.max() - m.min() + 1e-9)
def make_loop(x, xf=1.5):
    n = int(xf * SR); out = x[:-n].copy(); t = np.linspace(0, 1, n)
    out[:n] = out[:n] * np.sin(t * np.pi / 2) + x[-n:] * np.cos(t * np.pi / 2); return out
def wav(path, x):
    d = (np.clip(x, -1, 1) * 32767).astype(np.int16)
    with wave.open(path, "wb") as w: w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes(d.tobytes())
def sfx(name, x): wav(os.path.join(ROOT, "sfx", name + ".wav"), x)
def amb(name, x):
    tmp = tempfile.mktemp(suffix=".wav"); wav(tmp, x)
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", tmp, "-c:a", "libvorbis", "-q:a", "4", os.path.join(ROOT, "ambience", name + ".ogg")], check=True); os.remove(tmp)
def tone(freq, dur, kind="sq", slide=0.0):
    n = int(dur * SR); t = np.arange(n) / SR; f = freq * (1 + slide * t / dur); ph = 2 * np.pi * np.cumsum(f) / SR
    if kind == "sq": return np.sign(np.sin(ph)) * 0.5
    if kind == "tri": return (2 / np.pi) * np.arcsin(np.sin(ph))
    return np.sin(ph)

# ---------- ambientes ----------
L = 14; nn = L + 1.5
# biblioteca-abrigo: sala grande, murmúrio distante, papel, aquecedor
room = band(noise(nn), 30, 220) * 0.9 + band(noise(nn), 300, 1200) * (0.05 + 0.12 * slow(nn, 0.3))
murm = sum(band(noise(nn), f, f * 1.5) * (0.1 + slow(nn, 2 + i * 0.7)) for i, f in enumerate([300, 520, 800])) * 0.06
rustle = np.zeros(len(room))
for _ in range(int(2.0 * nn)):
    s = rng.integers(0, len(rustle) - SR // 2); m = int(rng.uniform(0.08, 0.3) * SR); rustle[s:s + m] += band(rng.standard_normal(m), 3000, 8000) * env(m, 0.02, 0.1) * rng.uniform(0.1, 0.35)
amb("library_room", norm(make_loop(room + murm + rustle * 0.2), 0.40))
# multidão na área humanitária: vozes difusas + latas + vento fraco
crowd = sum(band(noise(nn), f, f * 1.7) * (0.15 + slow(nn, 1.5 + i * 0.6)) for i, f in enumerate([220, 380, 600, 900, 1500])) * 0.5
wind = band(noise(nn), 80, 900) * (0.2 + 0.6 * slow(nn, 0.35)) * 0.6
clink = np.zeros(len(crowd))
for _ in range(int(1.4 * nn)):
    s = rng.integers(0, len(clink) - SR // 3); m = int(0.25 * SR); f0 = rng.uniform(1800, 3800)
    clink[s:s + m] += np.sin(2 * np.pi * f0 * np.arange(m) / SR) * env(m, 0.001, 0.05) * rng.uniform(0.05, 0.2)
amb("crowd_murmur", norm(make_loop(crowd + wind + clink), 0.50))

# ---------- efeitos ----------
# estrondo distante (artilharia ao longe): grave abafado, decaimento longo, eco
def boom(dur=3.2, lp=170):
    n = int(dur * SR); x = band(noise(dur), 22, lp, 3) * env(n, 0.04, 0.55) * 1.0
    x += np.sin(2 * np.pi * 48 * np.arange(n) / SR) * env(n, 0.02, 0.35) * 0.7
    for d_, g in ((0.55, 0.35), (1.1, 0.18)): k = int(d_ * SR); x[k:] += x[:-k] * g
    return norm(x, 0.9)
sfx("boom_far", boom())
sfx("boom_far2", boom(2.6, 130))
# metal pesado (grade/depósito): chacoalhar
m = int(0.7 * SR); r = band(noise(0.7), 600, 5000) * env(m, 0.002, 0.12)
for k in range(5):
    s = int(rng.uniform(0, 0.4) * SR); r[s:s + 2000] += np.sin(2 * np.pi * rng.uniform(900, 2200) * np.arange(2000) / SR) * env(2000, 0.001, 0.02) * 0.6
sfx("metal_rattle", norm(r, 0.6))
# lata / colher
t_ = int(0.5 * SR); sfx("tin_clink", norm(np.sin(2 * np.pi * 2650 * np.arange(t_) / SR) * env(t_, 0.001, 0.08) + 0.5 * np.sin(2 * np.pi * 3980 * np.arange(t_) / SR) * env(t_, 0.001, 0.05), 0.5))
# console / cartucho / TV
n = int(1.0 * SR); hum = np.sin(2 * np.pi * (60 + 90 * np.minimum(1, np.arange(n) / (0.4 * SR))) * np.arange(n) / SR) * 0.25
cr = band(noise(1.0), 3000, 9000) * env(n, 0.001, 0.03) * 0.6; ch = np.zeros(n); ch[:int(0.8 * SR)] = np.sin(2 * np.pi * 1700 * np.arange(int(0.8 * SR)) / SR) * 0.02
sfx("console_on", norm(hum * env(n, 0.1, 0.6) + cr + ch, 0.55))
n = int(0.18 * SR); sfx("cart_click", norm(band(noise(0.18), 800, 4500) * env(n, 0.001, 0.02) + tone(180, 0.18, "sin") * env(n, 0.001, 0.03), 0.6))
# minijogo (chiptune)
n = int(0.12 * SR); sfx("game_shoot", norm(tone(1500, 0.12, "sq", -0.7) * env(n, 0.001, 0.04), 0.35))
n = int(0.10 * SR); sfx("game_hit", norm(tone(260, 0.10, "sq", -0.5) * env(n, 0.001, 0.035) + band(noise(0.10), 800, 4000) * env(n, 0.001, 0.02) * 0.3, 0.4))
n = int(0.5 * SR); sfx("game_boom", norm(band(noise(0.5), 60, 1800, 2) * env(n, 0.003, 0.12) + tone(110, 0.5, "sq", -0.8) * env(n, 0.002, 0.1) * 0.4, 0.6))
n = int(0.65 * SR); sfx("game_hurt", norm(tone(420, 0.65, "sq", -0.75) * env(n, 0.002, 0.25) + band(noise(0.65), 200, 2500) * env(n, 0.002, 0.1) * 0.3, 0.5))
arp = np.concatenate([tone(f, 0.11, "sq") * env(int(0.11 * SR), 0.002, 0.08) for f in (523, 659, 784, 1047, 784, 1047, 1319)]); sfx("game_win", norm(arp, 0.4))
arp = np.concatenate([tone(f, 0.18, "tri") * env(int(0.18 * SR), 0.003, 0.14) for f in (392, 330, 262, 196)]); sfx("game_lose", norm(arp, 0.45))
arp = np.concatenate([tone(f, 0.07, "sq") * env(int(0.07 * SR), 0.002, 0.05) for f in (330, 440, 660)]); sfx("game_start", norm(arp, 0.35))
n = int(0.4 * SR); sfx("game_alert", norm((tone(880, 0.2, "sq") * env(int(0.2 * SR), 0.002, 0.1)).tolist() + [0] * 0 if False else np.concatenate([tone(880, 0.2, "sq") * env(int(0.2 * SR), 0.002, 0.15), tone(660, 0.2, "sq") * env(int(0.2 * SR), 0.002, 0.15)]), 0.35))
# batida de porta metálica distante / bicicleta... (passos de bota sobre neve compactada para soldados)
n = int(0.4 * SR); sfx("boot_snow", norm(band(noise(0.4), 120, 2500) * env(n, 0.004, 0.06) * 0.8 + band(noise(0.4), 3000, 8000) * env(n, 0.002, 0.03) * 0.2, 0.45))
print("áudio do capítulo I gerado")
