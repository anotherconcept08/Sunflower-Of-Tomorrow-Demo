# SUNFLOWER OF TOMORROW — Capítulo I: Prólogo
## Visão criativa e roteiro

# PARTE A — Visão criativa

## Contexto histórico: uma realidade alternativa de 2008
O mundo de *Sunflower of Tomorrow* começou a desandar em **2008**, mas **não é o 2008 real**. A história real é só **inspiração**: a crise financeira (a quebra de um grande banco), a escalada de um conflito na fronteira leste, crises humanitárias (fome, deslocamento, doenças, falta de infraestrutura) e guerras longas no deserto, “as tropas que nunca voltam”. No jogo, isso vira **uma sucessão de tragédias que se acumulam** — economias quebradas, governos instáveis, fronteiras fechadas, escassez de comida e de remédio, famílias que perdem a esperança aos poucos —, nunca uma explosão nem um vilão.

**Regras de escrita**
- O jogo **nunca cita nomes reais** (bancos, países, líderes): só “o banco”, “a fronteira leste”, “o governo”.
- O contexto aparece **como vida cotidiana**, em fragmentos curtos e inquietantes. Nada de documentário; ninguém explica a crise (os pais são pessoas comuns).
- O “agora” do prólogo **não é datado**. “2008” aparece no jornal que o pai guardou e no calendário do quarto (o ano em que tudo começou); o resto sugere que já passou tempo.
- **O mistério é intencional.** O prólogo faz três perguntas e não responde nenhuma: (1) o que realmente aconteceu com o mundo? (2) o que está acontecendo com a família de Alen? (3) ainda existe futuro ali?

**Onde o contexto aparece**
| Onde | Como |
|---|---|
| Rádio de pilha na sala | fragmentos (bolsa em queda, combates na fronteira, postos sem antibióticos, ajuda parada, “economize a bateria”, “neve, de novo”) com chiado; **de longe só algumas palavras, de perto a frase inteira** |
| Jornal de setembro de 2008 (mesinha de centro) | só o primeiro dia da crise foi guardado; o horóscopo promete “mudanças positivas à vista” |
| Conversa interrompida dos pais | “...se fecharem a estrada também, como é que a gente—” / “Shh. O Alen.” |
| Casa | remédios divididos com tesoura, tabela de racionamento (luz, água, remédio), TV coberta para poupar luz, prateleiras vazias, remendos para economizar |
| Quarto | pôsteres de turnês que nunca aconteceram (datas riscadas), calendário de 2008, computador apagado “porque a luz tem hora marcada”, escola que fechou |
| Cidade | farmácia “SEM ESTOQUE. NÃO INSISTA.”, edital de venda do jardim, casas fechadas, ruas sem luz |

## Premissa
Numa manhã fria em **Pinhal Alto**, cidade serrana de geada, araucárias e prédios em ruínas que ninguém explica, **Alen Hader** (16 anos) acorda no quarto de adolescente de meados dos anos 2000 que o mundo não o deixou terminar de viver, atravessa uma casa remendada onde os **pais, doentes, ouvem o rádio** e sai para a rua com uma lista que quase nada riscou. Ninguém lhe pede nada de grande. Ele caminha, é provocado por um vizinho, é reconhecido pelo jeito de andar por uma velha jardineira e, num jardim que pode ser vendido em março, planta uma semente na estação errada. O prólogo termina antes de saber se ela cresce.

## Temas
- **Continuar sem garantia.** O girassol é a possibilidade de tentar mesmo quando o amanhã não promete nada. Ninguém no prólogo diz isso; o jogador deduz.
- **Lugares e frases incompletos.** A fotografia com o rosto cortado pela dobra, o “Você anda igual a alguém que eu conhecia…”, a mensagem que Alen não responde.
- **Humor como sobrevivência.** Alen, Marcus e Eleanor se defendem com ironia; a melancolia convive com graça.
- **Cuidado que não resolve nada, mas importa.** Regar uma muda, varrer uma calçada, tirar o que secou, cobrir uma semente.

## Sinopse
Alen acorda sem ritual dramático: o quarto, a luz cinza, uma lista no caderno, uma planta que insiste. Veste a jaqueta (“um pequeno ato de fé”) e sai. Na rua, Marcus, que varre a calçada do Armazém Dias, o provoca, sonda e — sem dizer — o empurra para a estrada do Moinho, onde mora o que sobrou de um jardim. Lá, Eleanor tira o que secou, desconfia do jeito de andar de Alen e menciona, sem explicar, que alguém já andou igual. Ele acha uma lata com sementes de girassol. Eleanor avisa que a geada talvez pegue, “provavelmente”, e o deixa sozinho. Alen planta com as próprias mãos, diz que não sabe se vai crescer e que amanhã volta pra ver. Um raio baixo de sol toca a terra; uma nota; o título.

## Arco emocional de Alen
| Momento | Estado | Como aparece (sem explicar) |
|---|---|---|
| Quarto | Em suspenso | lista do caderno com “responder aquela mensagem” há 11 dias; foto dobrada; muda murchando |
| Porta | Pequeno esforço | a jaqueta como “ato de fé”; a escolha de sair ou ficar mais um minuto |
| Cidade | Evita a intimidade, mas responde | humor seco (ou gentil, ou calado) com Marcus; guarda um pinhão “inútil” no bolso |
| Jardim | É reconhecido | “Você anda igual a alguém que eu conhecia”; as iniciais L. e E. no banco |
| Semente | Decide algo mínimo | planta na estação errada; “amanhã eu volto” (um compromisso minúsculo, não uma cura) |

**Alen Hader** (ficha de personagem do projeto) — 16 anos, 1,62 m, **reservado, introspectivo, sarcástico às vezes, leal, sensível mesmo quando não demonstra**. Frase-guia: “Algumas pessoas só precisam de um lugar seguro pra existir.” / “Mesmo no caos, ainda existe um pouco de luz.” Manias: faz listas, coleciona coisas sem função, nota detalhes. Veste jaqueta xadrez sobre camiseta preta e leva mochila. Decide: regar ou não a muda, o tom com Marcus, plantar. Tem seis expressões de rosto (normal, irritado, triste, surpreso, sarcástico, envergonhado), usadas no retrato dos diálogos.

## Personagens apresentados
- **Marcus** — sarcástico e reservado, ligado à história da cidade (varre a calçada do Armazém Dias, conhece o edital e o jardim). Não revela: também evita aquela estrada (“meu joelho tem opinião sobre ladeira”).
- **Eleanor** — jardineira velha, humor seco, fala de plantas sem sermão. Não revela: quem é a pessoa a quem Alen se parece e o que a une ao jardim (iniciais L. e E.).
- **Sophia** — *não aparece* neste prólogo, de propósito: introduzi-la sem função seria pressa. Há apenas dois rastros dela (garrafa térmica e livro no banco; a “mensagem” sem resposta).

## Suposições assumidas (revise à vontade)
1. A cidade é serrana do sul do Brasil (geada, araucária, pinhão): torna o inverno e o girassol plausíveis.
2. L. (da foto/banco) é alguém ligado a Alen e a Eleanor; o prólogo **não** diz quem nem o que aconteceu.
3. Alen (16) mora num quarto de uma casa que divide com outras pessoas; **a situação familiar fica em aberto** de propósito (nenhum adulto de casa aparece no prólogo).
3b. A cidade tem ruínas (como no menu), mas o prólogo **não explica** o que as causou; as pessoas seguem a vida (Marcus varre a calçada, o rádio fala do tempo).
4. Escolhas do prólogo afetam **como Alen fala e como os outros reagem**; o caminho principal é um só.
5. Marcus, Eleanor e Sophia seguem o briefing. “Alen Hader” vem da sua ficha.

## Ganchos plantados (todos com destino planejado)
| Gancho | Onde aparece | Destino sugerido |
|---|---|---|
| A mensagem sem resposta | caderno (`notebook_1`) | Capítulo II: de quem é e por que Alen evita |
| Quem tirou a foto / quem é L. | foto, banco do jardim, Eleanor | Capítulo II–III |
| Edital de venda do jardim (março) | mural, Marcus | Pressão de tempo dos capítulos seguintes |
| Garrafa térmica e livro no banco | cidade (`bench_book`) | Introdução de Sophia |
| O que Eleanor não explica (“Um dia eu explico. Ou não.”) | jardim | Bulbos que “dormem” florescem na primavera |
| O que os pais não dizem (“...se fecharem a estrada também...”) | rádio, conversa interrompida | O que está vindo; o que “a estrada” significa |
| Remédio que não chega (pedido da mãe; Marcus “tô tentando”; farmácia sem estoque) | sala, cidade | Missão de longo prazo da família |
| Bilhete “Volto no sábado. Não esquece de regar.” (mesma letra da foto) | geladeira (`fridge_note`) | Quem partiu? Liga a muda, a foto e “L.” |
| Porta do fundo pregada (“Fui eu que preguei. Acho que fui eu.”) | sala (`closed_door_1`) | O cômodo fechado: de quem era? |
| A segunda cadeira, mantida arrumada | mesa (`table_2`) | Um lugar vazio que Alen não ocupa |
| Escada que sobe para o nada (11 degraus; eram 16) | entrada desabada | O segundo andar perdido |
| Alen volta “amanhã, pra ver” | fala final | Abertura do Capítulo II |

---

## Escolhas e consequências (resumo)
| Escolha | Opções | O que muda | O que permanece igual |
|---|---|---|---|
| Regar a muda (quarto) | Regar / Deixar | Terra escura no cenário; uma fala de Alen no bilhete da geladeira (“Hoje eu reguei. Isso conta.”) e outra no plantio (“A do quarto eu reguei hoje” ou “Tomara que eu me saia melhor…”) | O resto da história |
| Resposta a Marcus | gentil / seca / calado | `alen_tone`: reação de Marcus agora e de Eleanor depois; uma fala extra de Alen se for seco | Caminho e destino |
| “Pra onde vai?” | volta / não sei / não é da sua conta | Tom da resposta de Marcus | Informação dada |
| “O que tem no fim da estrada?” | perguntar / ir embora | Se Alen recebe o **pacote de dobradiça** (muda a abertura de Eleanor) | Ele pode ir ao jardim de qualquer modo |
| Apresentar-se a Eleanor | Alen / só passando / calado | Como Eleanor “arquiva” Alen | Ela sempre repara no jeito de andar |
| “Quem?” / “Muita gente anda igual” | duas respostas | Ela se esquiva de duas maneiras | O mistério continua |
| Pinhão (opcional) | pegar ou ignorar | Habilita o diálogo sobre plantar sem ver o resultado | — |
| Rádio | abaixar / deixar | Volume e legenda do rádio mudam; a primeira fala do pai muda (“Obrigado por abaixar o rádio.”) | O que as notícias dizem |
| Pai | “Tá doendo muito?” / olhar os remédios / “Eu abaixo o rádio.”; aula amanhã: “Tenho.” / “A escola fechou de novo.” / silêncio | Só o tom: o pai sempre tranquiliza e manda Alen descansar | Libera a saída (`parents_met`) |
| Mãe | “Tô sem fome.” / “Depois eu como.”; remédio / olhar | Como ela reage; Alen recebe o **pedido de perguntar a Marcus** (`meds_errand`) | Libera a saída (`parents_met`) |
| Sair / ficar mais um minuto | duas opções | Nada (permite olhar o quarto uma última vez) | — |

---

## A CASA DE ALEN (cenário das cenas 1 a 3)
A casa **ainda tenta funcionar como um lar** — e é **meio destruída e toda remendada** (a destruição se concentra no fim da casa; o resto é lar gasto e consertado com o que dá). O jogador a atravessa da esquerda para a direita:
1. **Quarto** — estética *Older Brother Core*: pôsteres de bandas **fictícias** (HOLLOW CITY, PAPER STATIC, LATE BUS, SEM VOLTA), prateleira de CDs, **computador de tubo** com teclado e mouse, mini system e fones, **guitarra elétrica** encostada, calendário de 2008, relógio parado (“pilha pro relógio”), cama com cobertor xadrez escuro e travesseiro gasto, cadeira com roupas jogadas (e a jaqueta), material escolar no chão, janela embaçada com neve, abajur de luz amarelada. Remendos: lona no teto, papelão e fita na janela, chapa de zinco, tábua nova no piso.
2. **Sala** — o cômodo dos pais: **poltrona do pai** (cobertor xadrez sobre as pernas) e **sofá da mãe** (caneca e manta de tricô), ambos remendados com retalhos; **rádio de válvula** no aparador; **TV coberta por renda** com um vaso; mesinha de **remédios** quase vazia, copo d’água, lenços usados; **tabela de racionamento** na parede; prateleira quase vazia; abajur de pé; **jornal de 2008** na mesinha de centro; **janela com neve** e a cidade em silêncio.
3. **Cozinha** — fogão a lenha (o único calor forte), pia com cano enfaixado de fita, janela de colcha pregada em X, geladeira-armário com o bilhete, porta do fundo pregada, mesa que manca, dois baldes de goteira, remendos de compensado, zinco, lona, papelão e tijolo por toda parte.
4. **Entrada desabada** — metade do teto no chão, vigas caídas, escada que termina no ar, neve entrando, buraco no piso, materiais de remendo na porta da frente.

**Transição entre os espaços (áudio):** do quarto (som abafado) ouve-se o rádio da sala *antes* de ver os pais; a legenda das notícias vai ficando nítida conforme Alen chega perto; na sala toca, bem baixinha, a melancolia da música do menu (só ali e na cozinha); no desabamento o ambiente “abre” (vento de fora). Rangidos da casa, goteiras e chiado de rádio ocasionais.

**Os pais** (“Pai” e “Mãe”; sem nomes): vivos, doentes, cansados, sem exagero. Ela tenta tranquilizar e está assustada; ele se preocupa com remédio, dinheiro e o futuro do filho. **Nenhum dos dois explica a crise.** Falam curto, com pausas e subtexto, e demonstram afeto com pequenos gestos (“Come mesmo assim”, “fecha bem a porta, que o frio entra”). Alen, introspectivo, hesita, olha os remédios, fica em silêncio quando não sabe o que dizer — e **não sai de casa sem falar com eles** (a porta da frente pede isso).

---

## CENA 1 — O silêncio do quarto (sem diálogo)
- **Duração:** ~16 s de cena + título; o jogador não perde nada se ficar parado.
- **Enquadramento:** plano aberto do quarto inteiro (448×256, no meio da tela de 640×360) com o calor do fogão da sala aparecendo na borda direita, pelo vão da porta; bordas escuras em vinheta. **Câmera:** deriva lenta de 14 px na horizontal e 5 px na vertical em 18 s (curva senoidal), sem zoom (zoom fracionário faz o pixel art tremer).
- **Luz:** fria e natural; o feixe da janela balança ±2% de intensidade; poeira (9 pontos) cai devagar dentro do feixe. **Cortina:** deslocamento senoidal de ~4 px.
- **Paleta:** azuis-acinzentados, marrons dessaturados; único calor: o amarelo apagado da foto.
- **Sons:** entra só *room tone* (muito baixo) + o vento da fresta, **abafado** (filtro passa-baixa a 900 Hz); em ~3 s um estalo de madeira; nenhuma música.
- **Título (~9 s):** “CAPÍTULO I” (pequeno) e “PRÓLOGO” (maior), no canto inferior esquerdo, fade-in de 2,2 s e 2,8 s, permanece ~3 s e some em 2,2 s. Sem animação adicional.
- **Fim:** som de tecido; o jogador assume o controle; objetivo discreto no canto superior esquerdo: “Prepare-se para sair.”

## CENA 3 — A porta (transição sonora e visual)
Ao escolher “Sair”: rangido de porta; o ambiente da **cidade** começa a subir em 5 s *antes* da imagem mudar; o filtro de abafamento “abre” em 4 s (o som de dentro se revela som de fora); o fade vai para **luz fria e pálida** (#b9c6d8), não para preto; a cena nova clareia em 2,8 s.

## CENA 6 — A última imagem
Depois de “Mas amanhã eu volto. Pra ver.”: o vento cai para –18 dB em 6 s; a câmera sobe 34 px em 9 s; aos 2,5 s um raio baixo de sol aparece sobre a terra (único calor da imagem); aos 5,5 s entra **uma única nota** de piano (ré), sem melodia; ~7 s de silêncio quase total; fade para o cartão **FIM DO PRÓLOGO**. O jogo salva e volta ao menu (agora com CONTINUAR habilitado).

### Sobre a fala final
Sua versão (“Não sei se vai crescer.” / pausa / “Mas acho que posso esperar.”) é boa, mas “esperar” é passivo. Usei **“Mas amanhã eu volto. Pra ver.”**: continua humilde e incerta, e ainda transforma o tema (“continuar tentando”) numa ação concreta e minúscula, que também abre o Capítulo II. Se preferir a sua, troque o texto do nó `n2` de `plant_end` em `data/dialogue/prologue_garden.json`.

---
