# Sunflower of Tomorrow — Demo v0.1 (alterações)

## O que mudou em relação ao projeto original
- **Tela de FIM DA DEMO** (`scripts/ui/demo_end.gd`): aparece depois do cartão "FIM DO CAPÍTULO I". Mostra agradecimento, tempo jogado e volta ao menu. Se você preencher o link do formulário, aparece também o botão "ABRIR FORMULÁRIO DE FEEDBACK".
- **Rótulo "DEMO v0.1"** no canto do menu principal e **versão gravada nos saves** (`game_version`). Para lançar a próxima demo, mude só `VERSION` em `scripts/core/demo_info.gd`.
- **Atalho F10 só funciona em build de depuração** (F5 no editor). Na demo exportada (release) ele não existe.
- **Dica de controles** (aparece uma vez, quando o jogador assume o controle no prólogo) e lembrete dos controles no menu de pausa.
- **Correção de texto no Capítulo I**: 203 frases estavam coladas sem espaço ("Bem-vindo!Isso aqui…") e 26 falas mostravam o nome do personagem dentro do texto ("Helena:Aquela mulher…"). A causa estava em `tools/roteiro_cap1/dsl.py` (a tag de pausa `{w=...}` engolia o espaço). Corrigido na origem; os JSON foram regenerados com `python tools/gerar_dialogos_cap1.py`.
- `export_presets.cfg` com o preset "Windows Desktop" (um único .exe) e um preset "Linux Teste" usado só para validar a exportação.
- `tests/smoke.tscn`: teste de fumaça (diálogos, todas as fases, salvar/carregar, tela de fim). Rodar: `godot --headless --path . res://tests/smoke.tscn`.

## Para colocar o link de feedback
Edite `FEEDBACK_URL` em `scripts/core/demo_info.gd` (ex.: link do Google Forms) e exporte de novo.

## Para exportar
Projeto → Exportar → "Windows Desktop" → Exportar projeto. (Precisa dos export templates da Godot 4.3 instalados: Editor → Gerenciar templates de exportação.)

## O que ainda NÃO foi feito
- Troca dos áudios placeholder (passos, portas, vento, ambientes) por sons reais com licença livre.
- O mapa novo da cidade (a imagem que você mostrou) não estava no zip enviado, então não está nesta versão.

## Ícone do jogo
- `icon.ico` (16 a 256 px) é o ícone do `.exe`; `icon.png` é o ícone da janela e da barra de tarefas (`config/icon` no project.godot). Os dois vêm da imagem do girassol.
- Para o preset "Windows Desktop" gravar o ícone no .exe, a Godot precisa do **rcedit**: Editor > Configurações do Editor > Exportar > Windows > Rcedit -> `tools/rcedit/rcedit-x64.exe`. Sem isso, a exportação reclama; se não quiser o ícone no .exe, desmarque "Modify Resources" no preset.

## Controles de toque (celular / tablet)
- `scripts/ui/touch_controls.gd` (autoload **TouchControls**): joystick flutuante na metade esquerda da tela, botão **E** (interagir), **CORRER** (liga/desliga) e **pausa** (II) à direita. Eles enviam as mesmas ações do teclado (`move_*`, `interact`, `run`, `ui_cancel`), então nenhuma fase foi alterada.
- Aparecem só durante o jogo (não no menu principal) e somem em cutscenes, pausa, fim de demo e **diálogos** (nos diálogos, tocar em qualquer lugar avança o texto).
- Em celular/web mobile ficam ligados desde o início. No PC ligam no primeiro toque na tela e desligam quando se usa teclado ou controle.
- A dica de controles e o menu de pausa mostram o texto certo para toque.
- Menus, painéis e escolhas de diálogo já eram botões comuns e respondem a toque.
- `display/window/handheld/orientation=0` (horizontal) no project.godot, para Android/iOS.
- Testes: `tests/touch_test.tscn` (toques simulados: joystick, E, correr, pausa, diálogo) e `tests/shots.tscn` (capturas de tela).
- Correção no diálogo: o clique que nasce do mesmo toque que abriu uma conversa é ignorado por 180 ms (evitava pular a primeira fala).

## Versão Web (roda no navegador do celular)
- Preset "Web" já configurado (sem threads, não precisa de cabeçalhos especiais). Exportar: Projeto → Exportar → Web → Exportar projeto → `index.html`.
- Para publicar: itch.io (enviar o .zip da pasta como "HTML", marcar "Playable in browser" e "Mobile friendly") ou qualquer hospedagem com HTTPS.
- Teste local no celular: na pasta da exportação rode `python -m http.server 8000` e abra `http://IP-DO-SEU-PC:8000` no celular (mesmo Wi-Fi).
- Se o celular estiver em pé, aparece o aviso "Gire o celular".
- Foi exportada e inspecionada aqui, mas **não foi aberta em um navegador de verdade**. Teste no seu celular antes de divulgar.

## Android (APK) — não gerado aqui
Precisa do Android SDK no seu PC. Resumo (documentação da Godot 4.3, "Exporting for Android"):
1. Instale o JDK 17 e o Android Studio (SDK Platform-Tools, Build-Tools 34, Platform 34, Cmdline-tools).
2. Godot: Editor → Configurações do Editor → Exportar → Android: caminho do SDK, do JDK e do keystore de debug (`keytool -genkeypair ...`).
3. Projeto → Exportar → Adicionar → Android; marque "Export with Debug" desligado para release e use um keystore de release.
4. Exporte o APK e mande por link ou instale com `adb install`.

## Correção (v2): cenas que esperam o botão E
- No prólogo (jardim, ao plantar) o jogo espera você apertar E com o personagem sem controle, e os botões de toque sumiam. Agora, nessas esperas, o botão **E** aparece (e um toque em qualquer lugar da tela também vale). Implementado com o grupo `touch_wait_press` em `LevelBase.wait_press()`.
- Teste novo em `tests/touch_test.tscn`: joga a sequência inteira de plantar só com toques.

## Tela cheia no celular (v3)
- No celular (e no navegador do celular) o jogo agora **preenche a tela inteira**: a altura do jogo fica em 360 e a largura cresce para acompanhar a proporção da tela (ex.: 780×360 num celular 19,5:9), sem faixas pretas. A escala de pixels também passa a ser "Ajustada" por padrão no celular.
- Em Configurações há a opção nova **"Preencher a tela"** (Manter 16:9 com bordas / Preencher a tela). No PC o padrão continua "Manter 16:9", então nada muda por lá.
- Tablets 4:3 e telas mais estreitas que 16:9 continuam com bordas em cima e embaixo (o jogo não mostra mais cenário na vertical).
- Os botões de toque e o texto de objetivo respeitam a **área segura** (entalhe da câmera e cantos arredondados) via `DisplayServer.get_display_safe_area()`. Isso não pôde ser testado em celular real.
- Código: `GameSettings.fill_screen`, `_apply_aspect()`, `safe_insets()`, `is_mobile_device()`. Testes visuais: `tests/shots_fit.tscn`.
