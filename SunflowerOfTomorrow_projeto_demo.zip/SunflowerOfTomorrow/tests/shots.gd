extends Node
## Tira capturas das telas novas (precisa de janela/OpenGL):  godot --path . res://tests/shots.tscn
const DemoEnd := preload("res://scripts/ui/demo_end.gd")
const ControlsHint := preload("res://scripts/ui/controls_hint.gd")
const OUT := "/tmp/shots/"


func shot(name: String) -> void:
    await RenderingServer.frame_post_draw
    var img := get_viewport().get_texture().get_image()
    img.save_png(OUT + name + ".png")
    print("captura ", name, " ", img.get_size())


func wait(s: float) -> void:
    await get_tree().create_timer(s).timeout


func _ready() -> void:
    await wait(0.5)
    # 1) menu principal
    GameState.new_game(1)
    var menu: Node = load("res://scenes/main_menu/main_menu.tscn").instantiate()
    add_child(menu)
    await wait(8.0)
    await shot("1_menu")
    menu.queue_free()
    await wait(0.5)
    # 2) fase com a dica de controles e depois a pausa
    GameState.new_game(1)
    GameState.set_flag("prologue_done", true)
    GameState.set_flag("planted", true)
    GameState.start_chapter1()
    GameState.set_flag("c1_intro_done", true)
    var lvl: Node = load("res://scenes/house/house.tscn").instantiate()
    add_child(lvl)
    await wait(3.0)
    GameState.flags.erase("seen_controls")
    ControlsHint.show_once(lvl, 20.0)
    await wait(2.6)
    await shot("2_dica_controles")
    lvl._pause.open()
    await wait(0.8)
    await shot("3_pausa")
    lvl._pause.close()
    lvl.queue_free()
    await wait(0.5)
    # 3) fim de demo (sem e com link de feedback)
    GameState.playtime = 3725.0
    var fin := [false]
    var run := func():
        await DemoEnd.show_panel(self)
        fin[0] = true
    run.call()
    await wait(2.4)
    await shot("4_fim_demo")
    print("FIM DAS CAPTURAS")
    get_tree().quit()
