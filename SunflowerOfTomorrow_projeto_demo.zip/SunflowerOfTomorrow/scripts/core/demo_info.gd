extends RefCounted
## Informações da versão DEMO (apenas constantes). Uso: const DemoInfo := preload("res://scripts/core/demo_info.gd")
## Para lançar uma nova versão da demo, mude só VERSION aqui.

const VERSION := "0.1"
const LABEL := "DEMO v" + VERSION

## Cole aqui o link do seu formulário de feedback (Google Forms etc.). Vazio = o botão não aparece na tela de fim de demo.
const FEEDBACK_URL := ""

const CONTROLS_TEXT := "WASD / setas  ·  mover        Shift  ·  correr\nE / Espaço / Enter  ·  interagir e avançar texto        Esc  ·  pausa"
