extends CanvasLayer
## Menu de pausa (Esc / botão B). O jogo fica CONGELADO enquanto aberto (get_tree().paused), então o personagem não anda,
## timers e animações do cenário param, e ao continuar tudo segue exatamente de onde estava.
##   CONTINUAR · CONFIGURAÇÕES (as mesmas do menu principal, aplicadas na hora) · VOLTAR AO MENU PRINCIPAL · SAIR DO JOGO
## Voltar ao menu / sair pedem confirmação quando há progresso não salvo (GameState.dirty): salvar e sair, sair sem salvar ou cancelar.
## Esc fecha o menu; dentro de Configurações ou de uma confirmação, Esc só volta um passo.

const UITheme := preload("res://scripts/ui/ui_theme.gd")
const MenuList := preload("res://scripts/ui/menu_list.gd")
const SettingsPanel := preload("res://scripts/main_menu/settings_panel.gd")
const ConfirmPanel := preload("res://scripts/main_menu/confirm_panel.gd")

var _root: Control
var _dim: ColorRect
var _panel: PanelContainer
var _list: Control
var _overlay: Control = null
var _busy := false


func _ready() -> void:
    layer = 60
    process_mode = Node.PROCESS_MODE_ALWAYS
    _root = Control.new()
    _root.set_anchors_preset(Control.PRESET_FULL_RECT)
    _root.visible = false
    add_child(_root)
    _dim = ColorRect.new()
    _dim.color = Color(0.015, 0.02, 0.04, 0.74)
    _dim.set_anchors_preset(Control.PRESET_FULL_RECT)
    _dim.mouse_filter = Control.MOUSE_FILTER_STOP
    _root.add_child(_dim)
    var center := CenterContainer.new()
    center.set_anchors_preset(Control.PRESET_FULL_RECT)
    _root.add_child(center)
    _panel = PanelContainer.new()
    _panel.add_theme_stylebox_override("panel", UITheme.box(Color(0.03, 0.04, 0.08, 0.93), UITheme.PANEL_BORDER, 1, 26, 16))
    center.add_child(_panel)
    var vb := VBoxContainer.new()
    vb.add_theme_constant_override("separation", 10)
    _panel.add_child(vb)
    vb.add_child(UITheme.label("PAUSA", 11, UITheme.GOLD))
    var items: Array = [
        {"id": "continue", "text": "CONTINUAR"},
        {"id": "settings", "text": "CONFIGURAÇÕES"},
        {"id": "menu", "text": "VOLTAR AO MENU PRINCIPAL"},
    ]
    if not OS.has_feature("web"):
        items.append({"id": "quit", "text": "SAIR DO JOGO"})
    _list = MenuList.new()
    vb.add_child(_list)
    _list.setup(items, 11, 18.0, 5.0, 210.0)
    _list.chosen.connect(_on_chosen)
    vb.add_child(UITheme.label("Esc  ·  continuar\nWASD / setas  ·  mover     Shift  ·  correr     E / Espaço  ·  interagir", 9, UITheme.MUTED))


func is_open() -> bool:
    return _root.visible


func open() -> void:
    if _root.visible or SceneRouter.is_busy():
        return
    _busy = false
    _root.visible = true
    get_tree().paused = true
    _dim.modulate.a = 0.0
    _panel.modulate.a = 0.0
    var t := create_tween().set_parallel(true)
    t.tween_property(_dim, "modulate:a", 1.0, 0.16)
    t.tween_property(_panel, "modulate:a", 1.0, 0.18)
    _list.set_active(true)
    _list.focus_first()
    AudioManager.play_sfx("ui_select", -10.0)


func close() -> void:
    _root.visible = false
    get_tree().paused = false


func _unhandled_input(event: InputEvent) -> void:
    if _root.visible and _overlay == null and not _busy and event.is_action_pressed("ui_cancel"):
        get_viewport().set_input_as_handled()
        AudioManager.play_sfx("ui_back", -8.0)
        close()


func _on_chosen(id: String) -> void:
    if _busy:
        return
    match id:
        "continue":
            close()
        "settings":
            _open_settings()
        "menu":
            _go_menu()
        "quit":
            _quit()


# ------------------------------------------------------------ configurações
func _open_settings() -> void:
    _list.set_active(false)
    var p := SettingsPanel.new()
    _overlay = p
    _root.add_child(p)
    p.closed.connect(_on_settings_closed.bind(p))


func _on_settings_closed(p: Control) -> void:
    p.queue_free()
    _overlay = null
    _list.set_active(true)
    _list.focus_id("settings")


# -------------------------------------------------------------- confirmações
## Mostra uma confirmação por cima do menu e devolve o índice da opção escolhida.
func _ask(text: String, labels: Array, default_index: int, cancel_index: int) -> int:
    _list.set_active(false)
    var p := ConfirmPanel.new()
    p.setup_options(text, labels, default_index, cancel_index)
    _overlay = p
    _root.add_child(p)
    var picked: int = await p.picked
    p.queue_free()
    _overlay = null
    _list.set_active(true)
    return picked


func _go_menu() -> void:
    if GameState.dirty:
        var i: int = await _ask("Há progresso que ainda não foi salvo.\nO que você quer fazer?", ["SALVAR E VOLTAR", "VOLTAR SEM SALVAR", "CANCELAR"], 0, 2)
        if i == 2:
            _list.focus_id("menu")
            return
        if i == 0:
            GameState.save_game()
    _busy = true
    GameState.playing = false
    _root.visible = false
    AudioManager.stop_ambience(1.5)
    SceneRouter.go(GameState.MENU_SCENE, 1.2, 0.3, 1.6)


func _quit() -> void:
    var i: int = 0
    if GameState.dirty:
        i = await _ask("Há progresso que ainda não foi salvo.\nSair do jogo mesmo assim?", ["SALVAR E SAIR", "SAIR SEM SALVAR", "CANCELAR"], 0, 2)
        if i == 2:
            _list.focus_id("quit")
            return
        if i == 0:
            GameState.save_game()
    else:
        i = await _ask("Sair do jogo?", ["SAIR", "CANCELAR"], 1, 1)
        if i == 1:
            _list.focus_id("quit")
            return
    _busy = true
    GameSettings.save_settings()
    get_tree().quit()
