extends RefCounted
## Dica de controles que aparece uma única vez (flag "seen_controls") quando o jogador assume o controle pela primeira vez.

const UITheme := preload("res://scripts/ui/ui_theme.gd")
const DemoInfo := preload("res://scripts/core/demo_info.gd")


static func show_once(host: Node, hold: float = 10.0) -> void:
    if GameState.get_flag("seen_controls", false):
        return
    GameState.set_flag("seen_controls", true)
    var cl := CanvasLayer.new()
    cl.layer = 15
    host.add_child(cl)
    var l := UITheme.label(DemoInfo.CONTROLS_TEXT, 10, Color(0.84, 0.86, 0.92, 0.9))
    l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    l.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
    l.offset_top = -34.0
    l.offset_bottom = -10.0
    l.modulate.a = 0.0
    cl.add_child(l)
    var t := host.create_tween()
    t.tween_property(l, "modulate:a", 1.0, 1.2)
    t.tween_interval(hold)
    t.tween_property(l, "modulate:a", 0.0, 1.6)
    t.tween_callback(cl.queue_free)
