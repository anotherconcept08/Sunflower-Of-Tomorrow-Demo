extends Control
## Space Travelers — o jogo fictício da Another Concept que Olivier joga na biblioteca.
## Demonstração curta (~1,5 a 3 min): nave, três vidas, drones, atiradores, sentinelas e o "Guardião MK-1".
## Campo virtual de 320x180, desenhado a 2x (640x360). Sprites em assets/minigame/ (tools/gerar_cap1.py minigame).
## Uso:   var game = SpaceTravelers.new(); camada.add_child(game); var res: Dictionary = await game.run()
## res = {"result": "win" | "lose" | "quit", "deaths": int, "score": int, "started": bool (false se saiu na tela de título)}
## Controles: setas/WASD movem, E/Espaço/Enter atiram (segurar atira sozinho), Esc encerra.

signal done

const VW := 320.0
const VH := 180.0
const S := 2.0
const T_SHIP := preload("res://assets/minigame/st_ship.png")
const T_DRONE := preload("res://assets/minigame/st_drone.png")
const T_SHOOTER := preload("res://assets/minigame/st_shooter.png")
const T_SENTINEL := preload("res://assets/minigame/st_sentinel.png")
const T_BOSS := preload("res://assets/minigame/st_boss.png")
const T_SHOT := preload("res://assets/minigame/st_shot.png")
const T_EBULLET := preload("res://assets/minigame/st_ebullet.png")
const T_HEART := preload("res://assets/minigame/st_heart.png")
const UITheme := preload("res://scripts/ui/ui_theme.gd")
const WAVE_END := 62.0          # segundos de ondas antes do chefe
const BOSS_HP := 70

var _state := "title"          # title | play | win | lose
var _t := 0.0                  # tempo de partida
var _grace := 0.6              # ignora teclas logo ao abrir (a tecla que fechou o diálogo)
var _result: Dictionary = {}

var _px := 160.0
var _py := 150.0
var _lives := 3
var _deaths := 0
var _score := 0
var _invuln := 0.0
var _shoot_cd := 0.0
var _flash := 0.0

var _shots: Array = []         # {x, y}
var _ebullets: Array = []      # {x, y, vx, vy}
var _enemies: Array = []       # {t, x, y, x0, hp, age, cd, cd2}
var _boom: Array = []          # {x, y, t}
var _stars: Array = []         # {x, y, v, b}
var _spawn_cd := 1.0
var _boss_spawned := false
var _boss_dead := false
var _boss_max := 1
var _end_t := 0.0

var _said: Dictionary = {}
var _comment := ""
var _comment_t := 0.0


func _ready() -> void:
    set_anchors_preset(Control.PRESET_FULL_RECT)
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
    for i in 46:
        _stars.append({"x": randf() * VW, "y": randf() * VH, "v": 8.0 + randf() * 40.0, "b": 0.3 + randf() * 0.7})


## Espera o fim da partida e devolve o resultado.
func run() -> Dictionary:
    await done
    return _result


# ------------------------------------------------------------------ laço
func _process(delta: float) -> void:
    _grace = maxf(0.0, _grace - delta)
    _comment_t = maxf(0.0, _comment_t - delta)
    _flash = maxf(0.0, _flash - delta)
    for st in _stars:
        st["y"] = float(st["y"]) + float(st["v"]) * delta
        if float(st["y"]) > VH:
            st["y"] = 0.0
            st["x"] = randf() * VW
    if _grace <= 0.0 and Input.is_action_just_pressed("ui_cancel"):
        _finish("quit")
        return
    match _state:
        "title":
            if _grace <= 0.0 and Input.is_action_just_pressed("interact"):
                _start_play()
        "play":
            _update_play(delta)
        "win", "lose":
            _end_t += delta
            if _end_t > 1.2 and Input.is_action_just_pressed("interact"):
                _finish(_state)
    queue_redraw()


func _finish(result: String) -> void:
    if not _result.is_empty():
        return
    _result = {"result": result, "deaths": _deaths, "score": _score, "started": _state != "title"}
    done.emit()


func _start_play() -> void:
    _state = "play"
    _t = 0.0
    AudioManager.play_sfx("game_start", -4.0)
    _say("start", "Esquerda. A outra esquerda.")


func _say(id: String, text: String) -> void:
    if _said.has(id):
        return
    _said[id] = true
    _comment = text
    _comment_t = 3.4


# ------------------------------------------------------------- partida
func _update_play(dt: float) -> void:
    _t += dt
    _invuln = maxf(0.0, _invuln - dt)
    _shoot_cd = maxf(0.0, _shoot_cd - dt)
    # nave
    var dir := Vector2(Input.get_axis("move_left", "move_right"), Input.get_axis("move_up", "move_down"))
    if dir.length() > 1.0:
        dir = dir.normalized()
    _px = clampf(_px + dir.x * 118.0 * dt, 9.0, VW - 9.0)
    _py = clampf(_py + dir.y * 100.0 * dt, 96.0, VH - 10.0)
    if Input.is_action_pressed("interact") and _shoot_cd <= 0.0:
        _shoot_cd = 0.15
        _shots.append({"x": _px, "y": _py - 8.0})
        AudioManager.play_sfx("game_shoot", -14.0, 1.0, 0.05)
    # tiros do jogador
    for s in _shots:
        s["y"] = float(s["y"]) - 230.0 * dt
    _shots = _shots.filter(func(s): return float(s["y"]) > -6.0)
    # inimigos
    _update_spawns(dt)
    for e in _enemies:
        _update_enemy(e, dt)
    _enemies = _enemies.filter(func(e): return float(e["y"]) < VH + 14.0 and int(e["hp"]) > 0)
    # tiros inimigos
    for b in _ebullets:
        b["x"] = float(b["x"]) + float(b["vx"]) * dt
        b["y"] = float(b["y"]) + float(b["vy"]) * dt
    _ebullets = _ebullets.filter(func(b): return float(b["y"]) < VH + 6.0 and float(b["y"]) > -8.0 and float(b["x"]) > -8.0 and float(b["x"]) < VW + 8.0)
    # colisões
    _hit_enemies()
    _hit_player()
    for x in _boom:
        x["t"] = float(x["t"]) + dt
    _boom = _boom.filter(func(x): return float(x["t"]) < 0.5)
    if _lives <= 0 and _state == "play":
        _state = "lose"
        _end_t = 0.0
        AudioManager.play_sfx("game_lose", -3.0)
    if _boss_dead and _state == "play":
        _state = "win"
        _end_t = 0.0
        _score += 500
        AudioManager.play_sfx("game_win", -3.0)


func _update_spawns(dt: float) -> void:
    if _boss_spawned:
        return
    if _t < WAVE_END:
        _spawn_cd -= dt
        if _spawn_cd <= 0.0:
            var kind := "drone"
            if _t > 18.0 and randf() < 0.35:
                kind = "shooter"
            if _t > 40.0 and randf() < 0.22:
                kind = "sentinel"
            if kind == "drone" and randf() < 0.3:
                var bx := randf_range(40.0, VW - 80.0)
                for i in 3:
                    _spawn_enemy("drone", bx + float(i) * 26.0, -8.0 - float(i) * 12.0)
            else:
                _spawn_enemy(kind, randf_range(24.0, VW - 24.0), -10.0)
            _spawn_cd = lerpf(1.3, 0.85, clampf(_t / WAVE_END, 0.0, 1.0))
    elif _enemies.is_empty() or _t > WAVE_END + 9.0:
        _spawn_boss()


func _spawn_enemy(kind: String, x: float, y: float) -> void:
    var hp := 1
    if kind == "shooter":
        hp = 2
        _say("shooter", "Esse atira de volta. Não fica parado.")
    elif kind == "sentinel":
        hp = 6
        _say("sentinel", "Esse aguenta mais. Insiste.")
    _enemies.append({"t": kind, "x": x, "y": y, "x0": x, "hp": hp, "age": 0.0, "cd": randf_range(0.8, 1.6), "cd2": 2.0})


func _spawn_boss() -> void:
    _boss_spawned = true
    _boss_max = BOSS_HP
    _enemies.append({"t": "boss", "x": VW * 0.5, "y": -24.0, "x0": VW * 0.5, "hp": BOSS_HP, "age": 0.0, "cd": 1.5, "cd2": 3.0})
    AudioManager.play_sfx("game_alert", -5.0)
    _say("boss", "Fogão com raiva. Eu avisei.")


func _update_enemy(e: Dictionary, dt: float) -> void:
    e["age"] = float(e["age"]) + dt
    var age: float = float(e["age"])
    match str(e["t"]):
        "drone":
            e["y"] = float(e["y"]) + 38.0 * dt
            e["x"] = float(e["x0"]) + sin(age * 2.4) * 30.0
        "shooter":
            if age < 7.0:
                e["y"] = minf(float(e["y"]) + 44.0 * dt, 34.0)
            else:
                e["y"] = float(e["y"]) + 34.0 * dt
            e["x"] = float(e["x0"]) + sin(age * 0.9) * 40.0
            e["cd"] = float(e["cd"]) - dt
            if float(e["cd"]) <= 0.0 and float(e["y"]) > 10.0:
                e["cd"] = 1.7
                _fire_at(float(e["x"]), float(e["y"]) + 4.0, 74.0, 0.0)
        "sentinel":
            if age < 9.0:
                e["y"] = minf(float(e["y"]) + 24.0 * dt, 30.0)
            else:
                e["y"] = float(e["y"]) + 30.0 * dt
            e["x"] = float(e["x0"]) + sin(age * 0.6) * 24.0
            e["cd"] = float(e["cd"]) - dt
            if float(e["cd"]) <= 0.0 and float(e["y"]) > 10.0:
                e["cd"] = 2.2
                for a in [-0.35, 0.0, 0.35]:
                    _fire_at(float(e["x"]), float(e["y"]) + 5.0, 66.0, a)
        "boss":
            var rage: bool = int(e["hp"]) * 2 < _boss_max
            if age < 3.0:
                e["y"] = minf(float(e["y"]) + 30.0 * dt, 36.0)
            else:
                var sp: float = 1.25 if rage else 0.85
                e["x"] = VW * 0.5 + sin((age - 3.0) * sp) * 108.0
            e["cd"] = float(e["cd"]) - dt
            e["cd2"] = float(e["cd2"]) - dt
            if age >= 3.0 and float(e["cd"]) <= 0.0:
                e["cd"] = 0.8 if rage else 1.15
                for a in [-0.5, -0.25, 0.0, 0.25, 0.5]:
                    _fire_at(float(e["x"]), float(e["y"]) + 10.0, 62.0, a, true)
            if age >= 3.0 and float(e["cd2"]) <= 0.0:
                e["cd2"] = 1.5 if rage else 2.4
                for a in [-0.12, 0.0, 0.12]:
                    _fire_at(float(e["x"]), float(e["y"]) + 10.0, 92.0, a)
    # inimigos que passam pelo fundo da tela não ficam para sempre
    if str(e["t"]) != "boss" and float(e["y"]) > VH + 12.0:
        e["hp"] = 0


## Tiro inimigo mirado na nave (desvio angular "spread" em radianos); "straight" ignora a mira e vai reto para baixo.
func _fire_at(x: float, y: float, speed: float, spread: float, straight: bool = false) -> void:
    var ang: float = PI * 0.5 + spread
    if not straight:
        ang = atan2(_py - y, _px - x) + spread
    _ebullets.append({"x": x, "y": y, "vx": cos(ang) * speed, "vy": sin(ang) * speed})


func _enemy_size(kind: String) -> Vector2:
    match kind:
        "drone":
            return T_DRONE.get_size()
        "shooter":
            return T_SHOOTER.get_size()
        "sentinel":
            return T_SENTINEL.get_size()
    return T_BOSS.get_size() * 2.0


func _hit_enemies() -> void:
    for s in _shots:
        for e in _enemies:
            if int(e["hp"]) <= 0 or float(e["y"]) < -4.0:
                continue
            var sz := _enemy_size(str(e["t"]))
            if absf(float(s["x"]) - float(e["x"])) < sz.x * 0.5 + 1.0 and absf(float(s["y"]) - float(e["y"])) < sz.y * 0.5 + 2.0:
                s["y"] = -100.0
                e["hp"] = int(e["hp"]) - 1
                AudioManager.play_sfx("game_hit", -12.0, 1.0, 0.06)
                if int(e["hp"]) <= 0:
                    _kill(e)
                break


func _kill(e: Dictionary) -> void:
    var kind := str(e["t"])
    var pts := 10
    if kind == "shooter":
        pts = 25
    elif kind == "sentinel":
        pts = 60
    _score += pts
    _boom.append({"x": float(e["x"]), "y": float(e["y"]), "t": 0.0})
    AudioManager.play_sfx("game_boom", -8.0, 1.0, 0.05)
    if kind == "boss":
        _boss_dead = true
        for i in 5:
            _boom.append({"x": float(e["x"]) + randf_range(-24.0, 24.0), "y": float(e["y"]) + randf_range(-8.0, 10.0), "t": -0.08 * float(i)})
    else:
        _say("kill", "Isso. Mais um assim.")


func _hit_player() -> void:
    if _invuln > 0.0 or _state != "play":
        return
    var hit := false
    for b in _ebullets:
        if absf(float(b["x"]) - _px) < 4.0 and absf(float(b["y"]) - _py) < 5.0:
            b["y"] = VH + 50.0
            hit = true
    for e in _enemies:
        if int(e["hp"]) <= 0 or float(e["y"]) < -2.0:
            continue
        var sz := _enemy_size(str(e["t"]))
        if absf(float(e["x"]) - _px) < sz.x * 0.5 + 4.0 and absf(float(e["y"]) - _py) < sz.y * 0.5 + 4.0:
            hit = true
    if hit:
        _lives -= 1
        _deaths += 1
        _invuln = 1.7
        _flash = 0.25
        _boom.append({"x": _px, "y": _py, "t": 0.0})
        AudioManager.play_sfx("game_hurt", -6.0)
        if _deaths == 1:
            _say("hurt", "Isso era um robô. Não um abraço.")
        elif _lives == 1:
            _say("last", "Uma vida só. Dramático.")


# ------------------------------------------------------------------ desenho
func _tex(t: Texture2D, cx: float, cy: float, k: float = 1.0, mod: Color = Color.WHITE) -> void:
    var sz: Vector2 = t.get_size() * k
    draw_texture_rect(t, Rect2(Vector2(roundf((cx - sz.x * 0.5) * S), roundf((cy - sz.y * 0.5) * S)), sz * S), false, mod)


func _text(s: String, x: float, y: float, size: int, col: Color) -> void:
    var f: Font = UITheme.font()
    if f == null:
        f = ThemeDB.fallback_font
    draw_string(f, Vector2(x, y), s, HORIZONTAL_ALIGNMENT_LEFT, -1, size, col)


func _text_c(s: String, y: float, size: int, col: Color) -> void:
    var f: Font = UITheme.font()
    if f == null:
        f = ThemeDB.fallback_font
    draw_string(f, Vector2(0, y), s, HORIZONTAL_ALIGNMENT_CENTER, VW * S, size, col)


func _draw() -> void:
    draw_rect(Rect2(0, 0, VW * S, VH * S), Color(0.03, 0.05, 0.14))
    for st in _stars:
        var b: float = float(st["b"])
        draw_rect(Rect2(floorf(float(st["x"])) * S, floorf(float(st["y"])) * S, S, S), Color(0.7 * b, 0.8 * b, 1.0 * b))
    if _state == "title":
        _draw_title()
    else:
        _draw_world()
    # CRT: linhas de varredura e cantos escuros
    for yy in range(0, int(VH * S), 2):
        draw_rect(Rect2(0, yy, VW * S, 1), Color(0, 0, 0, 0.16))
    draw_rect(Rect2(0, 0, VW * S, 10), Color(0, 0, 0, 0.30))
    draw_rect(Rect2(0, VH * S - 10, VW * S, 10), Color(0, 0, 0, 0.30))
    draw_rect(Rect2(0, 0, 10, VH * S), Color(0, 0, 0, 0.30))
    draw_rect(Rect2(VW * S - 10, 0, 10, VH * S), Color(0, 0, 0, 0.30))
    if _flash > 0.0:
        draw_rect(Rect2(0, 0, VW * S, VH * S), Color(1, 0.3, 0.3, _flash * 0.8))


func _draw_title() -> void:
    _text_c("ANOTHER CONCEPT  ·  1997", 70.0, 10, Color(0.55, 0.65, 0.85))
    _text_c("SPACE", 126.0, 36, Color(0.55, 0.75, 1.0))
    _text_c("TRAVELERS", 170.0, 36, Color(0.95, 0.95, 1.0))
    _tex(T_SHIP, VW * 0.5, 120.0, 2.0)
    var blink: float = 0.5 + 0.5 * sin(time_now() * 5.0)
    _text_c("PRESSIONE  E  PARA COMEÇAR", 292.0, 12, Color(0.95, 0.85, 0.5, 0.5 + 0.5 * blink))
    _text_c("SETAS / WASD mover   ·   E / ESPAÇO atirar   ·   ESC sair", 330.0, 9, Color(0.55, 0.62, 0.78))


func time_now() -> float:
    return float(Time.get_ticks_msec()) / 1000.0


func _draw_world() -> void:
    for e in _enemies:
        var kind := str(e["t"])
        var tex: Texture2D = T_DRONE
        var k := 1.0
        if kind == "shooter":
            tex = T_SHOOTER
        elif kind == "sentinel":
            tex = T_SENTINEL
        elif kind == "boss":
            tex = T_BOSS
            k = 2.0
        _tex(tex, float(e["x"]), float(e["y"]), k)
    for s in _shots:
        _tex(T_SHOT, float(s["x"]), float(s["y"]))
    for b in _ebullets:
        _tex(T_EBULLET, float(b["x"]), float(b["y"]))
    if _state != "lose":
        var vis := true
        if _invuln > 0.0:
            vis = int(_t * 14.0) % 2 == 0
        if vis:
            _tex(T_SHIP, _px, _py)
            var fl: float = 2.0 + 2.0 * sin(_t * 40.0)
            draw_rect(Rect2(roundf((_px - 1.0) * S), roundf((_py + 5.0) * S), S * 2.0, S * fl), Color(1.0, 0.7, 0.25))
    for x in _boom:
        var tt: float = float(x["t"])
        if tt < 0.0:
            continue
        var r: float = tt * 60.0
        for i in 8:
            var a: float = float(i) * TAU / 8.0
            draw_rect(Rect2(roundf((float(x["x"]) + cos(a) * r) * S), roundf((float(x["y"]) + sin(a) * r) * S), S * 2.0, S * 2.0), Color(1.0, 0.75 - tt, 0.3, 1.0 - tt * 2.0))
    # HUD
    for i in _lives:
        _tex(T_HEART, 8.0 + float(i) * 9.0, 8.0)
    _text("%06d" % _score, VW * S - 90.0, 20.0, 12, Color(0.9, 0.92, 1.0))
    if _boss_spawned:
        var hp := 0
        for e in _enemies:
            if str(e["t"]) == "boss":
                hp = int(e["hp"])
        draw_rect(Rect2(110.0 * S, 5.0 * S, 100.0 * S, 4.0 * S), Color(0.1, 0.1, 0.15))
        draw_rect(Rect2(110.0 * S, 5.0 * S, 100.0 * S * float(hp) / float(_boss_max), 4.0 * S), Color(0.9, 0.3, 0.3))
        draw_rect(Rect2(110.0 * S, 5.0 * S, 100.0 * S, 1.0), Color(0.8, 0.8, 0.9))
    # comentário do Olivier (rodapé)
    if _comment_t > 0.0 and _state == "play":
        var a: float = clampf(_comment_t, 0.0, 0.6) / 0.6
        draw_rect(Rect2(40.0, VH * S - 34.0, VW * S - 80.0, 22.0), Color(0.02, 0.03, 0.08, 0.78 * a))
        _text("OLIVIER:", 50.0, VH * S - 19.0, 10, Color(0.95, 0.6, 0.3, a))
        _text(_comment, 112.0, VH * S - 19.0, 10, Color(0.93, 0.9, 0.82, a))
    if _state == "win":
        _text_c("FASE 1 COMPLETA", 150.0, 26, Color(0.6, 0.95, 0.7))
        _text_c("PONTOS  %06d" % _score, 190.0, 14, Color(0.9, 0.92, 1.0))
        if _end_t > 1.2:
            _text_c("E  para voltar à biblioteca", 250.0, 11, Color(0.95, 0.85, 0.5))
    elif _state == "lose":
        _text_c("GAME OVER", 150.0, 30, Color(1.0, 0.45, 0.4))
        _text_c("PONTOS  %06d" % _score, 190.0, 14, Color(0.9, 0.92, 1.0))
        if _end_t > 1.2:
            _text_c("E  para voltar à biblioteca", 250.0, 11, Color(0.95, 0.85, 0.5))
