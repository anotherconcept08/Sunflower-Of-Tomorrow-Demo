# Sunflower of Tomorrow — Demo v0.1 (alterações)

## O que mudou em relação ao projeto original
- **Tela de FIM DA DEMO** (`scripts/ui/demo_end.gd`): aparece depois do cartão "FIM DO CAPÍTULO I". Mostra agradecimento, tempo jogado e volta ao menu. Se você preencher o link do formulário, aparece também o botão "ABRIR FORMULÁRIO DE FEEDBACK".
- **Rótulo "DEMO v0.1"** no canto do menu principal e **versão gravada nos saves** (`game_version`). Para lançar a próxima demo, mude só `VERSION` em `scripts/core/demo_info.gd`.
- **Atalho F10 só funciona em build de depuração** (F5 no editor). Na demo exportada (release) ele não existe.
- **Dica de controles** (aparece uma vez, quando o jogador assume o controle no prólogo) e lembrete dos controles no menu de pausa.
- **Correção de texto no Capítulo I**: 203 frases estavam coladas sem espaço ("Bem-vindo!Isso aqui…") e 26 falas mostravam o nome do personagem dentro do texto ("Helena:Aquela mulher…"). A causa estava em `tools/roteiro_cap1/dsl.py` (a tag de pausa `{w=...}` engolia o espaço). Corrigido na origem; os JSON foram regenerados com `python tools/gerar_dialogos_cap1.py`.
- `export_presets.cfg` com o preset "Windows Desktop" (um único .exe) e um preset "Linux Teste" usado só para validar a exportação.
- `tests/smoke.tscn`: teste de fumaça (diálogos, todas as fases, salvar/carregar, tela de fim). Rodar: `godot --headless --path . res://tests/smoke.tscn`.

## Para colocar o link de feedback
Edite `FEEDBACK_URL` em `scripts/core/demo_info.gd` (ex.: link do Google Forms) e exporte de novo.

## Para exportar
Projeto → Exportar → "Windows Desktop" → Exportar projeto. (Precisa dos export templates da Godot 4.3 instalados: Editor → Gerenciar templates de exportação.)

## O que ainda NÃO foi feito
- Troca dos áudios placeholder (passos, portas, vento, ambientes) por sons reais com licença livre.
- O mapa novo da cidade (a imagem que você mostrou) não estava no zip enviado, então não está nesta versão.

## Ícone do jogo
- `icon.ico` (16 a 256 px) é o ícone do `.exe`; `icon.png` é o ícone da janela e da barra de tarefas (`config/icon` no project.godot). Os dois vêm da imagem do girassol.
- Para o preset "Windows Desktop" gravar o ícone no .exe, a Godot precisa do **rcedit**: Editor > Configurações do Editor > Exportar > Windows > Rcedit -> `tools/rcedit/rcedit-x64.exe`. Sem isso, a exportação reclama; se não quiser o ícone no .exe, desmarque "Modify Resources" no preset.
